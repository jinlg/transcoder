
file description:
	common.h:  common header file, internal use

	trans_core.h : will share this header file to app
	trans_core.c : main file, register/release driver, and mange submodules.
	
	trans_edma.h : 
	trans_edma.c : edma function
	
	trans_mem.h :
	trans_mem.c : memory mangement 
	
	trans_pci.h :
	trans_pci.c : initialize pcie and msi-x
	