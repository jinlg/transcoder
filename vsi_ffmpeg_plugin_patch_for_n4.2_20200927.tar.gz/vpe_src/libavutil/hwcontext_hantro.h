#ifndef AVUTIL_HWCONTEXT_HANTRO_H
#define AVUTIL_HWCONTEXT_HANTRO_H


typedef struct AVHANTRODeviceContextInternal {

    char * device;
    unsigned int dec_client_type;
    unsigned int enc_client_type;

    int fd_trans;
    int priority;
    int task_id;


} AVHANTRODeviceContextInternal;

typedef struct AVHANTRODeviceContext {

    char * device;
    unsigned int dec_client_type;
    unsigned int enc_client_type;

    int max_frames_delay;

    int priority;
    int fbloglevel;

    // for multi-task test fps report
    int task_idx;
    char * ser_ip;
    int ser_port;
    void * net_sender_handle;

    AVHANTRODeviceContextInternal * internal;

} AVHANTRODeviceContext;

typedef enum AVHANTROFormat {
    AVHANTRO_FORMAT_YUV420_SEMIPLANAR,
    AVHANTRO_FORMAT_YUV420_SEMIPLANAR_VU,
    AVHANTRO_FORMAT_YUV420_SEMIPLANAR_YUV420P,
    AVHANTRO_FORMAT_YUV420_PLANAR_10BIT_P010,
} AVHANTROFormat;

typedef struct AVHANTROFramesContext {
    int task_id;
    
    struct {
        int enabled;
        int flag;
        AVHANTROFormat format;
        int width;
        int height;
        int pic_width;
        int pic_height;
        struct {
            int enabled;
            int x;
            int y;
            int w;
            int h;
        } crop;
        struct {
            int enabled;
            int w;
            int h;
        } scale;

        /* add for get init param*/
        struct {
            unsigned int is_interlaced;
            unsigned int pic_stride;
            unsigned int crop_out_width;
            unsigned int crop_out_height;
            unsigned int pic_format;
            unsigned int pic_pixformat;
            unsigned int bit_depth_luma;
            unsigned int bit_depth_chroma;
            unsigned int pic_compressed_status;
        } picdata;
    } pic_info[5];

    void * opaque;
    void * opaque_upload;
    pthread_mutex_t opaque_mutex;
} AVHANTROFramesContext;


#endif /* AVUTIL_HWCONTEXT_HANTRO_H */


