
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <fcntl.h>
#include <sys/ioctl.h>

#include "pixfmt.h"
#include "pixdesc.h"
#include "hwcontext.h"
#include "hwcontext_internal.h"
#include "hwcontext_hantro.h"
#include "libavutil/opt.h"

#include  "trans_mem_api.h"

#ifndef HANTRO_CMODEL
#include "transcoder.h"
#endif
#ifdef FB_SYSLOG_ENABLE
#include "syslog_sink.h"
#endif
#include "trans_fd_api.h"
#include "NetSender.h"

#define MAX_LINEAR_MEM_COUNT 20

typedef struct HANTROFramesContext {
    int fd_mem;
    int task_id;
} HANTROFramesContext;

typedef struct HANTRODeviceContext {
} HANTRODeviceContext;


static const enum AVPixelFormat supported_formats[] = {
    AV_PIX_FMT_HANTRO,
    AV_PIX_FMT_NV12,
    AV_PIX_FMT_P010LE,
};

static void hantro_frames_uninit(AVHWFramesContext *hwfc);


static int hantro_frames_get_constraints(AVHWDeviceContext *ctx,
                                       const void *hwconfig,
                                       AVHWFramesConstraints *constraints)
{
	av_log(ctx, AV_LOG_TRACE, "%s(%d)\n", __FUNCTION__, __LINE__);
    
    constraints->valid_hw_formats = av_malloc_array(2, sizeof(*constraints->valid_hw_formats));
    if (!constraints->valid_hw_formats)
        return AVERROR(ENOMEM);

    constraints->valid_hw_formats[0] = AV_PIX_FMT_HANTRO;
    constraints->valid_hw_formats[1] = AV_PIX_FMT_NONE;

    constraints->min_width = 144;
    constraints->min_height = 144;
    constraints->max_width = 4096;
    constraints->max_height = 4096;
    
    return 0;
}

static int hantro_transfer_get_formats(AVHWFramesContext *ctx,
                                     enum AVHWFrameTransferDirection dir,
                                     enum AVPixelFormat **formats)
{
	av_log(ctx, AV_LOG_TRACE, "%s(%d)\n", __FUNCTION__, __LINE__);
    return 0;
}

static void hantro_buffer_free(void *opaque, uint8_t * data)
{
	av_log(NULL, AV_LOG_TRACE, "%s(%d)\n", __FUNCTION__, __LINE__);
    return;
}

static AVBufferRef *hantro_pool_alloc(void *opaque, int size)
{
	av_log(NULL, AV_LOG_TRACE, "%s(%d)\n", __FUNCTION__, __LINE__);
  	return NULL;
}

static void hantro_pool_free(void *opaque)
{
	av_log(NULL, AV_LOG_TRACE, "%s(%d)\n", __FUNCTION__, __LINE__);
}

static int hantro_frames_init(AVHWFramesContext *hwfc)
{
    HANTROFramesContext *priv = hwfc->internal->priv;
    AVHANTRODeviceContext * hwctx;
    AVHANTROFramesContext * fmctx = hwfc->hwctx;
    int i;
    
	av_log(hwfc, AV_LOG_TRACE, "%s\n", __FUNCTION__);

    for (i = 0; i < FF_ARRAY_ELEMS(supported_formats); i++) {
        if (hwfc->format == supported_formats[i])
            break;
    }
    if (i == FF_ARRAY_ELEMS(supported_formats)) {
        av_log(hwfc, AV_LOG_ERROR, "Pixel format '%s' is not supported\n",
               av_get_pix_fmt_name(hwfc->sw_format));
        return AVERROR(ENOSYS);
    }

    av_log(hwfc, AV_LOG_TRACE, "%s(%d) hwfc->device_ref = %p\n", __FUNCTION__, __LINE__, hwfc->device_ref);

    hwfc->device_ctx = hwfc->device_ref->data;
    
    av_log(hwfc, AV_LOG_TRACE, "%s(%d) hwfc->device_ctx = %p\n", __FUNCTION__, __LINE__, hwfc->device_ctx);

    hwctx = hwfc->device_ctx->hwctx;
    
    av_log(hwfc, AV_LOG_TRACE, "%s(%d) hwctx = %p\n", __FUNCTION__, __LINE__, hwctx);

    priv->fd_mem = hwctx->internal->fd_trans;
    priv->task_id = hwctx->internal->task_id;
    av_log(hwfc, AV_LOG_DEBUG, "%s(%d) fd_mem %d task id %d\n", __FUNCTION__, __LINE__, priv->fd_mem, priv->task_id);

    fmctx->task_id = priv->task_id;

    hwfc->pool = av_buffer_pool_init(0, NULL);

    
    pthread_mutex_init(&fmctx->opaque_mutex, NULL);


    return 0;
error_exit:
    hantro_frames_uninit(hwfc);
    return -1;

}

static void hantro_frames_uninit(AVHWFramesContext *hwfc)
{
    HANTROFramesContext *priv = hwfc->internal->priv;
    AVHANTRODeviceContext * hwctx = hwfc->device_ctx->hwctx;
    AVHANTROFramesContext * fmctx = hwfc->hwctx;
    
	av_log(hwfc, AV_LOG_TRACE, "%s(%d)\n", __FUNCTION__, __LINE__);

    av_buffer_pool_uninit(&hwfc->pool);

    pthread_mutex_destroy(&fmctx->opaque_mutex);

    priv->task_id = 0;
    priv->fd_mem = -1;
}

static int hantro_get_buffer(AVHWFramesContext *hwfc, AVFrame *frame)
{
	av_log(hwfc, AV_LOG_TRACE, "%s(%d)\n", __FUNCTION__, __LINE__);
    return 0;
}

static int hantro_frames_derive_from(AVHWFramesContext *dst_ctx,
                                  AVHWFramesContext *src_ctx, int flags)
{
    AVHANTROFramesContext *src_hwctx = src_ctx->hwctx;
    AVHANTROFramesContext *dst_hwctx = dst_ctx->hwctx;
    int i;

    if (dst_ctx->device_ctx->type != AV_HWDEVICE_TYPE_HANTRO)
        return AVERROR(ENOSYS);

    dst_ctx->format = src_ctx->format;
    dst_ctx->sw_format = src_ctx->sw_format;
    dst_ctx->width = src_ctx->width;
    dst_ctx->height = src_ctx->height;

    memcpy(dst_hwctx, src_hwctx, sizeof(AVHANTROFramesContext));
                
    return 0;
}

static void hantro_device_uninit(AVHWDeviceContext *device_ctx)
{
    AVHANTRODeviceContext *hwctx = device_ctx->hwctx;
    AVHANTRODeviceContextInternal * hwl = hwctx->internal;;
    
	av_log(device_ctx, AV_LOG_TRACE, "%s(%d)\n", __FUNCTION__, __LINE__);

#ifdef CHECK_MEM_LEAK_TRANS
        TransCheckMemLeakGotResult();
#endif

#ifdef FB_SYSLOG_ENABLE
    close_syslog_module();
#endif

    net_sender_uninit(hwctx->net_sender_handle);

    if (!hwl)
        return;

    if (hwl->fd_trans && hwl->fd_trans != -1) {
#ifndef HANTRO_CMODEL
        if (hwl->task_id > 0) {
            if (ioctl(hwl->fd_trans, CB_TRANX_MEM_FREE_TASKID, &hwl->task_id) < 0) {
                av_log(device_ctx, AV_LOG_ERROR, "free task id failed!\n");
            }
        }

        TranscodeCloseFD(hwl->fd_trans);
#endif
    }
    
    av_freep(&hwctx->internal);
    
    av_freep(&hwctx->ser_ip);
    av_freep(&hwctx->device);
}

static int hantro_device_init(AVHWDeviceContext *device_ctx)
{
    AVHANTRODeviceContext * hwctx = device_ctx->hwctx;
    int ret = -1;
    AVHANTRODeviceContextInternal * hwl;
    
	av_log(device_ctx, AV_LOG_TRACE, "%s(%d)\n", __FUNCTION__, __LINE__);
    
	if (!hwctx->internal) {
        hwctx->internal = av_mallocz(sizeof(*hwctx->internal));
        if (!hwctx->internal)
            return AVERROR(ENOMEM);
    }
    hwl = hwctx->internal;
    
    hwl->priority = hwctx->priority;
    hwl->device = hwctx->device;
    
#ifdef FB_SYSLOG_ENABLE
    av_log(device_ctx, AV_LOG_TRACE, "fbloglevel %d\n", hwctx->fbloglevel);
    init_syslog_module("ffmpeg", hwctx->fbloglevel);
#endif

#ifdef CHECK_MEM_LEAK_TRANS
    TransCheckMemLeakInit();
#endif

    av_log(device_ctx, AV_LOG_TRACE, "hwl->device = %s\n", hwl->device);

#ifndef HANTRO_CMODEL
    hwl->fd_trans = TranscodeOpenFD(hwctx->device, O_RDWR);
    if (hwl->fd_trans == -1) {
        av_log(device_ctx, AV_LOG_ERROR, "failed to open device: %s\n", hwctx->device);
        goto error_exit;
    }
#endif
    av_log(device_ctx, AV_LOG_DEBUG, "%s(%d) device fd %d\n", __FUNCTION__, __LINE__, hwl->fd_trans);

#ifndef HANTRO_CMODEL
    if (ioctl(hwl->fd_trans, CB_TRANX_MEM_GET_TASKID, &hwl->task_id) < 0) {
        av_log(device_ctx, AV_LOG_ERROR, "get task id failed!\n");
        goto error_exit;
    }
#endif
    av_log(device_ctx, AV_LOG_DEBUG, "%s(%d) get task id %d\n", __FUNCTION__, __LINE__, hwl->task_id);
    
#if 1
    if ((hwctx->ser_ip) && (hwctx->ser_port != 0)) {
        av_log(device_ctx, AV_LOG_DEBUG, "ser_ip:%s, ser_port:%d, task_idx:%d\n", hwctx->ser_ip, hwctx->ser_port, hwctx->task_idx);
        hwctx->net_sender_handle = net_sender_init((const char *)hwctx->ser_ip, hwctx->ser_port, get_deviceId(hwctx->device), hwctx->task_idx);
        if (!hwctx->net_sender_handle) {
            av_log(device_ctx, AV_LOG_ERROR, "net_sender_handle is NULL\n");
            goto error_exit;
        }
        av_log(device_ctx, AV_LOG_DEBUG, "net_sender_handle init success! hwctx = %p, hwctx->net_sender_handle = %p\n", hwctx, hwctx->net_sender_handle);
    }
#endif

  	return 0;
    
error_exit:
    hantro_device_uninit(device_ctx);
    
    return ret;
}

static int hantro_device_create(AVHWDeviceContext *device_ctx, const char *device,
                              AVDictionary *opts, int flags)
{
  	AVHANTRODeviceContext *hwctx = device_ctx->hwctx;
	AVDictionaryEntry * opt;
    
	av_log(device_ctx, AV_LOG_TRACE, "%s(%d) hwctx = %p\n", __FUNCTION__, __LINE__, hwctx);

  	if (device) {
        av_log(device_ctx, AV_LOG_TRACE, "device(%s)\n", device);
    } else {
        av_log(device_ctx, AV_LOG_ERROR, "device error\n");
        goto error_exit;
    }

    hwctx->priority = TASK_VOD;
    hwctx->fbloglevel = SYSLOG_SINK_LEV_STAT;
        
    if (opts) {
		opt = av_dict_get(opts, "priority", NULL, 0);
		if (!opt) {
			hwctx->priority = TASK_VOD;
        } else {
    		av_log(device_ctx, AV_LOG_TRACE, "%s(%s)\n", opt->key, opt->value);
    		if (!strcmp(opt->value, "live")) {
    			hwctx->priority = TASK_LIVE;
    		} else if (!strcmp(opt->value, "vod")) {
    			hwctx->priority = TASK_VOD;
            } else {
                av_log(device_ctx, AV_LOG_ERROR, "Unknow priority : %s\n", opt->value);
                goto error_exit;
            }
        }

        opt = av_dict_get(opts, "fbloglevel", NULL, 0);
        if (!opt) {
			hwctx->fbloglevel = SYSLOG_SINK_LEV_STAT;
        } else {
            av_log(device_ctx, AV_LOG_TRACE, "%s(%s)\n", opt->key, opt->value);
            hwctx->fbloglevel = atoi(opt->value);
        }
        
        opt = av_dict_get(opts, "task-idx", NULL, 0);
        if (!opt) {
			hwctx->task_idx = 0;
        } else {
            av_log(device_ctx, AV_LOG_TRACE, "%s(%s)\n", opt->key, opt->value);
            hwctx->task_idx = atoi(opt->value);
        }

        opt = av_dict_get(opts, "ser-ip", NULL, 0);
        if (!opt) {
			hwctx->ser_ip = NULL;
        } else {
            av_log(device_ctx, AV_LOG_TRACE, "%s(%s)\n", opt->key, opt->value);
            hwctx->ser_ip = av_strdup(opt->value);
        }

        opt = av_dict_get(opts, "ser-port", NULL, 0);
        if (!opt) {
			hwctx->ser_port = 0;
        } else {
            av_log(device_ctx, AV_LOG_TRACE, "%s(%s)\n", opt->key, opt->value);
            hwctx->ser_port = atoi(opt->value);
        }
	}
    
  	hwctx->device = av_strdup(device);
    
    av_log(device_ctx, AV_LOG_TRACE, "hwctx->device = %s\n", hwctx->device);
    
    return 0;

error_exit:
    
    return AVERROR_UNKNOWN;
}

const HWContextType ff_hwcontext_type_hantro = {
    .type                 = AV_HWDEVICE_TYPE_HANTRO,
    .name                 = "HANTRO",

    .device_hwctx_size    = sizeof(AVHANTRODeviceContext),
    .device_priv_size       = sizeof(HANTRODeviceContext),
    .frames_hwctx_size      = sizeof(AVHANTROFramesContext),
    .frames_priv_size     = sizeof(HANTROFramesContext),

    .device_create        = hantro_device_create,
    .device_init          = hantro_device_init,
    .device_uninit        = hantro_device_uninit,
    .frames_get_constraints = hantro_frames_get_constraints,
    .frames_init          = hantro_frames_init,
    .frames_uninit        = hantro_frames_uninit,
    .frames_get_buffer    = hantro_get_buffer,
    .frames_derive_from   = hantro_frames_derive_from,
    .transfer_get_formats = hantro_transfer_get_formats,
    //.transfer_data_to     = hantro_transfer_data_to,
    //.transfer_data_from   = hantro_transfer_data_from,

    .pix_fmts             = (const enum AVPixelFormat[]){ AV_PIX_FMT_HANTRO, AV_PIX_FMT_NONE },
};
