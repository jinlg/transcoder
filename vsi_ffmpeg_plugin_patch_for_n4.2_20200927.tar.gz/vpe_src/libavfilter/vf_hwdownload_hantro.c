/*
 * This file is part of FFmpeg.
 *
 * FFmpeg is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * FFmpeg is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with FFmpeg; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA
 */

/**
 * @file
 * copy video filter
 */

#include "libavutil/imgutils.h"
#include "libavutil/internal.h"
#include "avfilter.h"
#include "internal.h"
#include "video.h"

#include "libavutil/attributes.h"
#include "libavutil/mem.h"
#include "libavutil/opt.h"

#include "audio.h"
#include "filters.h"
#include "formats.h"
#include "video.h"

#include <fcntl.h>
#include<sys/ioctl.h>

#include "dectypes.h"

#include "dwl.h"
#include "libavutil/hwcontext_hantro.h"
#include "trans_edma_api.h"
#include "trans_fd_api.h"
#include "hugepage_api.h"

#ifdef FB_SYSLOG_ENABLE
#include "syslog_sink.h"
#define DEBUG_PRINT(fmt, ...) FB_SYSLOG(log,SYSLOG_SINK_LEV_DEBUG_SW,"%s([%d]): " fmt,\
                                    __FUNCTION__, __LINE__, ## __VA_ARGS__)
#define ERROR_PRINT(fmt, ...)  FB_SYSLOG(log,SYSLOG_SINK_LEV_ERROR,"%s([%d]): " fmt,\
                                    __FUNCTION__, __LINE__, ## __VA_ARGS__)

#endif

typedef struct HWDownloadHANTROContext {
    const AVClass *class;
    
    AVBufferRef *hwframe;

    int pp_index;

    char * device;
    EDMA_HANDLE edma_handle;

} HWDownloadHANTROContext;

static void free_rc_buffer(void *opaque, uint8_t *data)
{
    av_log(NULL, AV_LOG_DEBUG, "to free rc buffer %p\n", data);
    fbtrans_free_huge_pages(data, 8*1024); //this len is only to distinguish hugepage
}

static int query_formats(AVFilterContext *ctx)
{
    static const enum AVPixelFormat pix_fmts[] = {
        AV_PIX_FMT_HANTRO,
        AV_PIX_FMT_NONE
    };
    static const enum AVPixelFormat out_pix_fmts[] = {
        AV_PIX_FMT_NV12,
        AV_PIX_FMT_P010LE,
        AV_PIX_FMT_NONE
    };
    int res;

    av_log(ctx, AV_LOG_DEBUG, "enter query_formats\n");

    AVFilterFormats *formats = ff_make_format_list(pix_fmts);
    
    AVFilterFormats *out_formats = ff_make_format_list(out_pix_fmts);
    if (!formats || !out_formats)
        return AVERROR(ENOMEM);
    
    res = ff_formats_ref(formats, &ctx->inputs[0]->out_formats);
    if (res < 0)
        return res;
    
    av_log(ctx, AV_LOG_DEBUG, "end query_formats\n");
    
    return ff_formats_ref(out_formats, &ctx->outputs[0]->in_formats);
}

static void hwdownload_hantro_uninit(AVFilterContext *avctx)
{
    HWDownloadHANTROContext *ctx = avctx->priv;
    av_log(avctx, AV_LOG_DEBUG, "in %s:%d\n",__FUNCTION__, __LINE__);


    av_buffer_unref(&ctx->hwframe);
    
    av_log(avctx, AV_LOG_DEBUG, "in %s:%d\n",__FUNCTION__, __LINE__);
    if (ctx->edma_handle) {
        TRANS_EDMA_release(ctx->edma_handle);
        ctx->edma_handle = NULL;
    }
    av_log(avctx, AV_LOG_DEBUG, "in %s:%d\n",__FUNCTION__, __LINE__);
}


static int hwdownload_hantro_config_input(AVFilterLink *inlink)
{
    AVFilterContext * dst = inlink->dst;
    HWDownloadHANTROContext * ctx = dst->priv;
    AVHWFramesContext *hwframe_ctx;
    AVHANTROFramesContext *frame_hwctx;
    AVHWDeviceContext *device_ctx;
    AVHANTRODeviceContext *device_hwctx;
    
    av_log(dst, AV_LOG_DEBUG, "input res %dx%d\n", inlink->w, inlink->h);
    
    if (!inlink->hw_frames_ctx) {
        av_log(dst, AV_LOG_ERROR, "The input must have a hardware frame reference.\n");
        return AVERROR(EINVAL);
    }

    ctx->hwframe = av_buffer_ref(inlink->hw_frames_ctx);
    if (ctx->hwframe == NULL) {
        av_log(dst, AV_LOG_ERROR, "Failed ref hwframe\n");
        return -1;
    }

    hwframe_ctx = inlink->hw_frames_ctx->data;
    frame_hwctx = (AVHANTROFramesContext *)hwframe_ctx->hwctx;
    device_ctx = hwframe_ctx->device_ctx;
    device_hwctx = device_ctx->hwctx;
    
    ctx->device = device_hwctx->device;
    ctx->edma_handle = TRANS_EDMA_init(ctx->device);
    if (ctx->edma_handle == NULL) {
        av_log(ctx, AV_LOG_ERROR, "hwdownload edma_handle init failed!\n");
        return -1;
    }

    return 0;
}

static int hwdownload_hantro_config_output(AVFilterLink *outlink)
{
    AVFilterContext *src = outlink->src;
    HWDownloadHANTROContext * ctx = src->priv;
    AVFilterLink *inlink   = src->inputs[0];
    enum AVPixelFormat *formats;
    AVHWFramesContext *hwframe_ctx;
    AVHANTROFramesContext *frame_hwctx;
    int pp_index;

    if (!ctx->hwframe)
        return AVERROR(EINVAL);

    hwframe_ctx = ctx->hwframe->data;
    frame_hwctx = (AVHANTROFramesContext *)hwframe_ctx->hwctx;

    for (pp_index = 0; pp_index < 5; pp_index++) {
        if (frame_hwctx->pic_info[pp_index].enabled == 1) {
             break;
        }
    }

    if (pp_index == 5) {
        av_log(src, AV_LOG_ERROR, "can't find pp_index\n");
        return -1;
    }
    
    av_log(src, AV_LOG_DEBUG, "find pp_index = %d\n", pp_index);

    ctx->pp_index = pp_index;


    outlink->w = inlink->w;
    outlink->h = inlink->h;

    if (frame_hwctx->pic_info[pp_index].picdata.bit_depth_luma == 8 && 
        frame_hwctx->pic_info[pp_index].picdata.bit_depth_chroma == 8) {
        outlink->format = AV_PIX_FMT_NV12;
    } else {
        outlink->format = AV_PIX_FMT_P010LE;
    }
    av_log(src, AV_LOG_DEBUG, "config output res %dx%d\n", outlink->w, outlink->h);

    return 0;
}

static int hwdownload_hantro_filter_frame(AVFilterLink *inlink, AVFrame *in)
{
    AVFilterContext *dst = inlink->dst;
    AVFilterLink *outlink = inlink->dst->outputs[0];
    HWDownloadHANTROContext * ctx = outlink->src->priv;
    AVHWFramesContext *hwframe_ctx;
    AVHANTROFramesContext * frame_hwctx;
    struct DecPicture *pic_info;
    int ret;
    struct DecPicturePpu *pic;
    int i;
    u32 *p;
    addr_t bus_address_lum, bus_address_chroma;
    u32 y_size,uv_size;
    u8 pix_width=8;


    av_log(ctx, AV_LOG_DEBUG, "ctx->pp_index = %d\n", ctx->pp_index);

    pic = (struct DecPicturePpu *) in->data[0];
    pic_info = &pic->pictures[ctx->pp_index];
    if(pic_info->picture_info.format == 0) {//tile4x4
        av_log(ctx, AV_LOG_ERROR, "picture_info.format is DEC_OUT_FRM_TILED_4X4 ,only support DEC_OUT_FRM_RASTER_SCAN !\n");
        return -1;
    }

    AVFrame *out = av_frame_alloc();

    av_frame_copy_props(out, in);

    if((pic_info->sequence_info.bit_depth_chroma==8)&&(pic_info->sequence_info.bit_depth_luma==8))
        out->format = AV_PIX_FMT_NV12;
    else
        out->format = AV_PIX_FMT_P010LE;
    out->width = pic_info->pic_width;
    out->height = pic_info->pic_height;
    //out->key_frame = 1;
    
    av_log(ctx, AV_LOG_DEBUG, "pic_info->picture_info.format=%d,\n",pic_info->picture_info.format);
    if((pic_info->sequence_info.bit_depth_chroma==8)&&(pic_info->sequence_info.bit_depth_luma==8))
        pix_width = 8;
    else
        pix_width = 16;
    
    out->linesize[0] = pic_info->pic_width*(pix_width/8);
    out->linesize[1] = pic_info->pic_width*(pix_width/8);
    
    av_log(ctx, AV_LOG_DEBUG, "\n \tin filter_frame after av_frame_get_buffer linesize info:out->width=%d,out->height=%d,out->format=%d(AV_PIX_FMT_NV12=%d,AV_PIX_FMT_P010LE=%d)\n",out->width,out->height,out->format,AV_PIX_FMT_NV12,AV_PIX_FMT_P010LE);

    y_size = pic_info->pic_width * pic_info->pic_height *(pix_width/8);
    uv_size = pic_info->pic_width * pic_info->pic_height *(pix_width/8)/2;
    if (y_size < 8*1024)
        y_size = 8*1024;
    if (uv_size < 8*1024)
        uv_size = 8*1024;
    
	bus_address_lum = pic_info->luma.bus_address;
	bus_address_chroma = pic_info->chroma.bus_address;

    out->data[0] = fbtrans_get_huge_pages(y_size);
	if (out->data[0] == NULL) {
		av_log(ctx, AV_LOG_ERROR,"No memory available for the frame buffer\n");
		return AVERROR(ENOMEM);
	}
    av_log(ctx, AV_LOG_DEBUG, "in %s:%d, dma get luma data from EP:%p to RC:%p \n",__FUNCTION__, __LINE__,(void *)bus_address_lum,out->data[0]);
    out->buf[0] = av_buffer_create((uint8_t *)out->data[0],
            y_size, free_rc_buffer, NULL, AV_BUFFER_FLAG_READONLY);
    if (out->buf[0] == NULL) {
        return -1;
    }

    out->data[1] = fbtrans_get_huge_pages(uv_size);
	if (out->data[1] == NULL) {
		av_log(ctx, AV_LOG_ERROR,"No memory available for the frame buffer\n");
		return AVERROR(ENOMEM);
	}
    av_log(ctx, AV_LOG_DEBUG, "in %s:%d, dma get chroma data from EP:%p to RC:%p \n",__FUNCTION__, __LINE__,(void *)bus_address_chroma,out->data[1]);
    out->buf[1] = av_buffer_create((uint8_t *)out->data[1],
            uv_size, free_rc_buffer, NULL, AV_BUFFER_FLAG_READONLY);
    if (out->buf[1] == NULL) {
        return -1;
    }

    TRANS_EDMA_EP2RC_nonlink(ctx->edma_handle, bus_address_lum, out->data[0], y_size);
    TRANS_EDMA_EP2RC_nonlink(ctx->edma_handle, bus_address_chroma, out->data[1], uv_size);
	
    av_frame_free(&in);
    
    return ff_filter_frame(outlink, out);
}

static const AVClass hwdownload_hantro_class = {
    .class_name = "hwdownload_hantro",
    .item_name  = av_default_item_name,
    .option     = NULL,
    .version    = LIBAVUTIL_VERSION_INT,
};



static const AVFilterPad hwdownload_hantro_inputs[] = {
    {
        .name         = "default",
        .type         = AVMEDIA_TYPE_VIDEO,
        .config_props = hwdownload_hantro_config_input,
        .filter_frame = hwdownload_hantro_filter_frame,
    },
    { NULL }
};

static const AVFilterPad hwdownload_hantro_outputs[] = {
    {
        .name = "default",
        .type = AVMEDIA_TYPE_VIDEO,
        .config_props = hwdownload_hantro_config_output,
    },
    { NULL }
};

AVFilter ff_vf_hwdownload_hantro = {
    .name        = "hwdownload_hantro",
    .description = NULL_IF_CONFIG_SMALL("Download a hantro hardware frame to a normal frame"),
    .inputs      = hwdownload_hantro_inputs,
    .outputs     = hwdownload_hantro_outputs,
    .uninit      = hwdownload_hantro_uninit,
    .query_formats = query_formats,
    .priv_size     = sizeof(HWDownloadHANTROContext),
    .priv_class    = &hwdownload_hantro_class,
    .flags_internal = FF_FILTER_FLAG_HWFRAME_AWARE,
};

