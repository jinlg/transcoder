
#include <sys/stat.h>
#include <fcntl.h>
#include <sys/ioctl.h>

#include "libavutil/avassert.h"
#include "libavutil/pixdesc.h"
#include "libavutil/hwcontext.h"
#include "libavutil/hwcontext_hantro.h"

#include "avfilter.h"
#include "filters.h"
#include "libavutil/opt.h"
#include "internal.h"


#include "hugepage_api.h"
#include "trans_fd_api.h"

#include "vf_hantro_pp.h"

extern u32 dec_pp_in_blk_size;
static struct TBCfg tb_cfg;

#define NUM_OUT  1
typedef void * PP_HANDLE;

typedef struct HANTROPPFilterContext {
    const AVClass *class;
    int nb_outputs;
    char *str_resizes;
    int	buffer_depth;
    int vce_ds_enable;

    ppResize_t resizes[4];
    int resize_num;

    int force_10bit;
    int raw_format;
    struct TestParams *params;

    AVBufferRef *hwframe;
    AVBufferRef *hwdevice;
    u8 *dev_name;

    const void* inst;
    const void * mwl;
    struct DecInput buffers;

    ppClient *pp_client;	

#ifdef PP_MEM_ERR_TEST
    int memory_err_shadow;
#endif

#ifdef PP_EDMA_ERR_TEST
    int edma_err_shadow;
#endif
} HANTROPPFilterContext;


struct MWLInitParam {
    u32 client_type;
    char * device;
    int mem_id;
};

struct HANTROMWL {
#ifdef FB_SYSLOG_ENABLE
    LOG_INFO_HEADER log_header;
#endif
    u32 client_type;
    int fd_memalloc;
    int mem_id;
    char * device;
    EDMA_HANDLE edma_handle;
};

ppClient *hantro_ppclient_init(struct TestParams *params, HANTROPPFilterContext *s);
void hantro_picture_consumed(void *opaque, uint8_t *data);
int hantro_ppclient_release(ppClient *pp_client);

static void * MWLInit(struct MWLInitParam * param);
static i32 MWLRelease(const void *instance);
static i32 MWLMallocLinear(const void *instance, u32 size, struct DWLLinearMem *info);
static void MWLFreeLinear(const void *instance, struct DWLLinearMem *info);

void *TransDemuxerInit(struct TestParams *params);
RawParserInst RawParserOpen(enum RAW_FORMAT format, int width, int height);
int RawParserReadFrame(RawParserInst instance, u8* buffer, u8* stream[2], i32* size, u8 rb, AVFrame *frame);
int Transcode_send_packet(HANTROPPFilterContext *s, struct DecInput ** input, AVFrame *frame);
void ResolvePpParamsOverlap(struct TestParams* params,       struct TBPpUnitParams *pp_units_params, u32 standalone);

#ifdef PP_MEM_ERR_TEST
static int pp_memory_err_cnt = 0;
static int pp_memory_err_shadow = 0;
static int PpMemoryCheck();

static int PpMemoryCheck()
{
    int ret = 0;
    if(pp_memory_err_cnt++ == pp_memory_err_shadow){
        av_log(NULL, AV_LOG_ERROR, "[%s,%d],pp_memory_err_cnt %d, pp_mem_err_test %d, force malloc memory error!!!\n", __FUNCTION__, __LINE__,
                pp_memory_err_cnt, pp_memory_err_shadow);
        ret = -1;
    }
    return ret;
}
#endif

#ifdef PP_EDMA_ERR_TEST
static int pp_edma_err_cnt   = 0;
static int pp_edma_err_shadow   = 0;
static int PpEDMAErrCheck();

static int PpEDMAErrCheck()
{
    int ret = 0;
    if(pp_edma_err_cnt++ == pp_edma_err_shadow){
        av_log(NULL, AV_LOG_ERROR, "[%s,%d],edma_err_cnt %d, pp_edma_err_test %d, force edma transfer error!!!\n", __FUNCTION__, __LINE__,
                pp_edma_err_cnt, pp_edma_err_shadow);
        ret = -1;
    }
    return ret;
}
#endif

static int pp_get_enc_buffer_num(HANTROPPFilterContext *pp_ctx)
{
  AVHWFramesContext *hwframe_ctx;
  AVHWDeviceContext *device_ctx;
  AVHANTRODeviceContext *device_hwctx;
  int nb_frames;

  hwframe_ctx = (AVHWFramesContext*)pp_ctx->hwframe->data;
  device_ctx = hwframe_ctx->device_ctx;
  device_hwctx = device_ctx->hwctx;
  nb_frames = device_hwctx->max_frames_delay;

  return nb_frames;
}

static int pp_add_extra_buffer( ppClient *pp,  int enc_need_buffers_num,  int current_pp_buffers_num)
{
  int i = 0;
  int ext_buffers_num = 0;
  
  PPInst pp_inst = pp->pp_inst;
  ext_buffers_num = enc_need_buffers_num;
  
  if(pp == NULL || ext_buffers_num <= 0){
    av_log(NULL, AV_LOG_ERROR, "[%s], enc_need_buffers_num %d, current_pp_buffers_num %d, error!\n", __FUNCTION__, ext_buffers_num, current_pp_buffers_num);
    return -1;
  }

  av_log(NULL, AV_LOG_DEBUG, "[%s,%d], ext_buffers_num %d \n", __FUNCTION__, __LINE__, ext_buffers_num);

  for (i = current_pp_buffers_num; i < current_pp_buffers_num + ext_buffers_num; i++) {
      pp->pp_out_buffer[i].mem_type = DWL_MEM_TYPE_DPB;
      if(DWLMallocLinear(((PPContainer*)pp_inst)->dwl, pp->out_buf_size, &pp->pp_out_buffer[i]) != DWL_OK) {
        PP_ERROR_PRINT("UNABLE TO ALLOCATE STREAM BUFFER MEMORY\n");
        return -1;
      }
  
      av_log(NULL, AV_LOG_DEBUG, "[%s,%d]out_buffer i %d, bus_address=0x%llx, bus_address_rc=0x%llx, virtual_address %p, virtual_address_ep %p, size %d \n", __FUNCTION__, __LINE__, i,
        pp->pp_out_buffer[i].bus_address, pp->pp_out_buffer[i].bus_address_rc, pp->pp_out_buffer[i].virtual_address, pp->pp_out_buffer[i].virtual_address_ep, pp->pp_out_buffer[i].size);
  
      FifoPush(pp->pp_out_Fifo, &pp->pp_out_buffer[i], FIFO_EXCEPTION_DISABLE);
  }
  pp->out_buf_nums += ext_buffers_num;
  
  av_log(NULL, AV_LOG_DEBUG, "[%s,%d],add ext_buffers_num %d, total out_buf_nums %d\n", __FUNCTION__, __LINE__, ext_buffers_num, pp->out_buf_nums);

  return 0;
}

static int pp_check_buffer_number_for_trans(HANTROPPFilterContext *pp_ctx, ppClient *pp)
{
  int enc_need_buffers_num;
  int current_pp_buffers_num;

  enc_need_buffers_num =  pp_get_enc_buffer_num(pp_ctx);
  current_pp_buffers_num = pp->out_buf_nums;

  if( pp->out_buf_nums_init + enc_need_buffers_num > current_pp_buffers_num ){
    av_log(NULL, AV_LOG_DEBUG, "[%s,%d] out_buf_nums_init %d, enc_need_buffers_num %d, current_pp_buffers_num %d\n", __FUNCTION__, __LINE__,pp->out_buf_nums_init, enc_need_buffers_num, current_pp_buffers_num);
    return pp_add_extra_buffer( pp, enc_need_buffers_num,  current_pp_buffers_num );
  }

  return 0;
}

static void * MWLInit(struct MWLInitParam * param)
{
    struct HANTROMWL *mwl;
#ifdef FB_SYSLOG_ENABLE
    LOG_INFO_HEADER * pheader;
#endif

    mwl = (struct HANTROMWL *)DWLcalloc(1, sizeof(struct HANTROMWL));
    if (mwl == NULL) {
        ERROR_PRINT("failed to alloc struct HANTROMWL struct\n");
        return NULL;
    }

#ifdef PP_MEM_ERR_TEST
    if(PpMemoryCheck() != 0){
        av_log(NULL, AV_LOG_ERROR, "[%s,%d]PP force memory error in function\n", __FUNCTION__, __LINE__);
        return NULL;
    }
#endif

#ifdef FB_SYSLOG_ENABLE
    pheader = &mwl->log_header;
    pheader->device_id = get_deviceId(param->device);
    static char module_name[] = "MWL";
    pheader->module_name = &module_name[0];
#endif

    DEBUG_PRINT("\n");

    mwl->client_type = param->client_type;
    mwl->fd_memalloc = -1;
    if (param->device == NULL) {
        ERROR_PRINT("device name error\n");
        goto err;
    }
    mwl->device = param->device;
    mwl->mem_id = param->mem_id;
    mwl->fd_memalloc = TranscodeOpenFD(param->device, O_RDWR | O_SYNC);
    if (mwl->fd_memalloc == -1) {
        DEBUG_PRINT("failed to open: %s\n", param->device);
        goto err;
    }

#ifdef PP_MEM_ERR_TEST
    if(PpMemoryCheck() != 0){
        av_log(NULL, AV_LOG_ERROR, "[%s,%d]PP force memory error in function\n", __FUNCTION__, __LINE__);
        goto err;
    }
#endif

    return mwl;

err:
    DEBUG_PRINT("%s","FAILED\n");
    MWLRelease(mwl);

    return NULL;
}

static i32 MWLRelease(const void *instance)
{
    struct HANTROMWL *mwl = (struct HANTROMWL *)instance;
    DEBUG_PRINT("\n");

    if (mwl) {
        
        if (mwl->edma_handle) {
            TRANS_EDMA_release(mwl->edma_handle);
        }
        
        if (mwl->fd_memalloc > 0) {
            TranscodeCloseFD(mwl->fd_memalloc);
        }
        
        DWLfree(mwl);
        mwl = NULL;
    }
    return 0;
}

static i32 MWLMallocLinear(const void *instance, u32 size, struct DWLLinearMem *info)
{
  struct HANTROMWL *mwl = (struct HANTROMWL *)instance;

  u32 pgsize = 4096;
  int ret = 0;
  struct mem_info params = {0};
  u32 alloc_flag = 0;
	
#define EP_SIDE_EN		(1<<1)
#define RC_SIDE_EN		(1<<2)

  assert(mwl != NULL);
  assert(info != NULL);

  info->logical_size = size;
  size = NEXT_MULTIPLE(size, pgsize);
  info->size = size;
  info->virtual_address = NULL;
  info->bus_address = 0;
  params.size = info->size;

  info->bus_address_rc = 0;
  info->virtual_address_ep = NULL;

  if(info->mem_type == DWL_MEM_TYPE_CPU_FILE_SINK)
    alloc_flag = RC_SIDE_EN;
  else if(info->mem_type == DWL_MEM_TYPE_DPB)
    alloc_flag = EP_SIDE_EN;
  else
    alloc_flag = EP_SIDE_EN | RC_SIDE_EN;

  if(alloc_flag&EP_SIDE_EN)
  {
    params.task_id = mwl->mem_id;
    params.mem_location = EP_SIDE;
    params.size = info->size;
    DEBUG_PRINT("EP: size(%d) task_id(%d)\n", params.size, params.task_id);
    ret = ioctl(mwl->fd_memalloc, CB_TRANX_MEM_ALLOC, &params);
    if (ret) {
      DEBUG_PRINT("%s", "ERROR! No linear buffer available\n");
      return DWL_ERROR;
    }

#ifdef PP_MEM_ERR_TEST
    if(PpMemoryCheck() != 0){
       av_log(NULL, AV_LOG_ERROR, "[%s,%d]PP force memory error in function\n", __FUNCTION__, __LINE__);
       return DWL_ERROR;
    }
#endif

    info->bus_address = params.phy_addr;
    info->size = params.size; 
  }
  if(alloc_flag&RC_SIDE_EN)
  {
	  info->virtual_address = fbtrans_get_huge_pages(info->size);
    info->bus_address_rc = info->virtual_address;
    if (info->virtual_address == NULL) 
	  return DWL_ERROR;

#ifdef PP_MEM_ERR_TEST
    if(PpMemoryCheck() != 0){
       av_log(NULL, AV_LOG_ERROR, "[%s,%d]PP force memory error in function\n", __FUNCTION__, __LINE__);
       return DWL_ERROR;
    }
#endif

  }

  return DWL_OK;
}

static void MWLFreeLinear(const void *instance, struct DWLLinearMem *info)
{
  struct HANTROMWL *mwl = (struct HANTROMWL *)instance;
  int i;
  int ret;
  struct mem_info params;

  assert(info != NULL);

  params.task_id = mwl->mem_id;
  params.mem_location = EP_SIDE;
  params.phy_addr = info->bus_address;
  params.size = info->size;
  params.rc_kvirt = info->rc_kvirt;
  if (info->bus_address != 0) {
  	ret = ioctl(mwl->fd_memalloc, CB_TRANX_MEM_FREE, &params);
    DEBUG_PRINT("ret = %d\n", ret);
  }

  if (info->virtual_address) {
    fbtrans_free_huge_pages(info->virtual_address, info->size);
    info->virtual_address = NULL;
  }
}


static int split_string(char ** tgt, int max, char * src, char * split)
{
  int count;
  char * currp;
  char * p;
  char c;
  int i;
  int last;

  //printf("string is %s\n", src);
  //printf("split is %s\n", split);

  currp = src;
  count = 0;
  i = 0;
  last = 0;
  while ((c = *currp++) != '\0') {
    if ((p = strchr(split, c)) == NULL) {
      if (count < max) {
        tgt[count][i++] = c;
        //printf("%d %d %c\n", count, i-1, c);
      } else {
        av_log(NULL,AV_LOG_ERROR,"the split count exceeds max num\n");
        return -1;
      }
      last = 1; // 1 means non split char, 0 means split char
    } else {
      if (last == 1) {
        tgt[count][i] = '\0';
        //printf("split %d: %s\n", count, &tgt[count][0]);
        count++;
        i = 0;
      }
      last = 0; // 1 means non split char, 0 means split char
    }
  }
  if (last == 1) {
    tgt[count][i] = '\0';
    //printf("split %d: %s\n", count, &tgt[count][0]);
    count++;
  }

  return count;
}


static int hantro_pp_parse_resize(HANTROPPFilterContext *pp_ctx)
{
    int i, j;
#define MAX_SEG_NUM 4
    char strs[MAX_SEG_NUM][256];
    char * pstrs[MAX_SEG_NUM];
    int seg_num = 0;
    char * p, * ep, *cp;

    for (i = 0; i < MAX_SEG_NUM; i++)
        pstrs[i] = &strs[i][0];
    
	pp_ctx->resize_num = 0;

    av_log(pp_ctx, AV_LOG_DEBUG,"pp_ctx->str_resizes: %s\n", pp_ctx->str_resizes);

    if (!pp_ctx->str_resizes)
        return;
	  	
    seg_num = split_string(&pstrs, MAX_SEG_NUM, pp_ctx->str_resizes, "()");
    if (seg_num <= 0) {
        av_log(pp_ctx,AV_LOG_ERROR,"can't find resize info!\n");
        return -1;
    }

    while (pp_ctx->resize_num < seg_num) {
        cp = strs[pp_ctx->resize_num];
        av_log(pp_ctx, AV_LOG_DEBUG,"cp: %s\n", cp);
        if ((p = strchr(cp, ',')) != NULL) {
            pp_ctx->resizes[pp_ctx->resize_num].x = atoi(cp);
            cp = p + 1;
            av_log(pp_ctx, AV_LOG_DEBUG, "cp: %s\n", cp);
            if ((p = strchr(cp, ',')) != NULL) {
                pp_ctx->resizes[pp_ctx->resize_num].y = atoi(cp);
                cp = p + 1;
                av_log(pp_ctx, AV_LOG_DEBUG,"cp: %s\n", cp);
                if ((p = strchr(cp, ',')) != NULL) {
                    pp_ctx->resizes[pp_ctx->resize_num].cw = atoi(cp);
                    pp_ctx->resizes[pp_ctx->resize_num].ch = atoi(p+1);
                    cp = p + 1;
                    av_log(pp_ctx, AV_LOG_DEBUG,"cp: %s\n", cp);
                    if ((p = strchr(cp, ',')) != NULL) {
                        cp = p + 1;
                        av_log(pp_ctx,AV_LOG_DEBUG,"cp: %s\n", cp);
                    } else if (pp_ctx->resize_num != 0) {
                        return -1;
                    }
                } else {
                    return -1;
                }
            }else {
                return -1;
            }			
        }
        if ((p = strchr(cp, 'x')) == NULL) {
            if (cp[0] == 'd') {
                int n = atoi(cp+1);
                if (n != 2 && n != 4 && n != 8) {
                    av_log(NULL,AV_LOG_DEBUG,"only support d2/d4/d8!\n");
                    return -1;
                }
                pp_ctx->resizes[pp_ctx->resize_num].sw = -n;
                pp_ctx->resizes[pp_ctx->resize_num].sh = -n;
            } else if (pp_ctx->resize_num != 0) {
                av_log(pp_ctx,AV_LOG_DEBUG,"can't find swxsh or dn!\n");
                return -1;
            }
        }else {
            pp_ctx->resizes[pp_ctx->resize_num].sw = atoi(cp);
            pp_ctx->resizes[pp_ctx->resize_num].sh = atoi(p+1);
        }
        if (pp_ctx->resizes[pp_ctx->resize_num].sw == -1 && pp_ctx->resizes[pp_ctx->resize_num].sh == -1) {
            av_log(pp_ctx,AV_LOG_DEBUG,"resize -1x-1 error!\n");
            return -1;
        }

        av_log(pp_ctx, AV_LOG_DEBUG,"[%s, %d]get resize %d: %d,%d, %d,%d, %dx%d\n", __FUNCTION__, __LINE__, pp_ctx->resize_num,
        pp_ctx->resizes[pp_ctx->resize_num].x,
        pp_ctx->resizes[pp_ctx->resize_num].y,
        pp_ctx->resizes[pp_ctx->resize_num].cw,
        pp_ctx->resizes[pp_ctx->resize_num].ch,
        pp_ctx->resizes[pp_ctx->resize_num].sw,
        pp_ctx->resizes[pp_ctx->resize_num].sh);

        pp_ctx->resize_num++;
    }

    return 0;
}

static void dump_config(ppClient *pp)
{
  ppTestConfig* pTestCfg = &pp->pp_config;
  int i;
  
  PP_DEBUGV_PRINT("dump ppTestConfig\n");
  
  PP_DEBUGV_PRINT("\tin_width = %d\n", pTestCfg->in_width);
  PP_DEBUGV_PRINT("\tin_height = %d\n", pTestCfg->in_height);
  PP_DEBUGV_PRINT("\tin_width_align = %d\n", pTestCfg->in_width_align);
  PP_DEBUGV_PRINT("\tin_height_align = %d\n", pTestCfg->in_height_align);
  PP_DEBUGV_PRINT("\tin_stride = %d\n", pTestCfg->in_stride);
  PP_DEBUGV_PRINT("\talign = %d\n", pTestCfg->align);
  PP_DEBUGV_PRINT("\tmax_num_pics = %d\n", pTestCfg->max_num_pics);
  PP_DEBUGV_PRINT("\tframe_size = %d\n", pTestCfg->frame_size);
  PP_DEBUGV_PRINT("\tin_p010 = %d\n", pTestCfg->in_p010);
  PP_DEBUGV_PRINT("\tcompress_bypass = %d\n", pTestCfg->compress_bypass);
  PP_DEBUGV_PRINT("\tcache_enable = %d\n", pTestCfg->cache_enable);
  PP_DEBUGV_PRINT("\tshaper_enable = %d\n", pTestCfg->shaper_enable);
  PP_DEBUGV_PRINT("\tpp_enabled = %d\n", pTestCfg->pp_enabled);
  PP_DEBUGV_PRINT("\tout_p010 = %d\n", pTestCfg->out_p010);

#ifdef SUPPORT_TCACHE
  TcacheContext *tcg = &pp->tcache_config;

  PP_DEBUGV_PRINT("dump TcacheContext\n");

  PP_DEBUGV_PRINT("\tt_in_fmt = %d\n", tcg->t_in_fmt);
  PP_DEBUGV_PRINT("\tt_out_fmt = %d\n", tcg->t_out_fmt);
  PP_DEBUGV_PRINT("\trgb_cov_bd = %d\n", tcg->rgb_cov_bd);
  
  PP_DEBUGV_PRINT("\tt_in_width = %d\n", tcg->t_in_width);
  PP_DEBUGV_PRINT("\tt_in_height = %d\n", tcg->t_in_height);
  PP_DEBUGV_PRINT("\tt_wplanes = %d\n", tcg->t_wplanes);
  for (i = 0; i < tcg->t_wplanes; i++) {
    PP_DEBUGV_PRINT("\tt_in_stride[%d] = %d\n", i, tcg->t_in_stride[i]);
    PP_DEBUGV_PRINT("\tt_in_align_stride[%d] = %d\n", i, tcg->t_in_align_stride[i]);
    PP_DEBUGV_PRINT("\tt_in_plane_height[%d] = %d\n", i, tcg->t_in_plane_height[i]);
    PP_DEBUGV_PRINT("\tt_in_plane_size[%d] = %d\n", i, tcg->t_in_plane_size[i]);
  }
  PP_DEBUGV_PRINT("\tt_out_width = %d\n", tcg->t_out_width);
  PP_DEBUGV_PRINT("\tt_out_height = %d\n", tcg->t_out_height);
  PP_DEBUGV_PRINT("\tt_rplanes = %d\n", tcg->t_rplanes);
  for (i = 0; i < tcg->t_rplanes; i++) {
    PP_DEBUGV_PRINT("\tt_out_stride[%d] = %d\n", i, tcg->t_out_stride[i]);
    PP_DEBUGV_PRINT("\tt_out_align_stride[%d] = %d\n", i, tcg->t_out_align_stride[i]);
    PP_DEBUGV_PRINT("\tt_out_plane_height[%d] = %d\n", i, tcg->t_out_plane_height[i]);
    PP_DEBUGV_PRINT("\tt_out_plane_size[%d] = %d\n", i, tcg->t_out_plane_size[i]);
  }
#endif

  PPConfig * pDecCfg = &pp->dec_cfg;

  PP_DEBUGV_PRINT("dump PPConfig\n");

  PP_DEBUGV_PRINT("\tin_format = %d\n", pDecCfg->in_format);
  PP_DEBUGV_PRINT("\tin_stride = %d\n", pDecCfg->in_stride);
  PP_DEBUGV_PRINT("\tin_height = %d\n", pDecCfg->in_height);
  PP_DEBUGV_PRINT("\tin_width = %d\n", pDecCfg->in_width);

  dump_ppuconfig(pp, &pDecCfg->ppu_config[0]);
}


static int ppParseParams(ppClient *pp, struct TestParams *params) 
{
#ifdef SUPPORT_TCACHE
  TcacheContext * pTCfg = &pp->tcache_config;
  int i;
#endif
  ppTestConfig* pTestCfg = &pp->pp_config;

  PP_DEBUGV_PRINT("pp dump input parameters:\n");
  PP_DEBUGV_PRINT("\twidth=%d\n", params->width);
  PP_DEBUGV_PRINT("\theight=%d\n", params->height);
  PP_DEBUGV_PRINT("\tin_format=%s\n", params->in_format);
  PP_DEBUGV_PRINT("\tin_10bit=%d\n", params->in_10bit);
  PP_DEBUGV_PRINT("\talign=%d\n", params->align);
  PP_DEBUGV_PRINT("\tin_file_name=%s\n", params->in_file_name);
  PP_DEBUGV_PRINT("\tcompress_bypass=%d\n", params->compress_bypass);
  PP_DEBUGV_PRINT("\tcache_enable=%d\n", params->cache_enable);
  PP_DEBUGV_PRINT("\tshaper_enable=%d\n", params->shaper_enable);
  PP_DEBUGV_PRINT("\tnum_of_decoded_pics= %d\n", params->num_of_decoded_pics);

  pTestCfg->max_num_pics = params->num_of_decoded_pics;
  pTestCfg->in_width = params->width;
  pTestCfg->in_height = params->height;
  pTestCfg->in_p010 = params->in_10bit;
  pTestCfg->align = params->align;
  pTestCfg->compress_bypass = params->compress_bypass;
  
#ifdef SUPPORT_CACHE
  pTestCfg->cache_enable = params->cache_enable;
  pTestCfg->shaper_enable = params->shaper_enable;
#endif

#ifdef SUPPORT_TCACHE
  pTCfg->t_in_width = params->width;
  pTCfg->t_in_height = NEXT_MULTIPLE(params->height, PP_IN_HEIGHT_ALIGN);
#endif

  if (!strcmp(params->in_format, "nv12")) {
  	pTestCfg->in_p010 = 0;
#ifdef SUPPORT_TCACHE
    pTCfg->t_in_fmt = TCACHE_PIX_FMT_NV12;
#endif
  } else if (!strcmp(params->in_format, "p010le")) {
    pTestCfg->in_p010 = 1;
#ifdef SUPPORT_TCACHE
    pTCfg->t_in_fmt = TCACHE_PIX_FMT_P010LE;
#endif
#ifdef SUPPORT_TCACHE
  } else if (!strcmp(params->in_format, "yuv420p")) {
    pTestCfg->in_p010 = 0;
    pTCfg->t_in_fmt = TCACHE_PIX_FMT_YUV420P;
  } else if (!strcmp(params->in_format, "iyuv")) {
    pTestCfg->in_p010 = 0;
    pTCfg->t_in_fmt = TCACHE_PIX_FMT_YUV420P;
  } else if (!strcmp(params->in_format, "yuv422p")) {
    pTestCfg->in_p010 = 0;
    pTCfg->t_in_fmt = TCACHE_PIX_FMT_YUV422P;
  } else if (!strcmp(params->in_format, "nv21")) {
    pTestCfg->in_p010 = 0;
    pTCfg->t_in_fmt = TCACHE_PIX_FMT_NV21;
  } else if (!strcmp(params->in_format, "yuv420p10le")) { 
    pTestCfg->in_p010 = 1;
    pTCfg->t_in_fmt = TCACHE_PIX_FMT_YUV420P10LE;
  } else if (!strcmp(params->in_format, "yuv420p10be")) { 
    pTestCfg->in_p010 = 1;
    pTCfg->t_in_fmt = TCACHE_PIX_FMT_YUV420P10BE;
  } else if (!strcmp(params->in_format, "yuv422p10le")) {
    pTestCfg->in_p010 = 1;
    pTCfg->t_in_fmt = TCACHE_PIX_FMT_YUV422P10LE;
  } else if (!strcmp(params->in_format, "yuv422p10be")) {
    pTestCfg->in_p010 = 1;
    pTCfg->t_in_fmt = TCACHE_PIX_FMT_YUV422P10BE;
  } else if (!strcmp(params->in_format, "p010be")) {
    pTestCfg->in_p010 = 1;
    pTCfg->t_in_fmt = TCACHE_PIX_FMT_P010BE;
  } else if (!strcmp(params->in_format, "yuv444p")) {
    pTestCfg->in_p010 = 0;
    pTCfg->t_in_fmt = TCACHE_PIX_FMT_YUV444P;
  } else if (!strcmp(params->in_format, "rgb24")) {
    pTCfg->t_in_fmt = TCACHE_PIX_FMT_RGB24;
    if(params->in_10bit) {
      pTestCfg->in_p010 = 1;
      pTCfg->rgb_cov_bd = TCACHE_COV_BD_10;
    } else {
      pTestCfg->in_p010 = 0;
      pTCfg->rgb_cov_bd = TCACHE_COV_BD_8;
    }
  } else if (!strcmp(params->in_format, "bgr24")) {
      pTCfg->t_in_fmt = TCACHE_PIX_FMT_BGR24;
      if(params->in_10bit) {
        pTestCfg->in_p010 = 1;
        pTCfg->rgb_cov_bd = TCACHE_COV_BD_10;
      } else {
        pTestCfg->in_p010 = 0;
        pTCfg->rgb_cov_bd = TCACHE_COV_BD_8;
      }
  } else if (!strcmp(params->in_format, "argb")) {
      pTCfg->t_in_fmt = TCACHE_PIX_FMT_ARGB;
      if(params->in_10bit) {
        pTestCfg->in_p010 = 1;
        pTCfg->rgb_cov_bd = TCACHE_COV_BD_10;
      } else {
        pTestCfg->in_p010 = 0;
        pTCfg->rgb_cov_bd = TCACHE_COV_BD_8;
      }
  } else if (!strcmp(params->in_format, "rgba")) {
      pTCfg->t_in_fmt = TCACHE_PIX_FMT_RGBA;
      if(params->in_10bit) {
        pTestCfg->in_p010 = 1;
        pTCfg->rgb_cov_bd = TCACHE_COV_BD_10;
      } else {
        pTestCfg->in_p010 = 0;
        pTCfg->rgb_cov_bd = TCACHE_COV_BD_8;
      }
  } else if (!strcmp(params->in_format, "abgr")) {
      pTCfg->t_in_fmt = TCACHE_PIX_FMT_ABGR;
      if(params->in_10bit) {
        pTestCfg->in_p010 = 1;
        pTCfg->rgb_cov_bd = TCACHE_COV_BD_10;
      } else {
        pTestCfg->in_p010 = 0;
        pTCfg->rgb_cov_bd = TCACHE_COV_BD_8;
      }
  } else if (!strcmp(params->in_format, "bgra")) {
      pTCfg->t_in_fmt = TCACHE_PIX_FMT_BGRA;
      if(params->in_10bit) {
        pTestCfg->in_p010 = 1;
        pTCfg->rgb_cov_bd = TCACHE_COV_BD_10;
      } else {
        pTestCfg->in_p010 = 0;
        pTCfg->rgb_cov_bd = TCACHE_COV_BD_8;
      }
#endif
  }else if (!strcmp(params->in_format, "hantro")){
     if(params->in_10bit)
        pTestCfg->in_p010 = 1;
     else
        pTestCfg->in_p010 = 0;
  }else {
      PP_ERROR_PRINT("unsupport input format %s!!!\n", params->in_format);
      return -1;
  }

  PP_DEBUGV_PRINT("pp get test config:\n");
  PP_DEBUGV_PRINT("\tin_width=%d\n", pTestCfg->in_width);
  PP_DEBUGV_PRINT("\tin_height=%d\n", pTestCfg->in_height);
  PP_DEBUGV_PRINT("\tin_p010=%d\n", pTestCfg->in_p010);
  PP_DEBUGV_PRINT("\talign=%d\n", pTestCfg->align);

#ifdef SUPPORT_TCACHE
  pTCfg->t_out_fmt = tcache_get_output_format(pTCfg->t_in_fmt, pTestCfg->in_p010 ? 10 : 8);
  if (pTCfg->t_out_fmt == -1) {
    PP_ERROR_PRINT("tcache get output format failed!\n");
    return -1;
  }
  PP_DEBUGV_PRINT("set tcache intput format %d -> output format %d\n", pTCfg->t_in_fmt, pTCfg->t_out_fmt);

  u32 maxbottom = 0;
  u32 maxright = 0;
  for (i = 0; i < 4; i++) {
    if (!params->ppu_cfg[i].crop.enabled)
      continue;
    u32 thisbottom = NEXT_MULTIPLE(params->ppu_cfg[i].crop.y + params->ppu_cfg[i].crop.height, 2);
    if (thisbottom > maxbottom) {
      maxbottom = thisbottom;
    }
    u32 thisright = params->ppu_cfg[i].crop.x + params->ppu_cfg[i].crop.width;
    if (thisright > maxright) {
      maxright = thisright;
    }
  }
  if ((maxbottom || maxright)
      && (maxbottom < params->height || maxright < params->width)) {
    pTestCfg->crop_enabled = 1;
    pTestCfg->crop_w = maxright;
    pTestCfg->crop_h = maxbottom;
  }
  
  PP_DEBUGV_PRINT("\tcrop_enabled=%d\n", pTestCfg->crop_enabled);
  PP_DEBUGV_PRINT("\tcrop_w=%d\n", pTestCfg->crop_w);
  PP_DEBUGV_PRINT("\tcrop_h=%d\n", pTestCfg->crop_h);
#endif

  return 0;
}

#ifdef SUPPORT_TCACHE
static void pp_tcache_calc_size(ppClient *pp)
{
  u32 i;
  ppTestConfig* pTestCfg;
  TcacheContext *tcg = &pp->tcache_config;

  tcg->t_wplanes = tcache_get_planes(tcg->t_in_fmt);

  for (i = 0; i < tcg->t_wplanes; i++){
    tcg->t_in_stride[i] = tcache_get_stride(tcg->t_in_width, tcg->t_in_fmt, i, 1);
    tcg->t_in_align_stride[i] = tcache_get_stride_align(NEXT_MULTIPLE(tcg->t_in_stride[i], TCACHE_RAW_INPUT_ALIGNMENT));
    tcg->t_in_plane_height[i] = tcache_get_height(NEXT_MULTIPLE(tcg->t_in_height, 4), tcg->t_in_fmt, i);
    tcg->t_in_plane_size[i] = tcg->t_in_align_stride[i] * tcg->t_in_plane_height[i];
    PP_DEBUGV_PRINT("tcache read plane %d, stride %d align to %d, height %d\n",
          i, tcg->t_in_stride[i], tcg->t_in_align_stride[i], tcg->t_in_plane_height[i]);
  }

  tcg->t_out_width = tcg->t_in_width;
  tcg->t_out_height = tcg->t_in_height;

  tcg->t_rplanes = tcache_get_planes(tcg->t_out_fmt);

  for (i = 0; i < tcg->t_rplanes; i++){
    tcg->t_out_stride[i] = tcache_get_stride(tcg->t_out_width, tcg->t_out_fmt, i, 1);
    tcg->t_out_align_stride[i] = tcache_get_stride_align(NEXT_MULTIPLE(tcg->t_out_stride[i], PP_FETCH_ALIGN));
    tcg->t_out_plane_height[i] = tcache_get_height(NEXT_MULTIPLE(tcg->t_out_height, PP_OUT_HEIGHT_ALIGN), tcg->t_out_fmt, i);
    tcg->t_out_plane_size[i] = tcg->t_out_align_stride[i] * tcg->t_out_plane_height[i];
    PP_DEBUGV_PRINT("tcache write plane %d, stride %d align to %d, height %d\n",
          i, tcg->t_out_stride[i], tcg->t_out_align_stride[i], tcg->t_out_plane_height[i]);
  }
}


static int pp_tcache_finish(ppClient *pp)
{
  int ret;

  PP_DEBUGV_PRINT("tcache wait for EDMA read link done\n");
  ret = TRANS_EDMA_RC2EP_link_finish(pp->edma_handle);
  if (ret < 0) {
    PP_ERROR_PRINT("tcache wait for EDMA read link done failed\n");
  }

#ifdef PP_EDMA_ERR_TEST
  if(PpEDMAErrCheck() != 0){
    av_log(NULL, AV_LOG_ERROR, "[%s,%d]PP force edma error in function\n", __FUNCTION__, __LINE__);
    return -1;
  }
#endif

  return ret;
}

static int pp_tcache_config(ppClient *pp)
{
  u32 edma_link_ep_base[MAX_INPUT_PLANE+MAX_OUTPUT_PLANE] = {
  	       0x00000000, 0x02000000, 0x03000000, 0x02000000, 0x01000000
  };

  int ret;
  u32 i, plane, wplanes;
  u32 output_width;
  u32 link_size = 0;
  u32 offset[MAX_INPUT_PLANE];
  u32 offset_ep[MAX_INPUT_PLANE];
  u32 block_size[MAX_INPUT_PLANE];
  struct dma_link_table * edma_link;
  u64 edma_link_rc_base[3];
  TcacheContext *tcg = &pp->tcache_config;
  TCACHE_PARAM tcache_param;
  TCACHE_PARAM *pParam = &tcache_param;
  ppTestConfig* pTestCfg = &pp->pp_config;
  u32 valid_in_plane_size[MAX_INPUT_PLANE];
  u32 valid_out_plane_size[MAX_OUTPUT_PLANE];

  memset(pParam, 0, sizeof(*pParam));

  pParam->RGB_COV_A = 0x4c85;
  pParam->RGB_COV_B = 0x962b;
  pParam->RGB_COV_C = 0x1d50;
  pParam->RGB_COV_E = 0x9090;
  pParam->RGB_COV_F = 0xb694;

  pParam->write_format = tcg->t_in_fmt;
  pParam->write_bd = tcg->rgb_cov_bd;

  pParam->dtrc_read_enable = 0;
  pParam->hs_enable = 1;
  pParam->hs_dma_ch = 0;
  pParam->hs_go_toggle_count = 0xf4;
  pParam->hs_ce = tcg->t_wplanes;

  edma_link_rc_base[0] = pp->pp_in_buffer->buffer.bus_address_rc;
  edma_link_rc_base[1] = edma_link_rc_base[0] + tcache_get_block_size(tcg->t_in_align_stride[0], tcg->t_in_fmt, 0);
  edma_link_rc_base[2] = edma_link_rc_base[1] + tcache_get_block_size(tcg->t_in_align_stride[1], tcg->t_in_fmt, 1);

  for (plane = 0; plane < tcg->t_wplanes; plane++)
  {
    pParam->writeStride[plane] = tcg->t_in_align_stride[plane];
    pParam->writeStartAddr[plane] = edma_link_ep_base[plane] & 0x03FFFFFF;
    
    if (pTestCfg->crop_enabled && pTestCfg->crop_h < tcg->t_in_height) {
      valid_in_plane_size[plane] = tcg->t_in_align_stride[plane] * tcache_get_height(pTestCfg->crop_h, tcg->t_in_fmt, plane);
    } else {
      valid_in_plane_size[plane] = tcg->t_in_plane_size[plane];
    }
    PP_DEBUGV_PRINT("valid_in_plane_size[%d] = %d\n", plane, valid_in_plane_size[plane]);
#ifdef ENABLE_HW_HANDSHAKE
    pParam->writeEndAddr[plane] = pParam->writeStartAddr[plane] + valid_in_plane_size[plane] - 1;
#else
    if (tcg->t_in_height <= 256) {
      if (pTestCfg->crop_enabled && pTestCfg->crop_h < tcg->t_in_height) {
        pParam->writeEndAddr[plane] = pParam->writeStartAddr[plane] + tcg->t_in_align_stride[plane] * tcache_get_height(pTestCfg->crop_h, tcg->t_in_fmt, plane) - 1;
      } else {
        pParam->writeEndAddr[plane] = pParam->writeStartAddr[plane] + tcg->t_in_plane_size[plane] - 1;
      }
    } else {
      if (pTestCfg->crop_enabled && pTestCfg->crop_h < 256) {
        pParam->writeEndAddr[plane] = pParam->writeStartAddr[plane] + tcg->t_in_align_stride[plane] * tcache_get_height(pTestCfg->crop_h, tcg->t_in_fmt, plane) - 1;
      } else {
        pParam->writeEndAddr[plane] = pParam->writeStartAddr[plane] + tcg->t_in_align_stride[plane] * tcache_get_height(256, tcg->t_in_fmt, plane) - 1;
      }
    }
#endif

    block_size[plane] = tcache_get_block_size(tcg->t_in_align_stride[plane], tcg->t_in_fmt, plane);
    link_size += (valid_in_plane_size[plane] + block_size[plane] - 1)/block_size[plane];
    PP_DEBUGV_PRINT("start addr: 0x%08x, end addr: 0x%08x, block size: %d, link size: %d\n",
           pParam->writeStartAddr[plane], pParam->writeEndAddr[plane], block_size[plane], link_size);
  }

  edma_link = (struct dma_link_table *)pp->edma_link.virtual_address;
  memset(edma_link, 0, link_size*sizeof(struct dma_link_table));
  wplanes = tcg->t_wplanes;

  //rc2ep
  offset[0] = offset[1] = offset[2] = 0;
  offset_ep[0] = offset_ep[1] = offset_ep[2] = 0;
  for (i = 0; i < link_size; i++) {
      if (i == link_size-1)
          edma_link[i].control = 0x00000009;
      else
          edma_link[i].control = 0x00000001;
              
      edma_link[i].size = MIN((u32)block_size[i%wplanes], valid_in_plane_size[i%wplanes]-offset_ep[i%wplanes]);
      edma_link[i].sar_low = (edma_link_rc_base[i%wplanes]+offset[i%wplanes]) & 0xffffffff;
      edma_link[i].sar_high = (edma_link_rc_base[i%wplanes]+offset[i%wplanes]) >> 32;
#ifdef ENABLE_HW_HANDSHAKE
      edma_link[i].dst_low = (edma_link_ep_base[i%wplanes]+offset_ep[i%wplanes]) & 0xffffffff;
#else
      edma_link[i].dst_low = (edma_link_ep_base[i%wplanes]+(offset_ep[i%wplanes]%(block_size[i%wplanes]*4))) & 0xffffffff;
#endif
      edma_link[i].dst_high = 0;
      offset[i%wplanes] += HUGE_PGAE_SIZE;
      offset_ep[i%wplanes] += edma_link[i].size;
  }

  PP_DEBUGV_PRINT("edma link table:\n");
  for (i = 0; i < link_size; i++) {
      PP_DEBUGV_PRINT(" i : %d\n", i);
      PP_DEBUGV_PRINT("\t%#010X\n", edma_link[i].control);
      PP_DEBUGV_PRINT("\t%#010X\n", edma_link[i].size);
      PP_DEBUGV_PRINT("\t%#010X\n", edma_link[i].sar_low);
      PP_DEBUGV_PRINT("\t%#010X\n", edma_link[i].sar_high);
      PP_DEBUGV_PRINT("\t%#010X\n", edma_link[i].dst_low);
      PP_DEBUGV_PRINT("\t%#010X\n", edma_link[i].dst_high);
  }
  
#ifndef ENABLE_HW_HANDSHAKE
  {
    u32 (*tcache_link)[10];
    u32 val;
    u32 last_height;
    int i,j;
    
    tcache_link = (u32*)((u8*)pp->edma_link.virtual_address+link_size*sizeof(struct dma_link_table));
    memset(tcache_link, 0, 2*10*sizeof(u32));
  
    if (pTestCfg->crop_enabled && pTestCfg->crop_h < tcg->t_in_height) {
      last_height = pTestCfg->crop_h % 256;
    } else {
      last_height = tcg->t_in_height % 256;
    }
    if (last_height == 0) {
      last_height = 256;
    }
  
#if 0
    tcache_link[0][0] = 0x1301;
    tcache_link[0][1] = 0x1302;
    tcache_link[0][2] = 0x1303;
    tcache_link[0][3] = 0x1304;
    tcache_link[0][4] = 0x1305;
    tcache_link[0][5] = 0x1306;
    tcache_link[0][6] = 0x1307;
    tcache_link[0][7] = 0x1308;
    tcache_link[0][8] = 0x1309;
    tcache_link[0][9] = 0x130a;
#endif
  
    val  = (pParam->write_format & ((1 << 5) - 1)) << 0;
    val |= (pParam->write_bd     & ((1 << 2) - 1)) << 5;
    tcache_link[0][0] = val;
    tcache_link[0][1] = pParam->writeStartAddr[0];
    tcache_link[0][2] = pParam->writeEndAddr[0];
    tcache_link[0][3] = pParam->writeStride[0];
    tcache_link[0][4] = pParam->writeStartAddr[1];
    tcache_link[0][5] = pParam->writeEndAddr[1];
    tcache_link[0][6] = pParam->writeStride[1];
    tcache_link[0][7] = pParam->writeStartAddr[2];
    tcache_link[0][8] = pParam->writeEndAddr[2];
    tcache_link[0][9] = pParam->writeStride[2];
  
    tcache_link[1][0] = val;
    tcache_link[1][1] = pParam->writeStartAddr[0];
    tcache_link[1][2] = pParam->writeStartAddr[0] + pParam->writeStride[0] * tcache_get_height(last_height, tcg->t_in_fmt, 0) - 1;
    tcache_link[1][3] = pParam->writeStride[0];
    tcache_link[1][4] = pParam->writeStartAddr[1];
    tcache_link[1][5] = pParam->writeStartAddr[1] + pParam->writeStride[1] * tcache_get_height(last_height, tcg->t_in_fmt, 1) - 1;
    tcache_link[1][6] = pParam->writeStride[1];
    tcache_link[1][7] = pParam->writeStartAddr[2];
    tcache_link[1][8] = pParam->writeStartAddr[2] + pParam->writeStride[2] * tcache_get_height(last_height, tcg->t_in_fmt, 2) - 1;
    tcache_link[1][9] = pParam->writeStride[2];
  
    PP_DEBUGV_PRINT("tcache link table:\n");
    for (i = 0; i < 2; i++) {
      for (j = 0; j < 10; j++) {
          PP_DEBUGV_PRINT("\t%#010X\n", tcache_link[i][j]);
      }
    }
  }
#endif

  // read params
  pParam->read_format = tcg->t_out_fmt;
  pParam->read_count = 0;
  pParam->read_client = 0; // PCIE/PP

  for (plane = 0; plane < tcg->t_rplanes; plane++)
  {
    pParam->readStride[plane] = tcg->t_out_align_stride[plane];
    pParam->readValidStride[plane] = tcg->t_out_align_stride[plane];
    
    if (pTestCfg->crop_enabled) {
      valid_out_plane_size[plane] = tcg->t_out_align_stride[plane] * tcache_get_height(pTestCfg->crop_h, tcg->t_out_fmt, plane);
      //if (tcg->rgb_cov_bd == TCACHE_COV_BD_8 || pTestCfg->crop_w < tcg->t_out_width) {
      if (tcg->t_out_fmt == TCACHE_PIX_FMT_NV12 || pTestCfg->crop_w < tcg->t_out_width) {
        //u32 crop_align = (tcg->rgb_cov_bd == TCACHE_COV_BD_8)? 1 : 32;
        u32 crop_align = (tcg->t_out_fmt == TCACHE_PIX_FMT_NV12)? 1 : 32;
        pParam->readValidStride[plane] = tcache_get_stride(pTestCfg->crop_w, tcg->t_out_fmt, plane, crop_align);
      }
    } else {
      valid_out_plane_size[plane] = tcg->t_out_plane_size[plane];
    }
    
    pParam->readStartAddr[plane] = edma_link_ep_base[MAX_INPUT_PLANE+plane] & 0x03FFFFFF;
    pParam->readEndAddr[plane] = pParam->readStartAddr[plane] + valid_out_plane_size[plane] - (pParam->readStride[plane] - pParam->readValidStride[plane]) - 1;
  
    PP_DEBUGV_PRINT("start addr: 0x%08x, end addr: 0x%08x, read stride: %d, read valid stride: %d\n",
           pParam->readStartAddr[plane], pParam->readEndAddr[plane], pParam->readStride[plane], pParam->readValidStride[plane]);
  }

  if (pTestCfg->crop_enabled && pTestCfg->crop_h < tcg->t_in_height) {
    pParam->hs_image_height = tcache_get_height(pTestCfg->crop_h, tcg->t_in_fmt, 0);
  } else {
    pParam->hs_image_height = tcg->t_in_height;
  }
#ifdef ENABLE_HW_HANDSHAKE
  pParam->hs_enable = 1;
#else
  pParam->hs_enable = 0;
#endif

  TCACHE_config(pp->tcache_handle, pParam);

  PP_DEBUGV_PRINT("config read link\n");
#ifdef ENABLE_HW_HANDSHAKE
  ret = TRANS_EDMA_RC2EP_link_config(pp->edma_handle, pp->edma_link.bus_address_rc, pp->edma_link.virtual_address, link_size);
#else
  ret = TRANS_EDMA_RC2EP_link_config(pp->edma_handle, pp->edma_link.bus_address_rc, pp->edma_link.virtual_address, link_size, MIN(link_size, tcg->t_wplanes * 4));
#endif
  if (ret < 0)
      return -1;

#ifdef PP_EDMA_ERR_TEST
    if(PpEDMAErrCheck() != 0){
      av_log(NULL, AV_LOG_ERROR, "[%s,%d]PP force edma error in function\n", __FUNCTION__, __LINE__);
      return -1;
    }
#endif

  pp->dec_cfg.pp_in_buffer.bus_address = pParam->readStartAddr[0];

  return 0;
}

#endif

static int CalcPicSize(ppClient *pp)
{
  ppTestConfig* pTestCfg = &pp->pp_config;
#ifdef SUPPORT_TCACHE
  TcacheContext * pTCfg = &pp->tcache_config;
#endif
  int i;

#ifdef SUPPORT_TCACHE
  pTestCfg->in_stride = NEXT_MULTIPLE(pTestCfg->in_width * (pTestCfg->in_p010 ? 2 : 1), PP_FETCH_ALIGN);
#else
  pTestCfg->in_stride = NEXT_MULTIPLE(pTestCfg->in_width * (pTestCfg->in_p010 ? 2 : 1), 16);
#endif
  pTestCfg->in_width_align = pTestCfg->in_stride / (pTestCfg->in_p010 ? 2 : 1);
  pTestCfg->in_height_align = NEXT_MULTIPLE(pTestCfg->in_height, PP_IN_HEIGHT_ALIGN);
  pTestCfg->frame_size = (pTestCfg->in_stride * pTestCfg->in_height_align * 3) / 2;
  
#ifdef SUPPORT_TCACHE
  pp_tcache_calc_size(pp);
  pTestCfg->frame_size = 0;
  for (i = 0; i < pTCfg->t_rplanes; i++) {
    pTestCfg->frame_size += pTCfg->t_in_plane_size[i];
  }
#endif

  PP_DEBUGV_PRINT("frame size %d\n", pTestCfg->frame_size);

  return 0;
}


static int ppBufInit(ppClient *pp,  HANTROPPFilterContext *pp_ctx) 
{
  u32 i;
  PPInst pp_inst = pp->pp_inst;
  ppTestConfig* pTestCfg = &pp->pp_config;
  PPConfig * pDecCfg = &pp->dec_cfg;
  u32 pp_out_byte_per_pixel;
  u32 pp_width, pp_height, pp_stride, pp_stride_2;
  u32 pp_buff_size;
  u32 ext_buffers_need;

  /* calc output buffer size */
  pp->out_buf_size = 0;
  for (i = 0; i < 4; i++) {
    if (!pDecCfg->ppu_config[i].enabled) continue;

    pp_out_byte_per_pixel = (pDecCfg->ppu_config[i].out_cut_8bits
                      || pTestCfg->in_p010 == 0) ? 1 : ((pDecCfg->ppu_config[i].out_p010
                      || (pDecCfg->ppu_config[i].tiled_e && pTestCfg->in_p010)) ? 2 : 1);

    if (pDecCfg->ppu_config[i].tiled_e) {
      pp_width = NEXT_MULTIPLE(pDecCfg->ppu_config[i].scale.width, 4);
      pp_height = NEXT_MULTIPLE(pDecCfg->ppu_config[i].scale.height, PP_OUT_HEIGHT_ALIGN) / 4;
      pp_stride = NEXT_MULTIPLE(4 * pp_width * pp_out_byte_per_pixel, ALIGN(pTestCfg->align));
      pDecCfg->ppu_config[i].ystride = pp_stride;
      pDecCfg->ppu_config[i].cstride = pp_stride;
      pDecCfg->ppu_config[i].align = pTestCfg->align;
      PP_DEBUGV_PRINT("pp[%d] luma, pp_width=%d, pp_height=%d, pp_stride=%d(0x%x), pp_out_byte_per_pixel=%d, align=%d\n",
        i,pp_width,pp_height,pp_stride,pp_stride,pp_out_byte_per_pixel,pTestCfg->align);
      pp_buff_size = pp_stride * pp_height;
      pp_buff_size += PP_LUMA_BUF_RES;
      /* chroma */
      if (!pDecCfg->ppu_config[i].monochrome) {
        //pp_height = NEXT_MULTIPLE(pDecCfg->ppu_config[i].scale.height, PP_OUT_HEIGHT_ALIGN) / 2 / 4;
        pp_height = NEXT_MULTIPLE(pDecCfg->ppu_config[i].scale.height / 2, PP_OUT_HEIGHT_ALIGN) / 4; //fix height align 2
        PP_DEBUGV_PRINT("pp[%d] chroma, pp_height=%d\n",i,pp_height);
        pp_buff_size += pp_stride * pp_height;
        pp_buff_size += PP_CHROMA_BUF_RES;
      }
      PP_DEBUGV_PRINT("pp[%d] pp_buff_size=%d(0x%x)\n",i,pp_buff_size,pp_buff_size);
    } else {
      pp_width = pDecCfg->ppu_config[i].scale.width;
      pp_height = pDecCfg->ppu_config[i].scale.height;
      pp_stride = NEXT_MULTIPLE(pp_width * pp_out_byte_per_pixel, 4);
      pp_stride_2 = NEXT_MULTIPLE(pp_width / 2 * pp_out_byte_per_pixel, 4);
      pp_buff_size = pp_stride * pp_height;
      pp_buff_size += PP_LUMA_BUF_RES;
      if (!pDecCfg->ppu_config[i].monochrome) {
        if (!pDecCfg->ppu_config[i].planar)
          pp_buff_size += pp_stride * pp_height / 2;
        else
          pp_buff_size += pp_stride_2 * pp_height;
        pp_buff_size += PP_LUMA_BUF_RES;
      }
      PP_DEBUGV_PRINT("pp[%d], tile_e=0 pp_width=%d , pp_height=%d , pp_stride=%d(0x%x),pp_out_byte_per_pixel=%d\n",
        i,pp_width,pp_height,pp_stride,pp_stride,pp_out_byte_per_pixel);
      PP_DEBUGV_PRINT("pp[%d], tile_e=0 pp_buff_size=%d(0x%x)\n",i,pp_buff_size,pp_buff_size);
    }
    pp->out_buf_size += NEXT_MULTIPLE(pp_buff_size, 16);
  }

#ifdef SUPPORT_DEC400
  pp->dec_table_offset = pp->out_buf_size;
  //add buffer for dec table, 4 pps
  pp->out_buf_size += DEC400_PPn_TABLE_OFFSET(4); 
#endif

#ifdef SUPPORT_TCACHE
  pp->edma_link.mem_type = DWL_MEM_TYPE_CPU_FILE_SINK;
  if(DWLMallocLinear(((PPContainer*)pp_inst)->dwl, 0x4000, &pp->edma_link) != DWL_OK) {
    PP_ERROR_PRINT("UNABLE TO ALLOCATE EDMA LINK BUFFER MEMORY\n");
    goto end;
  }
  av_log(NULL, AV_LOG_DEBUG, "[%s,%d]edma_link: bus_address=0x%llx, bus_address_rc=0x%llx, virtual_address %p, virtual_address_ep %p, size %d \n", __FUNCTION__, __LINE__, 
      pp->edma_link.bus_address, pp->edma_link.bus_address_rc, pp->edma_link.virtual_address,  pp->edma_link.virtual_address_ep, pp->edma_link.size);
#endif

#ifdef PP_MEM_ERR_TEST
  if(PpMemoryCheck() != 0){
    av_log(NULL, AV_LOG_ERROR, "[%s,%d]PP force memory error in function\n", __FUNCTION__, __LINE__);
    return -1;
  }
#endif

  /*used for buffer management*/
  FifoInit(OUTPUT_BUF_DEPTH, &pp->pp_out_Fifo);

  ext_buffers_need = pp_get_enc_buffer_num(pp_ctx);
  pp->out_buf_nums_init = 3;
  
  pp->out_buf_nums = pp->out_buf_nums_init + ext_buffers_need;
  if (pp->out_buf_nums > OUTPUT_BUF_DEPTH) {
    PP_ERROR_PRINT("TOO MANY BUFFERS REQUEST!\n");
    goto end;
  }
  
  PP_DEBUGV_PRINT("pp->out_buf_nums = %d\n", pp->out_buf_nums);  
  for (i = 0; i < pp->out_buf_nums; i++) {
    pp->pp_out_buffer[i].mem_type = DWL_MEM_TYPE_DPB;
    if(DWLMallocLinear(((PPContainer*)pp_inst)->dwl, pp->out_buf_size, &pp->pp_out_buffer[i]) != DWL_OK) {
      PP_ERROR_PRINT("UNABLE TO ALLOCATE STREAM BUFFER MEMORY\n");
      goto end;
    }

    av_log(NULL, AV_LOG_DEBUG, "[%s,%d]out_buffer i %d, bus_address=0x%llx, bus_address_rc=0x%llx, virtual_address %p, virtual_address_ep %p, size %d \n", __FUNCTION__, __LINE__, i,
      pp->pp_out_buffer[i].bus_address, pp->pp_out_buffer[i].bus_address_rc, pp->pp_out_buffer[i].virtual_address, pp->pp_out_buffer[i].virtual_address_ep, pp->pp_out_buffer[i].size);

#ifdef PP_MEM_ERR_TEST
  if(PpMemoryCheck() != 0){
    av_log(NULL, AV_LOG_ERROR, "[%s,%d]PP force memory error in function\n", __FUNCTION__, __LINE__);
    return -1;
  }
#endif

    FifoPush(pp->pp_out_Fifo, &pp->pp_out_buffer[i], FIFO_EXCEPTION_DISABLE);
  }

  PP_DEBUGV_PRINT("pp buffer fifo count=%d\n", FifoCount(pp->pp_out_Fifo));

  return 0;

end:
  return -1;
}

static void ppReqBuf(ppClient *pp)
{
  struct DWLLinearMem *pp_out_buffer;

  PP_DEBUGV_PRINT("pp dec request buffer\n");

  FifoPop(pp->pp_out_Fifo, &pp_out_buffer, FIFO_EXCEPTION_DISABLE);

  pp->dec_cfg.pp_out_buffer = *pp_out_buffer;

  PP_DEBUGV_PRINT("[pp] get buffer bus address=%p, virtual address=%p\n",
         (void *)pp_out_buffer->bus_address, pp_out_buffer->virtual_address);
}


static int ppBufRelease(ppClient *pp)
{
  u32 i;
  PPInst pp_inst = pp->pp_inst;

  PP_DEBUGV_PRINT("pp dec release buffer\n");

  if (pp->pp_out_Fifo) {
    FifoRelease(pp->pp_out_Fifo);
    pp->pp_out_Fifo = NULL;
  }

  if(pp->pp_inst != NULL){
    for (i = 0; i< pp->out_buf_nums; i++) {
      if (pp->pp_out_buffer[i].bus_address || pp->pp_out_buffer[i].bus_address_rc)
        DWLFreeLinear(((PPContainer*)pp_inst)->dwl, &pp->pp_out_buffer[i]);
    }
#ifdef SUPPORT_TCACHE
    if (pp->edma_link.bus_address || pp->edma_link.bus_address_rc)
      DWLFreeLinear(((PPContainer*)pp_inst)->dwl, &pp->edma_link);
#endif
  }
  return 0;
}


static void GetNextPicture(ppClient *pp, PPDecPicture *hpic)
{
	u32 i, j;
  int ret = 0;
  u32 index = 0;
  PPInst pp_inst = pp->pp_inst;
  PPContainer *pp_c;
  struct DecPicturePpu *pic = &hpic->pp_pic;

  pp_c = (PPContainer *)pp_inst;

  for (i = 0; i < DEC_MAX_OUT_COUNT; i++) {
  	if (!hpic->pictures[i].pp_enabled) {
    	//current mem alloc, the dec table is added after pic mem for each ppN.
      index += 1; 
      continue;
    }

    //pp0->vce is not the real scenario, just use to test performance.
    if (i == 0) {
    	j = 0;
    } else {
      j = i + 1;
    }

    PP_DEBUGV_PRINT("i = %d, j = %d\n", i, j);
    pic->pictures[j].sequence_info.bit_depth_luma = hpic->pictures[i].bit_depth_luma;
    pic->pictures[j].sequence_info.bit_depth_chroma = hpic->pictures[i].bit_depth_chroma;

    pic->pictures[j].sequence_info.pic_width = hpic->pictures[i].pic_width;
    pic->pictures[j].sequence_info.pic_height = hpic->pictures[i].pic_height;
                  
    pic->pictures[j].picture_info.format = hpic->pictures[i].output_format;
    pic->pictures[j].picture_info.pixel_format = hpic->pictures[i].pixel_format;
                  
    pic->pictures[j].pic_width = hpic->pictures[i].pic_width;
    pic->pictures[j].pic_height = hpic->pictures[i].pic_height;
    pic->pictures[j].pic_stride = hpic->pictures[i].pic_stride;
    pic->pictures[j].pic_stride_ch = hpic->pictures[i].pic_stride_ch;
    pic->pictures[j].pp_enabled = hpic->pictures[i].pp_enabled;
                      
#ifdef SUPPORT_TCACHE
    pic->pictures[j].luma.virtual_address = NULL;
    pic->pictures[j].chroma.virtual_address = NULL;
#else
    pic->pictures[j].luma.virtual_address = (u32*)hpic->pictures[i].output_picture;
    pic->pictures[j].chroma.virtual_address = (u32*)hpic->pictures[i].output_picture_chroma;
#endif
    pic->pictures[j].luma.bus_address = hpic->pictures[i].output_picture_bus_address;
    pic->pictures[j].chroma.bus_address = hpic->pictures[i].output_picture_chroma_bus_address;

    if ((hpic->pictures[i].output_format == DEC_OUT_FRM_TILED_4X4) && hpic->pictures[i].pp_enabled) {
    	pic->pictures[j].luma.size = pic->pictures[j].pic_stride * hpic->pictures[i].pic_height / 4;
      /*pic->pictures[i].chroma.size = stride_ch * hpic->pictures[i].pic_height / 8;*/
      if((hpic->pictures[i].pic_height / 4)&1 == 1)
        pic->pictures[j].chroma.size = pic->pictures[j].pic_stride_ch * (hpic->pictures[i].pic_height/4+1) / 2;
      else
        pic->pictures[j].chroma.size = pic->pictures[j].pic_stride_ch * hpic->pictures[i].pic_height / 8;
    } else {
        pic->pictures[j].luma.size = pic->pictures[j].pic_stride * hpic->pictures[i].pic_height;
        pic->pictures[j].chroma.size = pic->pictures[j].pic_stride_ch * hpic->pictures[i].pic_height / 2;
        //TODO
        //printf("error, other format is not support\n");
    }

#ifdef SUPPORT_DEC400
    pic->pictures[j].pic_compressed_status = 2;
    pic->pictures[j].luma_table.virtual_address = NULL;     //(u32 *)pp_c->pp_out_buffer.virtual_address + dec_table_offset + DEC400_PPn_Y_TABLE_OFFSET(index); //index*8*1024;
    pic->pictures[j].luma_table.bus_address = pp_c->pp_out_buffer.bus_address + pp->dec_table_offset + DEC400_PPn_Y_TABLE_OFFSET(index); //index*8*1024;
    pic->pictures[j].chroma_table.virtual_address = NULL;   //(u32 *)pp_c->pp_out_buffer.virtual_address + dec_table_offset + DEC400_PPn_UV_TABLE_OFFSET(index); //index*8*1024;
    pic->pictures[j].chroma_table.bus_address = pp_c->pp_out_buffer.bus_address + pp->dec_table_offset + DEC400_PPn_UV_TABLE_OFFSET(index); //index*8*1024;
    index++;
#else
    pic->pictures[j].pic_compressed_status = 0;
#endif

#if 1
    PP_DEBUGV_PRINT("[pp] dump pic info: \n \ 
           pic->pictures[%d].sequence_info.bit_depth_luma = %d \n \
           pic->pictures[%d].sequence_info.bit_depth_chroma = %d \n \
           pic->pictures[%d].picture_info.format = %d \n \
           pic->pictures[%d].picture_info.pixel_format = %d \n \
           pic->pictures[%d].pic_width = %d \n \
           pic->pictures[%d].pic_height = %d \n \
           pic->pictures[%d].pic_stride = %d \n \
           pic->pictures[%d].pic_stride_ch = %d \n \
           pic->pictures[%d].pp_enabled = %d \n \
           pic->pictures[%d].luma.virtual_address = %p \n \
           pic->pictures[%d].luma.bus_address = 0x%08lx \n \
           pic->pictures[%d].chroma.virtual_address =%p \n \
           pic->pictures[%d].chroma.bus_address = 0x%08lx \n \
           pic->pictures[%d].luma.size = %d \n \
           pic->pictures[%d].chroma.size = %d \n \
           pic->pictures[%d].luma_table.virtual_address  = %p \n \
           pic->pictures[%d].luma_table.bus_address = 0x%08lx \n \
           pic->pictures[%d].chroma_table.virtual_address  = %p \n \
           pic->pictures[%d].chroma_table.bus_address = 0x%08lx \n",
           j,pic->pictures[j].sequence_info.bit_depth_luma,
           j,pic->pictures[j].sequence_info.bit_depth_chroma,
           j,pic->pictures[j].picture_info.format,
           j,pic->pictures[j].picture_info.pixel_format,
           j,pic->pictures[j].pic_width,
           j,pic->pictures[j].pic_height,
           j,pic->pictures[j].pic_stride,
           j,pic->pictures[j].pic_stride_ch,
           j,pic->pictures[j].pp_enabled,
           j,pic->pictures[j].luma.virtual_address,
           j,pic->pictures[j].luma.bus_address,
           j,pic->pictures[j].chroma.virtual_address,
           j,pic->pictures[j].chroma.bus_address,
           j,pic->pictures[j].luma.size,
           j,pic->pictures[j].chroma.size,
           j,pic->pictures[j].luma_table.virtual_address, 
           j,pic->pictures[j].luma_table.bus_address,
           j,pic->pictures[j].chroma_table.virtual_address,
           j,pic->pictures[j].chroma_table.bus_address
        );
#endif
  }

  return ret;
}


void *TransDemuxerInit(struct TestParams *params)
{
	void *mwl = NULL;
	struct MWLInitParam mwlParam = {DWL_CLIENT_TYPE_ST_PP, params->dec_dev_name, params->mem_id};

  mwlParam.mem_id = params->mem_id;
  mwlParam.device = params->dec_dev_name;
	mwl = MWLInit(&mwlParam);
	if (mwl == NULL) {
		ERROR_PRINT("Transcode demuxer mwl init failed!\n");
		return NULL;
	}

	return mwl;
}


static int hantro_pp_input_buf_init(HANTROPPFilterContext *s)
{
	ppClient *pp = s->pp_client;

	//??? Maybe need malloc more buffer!!!! check fbtrans demux.c:L554
	int height = s->params->height;
	int width = s->params->width;

	int mwl_size = ((height + 63)/64) * (2 * 1024 *1024);
  
	const void * mwl;
	mwl = s->mwl;
	if (mwl == NULL) {
	   ERROR_PRINT("Transcode demuxer mwl error!\n");
	   return -1;
	 }

	s->buffers.buffer.mem_type = DWL_MEM_TYPE_CPU_FILE_SINK;
	if (MWLMallocLinear(mwl, mwl_size, &s->buffers.buffer)) {
		ERROR_PRINT("No memory available for the stream buffer\n");
		//DispatchEndOfStream(pDemuxer); ???  bug need to do 
		return -1;
	}
	DEBUG_PRINT("stream buffer %p %p, mwl malloc buffer size %d\n", &s->buffers, s->buffers.buffer.virtual_address, mwl_size);

	DEBUG_PRINT("[%s@%d], buffer %p, size %d \n", __FUNCTION__,__LINE__, s->buffers.buffer, s->buffers.buffer.size);

  av_log(NULL, AV_LOG_DEBUG, "[%s,%d]input_buf: bus_address=0x%llx, bus_address_rc=0x%llx, virtual_address %p, virtual_address_ep %p, size %d \n", __FUNCTION__, __LINE__, 
          s->buffers.buffer.bus_address, s->buffers.buffer.bus_address_rc, s->buffers.buffer.virtual_address, s->buffers.buffer.virtual_address_ep, s->buffers.buffer.size);

#ifdef PP_MEM_ERR_TEST
    if(PpMemoryCheck() != 0){
        av_log(s, AV_LOG_ERROR, "[%s,%d]PP force memory error in function\n", __FUNCTION__, __LINE__);
        return -1;
    }
#endif

	/* Initialize stream to buffer start */
	s->buffers.stream[0] = (u8*)s->buffers.buffer.virtual_address;
	s->buffers.stream[1] = (u8*)s->buffers.buffer.virtual_address;

	return 0;
}


#define ALIGN(x, n) (((x)+((n)-1))&(~((n)-1)))
#define MIN(a, b) (((a) < (b)) ? (a) : (b))

#define WIDTH_ALIGN 16 //the request of tcache input
#define HEIGHT_ALIGN 8 

RawParserInst RawParserOpen(enum RAW_FORMAT format, int width, int height)
{
	struct RawParser * inst;
	int i;
	u32 height_align;
#ifdef FB_SYSLOG_ENABLE
	LOG_INFO_HEADER * pheader;
#endif
	u32 entry_num;

	inst = DWLcalloc(1, sizeof(struct RawParser));
	if (inst == NULL) {
    	//ERROR_PRINT("alloc failed!\n");
    	av_log(NULL, AV_LOG_ERROR, "alloc failed!\n");
	    goto err_exit;
  	}

#ifdef FB_SYSLOG_ENABLE
  pheader = &inst->log_header;
  pheader->device_id = -1;
static char module_name[] = "RAW";
  pheader->module_name = &module_name[0];
#endif

	inst->img_width = width;
	inst->img_height = height;
	inst->format = format;

  av_log(NULL, AV_LOG_DEBUG, "img_width = %d, img_height = %d, format = %d\n", inst->img_width, inst->img_height, inst->format);

	switch (inst->format)
	{
    case RAW_FMT_YUV420P:
      inst->planes = 3;
      inst->byte_width[0] = inst->img_width;
      inst->height[0] = inst->img_height;
      inst->height_align[0] = ALIGN(inst->img_height, HEIGHT_ALIGN);
      inst->byte_width[1] = inst->byte_width[2] = (inst->img_width+1)/2;
      inst->height[1] = inst->height[2] = (inst->img_height+1)/2;
      inst->height_align[1] = inst->height_align[2] = inst->height_align[0]/2;
      break;
    case RAW_FMT_NV12:
    case RAW_FMT_NV21:
    case RAW_FMT_HANTRO:
      inst->planes = 2;
      inst->byte_width[0] = inst->byte_width[1] = inst->img_width;
      inst->height[0] = inst->img_height;
      inst->height_align[0] = ALIGN(inst->img_height, HEIGHT_ALIGN);
      inst->height[1] = (inst->img_height+1)/2;
      inst->height_align[1] = inst->height_align[0]/2;
      break;
    case RAW_FMT_YUV420P10LE:
    case RAW_FMT_YUV420P10BE:
      inst->planes = 3;
      inst->byte_width[0] = inst->img_width*2;
      inst->byte_width[1] = inst->byte_width[2] = ((inst->img_width+1)/2)*2;
      inst->height[0] = inst->img_height;
      inst->height_align[0] = ALIGN(inst->img_height, HEIGHT_ALIGN);
      inst->height[1] = inst->height[2] = (inst->img_height+1)/2;
      inst->height_align[1] = inst->height_align[2] = inst->height_align[0]/2;
      break;
    case RAW_FMT_P010LE:
    case RAW_FMT_P010BE:
      inst->planes = 2;
      inst->byte_width[0] = inst->byte_width[1] = inst->img_width*2;
      inst->height[0] = inst->img_height;
      inst->height_align[0] = ALIGN(inst->img_height, HEIGHT_ALIGN);
      inst->height[1] = (inst->img_height+1)/2;
      inst->height_align[1] = inst->height_align[0]/2;
      break;
    case RAW_FMT_YUV422P:
      inst->planes = 3;
      inst->byte_width[0] = inst->img_width;
      inst->byte_width[1] = inst->byte_width[2] = (inst->img_width+1)/2;
      inst->height[0] = inst->height[1] = inst->height[2] = inst->img_height;
      inst->height_align[0] = inst->height_align[1] = inst->height_align[2] = ALIGN(inst->img_height, HEIGHT_ALIGN);
      break;
    case RAW_FMT_YUV422P10LE:
    case RAW_FMT_YUV422P10BE:
      inst->planes = 3;
      inst->byte_width[0] = inst->img_width*2;
      inst->byte_width[1] = inst->byte_width[2] = ((inst->img_width+1)/2)*2;
      inst->height[0] = inst->height[1] = inst->height[2] = inst->img_height;
      inst->height_align[0] = inst->height_align[1] = inst->height_align[2] = ALIGN(inst->img_height, HEIGHT_ALIGN);
      break;
    case RAW_FMT_YUV444P:
      inst->planes = 3;
      inst->byte_width[0] = inst->byte_width[1] = inst->byte_width[2] = inst->img_width;
      inst->height[0] = inst->height[1] = inst->height[2] = inst->img_height;
      inst->height_align[0] = inst->height_align[1] = inst->height_align[2] = ALIGN(inst->img_height, HEIGHT_ALIGN);
      break;
    case RAW_FMT_RGB24:
    case RAW_FMT_BGR24:
      inst->planes = 1;
      inst->byte_width[0] = inst->img_width*3;
      inst->height[0] = inst->img_height;
      inst->height_align[0] = ALIGN(inst->img_height, HEIGHT_ALIGN);
      break;
    case RAW_FMT_ARGB:
    case RAW_FMT_RGBA:
    case RAW_FMT_ABGR:
    case RAW_FMT_BGRA:
      inst->planes = 1;
      inst->byte_width[0] = inst->img_width*4;
      inst->height[0] = inst->img_height;
      inst->height_align[0] = ALIGN(inst->img_height, HEIGHT_ALIGN);
      break;
    default:
      av_log(NULL, AV_LOG_ERROR, "error format!\n");
      goto err_exit;
	}

	for (i = 0; i < inst->planes; i++) {
		inst->stride[i] = ALIGN(inst->byte_width[i], WIDTH_ALIGN);
		inst->plane_size[i] = inst->stride[i]*inst->height_align[i];
		av_log(NULL, AV_LOG_DEBUG,"plane %d: stride = %d, height_align = %d, plane_size = %d\n", i, inst->stride[i], inst->height_align[i], inst->plane_size[i]);
		inst->frame_size += inst->byte_width[i]*inst->height[i];
	}

	av_log(NULL, AV_LOG_DEBUG,"inst->frame_size = %d\n", inst->frame_size);

	inst->entry_num = (inst->img_height + 63)/64;
	inst->hugepage_frame_size = inst->entry_num*HUGE_PGAE_SIZE;
	av_log(NULL, AV_LOG_DEBUG,"inst->entry_num = %d, inst->hugepage_frame_size = %d\n", inst->entry_num, inst->hugepage_frame_size);

	return (RawParserInst)inst;

err_exit:
	if (inst) {
    DWLfree(inst);
    inst  = NULL;
  }
	return NULL;
}

int RawParserReadFrame(RawParserInst instance, u8* buffer, u8* stream[2], i32* size, u8 rb, AVFrame *frame)
{
  struct RawParser* inst = (struct RawParser*)instance;
  int read_len, total_len = 0;
  int i, h;
  u8 * pPlaneBuf, * pBuf;
  u8 *src_buf= NULL;
	 
  if (inst == NULL || buffer == NULL)
		return -1;
  av_log(NULL, AV_LOG_DEBUG,"\n");
	

  u32 rest_height, cur_height;
  int e;
  u8 * pEntryBuf;

  av_log(NULL, AV_LOG_DEBUG,"[%s@%d],inst %p, buffer %p, *size %d, inst->hugepage_frame_size %d\n", __FUNCTION__, __LINE__, 
  				inst, buffer, *size, inst->hugepage_frame_size);
  
  if (*size < inst->hugepage_frame_size) {
		*size = inst->hugepage_frame_size;
		return -1;
  }
  pPlaneBuf = buffer;
	for (i = 0; i < inst->planes; i++) {
		pEntryBuf = pPlaneBuf;
		rest_height = inst->height[i];

		src_buf = frame->data[i];
		
		for (e = 0; e < inst->entry_num; e++) {
		  pBuf = pEntryBuf;
      #ifdef SUPPORT_TCACHE
		  cur_height = MIN(tcache_get_block_height(inst->format, i), rest_height);
      #endif
		  av_log(NULL, AV_LOG_DEBUG, "entry %d plane %d, cur_height = %d, pEntryBuf = %p\n", e, i, cur_height, pEntryBuf);
		  for (h = 0; h < cur_height; h++) {
				//DEBUG_PRINT("to read %d at %p\n", inst->byte_width[i], pBuf);
				//read_len = fread(pBuf, 1, inst->byte_width[i], inst->file);
				read_len = inst->byte_width[i];
			
		    memcpy(pBuf, src_buf, inst->byte_width[i]);
				//src_buf += inst->byte_width[i];
				src_buf += frame->linesize[i];
		
				if (read_len <= 0)
			  	return read_len;
				//DEBUG_PRINT("read %d\n", read_len);
				total_len += read_len;
				pBuf += inst->stride[i];
		  }
		  pEntryBuf += HUGE_PGAE_SIZE;
		  rest_height -= cur_height;
		}
    #ifdef SUPPORT_TCACHE
		pPlaneBuf += tcache_get_block_size(inst->stride[i], inst->format, i);
    #endif
		av_log(NULL, AV_LOG_DEBUG, "plane %d read bytes: %d\n", i, total_len);
	}

  av_log(NULL, AV_LOG_DEBUG,"[%s@%d], total_len%d, inst->frame_size %d\n", __FUNCTION__, __LINE__, total_len, inst->frame_size);

  if (total_len < inst->frame_size)
		return -1;

  return total_len;
}


int Transcode_send_packet(HANTROPPFilterContext *s, struct DecInput ** input, AVFrame *frame)
{
	ppClient *pp =s->pp_client;

	i32 size, len;
	struct DecInput * buffer;

	buffer = &s->buffers;
	size = buffer->buffer.size;

	PP_DEBUGV_PRINT("[%s@%d], buffer %p, size %d \n", __FUNCTION__,__LINE__, buffer, size);
	
	len = RawParserReadFrame(s->inst, (u8*)buffer->buffer.virtual_address, buffer->stream, &size, 0, frame);
	PP_DEBUGV_PRINT("len = %d\n", len);
	if (len <= 0) { /* */
		PP_DEBUGV_PRINT("Trying to reallocate buffer to fit next buffer.\n");
		av_log(NULL, AV_LOG_ERROR, "%s(%d),RawParserReadFrame failed!\n", __FUNCTION__, __LINE__);
	}else{
		PP_DEBUGV_PRINT("RawParserReadFrame read %d bytes\n", len);
    buffer->data_len = len;
	}

	*input = &s->buffers;

	return 0;
}

void ResolvePpParamsOverlap(struct TestParams* params,
                           struct TBPpUnitParams *pp_units_params,
                           u32 standalone) {
  /* Override PPU1-3 parameters with tb.cfg */
  u32 i, pp_enabled;

#if 0
  /* Either fixed ration scaling, or fixed size scaling. */
  if (params->pp_enabled &&
      !params->ppu_cfg[0].scale.enabled &&
      !params->fscale_cfg.fixed_scale_enabled) {
    params->fscale_cfg.fixed_scale_enabled = 1;
    params->fscale_cfg.down_scale_x = 1;
    params->fscale_cfg.down_scale_y = 1;
  }
#endif

  /* transcoder need cml have higher priority */
  if (params->pp_enabled)
    return;
	
  for (i = params->ppu_cfg[0].enabled ? 1 : 0; i < 4; i++) {
    params->ppu_cfg[i].enabled = pp_units_params[i].unit_enabled;
    params->ppu_cfg[i].cr_first = pp_units_params[i].cr_first;
    params->ppu_cfg[i].tiled_e = pp_units_params[i].tiled_e;
    params->ppu_cfg[i].crop.enabled = pp_units_params[i].unit_enabled;;
    params->ppu_cfg[i].crop.x = pp_units_params[i].crop_x;
    params->ppu_cfg[i].crop.y = pp_units_params[i].crop_y;
    params->ppu_cfg[i].crop.width = pp_units_params[i].crop_width;
    params->ppu_cfg[i].crop.height = pp_units_params[i].crop_height;
    params->ppu_cfg[i].scale.enabled = pp_units_params[i].unit_enabled;;
    params->ppu_cfg[i].scale.width = pp_units_params[i].scale_width;
    params->ppu_cfg[i].scale.height = pp_units_params[i].scale_height;
    params->ppu_cfg[i].shaper_enabled = pp_units_params[i].shaper_enabled;
    params->ppu_cfg[i].monochrome = pp_units_params[i].monochrome;
    params->ppu_cfg[i].planar = pp_units_params[i].planar;
    params->ppu_cfg[i].out_p010 = pp_units_params[i].out_p010;
    params->ppu_cfg[i].out_cut_8bits = pp_units_params[i].out_cut_8bits;
    params->ppu_cfg[i].align = params->align;
    params->ppu_cfg[i].ystride = pp_units_params[i].ystride;
    params->ppu_cfg[i].cstride = pp_units_params[i].cstride;
    params->ppu_cfg[i].align = params->align;
  }
  if (params->ppu_cfg[0].enabled) {
    /* PPU0 */
    params->ppu_cfg[0].align = params->align;
    params->ppu_cfg[0].enabled |= pp_units_params[0].unit_enabled;
    params->ppu_cfg[0].cr_first |= pp_units_params[0].cr_first;
    if (params->hw_format != DEC_OUT_FRM_RASTER_SCAN)
      params->ppu_cfg[0].tiled_e |= pp_units_params[0].tiled_e;
    params->ppu_cfg[0].planar |= pp_units_params[0].planar;
    params->ppu_cfg[0].out_p010 |= pp_units_params[0].out_p010;
    params->ppu_cfg[0].out_cut_8bits |= pp_units_params[0].out_cut_8bits;
    if (!params->ppu_cfg[0].crop.enabled && pp_units_params[0].unit_enabled) {
      params->ppu_cfg[0].crop.x = pp_units_params[0].crop_x;
      params->ppu_cfg[0].crop.y = pp_units_params[0].crop_y;
      params->ppu_cfg[0].crop.width = pp_units_params[0].crop_width;
      params->ppu_cfg[0].crop.height = pp_units_params[0].crop_height;
    }
    if (params->ppu_cfg[0].crop.width || params->ppu_cfg[0].crop.height)
      params->ppu_cfg[0].crop.enabled = 1;
    if (!params->ppu_cfg[0].scale.enabled && pp_units_params[0].unit_enabled) {
      params->ppu_cfg[0].scale.width = pp_units_params[0].scale_width;
      params->ppu_cfg[0].scale.height = pp_units_params[0].scale_height;
    }
    if (params->ppu_cfg[0].scale.width || params->ppu_cfg[0].scale.height)
      params->ppu_cfg[0].scale.enabled = 1;
    params->ppu_cfg[0].shaper_enabled = pp_units_params[0].shaper_enabled;
    params->ppu_cfg[0].monochrome = pp_units_params[0].monochrome;
    params->ppu_cfg[0].align = params->align;
    if (!params->ppu_cfg[0].ystride)
      params->ppu_cfg[0].ystride = pp_units_params[0].ystride;
    if (!params->ppu_cfg[0].cstride)
      params->ppu_cfg[0].cstride = pp_units_params[0].cstride;
  }
  pp_enabled = pp_units_params[0].unit_enabled ||
               pp_units_params[1].unit_enabled ||
               pp_units_params[2].unit_enabled ||
               pp_units_params[3].unit_enabled;
  if (pp_enabled)
    params->pp_enabled = 1;
  if (standalone) { /* pp standalone mode */
    params->pp_standalone = 1;
    if (!params->pp_enabled &&
        !params->fscale_cfg.fixed_scale_enabled) {
      /* No pp enabled explicitly, then enable fixed ratio pp (1:1) */
      params->fscale_cfg.down_scale_x = 1;
      params->fscale_cfg.down_scale_y = 1;
      params->fscale_cfg.fixed_scale_enabled = 1;
      params->pp_enabled = 1;
    }
  }
}


void hantro_picture_consumed(void *opaque, uint8_t *data)
{
    AVHANTROFramesContext *frame_hwctx = opaque;
	ppClient *pp;	
	struct DecPicturePpu picture = *((struct DecPicturePpu *)data);
	
	u32 i;
	int index;
	  
#ifdef SUPPORT_TCACHE
	index = 0;
#else
	index = 1;
#endif

    pthread_mutex_lock(&frame_hwctx->opaque_mutex);
    pp = frame_hwctx->opaque;
	
    if (pp == NULL) {
        av_log(NULL, AV_LOG_DEBUG, "[%s,%d],NULL, maybe pp have been released. do consumedd, pp= %p\n", __FUNCTION__, __LINE__, pp);
		pthread_mutex_unlock(&frame_hwctx->opaque_mutex);
        if (data) av_free(data);
        return NULL;
    }

	PP_DEBUGV_PRINT("pp picture consumed,  picture.pictures[%d].luma.bus_address =0x%08x\n", 
			index,picture.pictures[index].luma.bus_address);

	av_log(NULL, AV_LOG_DEBUG, "[%s,%d],======do consumedd, out_buf_nums %d\n", __FUNCTION__, __LINE__, pp->out_buf_nums);
			 
	for (i = 0; i< pp->out_buf_nums; i++) {
		if (pp->pp_out_buffer[i].bus_address == picture.pictures[index].luma.bus_address) {
			PP_DEBUGV_PRINT("push buff %d...\n", i);
			FifoPush(pp->pp_out_Fifo, &pp->pp_out_buffer[i], FIFO_EXCEPTION_DISABLE);
			av_log(NULL, AV_LOG_DEBUG, "[%s,%d],======FifoPush, i %d\n", __FUNCTION__, __LINE__, i);
            break;
		}
	}
	pthread_mutex_unlock(&frame_hwctx->opaque_mutex);

	av_free(data);
}


int hantro_ppclient_release(ppClient *pp_client)
{
    if(pp_client != NULL){
        ppBufRelease(pp_client);

      /* release decoder instance */
      PPRelease(pp_client->pp_inst);

      if (pp_client->dwl != NULL)
          DWLRelease(pp_client->dwl);

      DWLfree(pp_client);
      pp_client = NULL;
  }

  return 0;
}

ppClient *hantro_ppclient_init(struct TestParams *params, HANTROPPFilterContext *pp_ctx)
{
	ppClient *pp_client = NULL;
	ppClient *pp = NULL;
	PPInst pp_inst = NULL;
	ppTestConfig * pTestCfg = NULL;;
	int iret;
	u32 i, j;
	PPResult ret;
	PPConfig *pDecCfg = NULL;
	struct DWLInitParam dwl_init;
    av_log(NULL, AV_LOG_TRACE, "%s(%d)\n", __FUNCTION__, __LINE__);

	pp_client = (ppClient *)DWLcalloc(1, sizeof(ppClient));
	if (pp_client == NULL) {
    av_log(NULL, AV_LOG_ERROR, "pp client malloc failed!!!\n");
		//PP_ERROR_PRINT("pp client malloc failed!!!\n");
		goto err_exit;
	}

#ifdef PP_MEM_ERR_TEST
  if(PpMemoryCheck() != 0){
    av_log(NULL, AV_LOG_ERROR, "[%s,%d]PP force memory error in function\n", __FUNCTION__, __LINE__);
    goto err_exit;
  }
#endif

#ifdef FB_SYSLOG_ENABLE
	static char module_name[] = "PP";
  	pp = pp_client;
	pp_client->log_header.module_name = &module_name[0];
	if (params->dec_dev_name)
    pp_client->log_header.device_id = get_deviceId(params->dec_dev_name);
	else
    pp_client->log_header.device_id = 0;
	
	av_log(NULL, AV_LOG_DEBUG, "%s(%d), fb_syslog, dev_name %s, dev_id %d !\n", __FUNCTION__, __LINE__, 
			params->dec_dev_name, pp_client->log_header.device_id);
#endif

	pp_client->param = *params;
	//pp_ctx->pp_client->trans_handle = trans_handle;   //??? maybe bug, fix next time

	/* set test bench configuration */
  TBSetDefaultCfg(&tb_cfg);

  if (tb_cfg.pp_params.pre_fetch_height == 16)
  	dec_pp_in_blk_size = 0;
	else if (tb_cfg.pp_params.pre_fetch_height == 64)
   	dec_pp_in_blk_size = 1;

/* process pp size -1/-2/-4/-8. */
{
  int i;
  u32 alignh = 2;
  u32 alignw = 2;
  for (i = 1; i < 4; i++) {
    if (pp_client->param.ppu_cfg[i].scale.width == -1 || pp_client->param.ppu_cfg[i].scale.width == -2
      || pp_client->param.ppu_cfg[i].scale.width == -4 || pp_client->param.ppu_cfg[i].scale.width == -8
      || pp_client->param.ppu_cfg[i].scale.height == -1 || pp_client->param.ppu_cfg[i].scale.height == -2
      || pp_client->param.ppu_cfg[i].scale.height == -4 || pp_client->param.ppu_cfg[i].scale.height == -8) {
      u32 original_width = pp_client->param.width;
      u32 original_height = pp_client->param.height;
      if (pp_client->param.ppu_cfg[i].scale.width == -1 && pp_client->param.ppu_cfg[i].scale.height == -1) {
        PP_ERROR_PRINT("pp %d scale setting error!!!\n", i);
        goto err_exit;
      }
      if (pp_client->param.ppu_cfg[i].crop.enabled) {
        if (pp_client->param.ppu_cfg[i].crop.width != original_width) {
          original_width = pp_client->param.ppu_cfg[i].crop.width;
        }
        if (pp_client->param.ppu_cfg[i].crop.height != original_height) {
          original_height = pp_client->param.ppu_cfg[i].crop.height;
        }
      }
      PP_DEBUGV_PRINT("original_width = %d, original_height = %d\n", original_width, original_height);
      if (pp_client->param.ppu_cfg[i].scale.width == -1) {
        pp_client->param.ppu_cfg[i].scale.width = NEXT_MULTIPLE((original_width * pp_client->param.ppu_cfg[i].scale.height)/original_height, alignw);
        pp_client->param.ppu_cfg[i].scale.height = NEXT_MULTIPLE(pp_client->param.ppu_cfg[i].scale.height, alignh);
      } else if (pp_client->param.ppu_cfg[i].scale.height == -1) {
        pp_client->param.ppu_cfg[i].scale.width = NEXT_MULTIPLE(pp_client->param.ppu_cfg[i].scale.width, alignw);
        pp_client->param.ppu_cfg[i].scale.height = NEXT_MULTIPLE((original_height * pp_client->param.ppu_cfg[i].scale.width)/original_width, alignh);
      } else if (pp_client->param.ppu_cfg[i].scale.width == -2 && pp_client->param.ppu_cfg[i].scale.height == -2) {
        pp_client->param.ppu_cfg[i].scale.width = NEXT_MULTIPLE(original_width / 2, alignw);
        pp_client->param.ppu_cfg[i].scale.height = NEXT_MULTIPLE(original_height / 2, alignh);
      } else if (pp_client->param.ppu_cfg[i].scale.width == -4 && pp_client->param.ppu_cfg[i].scale.height == -4) {
        pp_client->param.ppu_cfg[i].scale.width = NEXT_MULTIPLE(original_width / 4, alignw);
       pp_client->param.ppu_cfg[i].scale.height = NEXT_MULTIPLE(original_height / 4, alignh);
      } else if (pp_client->param.ppu_cfg[i].scale.width == -8 && pp_client->param.ppu_cfg[i].scale.height == -8) {
        pp_client->param.ppu_cfg[i].scale.width = NEXT_MULTIPLE(original_width / 8, alignw);
        pp_client->param.ppu_cfg[i].scale.height = NEXT_MULTIPLE(original_height / 8, alignh);
      } else {
        PP_ERROR_PRINT("pp %d scale setting error!!!\n", i);
        goto err_exit;
      }
      PP_DEBUGV_PRINT("pp_client->param.ppu_cfg[%d].scale.width = %d, pp_client->param.ppu_cfg[%d].scale.height = %d\n",
              i, pp_client->param.ppu_cfg[i].scale.width, i, pp_client->param.ppu_cfg[i].scale.height);
    }
  }
}

	iret = ppParseParams(pp_client, &pp_client->param);
	pTestCfg = &pp_client->pp_config;
  if (iret < 0) {
  	PP_ERROR_PRINT("ppParseParams failed!\n");
	  goto err_exit;
  }

	dwl_init.client_type = DWL_CLIENT_TYPE_ST_PP;
 	dwl_init.dec_dev_name = params->dec_dev_name;
	dwl_init.mem_id = params->mem_id;
	dwl_init.priority = params->priority;
	pp_client->dwl = DWLInit(&dwl_init);
 	if (pp_client->dwl == NULL) {
    PP_ERROR_PRINT("pp DWLInit failed!\n");
	  goto err_exit;
  }

	/* initialize decoder. If unsuccessful -> exit */
	ret = PPInit(&pp_client->pp_inst, pp_client->dwl);
	pp_inst = pp_client->pp_inst;
	if(ret != PP_OK) {
  	PP_ERROR_PRINT("PP INITIALIZATION FAILED\n");
	  goto err_exit;
  }
  
	if (CalcPicSize(pp_client) < 0) {
  	PP_ERROR_PRINT("CalcPicSize failed!\n");
	  goto err_exit;
  }

	PP_DEBUGV_PRINT("ALIGN TCACHE size in_width_align=%d, in_stride=%d\n", pp_client->pp_config.in_width_align, pp_client->pp_config.in_stride);

	/* Override command line options and tb.cfg for PPU0. */
  	/* write pp params form tb_cfg.pp_units_params to pp_client->param.ppu_cfg
       or keep cml params - kwu */
	ResolvePpParamsOverlap(&pp_client->param, tb_cfg.pp_units_params,
                       		!tb_cfg.pp_params.pipeline_e);

#ifdef SUPPORT_CACHE
  /* resolve shaper setting */
  for (i = 0; i < 4; i++) {
    if (!pp_client->param.ppu_cfg[i].enabled) continue;
    pp_client->param.ppu_cfg[i].shaper_enabled = pTestCfg->shaper_enable;
  }
#endif

	if (pp_client->param.fscale_cfg.fixed_scale_enabled) {
  	u32 crop_w = pp_client->param.ppu_cfg[0].crop.width;
    u32 crop_h = pp_client->param.ppu_cfg[0].crop.height;
  	if (!crop_w) crop_w = pTestCfg->in_width;
    if (!crop_h) crop_h = pTestCfg->in_height;
 		pp_client->param.ppu_cfg[0].scale.width = (crop_w / pp_client->param.fscale_cfg.down_scale_x) & ~0x1;
 		pp_client->param.ppu_cfg[0].scale.height = (crop_h / pp_client->param.fscale_cfg.down_scale_y) & ~0x1;
 		pp_client->param.ppu_cfg[0].scale.enabled = 1;
  	pp_client->param.ppu_cfg[0].enabled = 1;
	}
	pp_client->pp_enabled = pp_client->param.pp_enabled;

	/* resolve pp align and set crop - kwu add */
	if (pTestCfg->in_width_align != pTestCfg->in_width || pTestCfg->in_height_align != pTestCfg->in_height) {
    for (i = 1; i < 4; i++) {
			if (!pp_client->param.ppu_cfg[i].enabled) continue;
	 		if (!pp_client->param.ppu_cfg[i].crop.enabled) {
				pp_client->param.ppu_cfg[i].crop.enabled = 1;
	   		pp_client->param.ppu_cfg[i].crop.x = 0;
			  pp_client->param.ppu_cfg[i].crop.y = 0;
		    pp_client->param.ppu_cfg[i].crop.width = pTestCfg->in_width;
				pp_client->param.ppu_cfg[i].crop.height = pTestCfg->in_height;
	 		}
	 		PP_DEBUGV_PRINT("[pp] enable pp[%d] crop [%d, %d, %d, %d]\n", i,
		    	pp_client->param.ppu_cfg[i].crop.x,
			    pp_client->param.ppu_cfg[i].crop.y,
		   		pp_client->param.ppu_cfg[i].crop.width,
	   			pp_client->param.ppu_cfg[i].crop.height);
   	}
  }

	PP_DEBUGV_PRINT("before copy\n");
	dump_ppuconfig(pp, &pp_client->param.ppu_cfg);

	/* write pp config to pDecCfg->ppu_config - kwu */
	pDecCfg = &pp_client->dec_cfg;
	memcpy(pDecCfg->ppu_config, pp_client->param.ppu_cfg, sizeof(pp_client->param.ppu_cfg));

	PP_DEBUGV_PRINT("after copy\n");
	dump_ppuconfig(pp, &pDecCfg->ppu_config);

	for (i = 0; i < 4; i++) {
		if (pDecCfg->ppu_config[i].tiled_e && pp_client->param.in_10bit)
			pDecCfg->ppu_config[i].out_cut_8bits = 0;
		if (pp_client->param.in_10bit == 0) {
			pDecCfg->ppu_config[i].out_cut_8bits = 0;
			pDecCfg->ppu_config[i].out_p010 = 0;
  	}
		
		av_log(NULL, AV_LOG_DEBUG, "[%s%d],pDecCfg->ppu_config[%d].crop.width %d, pDecCfg->ppu_config[%d].crop.height %d \n", __FUNCTION__, __LINE__,
				i, pDecCfg->ppu_config[i].crop.width, i, pDecCfg->ppu_config[i].crop.height);
  	if (!pDecCfg->ppu_config[i].crop.width || !pDecCfg->ppu_config[i].crop.height) {
			pDecCfg->ppu_config[i].crop.x = pDecCfg->ppu_config[i].crop.y = 0;
			pDecCfg->ppu_config[i].crop.width = pTestCfg->in_width_align;
		  pDecCfg->ppu_config[i].crop.height = pTestCfg->in_height_align;

			av_log(NULL, AV_LOG_DEBUG, "[%s%d],pDecCfg->ppu_config[%d].crop.width %d, pDecCfg->ppu_config[%d].crop.height %d \n", __FUNCTION__, __LINE__,
					i, pDecCfg->ppu_config[i].crop.width, i, pDecCfg->ppu_config[i].crop.height);	
  	}

		av_log(NULL, AV_LOG_DEBUG, "[%s%d],pDecCfg->ppu_config[%d].scale.width %d, pDecCfg->ppu_config[%d].scale.height %d \n", __FUNCTION__, __LINE__,
				i, pDecCfg->ppu_config[i].scale.width, i,  pDecCfg->ppu_config[i].scale.height);				
  	if (!pDecCfg->ppu_config[i].scale.width || !pDecCfg->ppu_config[i].scale.height) {		
			pDecCfg->ppu_config[i].scale.width = pDecCfg->ppu_config[i].crop.width;
			pDecCfg->ppu_config[i].scale.height = pDecCfg->ppu_config[i].crop.height;

			av_log(NULL, AV_LOG_DEBUG, "[%s%d],pDecCfg->ppu_config[%d].scale.width %d, pDecCfg->ppu_config[%d].scale.height %d \n", __FUNCTION__, __LINE__,
				i, pDecCfg->ppu_config[i].scale.width, i,  pDecCfg->ppu_config[i].scale.height);	
  	}		
	}

	pDecCfg->in_format = pTestCfg->in_p010;   //???  why? is it a bug ?
	pDecCfg->in_stride = pTestCfg->in_stride;
	pDecCfg->in_height = pTestCfg->in_height_align;
	pDecCfg->in_width  = pTestCfg->in_width_align;

	for (i = 0; i < 4; i++) {
  	if (!pDecCfg->ppu_config[i].enabled) continue;
  }

	ret = ppBufInit(pp_client, pp_ctx);
	if (ret < 0) {
  	PP_ERROR_PRINT("ppBufInit failed!\n");
  	goto err_exit;
  }

	dump_config(pp_client);

	ret = PPSetInfo(pp_inst, pDecCfg);
	if (ret != PP_OK) {
  	PP_ERROR_PRINT("encode fails for Invalid pp parameters\n");
  	goto err_exit;
	}

	return pp_client;

err_exit:
	hantro_ppclient_release(pp_client);

	return NULL;
}

static void hantro_report_pp_pic_info(struct DecPicturePpu *picture)
{
  char info_string[2048];
  static char* pic_types[] = {"        IDR", "Non-IDR (P)", "Non-IDR (B)"};

  sprintf(&info_string[0], "pic_id %2d, type %s, ", 
         picture->pictures[0].picture_info.pic_id,
         pic_types[picture->pictures[0].picture_info.pic_coding_type]);
  if (picture->pictures[0].picture_info.cycles_per_mb) {
  //client->cycle_count += picture->pictures[0].picture_info.cycles_per_mb;
  sprintf(&info_string[strlen(info_string)], " %4d cycles / mb,", picture->pictures[0].picture_info.cycles_per_mb);
  }

  sprintf(&info_string[strlen(info_string)], " %d x %d, Crop: (%d, %d), %d x %d %s",
         picture->pictures[0].sequence_info.pic_width,
         picture->pictures[0].sequence_info.pic_height,
         picture->pictures[0].sequence_info.crop_params.crop_left_offset,
         picture->pictures[0].sequence_info.crop_params.crop_top_offset,
         picture->pictures[0].sequence_info.crop_params.crop_out_width,
         picture->pictures[0].sequence_info.crop_params.crop_out_height,
         picture->pictures[0].picture_info.is_corrupted ? "CORRUPT" : "");

  av_log(NULL, AV_LOG_DEBUG, "%s\n", info_string);
}



static int hantro_pp_output_frame(HANTROPPFilterContext *s, AVFrame *out, PPDecPicture *hipc)
{
	AVHANTROFramesContext *frame_hwctx;
	AVHWFramesContext *hwframe_ctx;
	int ref_num_0 = 0;
	int ref_num_1 = 0;
	
	struct TestParams *params = &s->pp_client->param;

	struct DecPicturePpu *pic = av_mallocz(sizeof(*pic));
	if(!pic)
  	return AVERROR(ENOMEM);

#ifdef PP_MEM_ERR_TEST
    if(PpMemoryCheck() != 0){
      av_log(s, AV_LOG_ERROR, "[%s,%d]PP force memory error in function\n", __FUNCTION__, __LINE__);
      goto err_exit;
    }
#endif

  memcpy(pic, &hipc->pp_pic, sizeof(struct DecPicturePpu));
    
  av_log(s, AV_LOG_DEBUG, "[%s@%d]DecPicturePpu pic %p,  PPDecPicture hipc->pp_pic %p\n",__FUNCTION__, __LINE__, pic, &hipc->pp_pic);
	hantro_report_pp_pic_info(pic);

	out->format = AV_PIX_FMT_HANTRO;	//AV_PIX_FMT_YUV420P;
    if (pic->pictures[0].pic_width > params->width) {
        out->width = params->width;
    } else {
        out->width = pic->pictures[0].pic_width;
    }
    if (pic->pictures[0].pic_height > params->height) {
        out->height = params->height;
    } else {
        out->height = pic->pictures[0].pic_height;
    }
    out->linesize[0] = pic->pictures[0].pic_width;
    out->linesize[1] = pic->pictures[0].pic_width/2;
    out->linesize[2] = pic->pictures[0].pic_width/2;
    //out->key_frame = (pic->pictures[0].picture_info.pic_coding_type == DEC_PIC_TYPE_I);

    av_log(s, AV_LOG_DEBUG, "out->width = %d, out->height = %d, out->linesize[0] = %d, out->key_frame = %d\n",
        out->width, out->height, out->linesize[0], out->key_frame);

	//always using pp0, never pp1
	pic->pictures[0].pp_enabled = 1;
	pic->pictures[1].pp_enabled = 0;
	
	for (int i = 2; i < 5; i++){
		if(params->ppu_cfg[i-1].enabled == 1){
			pic->pictures[i].pp_enabled = 1;
		}else{
			pic->pictures[i].pp_enabled = 0;
		}
	}

	for(int i=0;i<5;i++)
      av_log(s, AV_LOG_DEBUG, "pic.pictures[%d].pp_enabled = %d,comperss_status=%d,bit_depth_luma=%d\n",
        	i,pic->pictures[i].pp_enabled,pic->pictures[i].pic_compressed_status,pic->pictures[i].sequence_info.bit_depth_luma);

	av_log(s, AV_LOG_DEBUG, "fb_dec_ctx->picRdy = 1\n");

	av_log(s, AV_LOG_DEBUG, "[%s%d]s->hwframe = %p\n", __FUNCTION__, __LINE__, s->hwframe);
    hwframe_ctx = s->hwframe->data;
    av_log(s, AV_LOG_DEBUG, "(%s[%d])hwframe_ctx = %p\n", __FUNCTION__, __LINE__, hwframe_ctx);
    frame_hwctx = hwframe_ctx->hwctx;
    av_log(s, AV_LOG_DEBUG, "(%s[%d])frame_hwctx = %p\n", __FUNCTION__, __LINE__, frame_hwctx);

	frame_hwctx->pic_info[0].enabled = 1;	
	if(params->ppu_cfg[0].scale.width != 0 && params->ppu_cfg[0].scale.height !=0){
		frame_hwctx->pic_info[0].width  =  params->ppu_cfg[0].scale.width;
		frame_hwctx->pic_info[0].height =  params->ppu_cfg[0].scale.height;
	}else{
		frame_hwctx->pic_info[0].width  =  out->width; //params->width;    //out->width; 	fix crop 400x226 align bug
		frame_hwctx->pic_info[0].height =  out->height; //params->height;   //out->height;
	}

	av_log(s, AV_LOG_DEBUG, "frame_hwctx->pic_info[0].width %d, frame_hwctx->pic_info[0].height %d\n", frame_hwctx->pic_info[0].width, frame_hwctx->pic_info[0].height);


	frame_hwctx->pic_info[0].picdata.is_interlaced = pic->pictures[0].sequence_info.is_interlaced;
	frame_hwctx->pic_info[0].picdata.pic_stride = pic->pictures[0].pic_stride;
#if 0
    if (params->width < out->width) {
        frame_hwctx->pic_info[0].picdata.crop_out_width = params->width;
    } else {
	    frame_hwctx->pic_info[0].picdata.crop_out_width = pic->pictures[0].sequence_info.crop_params.crop_out_width;
    }
    if (params->height < out->height) {
        frame_hwctx->pic_info[0].picdata.crop_out_height = params->height;
    } else {
	    frame_hwctx->pic_info[0].picdata.crop_out_height = pic->pictures[0].sequence_info.crop_params.crop_out_height;
    }
#endif
	frame_hwctx->pic_info[0].picdata.pic_format = pic->pictures[0].picture_info.format;
	frame_hwctx->pic_info[0].picdata.pic_pixformat = pic->pictures[0].picture_info.pixel_format;
	frame_hwctx->pic_info[0].picdata.bit_depth_luma = pic->pictures[0].sequence_info.bit_depth_luma;
	frame_hwctx->pic_info[0].picdata.bit_depth_chroma = pic->pictures[0].sequence_info.bit_depth_chroma;
	frame_hwctx->pic_info[0].picdata.pic_compressed_status = pic->pictures[0].pic_compressed_status;

	if(pic->pictures[1].pp_enabled == 1){
		frame_hwctx->pic_info[1].enabled = 1;
		frame_hwctx->pic_info[1].width = pic->pictures[0].pic_width;
		frame_hwctx->pic_info[1].height = pic->pictures[0].pic_height;
	}else{
		frame_hwctx->pic_info[1].enabled = 0;
		frame_hwctx->pic_info[1].width = pic->pictures[0].pic_width;
		frame_hwctx->pic_info[1].height = pic->pictures[0].pic_height;
	}
	
	for (int i = 2; i < 5; i++) {	
		if(params->ppu_cfg[i-1].enabled == 1){
			frame_hwctx->pic_info[i].enabled = 1;
      frame_hwctx->pic_info[i].width  =  params->ppu_cfg[i-1].scale.width;  //pic->pictures[i-1].pic_width;
      frame_hwctx->pic_info[i].height =  params->ppu_cfg[i-1].scale.height;
			
      frame_hwctx->pic_info[i].picdata.is_interlaced = pic->pictures[i].sequence_info.is_interlaced;
      frame_hwctx->pic_info[i].picdata.pic_stride = pic->pictures[i].pic_stride;
      frame_hwctx->pic_info[i].picdata.crop_out_width = pic->pictures[i].sequence_info.crop_params.crop_out_width;
      frame_hwctx->pic_info[i].picdata.crop_out_height = pic->pictures[i].sequence_info.crop_params.crop_out_height;
      frame_hwctx->pic_info[i].picdata.pic_format = pic->pictures[i].picture_info.format;
      frame_hwctx->pic_info[i].picdata.pic_pixformat = pic->pictures[i].picture_info.pixel_format;
      frame_hwctx->pic_info[i].picdata.bit_depth_luma = pic->pictures[i].sequence_info.bit_depth_luma;
      frame_hwctx->pic_info[i].picdata.bit_depth_chroma = pic->pictures[i].sequence_info.bit_depth_chroma;
      frame_hwctx->pic_info[i].picdata.pic_compressed_status = pic->pictures[i].pic_compressed_status;
		}
  }
    av_log(s, AV_LOG_DEBUG, "frame_hwctx->pic_info[0].picdata.pic_compressed_status = %d.\n", frame_hwctx->pic_info[0].picdata.pic_compressed_status);

	av_log(s, AV_LOG_DEBUG, "[%s,%d]:output frames:[%d(%dx%d)][%d(%dx%d)][%d(%dx%d)][%d(%dx%d)][%d(%dx%d)]\n", __FUNCTION__, __LINE__,
		   frame_hwctx->pic_info[0].enabled, frame_hwctx->pic_info[0].width, frame_hwctx->pic_info[0].height,
		   frame_hwctx->pic_info[1].enabled, frame_hwctx->pic_info[1].width, frame_hwctx->pic_info[1].height,
		   frame_hwctx->pic_info[2].enabled, frame_hwctx->pic_info[2].width, frame_hwctx->pic_info[2].height,
		   frame_hwctx->pic_info[3].enabled, frame_hwctx->pic_info[3].width, frame_hwctx->pic_info[3].height,
		   frame_hwctx->pic_info[4].enabled, frame_hwctx->pic_info[4].width, frame_hwctx->pic_info[4].height);

    if (s->vce_ds_enable) {
        if (!frame_hwctx->pic_info[0].enabled || !frame_hwctx->pic_info[2].enabled) {
            av_log(s, AV_LOG_ERROR, "When use 1/4 ds pass1 for vce, pp0 and pp1 should be enabled!\n");
            goto err_exit;
        }
        if (frame_hwctx->pic_info[1].enabled || frame_hwctx->pic_info[3].enabled || frame_hwctx->pic_info[4].enabled) {
            av_log(s, AV_LOG_ERROR, "When use 1/4 ds pass1 for vce, except pp0 and pp1 should not be enabled!\n");
            goto err_exit;
        }
        av_log(s, AV_LOG_DEBUG, "set flag to 1\n");
        frame_hwctx->pic_info[2].flag = 1;
    }
    av_log(s, AV_LOG_DEBUG, "(%s[%d])frame_hwctx = %p\n", __FUNCTION__, __LINE__, frame_hwctx);
  out->data[0] = pic;
  out->buf[0] = av_buffer_create((uint8_t *)pic, sizeof(struct DecPicturePpu), hantro_picture_consumed, frame_hwctx, AV_BUFFER_FLAG_READONLY);
  if (out->buf[0] == NULL) {
    goto err_exit;
  }

#ifdef PP_MEM_ERR_TEST
    if(PpMemoryCheck() != 0){
      av_log(s, AV_LOG_ERROR, "[%s,%d]PP force memory error in function\n", __FUNCTION__, __LINE__);
      goto err_exit;
    }
#endif

  //av_log(s, AV_LOG_DEBUG, "[%s,%d]frame ref count %d for %p\n",__FUNCTION__,__LINE__,av_buffer_get_ref_count(out->buf[0]), out->buf[0]->data);
  out->hw_frames_ctx = av_buffer_ref(s->hwframe);
  if (out->hw_frames_ctx == NULL) {
    goto err_exit;
  }
	
	//ref_num_0 = av_buffer_get_ref_count(s->hwframe);
	//ref_num_1 = av_buffer_get_ref_count(out->hw_frames_ctx);	
  //av_log(s, AV_LOG_DEBUG, "[%s, %d]------ref_num_0 %d, ref_num_1 %d\n",__FUNCTION__, __LINE__, ref_num_0, ref_num_1);

	return 0;
		
err_exit:	
	return -1;
}

static int hantro_pp_init_hwctx(AVFilterContext *ctx, AVFilterLink *inlink, struct TestParams *params)
{
  AVHWFramesContext *hwframe_ctx;	
	AVHWDeviceContext *device_ctx;
  AVHANTRODeviceContext *device_hwctx;
  AVHANTROFramesContext *frame_hwctx;
	int ret =0;

	HANTROPPFilterContext *s = ctx->priv;
    av_log(ctx, AV_LOG_TRACE, "%s(%d)\n", __FUNCTION__, __LINE__);

	/* hw device & frame init */
	if(inlink->hw_frames_ctx){
		av_log(ctx, AV_LOG_TRACE, "%s(%d) inlink->hw_frames_ctx = %p\n", __FUNCTION__, __LINE__,inlink->hw_frames_ctx);
	
		s->hwframe = av_buffer_ref(inlink->hw_frames_ctx);
		if (!s->hwframe) {
    	ret = AVERROR(ENOMEM);
      goto error_exit;
    }

		hwframe_ctx = (AVHWFramesContext*)s->hwframe->data;
		s->hwdevice = av_buffer_ref(hwframe_ctx->device_ref);
    if (!s->hwdevice) {
    	ret = AVERROR(ENOMEM);
      goto error_exit;
    }
	}else{		
		av_log(ctx, AV_LOG_TRACE, "%s(%d) ctx->hw_device_ctx = %p\n", __FUNCTION__, __LINE__, ctx->hw_device_ctx);
		if(ctx->hw_device_ctx){
			s->hwdevice = av_buffer_ref(ctx->hw_device_ctx);
			av_log(ctx, AV_LOG_TRACE, "%s(%d) ctx->hwdevice = %p\n", __FUNCTION__, __LINE__, s->hwdevice);
			if(!s->hwdevice){
				ret = AVERROR(ENOMEM);
				goto error_exit;
			}
		}else{			
			av_log(ctx, AV_LOG_TRACE, "%s(%d) s->dev_name = %p\n", __FUNCTION__, __LINE__,s->dev_name);
			ret = av_hwdevice_ctx_create((AVBufferRef *)&s->hwdevice, AV_HWDEVICE_TYPE_HANTRO, s->dev_name, NULL, 0);
			if (ret < 0)
				goto error_exit;
		}

		s->hwframe = av_hwframe_ctx_alloc(s->hwdevice);
		if (!s->hwframe) {
			av_log(ctx, AV_LOG_ERROR, "%s(%d) av_hwframe_ctx_alloc failed\n", __FUNCTION__, __LINE__);
			ret = AVERROR(ENOMEM);
			goto error_exit;
		}

#ifdef PP_MEM_ERR_TEST
      if(PpMemoryCheck() != 0){
        av_log(NULL, AV_LOG_ERROR, "[%s,%d]PP force memory error in function\n", __FUNCTION__, __LINE__);
        ret = -1;
        goto error_exit;
      }
#endif

		hwframe_ctx = (AVHWFramesContext*)s->hwframe->data;
	}

	if (!hwframe_ctx->pool) {		
		hwframe_ctx->format = AV_PIX_FMT_HANTRO;
		hwframe_ctx->sw_format = inlink->format;
		hwframe_ctx->width	= inlink->w;
		hwframe_ctx->height = inlink->h;
		av_log(ctx, AV_LOG_DEBUG, "%s(%d), ++++++++inlink %p, width %d height %d format %d!\n", __FUNCTION__, __LINE__, inlink, inlink->w, inlink->h, inlink->format);
	
		if ((ret = av_hwframe_ctx_init(s->hwframe)) < 0) {
			av_log(NULL, AV_LOG_ERROR, "av_hwframe_ctx_init failed\n");
			return -1;
		}
	}

	device_ctx   = hwframe_ctx->device_ctx;
  device_hwctx = device_ctx->hwctx;
  frame_hwctx  = hwframe_ctx->hwctx;

    if (inlink->hw_frames_ctx == NULL) {
    	inlink->hw_frames_ctx = av_buffer_ref(s->hwframe);
        if (inlink->hw_frames_ctx == NULL)
            return AVERROR(ENOMEM);
    }

	av_log(ctx, AV_LOG_DEBUG, "[%s@%d], hwframe_ctx %p, frame_hwctx = %p, hwframe %p,  priority %d, device %s, task_id %d \n", __FUNCTION__, __LINE__,
			hwframe_ctx, frame_hwctx, s->hwframe, device_hwctx->priority, device_hwctx->device, frame_hwctx->task_id );

	params->dec_dev_name = device_hwctx->device;
	params->mem_id		 = frame_hwctx->task_id;
	params->priority 	 = device_hwctx->priority;

	return 0;

error_exit:
	return ret;
}


static av_cold int hantro_pp_init(AVFilterContext *ctx)
{
	HANTROPPFilterContext *s = ctx->priv;
  int i = 0;
	int ret = 0;

    av_log(ctx, AV_LOG_TRACE, "%s(%d)\n", __FUNCTION__, __LINE__);

#ifdef PP_MEM_ERR_TEST
  pp_memory_err_shadow = s->memory_err_shadow;
#endif

#ifdef PP_EDMA_ERR_TEST
  pp_edma_err_shadow   = s->edma_err_shadow;
#endif

#if defined(PP_MEM_ERR_TEST) && defined(PP_EDMA_ERR_TEST)
  av_log(ctx, AV_LOG_DEBUG,  "%s(%d), pp filter: pp_memory_err_shadow %d, pp_edma_err_shadow %d\n", __FUNCTION__, __LINE__, pp_memory_err_shadow, pp_edma_err_shadow);
#endif

	//pp's 1 output link to spliter
	//TODO: PP's 4 outputs link to 4 hantro enc
  //for (i = 0; i < s->nb_outputs; i++) {
	for (i = 0; i < NUM_OUT; i++) {	
  	char name[32];
    AVFilterPad pad = { 0 };

    snprintf(name, sizeof(name), "output%d", i);
    pad.type = AVMEDIA_TYPE_VIDEO;
    pad.name = av_strdup(name);
    if (!pad.name)
      return AVERROR(ENOMEM);

    if ((ret = ff_insert_outpad(ctx, i, &pad)) < 0) {
      av_freep(&pad.name);
      return ret;
    }
  }
   
  return 0;
}

static av_cold void hantro_pp_uninit(AVFilterContext *ctx)
{
	int i;
	HANTROPPFilterContext *s = ctx->priv;
	ppClient *pp_client = s->pp_client;
    AVHANTROFramesContext *frame_hwctx = NULL;
	AVHWFramesContext *hwframe_ctx = NULL;

	int ref_num_0 = 0; 
	int	ref_num_1 = 0;
  av_log(ctx, AV_LOG_DEBUG, "%s(%d)\n", __FUNCTION__, __LINE__);
  av_log(ctx, AV_LOG_DEBUG, "s = %p, s->hwframe = %p\n", s, s->hwframe);

  if (s->hwframe) hwframe_ctx = s->hwframe->data;
  av_log(ctx, AV_LOG_DEBUG, "hwframe_ctx = %p\n", hwframe_ctx);

  if (hwframe_ctx)
    av_log(ctx, AV_LOG_DEBUG, "hwframe_ctx->hwctx = %p\n", hwframe_ctx->hwctx);
  if (hwframe_ctx) frame_hwctx = hwframe_ctx->hwctx;
  av_log(ctx, AV_LOG_DEBUG, "frame_hwctx = %p\n", frame_hwctx);
  
  if (frame_hwctx) pthread_mutex_lock(&frame_hwctx->opaque_mutex);
  if(pp_client != NULL){
    s->pp_client = NULL;
    if (frame_hwctx) frame_hwctx->opaque = NULL;

    ppBufRelease(pp_client);

    /* release decoder instance */
    PPRelease(pp_client->pp_inst);	

    if (pp_client->dwl)
      DWLRelease(pp_client->dwl);
    
    DWLfree(pp_client);
    //ctx->priv = NULL;
  }
  av_log(ctx, AV_LOG_DEBUG, "%s(%d),s=%p,pp_client=%p\n", __FUNCTION__, __LINE__,s,s->pp_client);
  if (frame_hwctx) pthread_mutex_unlock(&frame_hwctx->opaque_mutex);

  if(s->inst != NULL){
    DWLfree(s->inst);
    s->inst = NULL;
  }

  if(s->mwl != NULL){
    MWLFreeLinear(s->mwl, &s->buffers.buffer);
    av_log(ctx, AV_LOG_DEBUG, "%s(%d), do MWLFreeLinear\n", __FUNCTION__, __LINE__);

    MWLRelease(s->mwl);
    s->mwl = NULL;
    av_log(ctx, AV_LOG_DEBUG, "%s(%d), do MWLRelease\n", __FUNCTION__, __LINE__);
  }

  if (s->params != NULL){
    av_free(s->params);
    s->params = NULL;
  }

  av_log(ctx, AV_LOG_DEBUG, "%s(%d),  filter_ctx %p\n", __FUNCTION__, __LINE__, ctx);
  for (i = 0; i < NUM_OUT; i++){
    if(ctx->output_pads != NULL && ctx->output_pads[i].name != NULL ){
      av_log(ctx, AV_LOG_DEBUG, "%s%d,ctx->output_pads[%d].name %s\n", __FUNCTION__, __LINE__, i,ctx->output_pads[i].name);
      av_freep(&ctx->output_pads[i].name);
    }
  }

  //if(s->hwdevice != NULL){
    //ref_num_0 = av_buffer_get_ref_count(s->hwframe);
    //ref_num_1 = av_buffer_get_ref_count(s->hwdevice); 
    //av_log(ctx, AV_LOG_DEBUG, "[%s, %d]befor------ref_num_0 %d, ref_num_1 %d\n", __FUNCTION__, __LINE__,ref_num_0, ref_num_1);
      
    //fix filter self would release the hwframe resource at close filter.
    av_buffer_unref(&s->hwframe);
    av_buffer_unref(&s->hwdevice);
  //}
  av_log(ctx, AV_LOG_DEBUG, "%s(%d), transcode pp released\n", __FUNCTION__, __LINE__);
}

static int hantro_pp_query_formats(AVFilterContext *ctx)
{
  int ret;

  static const enum AVPixelFormat input_pix_fmts[] = {
      AV_PIX_FMT_NV12, 				AV_PIX_FMT_P010LE, 			AV_PIX_FMT_YUV420P,			AV_PIX_FMT_YUV422P,
			AV_PIX_FMT_NV21, 				AV_PIX_FMT_YUV420P10LE, AV_PIX_FMT_YUV420P10BE, AV_PIX_FMT_YUV422P10LE,
			AV_PIX_FMT_YUV422P10BE, AV_PIX_FMT_P010BE, 			AV_PIX_FMT_YUV444P,			AV_PIX_FMT_RGB24,
			AV_PIX_FMT_BGR24,				AV_PIX_FMT_ARGB,				AV_PIX_FMT_RGBA,				AV_PIX_FMT_ABGR,
			AV_PIX_FMT_BGRA,  			AV_PIX_FMT_HANTRO,      AV_PIX_FMT_NONE,
	};
	
  static const enum AVPixelFormat output_pix_fmts[] = {
      AV_PIX_FMT_HANTRO,		AV_PIX_FMT_NONE,
  };

  AVFilterFormats *in_fmts  = ff_make_format_list(input_pix_fmts);
  AVFilterFormats *out_fmts;

	av_log(ctx, AV_LOG_DEBUG, "%s%d \n", __FUNCTION__, __LINE__);

  ret = ff_formats_ref(in_fmts, &ctx->inputs[0]->out_formats);
  if (ret < 0)
    return ret;

  out_fmts = ff_make_format_list(output_pix_fmts);

  ret = ff_formats_ref(out_fmts, &ctx->outputs[0]->in_formats);
  if (ret < 0)
    return ret;

  return 0;
}


static int hantro_pp_filter_frame(AVFilterLink *inlink, AVFrame *frame)
{
  AVFilterContext *ctx = inlink->dst;
	HANTROPPFilterContext *s = ctx->priv;
	
	int ret  = 0;
	int iret = 0 ;
	static u32 decode_pic_num = 0;

	av_log(ctx, AV_LOG_DEBUG, "%s(%d), ----hantro_pp_filter_frame, decode_pic_num %d,  hantro_pp_ctx %p , filter_ctx %p\n", 
			__FUNCTION__, __LINE__, decode_pic_num, s,  ctx);

	ppClient *pp = s->pp_client;

	av_log(ctx, AV_LOG_DEBUG, "linesize %d %d %d\n", frame->linesize[0], frame->linesize[1], frame->linesize[2]);

	PPDecPicture dec_picture;
	ppTestConfig* pTestCfg = &pp->pp_config;
  PPInst pp_inst		     = pp->pp_inst;
  PPConfig *pDecCfg      = &pp->dec_cfg;
	PPContainer *pp_c      = (PPContainer *)pp_inst;

  if(frame->format != AV_PIX_FMT_HANTRO){  //pp read raw data from RC
    pp_c->b_disable_tcache = 0;
  	//read frame from frame to pp_in_buffer
  	Transcode_send_packet(s, &pp->pp_in_buffer, frame);
    if (pp->pp_in_buffer == NULL) {
  	  av_log(s, AV_LOG_ERROR, "[%s@%d], Transcode_send_packet failed!", __FUNCTION__, __LINE__);
      goto err_exit;
    }
    pDecCfg->pp_in_buffer = pp->pp_in_buffer->buffer;

#ifdef SUPPORT_TCACHE
  	if (pp->tcache_handle == NULL) {
  		pp->tcache_handle = DWLGetIpHandleByOffset(pp_c->dwl, TCACHE_OFFSET_TO_VCEA);
  		if (pp->tcache_handle == NULL) {
  			PP_ERROR_PRINT("failed get tcache handle!\n");
  			goto err_exit;
  		}
  	}
  	if (pp->edma_handle == NULL) {
  		pp->edma_handle = DWLGetIpHandleByOffset(pp_c->dwl, PCIE_EDMA_REG_BASE-PCIE_REG_START);
  		if (pp->edma_handle == NULL) {
  			PP_ERROR_PRINT("failed get edma handle!\n");
  			goto err_exit;
  		}
  	}
  	
  	iret = pp_tcache_config(pp);
  	if (iret < 0)
  		goto err_exit;
#endif

#ifdef PP_EDMA_ERR_TEST
    if(PpEDMAErrCheck() != 0){
      av_log(s, AV_LOG_ERROR, "[%s,%d]PP force edma error in function\n", __FUNCTION__, __LINE__);
      goto err_exit;
    }
#endif

  }else{ //pp read raw data from upload filter EP
    struct DecPicturePpu * picPpu;
    picPpu = (struct DecPicturePpu *)frame->data[0];
    pp_c->b_disable_tcache = 1;
    pp->tcache_handle     = NULL;
    pp->edma_handle       = NULL;
    pp->dec_cfg.pp_in_buffer = picPpu->pictures[0].luma;
  }

  av_log(ctx, AV_LOG_DEBUG, "[%s@%d]input buffer %p\n", __FUNCTION__, __LINE__, (void *)pp->dec_cfg.pp_in_buffer.bus_address);
  
	PP_DEBUGV_PRINT("input buffer %p\n", (void *)pp->dec_cfg.pp_in_buffer.bus_address);

	ret = PPSetInput(pp_inst, pp->dec_cfg.pp_in_buffer);
	if (ret != PP_OK) {
		PP_ERROR_PRINT("encode fails for PPSetInput\n");
		goto err_exit;
	}

	ppReqBuf(pp);

	PP_DEBUGV_PRINT("output buffer %p\n", (void *)pp->dec_cfg.pp_out_buffer.bus_address);

	ret = PPSetOutput(pp_inst, pp->dec_cfg.pp_out_buffer);
	if (ret != PP_OK) {
		PP_ERROR_PRINT("encode fails for PPSetOutput\n");
		goto err_exit;
	}
	
	dump_config(pp);

 if( pp_check_buffer_number_for_trans(s, pp) < 0 )
    goto err_exit;

	ret = PPDecode(pp_inst);
#if 0 //def SUPPORT_TCACHE
	iret = pp_tcache_finish(pp);
	if (iret < 0) {
		PP_ERROR_PRINT("encode fails for pp_tcache_finish\n");
		goto err_exit;
	}

#ifdef PP_EDMA_ERR_TEST
    if(PpEDMAErrCheck() != 0){
        av_log(NULL, AV_LOG_ERROR, "[%s,%d]PP force edma error in function\n", __FUNCTION__, __LINE__);
        return -1;
    }
#endif

#endif
	if (ret != PP_OK) {
		PP_ERROR_PRINT("encode fails for PPDecode failed, %d\n", ret);
		goto err_exit;
	}

	ret = PPNextPicture(pp_inst, &dec_picture);
	GetNextPicture(pp, &dec_picture);
	
{
	char info_string[2048];
	int i;
	
	sprintf(&info_string[0], "PIC %2d", decode_pic_num++);
	
	for (i = 0; i < 4; i++) {
		if (dec_picture.pictures[i].pp_enabled) {
			sprintf(&info_string[strlen(info_string)], ", %d : %d x %d", i,
					 dec_picture.pictures[i].pic_width,
					 dec_picture.pictures[i].pic_height);
		}
	}
		
	PP_INFO_PRINT("%s\n", info_string);
}
	
	AVFrame *buf_out;
	buf_out = av_frame_alloc();
	if (!buf_out) {
  	return AVERROR(ENOMEM);
  }
  
#ifdef PP_MEM_ERR_TEST
    if(PpMemoryCheck() != 0){
        av_log(NULL, AV_LOG_ERROR, "[%s,%d]PP alloc error in function\n", __FUNCTION__, __LINE__);
        goto err_exit;
    }
#endif

	ret = av_frame_copy_props(buf_out, frame);
	if(ret)
		return ret;
	
	ret = hantro_pp_output_frame(s, buf_out, &dec_picture);
	if(ret < 0){
		av_log(ctx, AV_LOG_DEBUG, "[%s, @%d] frame to pp's buf_out failed !", __FUNCTION__, __LINE__);
		goto err_exit;
	}

#if 0
    if(frame->format != AV_PIX_FMT_HANTRO){
        av_log(ctx, AV_LOG_INFO, "[%s@%d], %s, %dx%d\n", __FUNCTION__, __LINE__, av_get_pix_fmt_name(frame->format), frame->width, frame->height);
        static FILE *fp = NULL;
        static int frame_cnt = 0;
        if(NULL == fp){
            fp = fopen("dump_rawdata_pp.yuv", "wb");
        }
        if(fp != NULL){
            av_log(ctx, AV_LOG_INFO, "[%s@%d], dump pp filter in avframe count %d, w %d h %d, linesize[0] %d, linesize[1] %d, linesize[2] %d, fmt %s\n", __FUNCTION__, __LINE__, 
                      frame_cnt++, frame->width, frame->height, frame->linesize[0], frame->linesize[1], frame->linesize[2], av_get_pix_fmt_name(frame->format));
            if(frame->format == AV_PIX_FMT_NV12 || frame->format == AV_PIX_FMT_P010LE){
                for(int i=0; i<frame->height; i++ )
                    fwrite(frame->data[0] + i*frame->linesize[0], frame->width, 1, fp);
                for(int j=0; j<frame->height/2; j++)
                    fwrite(frame->data[1] + j*frame->linesize[1], frame->width, 1, fp);
            }else if(frame->format == AV_PIX_FMT_YUV420P){
                for(int i=0; i<frame->height; i++ )
                    fwrite(frame->data[0] + i*frame->linesize[0], frame->width, 1, fp);
                for(int j=0; j<frame->height/2; j++)
                    fwrite(frame->data[1] + j*frame->linesize[1], frame->width/2, 1, fp);
                for(int k=0; k<frame->height/2; k++)
                    fwrite(frame->data[2] + k*frame->linesize[2], frame->width/2, 1, fp);
            }else{
                av_log(ctx, AV_LOG_ERROR, "[%s@%d],dump avframe not support the fmt %s\n", __FUNCTION__, __LINE__, av_get_pix_fmt_name(frame->format));
            }
       }
   }
#endif

	av_frame_free(&frame);
	pp->num_of_output_pics++;

	//pp's 1 output link to spliter
	//TODO: PP's 4 outputs link to 4 hantro enc
  //for(int i = 0; i < ctx->nb_outputs; i++){
	for (int i = 0; i < NUM_OUT; i++) {	
		AVFilterLink *outlink = ctx->outputs[i];
		
		if (ff_outlink_get_status(outlink))
    	continue;

		ret = ff_filter_frame(outlink, buf_out);
		if (ret < 0) {
            return ret;
		}
	}


	return ret;

err_exit:
    return AVERROR_UNKNOWN;
}

static int hantro_trans_pp_formats(int format, char **pp_format, int *in_10bit, int *raw_format, int force_10bit)
{
	if(format == AV_PIX_FMT_YUV420P){
		*pp_format = "yuv420p";
		*raw_format = RAW_FMT_YUV420P;
		*in_10bit = 0;
	}else if(format == AV_PIX_FMT_YUV422P){
		*pp_format = "yuv422p";
		*raw_format = RAW_FMT_YUV422P;
		*in_10bit = 0;
	}else if(format == AV_PIX_FMT_NV12){
		*pp_format = "nv12";
		*raw_format = RAW_FMT_NV12;
		*in_10bit = 0;
	}else if(format == AV_PIX_FMT_NV21){
		*pp_format = "nv21";
		*raw_format = RAW_FMT_NV21;
		*in_10bit = 0;
	}else if(format == AV_PIX_FMT_YUV420P10LE){
		*pp_format = "yuv420p10le";
		*raw_format = RAW_FMT_YUV420P10LE;
		*in_10bit = 1;
	}else if(format == AV_PIX_FMT_YUV420P10BE){
		*pp_format = "yuv420p10be";
		*raw_format = RAW_FMT_YUV420P10BE;
		*in_10bit = 1;	
	}else if(format == AV_PIX_FMT_YUV422P10LE){
		*pp_format = "yuv422p10le";
		*raw_format = RAW_FMT_YUV422P10LE;
		*in_10bit = 1;
	}else if(format == AV_PIX_FMT_YUV422P10BE){
		*pp_format = "yuv422p10be";
		*raw_format = RAW_FMT_YUV422P10BE;
		*in_10bit = 1;
	}else if(format == AV_PIX_FMT_P010LE){
		*pp_format = "p010le";
		*raw_format = RAW_FMT_P010LE;
		*in_10bit = 1;
	}else if(format == AV_PIX_FMT_P010BE){
		*pp_format = "p010be";
		*raw_format = RAW_FMT_P010BE;
		*in_10bit = 1;
	}else if(format == AV_PIX_FMT_YUV444P){
		*pp_format = "yuv444p";
		*raw_format = RAW_FMT_YUV444P;
		*in_10bit = 0;
	}else if(format == AV_PIX_FMT_RGB24){
		*pp_format = "rgb24";
		*raw_format = RAW_FMT_RGB24;
		*in_10bit = 0;
		if(force_10bit)
			*in_10bit = 1;
	}else if(format == AV_PIX_FMT_BGR24){
		*pp_format = "bgr24";
		*raw_format = RAW_FMT_BGR24;
		*in_10bit = 0;
		if(force_10bit)
			*in_10bit = 1;
	}else if(format == AV_PIX_FMT_ARGB){
		*pp_format = "argb";
		*raw_format = RAW_FMT_ARGB;
		*in_10bit = 0;
		if(force_10bit)
			*in_10bit = 1;
	}else if(format == AV_PIX_FMT_RGBA){
		*pp_format = "rgba";
		*raw_format = RAW_FMT_RGBA;
		*in_10bit = 0;
		if(force_10bit)
			*in_10bit = 1;
	}else if(format == AV_PIX_FMT_ABGR){
		*pp_format = "abgr";
		*raw_format = RAW_FMT_ABGR;
		*in_10bit = 0;
		if(force_10bit)
			*in_10bit = 1;
	}else if(format == AV_PIX_FMT_BGRA){
		*pp_format = "bgra";
		*raw_format = RAW_FMT_BGRA;
		*in_10bit = 0;
		if(force_10bit)
			*in_10bit = 1;
	}else if(format == AV_PIX_FMT_HANTRO){
		*pp_format = "hantro";
		*raw_format = RAW_FMT_HANTRO;
		//*in_10bit = 1;
		if(force_10bit)
			*in_10bit = 1;
		}else{
		av_log(NULL, AV_LOG_ERROR, "Transcoder unsupport input format %s!!!\n", av_get_pix_fmt_name(format));
		return -1;
	}
	
	return 0;	
}

static void hantro_setup_defaul_params_pp(struct TestParams* params) 
{
  memset(params, 0, sizeof(struct TestParams));
  params->read_mode = STREAMREADMODE_FRAME;
  params->fscale_cfg.down_scale_x = 1;
  params->fscale_cfg.down_scale_y = 1;
  params->is_ringbuffer = 1;
  //params->force_output_8_bits = 0;
  //params->align = DEC_ALIGN_16B;
  params->display_cropped = 0;
  params->tile_by_tile = 0;
  params->mc_enable = 0;
  //params->cr_first = 0;
  //params->pp_tile_e = 0;
  //params->pp_planar = 0;
  memset(params->ppu_cfg, 0, sizeof(params->ppu_cfg));
}

static void *hantro_pp_set_params(HANTROPPFilterContext *s, AVFilterLink *inlink)
{
	int ret = 0;
	int pp_index = 0;
	
	struct TestParams *params = (struct TestParams *)av_malloc(sizeof(struct TestParams));
	if(NULL == params){
		av_log(s, AV_LOG_ERROR, "[%s,%d],can not malloc params\n", __FUNCTION__, __LINE__);
		return NULL;
	}

	//check resize and output numbers
    if (s->nb_outputs < 1 || s->nb_outputs > 4) {
        av_log(s, AV_LOG_ERROR, "outputs number error\n");
        return NULL;
    }

    av_log(s, AV_LOG_DEBUG, "s->nb_outputs = %d, s->resize_num = %d\n", s->nb_outputs, s->resize_num);

    if (s->nb_outputs == 1 && s->resize_num == 1
          && (s->resizes[0].x == 0 &&
              s->resizes[0].y == 0 &&
              s->resizes[0].cw == 0 &&
              s->resizes[0].ch == 0 &&
              s->resizes[0].sw == -2 &&
              s->resizes[0].sh == -2)) {

        av_log(s, AV_LOG_DEBUG, "set vce_ds_enable to 1\n");

        s->vce_ds_enable = 1;
        
        s->resizes[1] = s->resizes[0];
        
        s->resizes[0].x =
        s->resizes[0].y =
        s->resizes[0].cw =
        s->resizes[0].ch = 
        s->resizes[0].sw =
        s->resizes[0].sh = 0;
        
        s->resize_num++;
        
    } else if (s->nb_outputs == 1 && s->resize_num == 2) {
        
        if (!(s->resizes[0].x == s->resizes[1].x &&
              s->resizes[0].y == s->resizes[1].y &&
              s->resizes[0].cw == s->resizes[1].cw &&
              s->resizes[0].ch == s->resizes[1].ch &&
              s->resizes[1].sw == -2 &&
              s->resizes[1].sh == -2)) {
            av_log(s,AV_LOG_ERROR,"resize param error!\n");
            return NULL;
        }
              
        s->vce_ds_enable = 1;
    
    } else if (s->nb_outputs == s->resize_num + 1) {
        
		if (s->resize_num){
			for(int i = s->nb_outputs-1; i > 0; i--){
				s->resizes[i] = s->resizes[i-1];
			}
		}
        
		s->resizes[0].x = 
		s->resizes[0].y = 
		s->resizes[0].cw = 
		s->resizes[0].ch =
		s->resizes[0].sw = 
		s->resizes[0].sh = 0;

        s->resize_num++;
        
	} else if (s->nb_outputs != s->resize_num) {
        av_log(s, AV_LOG_ERROR, "resize param error!\n");
        return NULL;
    }

#if 0
	//try to fix 400x226 resolution align alloc less bug
	if(s->nb_outputs==1 && s->resize_num == 1){
		s->resizes[0].x = 
		s->resizes[0].y = 
		s->resizes[0].cw = 
		s->resizes[0].ch =
		s->resizes[0].sw = 
		s->resizes[0].sh = 0;
	}
#endif

	av_log(s, AV_LOG_DEBUG, "pp decoder resizes info summay:\n");
	for (int i = 0; i < s->resize_num; i++) {
    	av_log(s, AV_LOG_DEBUG, "resize %d : (%d,%d, %d,%d, %dx%d)\n", i,
            s->resizes[i].x, s->resizes[i].y, s->resizes[i].cw, s->resizes[i].ch, s->resizes[i].sw, s->resizes[i].sh);
    }

	//set TestParams params
	hantro_setup_defaul_params_pp(params);
	params->width = inlink->w;
	params->height= inlink->h;
	ret = hantro_trans_pp_formats(inlink->format, &params->in_format, &params->in_10bit, &s->raw_format,  s->force_10bit);
	if(ret < 0){
		av_log(s, AV_LOG_ERROR, "[%s,%d], input format failed! \n", __FUNCTION__, __LINE__);
		return NULL;
	}

  //upload link with pp, the frame format is hantro, it needs to decide 10bit or 8bit
  if(inlink->hw_frames_ctx){
    AVHWFramesContext *hwframe_ctx;
    AVHANTROFramesContext *frame_hwctx;
    u32 in_10bit_hantro_fmt = 0;

    //s->hwframe = av_buffer_ref(inlink->hw_frames_ctx);
    hwframe_ctx = (AVHWFramesContext*)inlink->hw_frames_ctx->data;
    frame_hwctx  = hwframe_ctx->hwctx;
    if( frame_hwctx->pic_info[0].picdata.pic_pixformat == 1)
      in_10bit_hantro_fmt = 1;

    if(!strcmp(params->in_format, "hantro") && in_10bit_hantro_fmt == 1)
      params->in_10bit = 1;
    
    //av_buffer_unref(&s->hwframe);
    av_log(s, AV_LOG_DEBUG, "%s(%d)inlink->hw_frames_ctx = %p,  in_10bit_hantro_fmt = %d, params->in_10bit = %d \n", __FUNCTION__, __LINE__, inlink->hw_frames_ctx, in_10bit_hantro_fmt, params->in_10bit );
  }
  
	params->align = DEC_ALIGN_1024B;
	params->compress_bypass = 0;
	params->cache_enable = 1;
	params->shaper_enable = 1; 
  
	params->dec_dev_name = NULL; //"/dev/transcoder0";
	params->mem_id = 0;
	params->priority = 0;

	//params->ext_buffers_need = 17 + s->buffer_depth;  //Superseded this params!!!
	
	/* set options to pp params */
    params->pp_enabled = 1;
    params->ppu_cfg[0].enabled  = 1;
    params->ppu_cfg[0].tiled_e  = 1;
    params->ppu_cfg[0].out_p010 = params->in_10bit;
    params->ppu_cfg[0].align = 10;
    params->ppu_cfg[0].shaper_enabled = 1;


	av_log(s, AV_LOG_DEBUG, "[%s, %d], pp test Params summary,width %d, height %d, in_format %s, in_10bit %d, raw_format %d\n", __FUNCTION__, __LINE__,
			params->width, params->height, params->in_format, params->in_10bit, s->raw_format);

	for (int i = 0; i < s->resize_num; i++) {
		if (s->resizes[i].x == 0 && s->resizes[i].y == 0 
				&& s->resizes[i].cw == 0 && s->resizes[i].ch == 0
				&& s->resizes[i].sw == 0 && s->resizes[i].sh == 0){
			continue;
		}
		av_log(s, AV_LOG_DEBUG,"pp %d resize %d get param\n", i, i);
		pp_index = i;
      	params->ppu_cfg[pp_index].enabled = 1;
      	params->ppu_cfg[pp_index].tiled_e = 1;

		////crop params
		if(!(s->resizes[i].x == 0 && s->resizes[i].y == 0
				&& s->resizes[i].cw == 0 && s->resizes[i].ch == 0)){
			if (!(params->width && params->height
					&& s->resizes[i].x == 0 && s->resizes[i].y == 0
					&& s->resizes[i].cw == params->width
					&& s->resizes[i].ch == params->height)) {
				params->ppu_cfg[pp_index].crop.enabled = 1;
				params->ppu_cfg[pp_index].crop.x = s->resizes[i].x;
				params->ppu_cfg[pp_index].crop.y = s->resizes[i].y;
				params->ppu_cfg[pp_index].crop.width  = s->resizes[i].cw;
				params->ppu_cfg[pp_index].crop.height = s->resizes[i].ch;
			}
		}
		//scale params
		if (!(s->resizes[i].sw == 0 && s->resizes[i].sh == 0)) {		
	 		params->ppu_cfg[pp_index].scale.enabled = 1;
			params->ppu_cfg[pp_index].scale.width  = s->resizes[i].sw;
		  params->ppu_cfg[pp_index].scale.height = s->resizes[i].sh;
	 	}
       	params->ppu_cfg[pp_index].out_p010 =  params->in_10bit;
       	params->ppu_cfg[pp_index].align = 10;
       	params->ppu_cfg[pp_index].shaper_enabled = 1;

		av_log(s, AV_LOG_DEBUG, "ppu_cfg[%d]:enabled %d, tiled_e %d, out_p010 %d, align %d, shaper_enabled %d, crop(enabled %d, %d %d, %dx%d), scale(enabled %d, %dx%d)\n",
			pp_index, params->ppu_cfg[pp_index].enabled, params->ppu_cfg[pp_index].tiled_e,params->ppu_cfg[pp_index].out_p010, params->ppu_cfg[pp_index].align, params->ppu_cfg[pp_index].shaper_enabled,
			params->ppu_cfg[pp_index].crop.enabled, params->ppu_cfg[pp_index].crop.x, params->ppu_cfg[pp_index].crop.y, params->ppu_cfg[pp_index].crop.width, params->ppu_cfg[pp_index].crop.height,
			params->ppu_cfg[pp_index].scale.enabled, params->ppu_cfg[pp_index].scale.width, params->ppu_cfg[pp_index].scale.height );

	}

	return params;
}


static int hantro_set_hwframe_res(HANTROPPFilterContext *s)
{
	AVHANTROFramesContext *frame_hwctx;
	AVHWFramesContext *hwframe_ctx;
    PpUnitConfig * ppu_cfg = s->pp_client->dec_cfg.ppu_config;


	hwframe_ctx = s->hwframe->data;
	av_log(NULL, AV_LOG_DEBUG, "[%s, %d]hwframe_ctx = %p\n", __FUNCTION__, __LINE__, hwframe_ctx);
	frame_hwctx = hwframe_ctx->hwctx;
	av_log(NULL, AV_LOG_DEBUG, "[%s, %d]frame_hwctx = %p\n", __FUNCTION__, __LINE__, frame_hwctx);


    pthread_mutex_lock(&frame_hwctx->opaque_mutex);
    frame_hwctx->opaque = s->pp_client;
    pthread_mutex_unlock(&frame_hwctx->opaque_mutex);
	
	frame_hwctx->pic_info[0].enabled = 1;

    dump_ppuconfig(NULL, ppu_cfg);
		
	if (ppu_cfg[0].scale.width < s->params->width) {
        frame_hwctx->pic_info[0].width   = ppu_cfg[0].scale.width;
    } else {
		frame_hwctx->pic_info[0].width	 = s->params->width;   //params->ppu_cfg[0].scale.width;
    }
    if (ppu_cfg[0].scale.height < s->params->height) {
		frame_hwctx->pic_info[0].height  = ppu_cfg[0].scale.height;
	}else{
		frame_hwctx->pic_info[0].height  = s->params->height;  //params->ppu_cfg[0].scale.height;
	}

    frame_hwctx->pic_info[0].pic_width = ppu_cfg[0].scale.width;
    frame_hwctx->pic_info[0].pic_height = ppu_cfg[0].scale.height;
    
	frame_hwctx->pic_info[0].picdata.is_interlaced = 0;
	frame_hwctx->pic_info[0].picdata.pic_format = 0;

    if (s->params->in_10bit) {
    	frame_hwctx->pic_info[0].picdata.pic_pixformat = 1;
    	frame_hwctx->pic_info[0].picdata.bit_depth_luma = frame_hwctx->pic_info[0].picdata.bit_depth_chroma = 10;
    } else {
    	frame_hwctx->pic_info[0].picdata.pic_pixformat = 0;
    	frame_hwctx->pic_info[0].picdata.bit_depth_luma = frame_hwctx->pic_info[0].picdata.bit_depth_chroma = 8;
    }
	frame_hwctx->pic_info[0].picdata.pic_compressed_status = 2;

	frame_hwctx->pic_info[1].enabled = 0;


	for (int i = 2; i < 5; i++) {	
		if(s->params->ppu_cfg[i-1].enabled == 1){
			frame_hwctx->pic_info[i].enabled = 1;
			frame_hwctx->pic_info[i].width	=  ppu_cfg[i-1].scale.width;
			frame_hwctx->pic_info[i].height =  ppu_cfg[i-1].scale.height;


            frame_hwctx->pic_info[i].picdata.is_interlaced = 0;
            frame_hwctx->pic_info[i].picdata.pic_format = 0;
            if (s->params->in_10bit) {
                frame_hwctx->pic_info[i].picdata.pic_pixformat = 1;
                frame_hwctx->pic_info[i].picdata.bit_depth_luma = frame_hwctx->pic_info[i].picdata.bit_depth_chroma = 10;
            } else {
                frame_hwctx->pic_info[i].picdata.pic_pixformat = 0;
                frame_hwctx->pic_info[i].picdata.bit_depth_luma = frame_hwctx->pic_info[i].picdata.bit_depth_chroma = 8;
            }

            frame_hwctx->pic_info[i].picdata.pic_compressed_status = 2;
		}
	}

	av_log(NULL, AV_LOG_DEBUG, "[%s,%d]:output frames:[%d(%dx%d)][%d(%dx%d)][%d(%dx%d)][%d(%dx%d)][%d(%dx%d)]\n", __FUNCTION__, __LINE__,
			   frame_hwctx->pic_info[0].enabled, frame_hwctx->pic_info[0].width, frame_hwctx->pic_info[0].height,
			   frame_hwctx->pic_info[1].enabled, frame_hwctx->pic_info[1].width, frame_hwctx->pic_info[1].height,
			   frame_hwctx->pic_info[2].enabled, frame_hwctx->pic_info[2].width, frame_hwctx->pic_info[2].height,
			   frame_hwctx->pic_info[3].enabled, frame_hwctx->pic_info[3].width, frame_hwctx->pic_info[3].height,
			   frame_hwctx->pic_info[4].enabled, frame_hwctx->pic_info[4].width, frame_hwctx->pic_info[4].height);

    if (s->vce_ds_enable) {
        if (!frame_hwctx->pic_info[0].enabled || !frame_hwctx->pic_info[2].enabled) {
            av_log(s, AV_LOG_ERROR, "When use 1/4 ds pass1 for vce, pp0 and pp1 should be enabled!\n");
            return -1;
        }
        if (frame_hwctx->pic_info[1].enabled || frame_hwctx->pic_info[3].enabled || frame_hwctx->pic_info[4].enabled) {
            av_log(s, AV_LOG_ERROR, "When use 1/4 ds pass1 for vce, except pp0 and pp1 should not be enabled!\n");
            return -1;
        }
        av_log(s, AV_LOG_DEBUG, "set flag to 1\n");
        frame_hwctx->pic_info[2].flag = 1;
    }

	return 0;
}

static int hantro_pp_config_props(AVFilterLink *inlink)
{
	AVFilterContext *ctx = inlink->dst;	
	HANTROPPFilterContext *s = ctx->priv;
	int ret = 0;
    
    av_log(ctx, AV_LOG_TRACE, "%s(%d)\n", __FUNCTION__, __LINE__);
    av_log(ctx, AV_LOG_DEBUG, "%s(%d)inlink->w = %d, inlink->h = %d\n", __FUNCTION__, __LINE__, inlink->w, inlink->h);

	ret = hantro_pp_parse_resize(s);
	if(ret < 0){
		av_log(ctx, AV_LOG_ERROR, "%s(%d), can not parse pp resize parms!\n", __FUNCTION__, __LINE__);
		goto error_exit;
	}
	av_log(ctx, AV_LOG_DEBUG, "%s(%d),ctx %p, s %p, nb_outputs %d, resize_num %d\n", __FUNCTION__, __LINE__, ctx, s,  s->nb_outputs, s->resize_num);

	s->params = hantro_pp_set_params(s, inlink);
	if(NULL == s->params){
		av_log(ctx, AV_LOG_ERROR, "%s(%d), init pp params failed !\n", __FUNCTION__, __LINE__);
		goto error_exit;
	}

	ret = hantro_pp_init_hwctx(ctx, inlink, s->params);
	if(ret < 0){
		av_log(ctx, AV_LOG_ERROR, "%s(%d), hantro_pp_init_hwctx failed !\n", __FUNCTION__, __LINE__);
		goto error_exit;
	}

	s->mwl = TransDemuxerInit(s->params);		
	if(!s->mwl){
		av_log(ctx, AV_LOG_ERROR, "%s(%d), TransDemuxerInit failed !\n", __FUNCTION__, __LINE__);
		goto error_exit;
	}

	s->inst = RawParserOpen((enum RAW_FORMAT)s->raw_format, s->params->width,  s->params->height);
	if(!s->inst){
		av_log(ctx, AV_LOG_ERROR, "%s(%d), RawParserOpen failed !\n", __FUNCTION__, __LINE__);
		goto error_exit;
	}

	s->pp_client  = hantro_ppclient_init(s->params, s);		
	if(!s->pp_client){
		av_log(ctx, AV_LOG_ERROR, "%s(%d), DemoPPInit failed, can not get ppclient !\n", __FUNCTION__, __LINE__);
		goto error_exit;
	}
	
	ret = hantro_set_hwframe_res(s);
	if(ret < 0){
		av_log(ctx, AV_LOG_ERROR, "%s(%d), hantro_set_hwframe_res failed!\n", __FUNCTION__, __LINE__);
		goto error_exit;
	}	

	ret = hantro_pp_input_buf_init(s);
	if(ret < 0){
		av_log(ctx, AV_LOG_ERROR, "%s(%d), TransDemuxerLoop_BindbBuf failed, can not get ppclient !\n", __FUNCTION__, __LINE__);
		goto error_exit;
	}
#if 0
	av_log(ctx, AV_LOG_ERROR, "%s(%d), force error\n", __FUNCTION__, __LINE__);
	goto error_exit;
#endif
	av_log(ctx, AV_LOG_DEBUG, "%s(%d), nb_outputs %d, s %p\n", __FUNCTION__, __LINE__, s->nb_outputs,  s);

	return 0;

error_exit:
    return AVERROR_UNKNOWN;
}


#define OFFSET(x) offsetof(HANTROPPFilterContext, x)
#define FLAGS (AV_OPT_FLAG_VIDEO_PARAM | AV_OPT_FLAG_FILTERING_PARAM)
static const AVOption hantro_pp_options[] = {
		{ "outputs", "set number of outputs", OFFSET(nb_outputs), AV_OPT_TYPE_INT, {.i64 = 1}, 1, 4, FLAGS},
		{ "resizes", "specific resize config for up to 4 outputs with resize string syntax", OFFSET(str_resizes), AV_OPT_TYPE_STRING, {.str=NULL}, .flags = FLAGS},
		{ "force10bit", "for RGB colour space pp can do force 8bit to 10bit",  OFFSET(force_10bit), AV_OPT_TYPE_INT,  {.i64 = 0}, 0, 1, FLAGS},
		//{ "buffer-depth", "set the pp allocate raw buffer for enc 2pass lookaheadDepath", OFFSET(buffer_depth), AV_OPT_TYPE_INT, {.i64 = 0}, 0, 40, FLAGS},
#ifdef PP_MEM_ERR_TEST
		{ "pp_mem_err_test", "pp filter error process test", OFFSET(memory_err_shadow), AV_OPT_TYPE_INT, {.i64 = -1}, -1, 10000, FLAGS},
#endif
#ifdef PP_EDMA_ERR_TEST
		{ "pp_edma_err_test", "pp filter edma error process test", OFFSET(edma_err_shadow), AV_OPT_TYPE_INT, {.i64 = -1}, -1, 10000, FLAGS},
#endif
		{ NULL }
};


AVFILTER_DEFINE_CLASS(hantro_pp);

static const AVFilterPad hantro_pp_inputs[] = {
    {
        .name         = "default",
        .type         = AVMEDIA_TYPE_VIDEO,
        .filter_frame = hantro_pp_filter_frame,
        .config_props = hantro_pp_config_props,
    },
    { NULL }
};

AVFilter ff_vf_hantro_pp = {
    .name           = "hantro_pp",
    .description    = NULL_IF_CONFIG_SMALL("Filter using hantro postproc."),
    .priv_size      = sizeof(HANTROPPFilterContext),
    .priv_class     = &hantro_pp_class,
    .init           = hantro_pp_init,
    .uninit         = hantro_pp_uninit,
    .query_formats  = hantro_pp_query_formats,
    .inputs         = hantro_pp_inputs,
    .outputs        = NULL,
    .flags          = AVFILTER_FLAG_DYNAMIC_OUTPUTS,
};
