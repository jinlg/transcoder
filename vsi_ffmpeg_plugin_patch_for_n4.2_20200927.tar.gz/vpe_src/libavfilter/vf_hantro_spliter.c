/**
 * hantro video spliter - kwu
 */

#include <stdio.h>

#include "libavutil/attributes.h"
#include "libavutil/internal.h"
#include "libavutil/mem.h"
#include "libavutil/opt.h"
#include "libavutil/hwcontext_hantro.h"

#include "avfilter.h"
#include "audio.h"
#include "filters.h"
#include "formats.h"
#include "internal.h"
#include "video.h"

#include "dectypes.h"

enum {
  HANTRO_DEC_OUT_RFC,
  HANTRO_DEC_OUT_PP0,
  HANTRO_DEC_OUT_PP1,
  HANTRO_DEC_OUT_PP2,
  HANTRO_DEC_OUT_PP3,
  HANTRO_DEC_OUT_NUM
};


typedef struct HANTROSpliterFilterContext {
    const AVClass *class;
    int nb_outputs;
    struct {
        int enabled;
        int out_index;
        int flag;
        AVHANTROFormat format;
        int width;
        int height;
        struct {
            int enabled;
            int x;
            int y;
            int w;
            int h;
        } crop;
        struct {
            int enabled;
            int w;
            int h;
        } scale;
    } pic_info[HANTRO_DEC_OUT_NUM];
} HANTROSpliterFilterContext;


static int hantro_spliter_out_config_props(AVFilterLink *outlink);


static av_cold int hantro_spliter_init(AVFilterContext *ctx)
{
    HANTROSpliterFilterContext *s = ctx->priv;
    int i, ret;
	av_log(ctx, AV_LOG_DEBUG, "%s(%d)\n", __FUNCTION__, __LINE__);
	av_log(ctx, AV_LOG_DEBUG, "%s(%d)ctx->hw_device_ctx = %p\n", __FUNCTION__, __LINE__, ctx->hw_device_ctx);
    
    for (i = 0; i < s->nb_outputs; i++) {
        char name[32];
        AVFilterPad pad = { 0 };

        snprintf(name, sizeof(name), "output%d", i);
        pad.type = AVMEDIA_TYPE_VIDEO;
        pad.name = av_strdup(name);
        if (!pad.name)
            return AVERROR(ENOMEM);
        pad.config_props = hantro_spliter_out_config_props;

        if ((ret = ff_insert_outpad(ctx, i, &pad)) < 0) {
            av_freep(&pad.name);
            return ret;
        }
    }

    for (i = 0; i < HANTRO_DEC_OUT_NUM; i++) {
        s->pic_info[i].out_index = -1;
    }
   
    return 0;
}

static av_cold void hantro_spliter_uninit(AVFilterContext *ctx)
{
    int i;

	av_log(ctx, AV_LOG_DEBUG, "%s(%d)\n", __FUNCTION__, __LINE__);

    for (i = 0; i < ctx->nb_outputs; i++)
        av_freep(&ctx->output_pads[i].name);
}

static int hantro_spliter_config_props(AVFilterLink *inlink)
{
    AVFilterContext * src = inlink->src;
    AVHWFramesContext *hwframe_ctx;
    AVHANTROFramesContext * frame_hwctx;
    AVFilterContext * dst = inlink->dst;
    HANTROSpliterFilterContext *s = dst->priv;
    int i;

    av_log(src, AV_LOG_DEBUG, "inlink = %p\n", inlink);
    av_log(src, AV_LOG_DEBUG, "%s %dx%d\n", __FUNCTION__, inlink->w, inlink->h);
    av_log(src, AV_LOG_DEBUG, "inlink->hw_frames_ctx = %p\n", inlink->hw_frames_ctx);
	av_log(src, AV_LOG_DEBUG, "%s(%d)src->hw_device_ctx = %p\n", __FUNCTION__, __LINE__, src->hw_device_ctx);
    av_log(src, AV_LOG_DEBUG, "dst->priv = %p\n", dst->priv);

    if (!inlink->hw_frames_ctx) //for ffplay
        return 0;

    hwframe_ctx = inlink->hw_frames_ctx->data;
    av_log(src, AV_LOG_DEBUG, "hwframe_ctx = %p\n", hwframe_ctx);

    if (!hwframe_ctx) {
        av_log(src, AV_LOG_ERROR, "hwframe_ctx is nil\n");
        return -1;
    }

    frame_hwctx = hwframe_ctx->hwctx;
    av_log(src, AV_LOG_DEBUG, "frame_hwctx = %p\n", frame_hwctx);

    if (!frame_hwctx) {
        av_log(src, AV_LOG_ERROR, "frame_hwctx is nil\n");
        return -1;
    }
    av_log(src, AV_LOG_DEBUG, "[%d(%dx%d)][%d(%dx%d)][%d(%dx%d)][%d(%dx%d)][%d(%dx%d)]\n", 
            frame_hwctx->pic_info[0].enabled, frame_hwctx->pic_info[0].width, frame_hwctx->pic_info[0].height,
            frame_hwctx->pic_info[1].enabled, frame_hwctx->pic_info[1].width, frame_hwctx->pic_info[1].height,
            frame_hwctx->pic_info[2].enabled, frame_hwctx->pic_info[2].width, frame_hwctx->pic_info[2].height,
            frame_hwctx->pic_info[3].enabled, frame_hwctx->pic_info[3].width, frame_hwctx->pic_info[3].height,
            frame_hwctx->pic_info[4].enabled, frame_hwctx->pic_info[4].width, frame_hwctx->pic_info[4].height);
    av_log(src, AV_LOG_DEBUG, "frame_hwctx->pic_info[0].picdata.pic_compressed_status = %d.\n", frame_hwctx->pic_info[0].picdata.pic_compressed_status);

    for (i = 0; i < HANTRO_DEC_OUT_NUM; i++) {
        s->pic_info[i].enabled = frame_hwctx->pic_info[i].enabled;
        s->pic_info[i].flag = frame_hwctx->pic_info[i].flag;
        s->pic_info[i].width = frame_hwctx->pic_info[i].width;
        s->pic_info[i].height = frame_hwctx->pic_info[i].height;
    }
    s->pic_info[0].crop.enabled = frame_hwctx->pic_info[0].crop.enabled;
    s->pic_info[0].crop.x = frame_hwctx->pic_info[0].crop.x;
    s->pic_info[0].crop.y = frame_hwctx->pic_info[0].crop.y;
    s->pic_info[0].crop.w = frame_hwctx->pic_info[0].crop.w;
    s->pic_info[0].crop.h = frame_hwctx->pic_info[0].crop.h;
    
    av_log(src, AV_LOG_DEBUG, "[%d(%dx%d[%d(%d,%d,%d,%d)])][%d(%dx%d)][%d(%dx%d)][%d(%dx%d)][%d(%dx%d)]\n", 
                    s->pic_info[0].enabled, s->pic_info[0].width, s->pic_info[0].height,
                    s->pic_info[0].crop.enabled, s->pic_info[0].crop.x, s->pic_info[0].crop.y,
                                                 s->pic_info[0].crop.w, s->pic_info[0].crop.h,
                    s->pic_info[1].enabled, s->pic_info[1].width, s->pic_info[1].height,
                    s->pic_info[2].enabled, s->pic_info[2].width, s->pic_info[2].height,
                    s->pic_info[3].enabled, s->pic_info[3].width, s->pic_info[3].height,
                    s->pic_info[4].enabled, s->pic_info[4].width, s->pic_info[4].height);
    
    return 0;
}

static int hantro_spliter_out_config_props(AVFilterLink *outlink)
{
    AVFilterContext * src = outlink->src;
    HANTROSpliterFilterContext *s = src->priv;
    int out_index, pp_index, ret, j;
    AVHWFramesContext *hwframe_ctx, *hwframe_ctx0;
    AVHANTROFramesContext *frame_hwctx, *frame_hwctx0;

    av_log(src, AV_LOG_DEBUG, "outlink = %p\n", outlink);
    av_log(src, AV_LOG_DEBUG, "enter %s, outlink->w = %d, outlink->h = %d\n", __FUNCTION__, outlink->w, outlink->h);
    av_log(src, AV_LOG_DEBUG, "outlink->srcpad->name = %s\n", outlink->srcpad->name);
    av_log(src, AV_LOG_DEBUG, "s = %p, outlink->dst = %p\n", s, outlink->dst);
    av_log(src, AV_LOG_DEBUG, "src->inputs[0] = %p\n", src->inputs[0]);
    av_log(src, AV_LOG_DEBUG, "outlink->hw_frames_ctx = %p\n", outlink->hw_frames_ctx);
    av_log(src, AV_LOG_DEBUG, "src->inputs[0]->hw_frames_ctx = %p\n", src->inputs[0]->hw_frames_ctx);
    
	av_log(src, AV_LOG_DEBUG, "%s(%d)src->hw_device_ctx = %p\n", __FUNCTION__, __LINE__, src->hw_device_ctx);
    av_log(src, AV_LOG_DEBUG, "%s(%d)outlink->srcpad->filter_frame = %p\n", __FUNCTION__, __LINE__, outlink->srcpad->filter_frame);
    
    av_log(src, AV_LOG_DEBUG, "[%d(%dx%d)][%d(%dx%d)][%d(%dx%d)][%d(%dx%d)][%d(%dx%d)]\n", 
                    s->pic_info[0].enabled, s->pic_info[0].width, s->pic_info[0].height,
                    s->pic_info[1].enabled, s->pic_info[1].width, s->pic_info[1].height,
                    s->pic_info[2].enabled, s->pic_info[2].width, s->pic_info[2].height,
                    s->pic_info[3].enabled, s->pic_info[3].width, s->pic_info[3].height,
                    s->pic_info[4].enabled, s->pic_info[4].width, s->pic_info[4].height);

    av_log(src, AV_LOG_DEBUG, "outlink = %p\n", outlink);
    
    av_log(src, AV_LOG_DEBUG, "src->nb_outputs = %d\n", src->nb_outputs);

    if (!src->inputs[0]->hw_frames_ctx) //for ffplay
        return 0;

    hwframe_ctx0 = src->inputs[0]->hw_frames_ctx->data;
    if (!hwframe_ctx0) {
        av_log(src, AV_LOG_ERROR, "hwframe_ctx0 is nil\n");
        return -1;
    }
    frame_hwctx0 = (AVHANTROFramesContext *)hwframe_ctx0->hwctx;
    if (!frame_hwctx0) {
        av_log(src, AV_LOG_ERROR, "frame_hwctx0 is nil\n");
        return -1;
    }
    
    ret = av_hwframe_ctx_create_derived(&outlink->hw_frames_ctx,
        AV_HWDEVICE_TYPE_HANTRO, hwframe_ctx0->device_ref, src->inputs[0]->hw_frames_ctx, 0);
    if (ret) {
        av_log(src, AV_LOG_ERROR, "av_hwframe_ctx_create_derived failed\n");
        return ret;
    }
    av_log(src, AV_LOG_DEBUG, "%s(%d)outlink->hw_frames_ctx = %p\n", __FUNCTION__, __LINE__, outlink->hw_frames_ctx);
    
    hwframe_ctx = outlink->hw_frames_ctx->data;
    frame_hwctx = (AVHANTROFramesContext *)hwframe_ctx->hwctx;
    av_log(src, AV_LOG_DEBUG, "%s(%d)frame_hwctx->task_id = %d\n", __FUNCTION__, __LINE__, frame_hwctx->task_id);
    av_log(src, AV_LOG_DEBUG, "frame_hwctx->pic_info[0].picdata.pic_compressed_status = %d.\n", frame_hwctx->pic_info[0].picdata.pic_compressed_status);

    
    for (out_index = 0; out_index < src->nb_outputs; out_index++) {
        av_log(src, AV_LOG_DEBUG, "src->outputs[%d] = %p\n", out_index, src->outputs[out_index]);
        if (outlink == src->outputs[out_index])
            break;
    }
    if (out_index == src->nb_outputs) {
        av_log(src, AV_LOG_ERROR, "can't find output\n");
        return -1;
    }
    av_log(src, AV_LOG_DEBUG, "select output %d\n", out_index);

    for (pp_index = 4; pp_index >= 0; pp_index--) {
        av_log(src, AV_LOG_DEBUG, "s->pic_info[%d].flag = %d\n", pp_index, s->pic_info[pp_index].flag);
        if (s->pic_info[pp_index].enabled && !s->pic_info[pp_index].flag && s->pic_info[pp_index].out_index == -1) {
            break;
        }
    }
    av_log(src, AV_LOG_DEBUG, "match pp_index %d\n", pp_index);

    for (j = 0; j < HANTRO_DEC_OUT_NUM; j++) {
        if (j == pp_index)
            continue;
        if (frame_hwctx->pic_info[j].flag)
            continue;
        frame_hwctx->pic_info[j].enabled = 0;
        av_log(src, AV_LOG_DEBUG, "disable pic_info %d\n", j);
    }
    
    outlink->w = s->pic_info[pp_index].width;
    outlink->h = s->pic_info[pp_index].height;
    s->pic_info[pp_index].out_index = out_index;

    av_log(src, AV_LOG_DEBUG, "outlink->w = %d, outlink->h = %d\n", outlink->w, outlink->h);
    
    return 0;
}


static int hantro_spliter_query_formats(AVFilterContext *ctx)
{
    static const enum AVPixelFormat pix_fmts[] = {
        AV_PIX_FMT_HANTRO,
        AV_PIX_FMT_NONE
    };
    
    av_log(ctx, AV_LOG_DEBUG, "%s(%d)\n", __FUNCTION__, __LINE__);
	av_log(ctx, AV_LOG_DEBUG, "%s(%d)ctx->hw_device_ctx = %p\n", __FUNCTION__, __LINE__, ctx->hw_device_ctx);

    AVFilterFormats *fmts_list = ff_make_format_list(pix_fmts);
    if (!fmts_list)
        return AVERROR(ENOMEM);
    
    return ff_set_common_formats(ctx, fmts_list);
} 


static int hantro_spliter_filter_frame(AVFilterLink *inlink, AVFrame *frame)
{
    AVFilterContext *ctx = inlink->dst;
    HANTROSpliterFilterContext *s = ctx->priv;
    int i, j, pp_index, ret = AVERROR_UNKNOWN;
    struct DecPicturePpu *pic;
    AVHWFramesContext *hwframe_ctx, *hwframe_ctx0;
    AVHANTROFramesContext *frame_hwctx, *frame_hwctx0;
    
    av_log(ctx, AV_LOG_DEBUG, "%s(%d)inlink = %p\n", __FUNCTION__, __LINE__, inlink);
    av_log(ctx, AV_LOG_DEBUG, "%s(%d)s = %p\n", __FUNCTION__, __LINE__, s);
	av_log(ctx, AV_LOG_DEBUG, "%s(%d)ctx->hw_device_ctx = %p\n", __FUNCTION__, __LINE__, ctx->hw_device_ctx);

    pic = (struct DecPicturePpu *) frame->data[0];
    av_log(ctx, AV_LOG_DEBUG, "%s(%d)pic = %p\n", __FUNCTION__, __LINE__, pic);
    pp_index = 0;

    for (i = 0; i < ctx->nb_outputs; i++) {
        AVFrame *buf_out;

        if (ff_outlink_get_status(ctx->outputs[i]))
            continue;

        av_log(ctx, AV_LOG_TRACE, "ctx->outputs[%d] = %p\n", i, ctx->outputs[i]);

        if (ctx->inputs[0]->hw_frames_ctx) {

            hwframe_ctx0 = ctx->inputs[0]->hw_frames_ctx->data;
            frame_hwctx0 = (AVHANTROFramesContext *)hwframe_ctx0->hwctx;
            
            for (pp_index = 0; pp_index < HANTRO_DEC_OUT_NUM; pp_index++) {
                if (i == s->pic_info[pp_index].out_index)
                    break;
            }
            if (pp_index == HANTRO_DEC_OUT_NUM) {
                av_log(ctx, AV_LOG_ERROR, "can't find pp_index\n");
                ret = AVERROR_UNKNOWN;
                goto err_exit;
            }
            av_log(ctx, AV_LOG_DEBUG, "find pp_index = %d\n", pp_index);

            av_log(ctx, AV_LOG_DEBUG, "ctx->outputs[%d]->hw_frames_ctx = %p\n", i, ctx->outputs[i]->hw_frames_ctx);
            if (ctx->outputs[i]->hw_frames_ctx) {
                hwframe_ctx = ctx->outputs[i]->hw_frames_ctx->data;
                av_log(ctx, AV_LOG_DEBUG, "hwframe_ctx = %p\n", hwframe_ctx);
            } else {
                av_log(ctx, AV_LOG_ERROR, "can't get output hw_frames_ctx\n");
                goto err_exit;
            }

            frame_hwctx = (AVHANTROFramesContext *)hwframe_ctx->hwctx;

            av_log(ctx, AV_LOG_DEBUG, "s->pic_info[%d].width = %d\n", pp_index, s->pic_info[pp_index].width);
            av_log(ctx, AV_LOG_DEBUG, "s->pic_info[%d].height = %d\n", pp_index, s->pic_info[pp_index].height);

            av_log(ctx, AV_LOG_DEBUG, "frame_hwctx->pic_info[%d].width = %d\n", pp_index, frame_hwctx->pic_info[pp_index].width);
            av_log(ctx, AV_LOG_DEBUG, "frame_hwctx->pic_info[%d].height = %d\n", pp_index, frame_hwctx->pic_info[pp_index].height);

            av_log(ctx, AV_LOG_DEBUG, "frame_hwctx0->pic_info[%d].width = %d\n", pp_index, frame_hwctx0->pic_info[pp_index].width);
            av_log(ctx, AV_LOG_DEBUG, "frame_hwctx0->pic_info[%d].height = %d\n", pp_index, frame_hwctx0->pic_info[pp_index].height);
            av_log(ctx, AV_LOG_DEBUG, "frame_hwctx0->pic_info[%d].picdata.crop_out_width = %d\n", pp_index, frame_hwctx0->pic_info[pp_index].picdata.crop_out_width);
            av_log(ctx, AV_LOG_DEBUG, "frame_hwctx0->pic_info[%d].picdata.crop_out_height = %d\n", pp_index, frame_hwctx0->pic_info[pp_index].picdata.crop_out_height);

            //memcpy(frame_hwctx, frame_hwctx0, sizeof(AVHANTROFramesContext));
            //frame_hwctx->pic_info[pp_index].width = frame_hwctx0->pic_info[pp_index].width;
            //frame_hwctx->pic_info[pp_index].height = frame_hwctx0->pic_info[pp_index].height;
            //frame_hwctx->pic_info[pp_index].picdata.crop_out_width = frame_hwctx0->pic_info[pp_index].picdata.crop_out_width;
            //frame_hwctx->pic_info[pp_index].picdata.crop_out_height = frame_hwctx0->pic_info[pp_index].picdata.crop_out_height;
        }
        
        if (i > 0) {
        	buf_out = av_frame_alloc();
            if (!buf_out) {
                ret = AVERROR(ENOMEM);
                goto err_exit;
            }
            ret = av_frame_ref(buf_out, frame);
            if (ret < 0) {
                goto err_exit;
            }

            if (ctx->inputs[0]->hw_frames_ctx) {
                av_buffer_unref(&buf_out->hw_frames_ctx);
                buf_out->hw_frames_ctx = av_buffer_ref(ctx->outputs[i]->hw_frames_ctx);
                if (buf_out->hw_frames_ctx == NULL) {
                    ret = AVERROR(ENOMEM);
                    goto err_exit;
                }
            }
        
            //av_log(ctx, AV_LOG_DEBUG, "frame ref count %d for %p\n", av_buffer_get_ref_count(frame->buf[0]), frame->buf[0]->data);
            //av_log(ctx, AV_LOG_DEBUG, "frame ref count %d for %p\n", av_buffer_get_ref_count(buf_out->buf[0]), buf_out->buf[0]->data);

        } else {
            buf_out = frame;
        }
        
        ret = ff_filter_frame(ctx->outputs[i], buf_out);
        if (ret < 0) {
            goto err_exit;
        }

    }

err_exit:

    //av_log(ctx, AV_LOG_DEBUG, "%s(%d) frame ref count %d for %p\n",  __FUNCTION__, __LINE__, av_buffer_get_ref_count(frame->buf[0]), frame->buf[0]->data);
    av_log(ctx, AV_LOG_DEBUG, "frame %p frame->buf[0] %p\n", frame, frame->buf[0]);
    //av_log(ctx, AV_LOG_DEBUG, "frame ref count %d for %p\n", av_buffer_get_ref_count(frame->buf[0]), frame->buf[0]->data);
    
  	av_log(ctx, AV_LOG_DEBUG, "%s(%d) ret = %d\n", __FUNCTION__, __LINE__, ret);
    
    return ret;
}

#define OFFSET(x) offsetof(HANTROSpliterFilterContext, x)
#define FLAGS (AV_OPT_FLAG_VIDEO_PARAM | AV_OPT_FLAG_FILTERING_PARAM)
static const AVOption hantro_spliter_options[] = {
    { "outputs", "set number of outputs", OFFSET(nb_outputs), AV_OPT_TYPE_INT, { .i64 = 1 }, 1, 4, FLAGS},
    { NULL }
};


AVFILTER_DEFINE_CLASS(hantro_spliter);

static const AVFilterPad hantro_spliter_inputs[] = {
    {
        .name         = "default",
        .type         = AVMEDIA_TYPE_VIDEO,
        .config_props = hantro_spliter_config_props,
        .filter_frame = hantro_spliter_filter_frame,
    },
    { NULL }
};

AVFilter ff_vf_hantro_spliter = {
    .name           = "hantro_spliter",
    .description    = NULL_IF_CONFIG_SMALL("Filter to split pictures generated by hantro postproc."),
    .priv_size      = sizeof(HANTROSpliterFilterContext),
    .priv_class     = &hantro_spliter_class,
    .init           = hantro_spliter_init,
    .uninit         = hantro_spliter_uninit,
    .query_formats  = hantro_spliter_query_formats,
    .inputs         = hantro_spliter_inputs,
    .outputs        = NULL,
    .flags          = AVFILTER_FLAG_DYNAMIC_OUTPUTS,
    .flags_internal = FF_FILTER_FLAG_HWFRAME_AWARE,
};


