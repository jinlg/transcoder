#ifndef FILTER_HANTRO_PP_H
#define FILTER_HANTRO_PP_H

#include "ppapi.h"
#include "ppinternal.h"
#include "dwl.h"
#include "dwlthread.h"
#include "fifo.h"

#include "libavcodec/hantro_dec_tb_defs.h"
#include "libavcodec/hantro_dec_common.h"

#ifdef SUPPORT_TCACHE
#include "fb_ips.h"
#ifdef DRV_NEW_ARCH
#include "transcoder.h"
#else
#include "trans_edma.h"
#endif
#include "tcache_api.h"
#endif

#include "trans_edma_api.h"
#include "trans_mem_api.h"


#ifdef FB_SYSLOG_ENABLE
#include "syslog_sink.h"

#define PP_INFO_PRINT(fmt, ...) FB_SYSLOG(pp,SYSLOG_SINK_LEV_INFO,fmt, ## __VA_ARGS__)
#define PP_ERROR_PRINT(fmt, ...) FB_SYSLOG(pp,SYSLOG_SINK_LEV_ERROR,"%s([%d]): " fmt,\
                                    __FUNCTION__, __LINE__, ## __VA_ARGS__)
#define PP_DEBUGV_PRINT(fmt, ...) FB_SYSLOG(pp,SYSLOG_SINK_LEV_DEBUG_SW_VERBOSE,"%s([%d]): " fmt,\
                                    __FUNCTION__, __LINE__, ## __VA_ARGS__)

#define DEBUG_PRINT(fmt, ...) FB_SYSLOG(mwl,SYSLOG_SINK_LEV_DEBUG_SW,"%s([%d]): " fmt,\
                                    __FUNCTION__, __LINE__, ## __VA_ARGS__)
#define ERROR_PRINT(fmt, ...)  FB_SYSLOG(mwl,SYSLOG_SINK_LEV_ERROR,"%s([%d]): " fmt,\
                                    __FUNCTION__, __LINE__, ## __VA_ARGS__)

#else
#ifdef DEBUG_PRINT_EN
#define DEBUG_PRINT(fmt, ...) printf("%s(%s[%d]): " fmt,\
                                    __FILE__, __FUNCTION__, __LINE__, ## __VA_ARGS__);
#else
#define DEBUG_PRINT(fmt, ...)
#endif
#endif


#define NEXT_MULTIPLE(value, n) (((value) + (n) - 1) & ~((n) - 1))
#define ALIGN(a) (1 << (a))

//#define OUTPUT_BUF_DEPTH 50
#define OUTPUT_BUF_DEPTH 68 /* support VCE lookaheadDepth 40 */
#define PP_IN_HEIGHT_ALIGN 8
#define PP_OUT_HEIGHT_ALIGN 4
#define PP_FETCH_ALIGN 32

typedef struct {
  u32 in_width;
  u32 in_height;
  u32 in_width_align;
  u32 in_stride;
  u32 in_height_align;
  u32 align; // for pp output
  u32 max_num_pics;
  u32 frame_size;
  int in_p010;
  int compress_bypass;
  int cache_enable;
  int shaper_enable;
  int pp_enabled;
  int out_p010;
#if 0
  u32 md5sum;
  u32 pixel_width;
  u32 pixel_width_pp;
  /* user input arguments */
  u32 scale_enabled;
  u32 scaled_w, scaled_h;
  enum SCALE_MODE scale_mode;
  u32 crop_x;
  u32 crop_y;
#endif
#ifdef SUPPORT_TCACHE
  u32 crop_enabled;
  u32 crop_w;
  u32 crop_h;
#endif
} ppTestConfig;


#ifdef SUPPORT_TCACHE
typedef struct {
  TCACHE_PIX_FMT t_in_fmt;
  TCACHE_PIX_FMT t_out_fmt;
  TCACHE_COV_BD rgb_cov_bd;
  
  u32 t_in_width;
  u32 t_in_height;
  u32 t_wplanes;
  u32 t_in_stride[MAX_INPUT_PLANE];
  u32 t_in_align_stride[MAX_INPUT_PLANE];
  u32 t_in_plane_height[MAX_INPUT_PLANE];
  u32 t_in_plane_size[MAX_INPUT_PLANE];
  
  u32 t_out_width;
  u32 t_out_height;
  u32 t_rplanes;
  u32 t_out_stride[MAX_OUTPUT_PLANE];
  u32 t_out_align_stride[MAX_OUTPUT_PLANE];
  u32 t_out_plane_height[MAX_OUTPUT_PLANE];
  u32 t_out_plane_size[MAX_OUTPUT_PLANE];
} TcacheContext;
#endif


enum RAW_FORMAT {
  RAW_FMT_YUV420P,
  RAW_FMT_NV12,
  RAW_FMT_NV21,
  RAW_FMT_YUV420P10LE,
  RAW_FMT_YUV420P10BE,
  RAW_FMT_P010LE,
  RAW_FMT_P010BE,
  RAW_FMT_YUV422P,
  RAW_FMT_YUV422P10LE,
  RAW_FMT_YUV422P10BE,
  RAW_FMT_YUV444P,
  RAW_FMT_RGB24,
  RAW_FMT_BGR24,
  RAW_FMT_ARGB,
  RAW_FMT_RGBA,
  RAW_FMT_ABGR,
  RAW_FMT_BGRA,
  RAW_FMT_HANTRO,
};

#define HUGE_PGAE_SIZE (2*1024*1024)

struct RawParser {
#ifdef FB_SYSLOG_ENABLE
  LOG_INFO_HEADER log_header;
#endif
  FILE* file;
  off_t file_size;
  u32 img_width;
  u32 img_height;
  enum RAW_FORMAT format;
  u32 planes;
  u32 byte_width[3];
  u32 stride[3];
  u32 height[3];
  u32 height_align[3];
  u32 plane_size[3];
  u32 frame_size;
  
  u32 hugepage_frame_size;
  u32 entry_num;
};

typedef const void * RawParserInst;

enum StreamReadMode {
  STREAMREADMODE_FRAME = 0,
  STREAMREADMODE_NALUNIT = 1,
  STREAMREADMODE_FULLSTREAM = 2,
  STREAMREADMODE_PACKETIZE = 3
};

struct TestParams {
  char* in_file_name;
  char* out_file_name[2*DEC_MAX_OUT_COUNT];
  u32 num_of_decoded_pics;
  enum DecPictureFormat format;
  enum DecPictureFormat hw_format;
//  enum SinkType sink_type;
  u32 pp_enabled;
  u8 display_cropped;
  u8 hw_traces;
  u8 trace_target;
  u8 extra_output_thread;
  u8 disable_display_order;
//  enum FileFormat file_format;
  enum StreamReadMode read_mode;
//  struct ErrorSimulationParams error_sim;
  enum DecErrorConcealment concealment_mode;
  enum DecDecoderMode decoder_mode;
  struct DecFixedScaleCfg fscale_cfg;
  PpUnitConfig ppu_cfg[4];
  DecPicAlignment align;
  u8 compress_bypass;   /* compressor bypass flag */
  u8 is_ringbuffer;     /* ringbuffer mode by default */
  //u32 force_output_8_bits;  /* Output 8 bits per pixel. */
  //u32 p010_output;          /* Output in MS P010 format. */
  //u32 bigendian_output;     /* Output big endian format. */
  u32 tile_by_tile;
  //u32 cr_first;
  //u32 pp_tile_e;        /* Enable pp tiled output */
  //u32 pp_planar;
  u32 pp_standalone;    /* PP in standalone mode */
  /*only used for cache&shaper rtl simulation*/
  u32 cache_bypass;
  u32 shaper_bypass;
  u32 cache_enable;
  u32 shaper_enable;
  u32 stripe_enable;
  u32 out_format_conv;   /* output format conversion enabled in TB (via -T/-S/-P options) */
  u32 mc_enable;
  //******************
  //parameters for pp transcode
  u32 width;
  u32 height;
  u32 in_10bit;
  char *in_format;
  //******************
  int priority;
  char* dec_dev_name;
  int mem_id;
  //for external buffer
  int ext_buffers_need;
  int ext_buffers_need_minus_dpb;
};

typedef struct {
#ifdef FB_SYSLOG_ENABLE
  LOG_INFO_HEADER log_header;
#endif
  struct TestParams param;
  void *dwl;
  PPInst *pp_inst;
  ppTestConfig pp_config;
  PPConfig dec_cfg;
  u32 num_of_output_pics;
  int pp_enabled;

  struct RawParser *rawparse_ctx;

#ifdef SUPPORT_TCACHE
  TcacheContext tcache_config;
  struct DWLLinearMem edma_link;
#endif

  struct DecInput * pp_in_buffer;

  u32 out_buf_size;
  u32 out_buf_nums;
  u32 out_buf_nums_init;
  struct DWLLinearMem pp_out_buffer[OUTPUT_BUF_DEPTH];
  FifoInst pp_out_Fifo;
#ifdef SUPPORT_DEC400
  u32 dec_table_offset;
#endif

  //pthread_t decode_thread;
  //sem_t pp_done;  /* Semaphore which is signalled when pp decoding is done. */
  
  const void *trans_handle;
  const void *edma_handle;
  const void *tcache_handle;
} ppClient;

typedef struct ppResize_s {
  int x;
  int y;
  int cw;
  int ch;
  int sw;
  int sh;
} ppResize_t;

#endif

