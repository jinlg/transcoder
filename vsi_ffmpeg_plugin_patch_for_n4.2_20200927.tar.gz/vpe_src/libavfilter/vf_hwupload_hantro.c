/*
 * This file is part of FFmpeg.
 *
 * FFmpeg is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * FFmpeg is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with FFmpeg; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA
 */

#include <fcntl.h>
#include <sys/ioctl.h>

#include "libavutil/buffer.h"
#include "libavutil/hwcontext.h"
#include "libavutil/log.h"
#include "libavutil/opt.h"
#include "libavutil/pixdesc.h"

#include "avfilter.h"
#include "formats.h"
#include "internal.h"
#include "video.h"


#include "dectypes.h"

#include "fifo.h"

#include "dwl.h"
#include "libavutil/hwcontext_hantro.h"
#include "trans_edma_api.h"
#include "trans_fd_api.h"
#include "hugepage_api.h"

#define MWL_BUF_DEPTH 68 /* support VCE lookaheadDepth 40 */


typedef struct UploadInst {
    FifoInst mwl_Fifo;
    int mwl_nums;
    struct DWLLinearMem mwl_mem[MWL_BUF_DEPTH];
} UploadInst;

typedef struct HantroUploadContext {
    const AVClass *class;
    
    AVBufferRef *hwframe;
    AVBufferRef *hwdevice;

    int    priority;
    char  *device;
    int    mem_id;
    EDMA_HANDLE edma_handle;

    void *mwl;
    
    UploadInst * uploadInst;
    
    int mwl_nums_init;
    u32 mwl_item_size;
    

    int disable_add_ext_buffer;

    uint8_t *p_hugepage_buf_y;
    uint8_t *p_hugepage_buf_uv;
    uint32_t i_hugepage_size_y;
    uint32_t i_hugepage_size_uv;

#ifdef HANTRO_UPLOAD_MEM_ERR_TEST
    int upload_memory_err_shadow;
    int upload_memory_err_cnt;
#endif

#ifdef HANTRO_UPLOAD_EDMA_ERR_TEST
    int upload_edma_err_shadow;
    int upload_edma_err_cnt;
#endif
} HantroUploadContext;

#ifdef HANTRO_UPLOAD_MEM_ERR_TEST
static int UploadMemoryErrCheck(HantroUploadContext *opts)
{
    int ret = 0;
    if(opts->upload_memory_err_cnt++ == opts->upload_memory_err_shadow){
        av_log(NULL, AV_LOG_ERROR, "[%s,%d],upload_memory_err_cnt %d, upload_memory_err_shadow %d\n", __FUNCTION__, __LINE__, opts->upload_memory_err_cnt, opts->upload_memory_err_shadow);
        av_log(NULL, AV_LOG_ERROR, "force malloc memory error!!!\n");
        ret = -1;
    }
    return ret;
}
#endif

#ifdef HANTRO_UPLOAD_EDMA_ERR_TEST
static int UploadEdmaErrCheck(HantroUploadContext *opts)
{
    int ret = 0;
    if(opts->upload_edma_err_cnt++ == opts->upload_edma_err_shadow){
        av_log(NULL, AV_LOG_ERROR, "[%s,%d],upload_memory_err_cnt %d, upload_memory_err_shadow %d\n", __FUNCTION__, __LINE__, opts->upload_edma_err_cnt, opts->upload_edma_err_shadow);
        av_log(NULL, AV_LOG_ERROR, "force malloc memory error!!!\n");
        ret = -1;
    }
    return ret;
}
#endif

struct MWLInitParam {
    u32 client_type;
    char * device;
    int mem_id;
};

struct HANTROMWL {
    u32 client_type;
    int fd_memalloc;
    int mem_id;
    char * device;
    EDMA_HANDLE edma_handle;
};

static i32 MWLRelease(const void *instance)
{
    struct HANTROMWL *mwl = (struct HANTROMWL *)instance;
    av_log(NULL, AV_LOG_TRACE, "[%s@%d]\n", __FUNCTION__, __LINE__);

    if (mwl) {
        if (mwl->edma_handle) {
            TRANS_EDMA_release(mwl->edma_handle);
        }
        
        if (mwl->fd_memalloc > 0) {
            TranscodeCloseFD(mwl->fd_memalloc);
        }
        
        DWLfree(mwl);
        mwl = NULL;
    }
    return 0;
}

static void * MWLInit(struct MWLInitParam * param,  HantroUploadContext *s)
{
    struct HANTROMWL *mwl;
    mwl = (struct HANTROMWL *)DWLcalloc(1, sizeof(struct HANTROMWL));
    if (mwl == NULL) {
        av_log(NULL, AV_LOG_ERROR, "failed to alloc struct HANTROMWL struct\n");
        return NULL;
    }
    av_log(NULL, AV_LOG_TRACE, "[%s@%d]\n", __FUNCTION__, __LINE__);

#ifdef HANTRO_UPLOAD_MEM_ERR_TEST
    if(UploadMemoryErrCheck(s) != 0){
        av_log(s, AV_LOG_ERROR, "[%s,%d]hantro upload force memory error in function\n", __FUNCTION__, __LINE__);
        return NULL;
    }
#endif

    mwl->client_type = param->client_type;
    mwl->fd_memalloc = -1;
    if (param->device == NULL) {
        av_log(NULL, AV_LOG_ERROR, "device name error\n");
        goto err;
    }
    mwl->device = param->device;
    mwl->mem_id = param->mem_id;
    mwl->fd_memalloc = TranscodeOpenFD(param->device, O_RDWR | O_SYNC);
    if (mwl->fd_memalloc == -1) {
        av_log(NULL, AV_LOG_ERROR, "failed to open: %s\n", param->device);
        goto err;
    }

    av_log(NULL, AV_LOG_TRACE, "[%s@%d], mwl: device %s, mem_id %d, fd_memalloc %d \n", __FUNCTION__, __LINE__, 
              mwl->device, mwl->mem_id, mwl->fd_memalloc);

    return mwl;
err:
    av_log(NULL, AV_LOG_ERROR, "%s","FAILED\n", __FUNCTION__);
    MWLRelease(mwl);

    return NULL;
}

static i32 MWLMallocLinear(const void *instance, u32 size, struct DWLLinearMem *info)
{
    struct HANTROMWL *mwl = (struct HANTROMWL *)instance;

    u32 pgsize = 4096;
    int ret = 0;
    struct mem_info params = {0};
    u32 alloc_flag = 0;

#define EP_SIDE_EN		(1<<1)
#define RC_SIDE_EN		(1<<2)

    //assert(mwl != NULL);
    //assert(info != NULL);
    if(mwl == NULL || info == NULL)
    {
        av_log(NULL, AV_LOG_ERROR, "[%s@%d], mwl %p, info %p\n", __FUNCTION__, __LINE__, mwl, info);
        return DWL_ERROR;
    }

#ifndef NEXT_MULTIPLE
#define NEXT_MULTIPLE(value, n) (((value) + (n) - 1) & ~((n) - 1))
#endif

    info->logical_size = size;
    size = NEXT_MULTIPLE(size, pgsize);
    info->size = size;
    info->virtual_address = NULL;
    info->bus_address = 0;
    params.size = info->size;

    info->bus_address_rc = 0;
    info->virtual_address_ep = NULL;

    if(info->mem_type == DWL_MEM_TYPE_CPU_FILE_SINK)
        alloc_flag = RC_SIDE_EN;
    else if(info->mem_type == DWL_MEM_TYPE_DPB)
        alloc_flag = EP_SIDE_EN;
    else
        alloc_flag = EP_SIDE_EN | RC_SIDE_EN;

    if(alloc_flag&EP_SIDE_EN)
    {
        params.task_id = mwl->mem_id;
        params.mem_location = EP_SIDE;
        params.size = info->size;
        av_log(NULL, AV_LOG_TRACE, "[%s@%d], EP: size(%d) task_id(%d)\n",__FUNCTION__, __LINE__, params.size, params.task_id);
        ret = ioctl(mwl->fd_memalloc, CB_TRANX_MEM_ALLOC, &params);
        if (ret) {
            av_log(NULL, AV_LOG_ERROR, "[%s@%d],ERROR! No linear buffer available\n", __FUNCTION__, __LINE__);
            return DWL_ERROR;
        }
        info->bus_address = params.phy_addr;
        info->size = params.size; 
    }
    if(alloc_flag&RC_SIDE_EN)
    {
        info->virtual_address = fbtrans_get_huge_pages(info->size);
        info->bus_address_rc = info->virtual_address;
        if (info->virtual_address == NULL) 
            return DWL_ERROR;
    }

    return DWL_OK;
}

static void MWLFreeLinear(const void *instance, struct DWLLinearMem *info)
{
#ifdef BUILD_CMODEL
    if (info->virtual_address)
        DWLFreeLinear(instance, info);
#else
    struct HANTROMWL *mwl = (struct HANTROMWL *)instance;
    int i;
    int ret;
    struct mem_info params;

    //assert(info != NULL);
    if(info == NULL){
        av_log(NULL, AV_LOG_ERROR, "[%s@%d], info %p\n", __FUNCTION__, __LINE__, info);
        return DWL_ERROR;
    }

#ifndef ENABLE_HUGEPAGE
    if ((info->virtual_address != NULL) && (info->virtual_address != MAP_FAILED)	&& (info->size != 0))
        munmap(info->virtual_address, info->size);
#endif

#ifdef DRV_NEW_ARCH
    params.task_id = mwl->mem_id;
#endif
    params.mem_location = EP_SIDE;
    params.phy_addr = info->bus_address;
    params.size = info->size;
    params.rc_kvirt = info->rc_kvirt;
    if (info->bus_address != 0) {
        ret = ioctl(mwl->fd_memalloc, CB_TRANX_MEM_FREE, &params);
         av_log(NULL, AV_LOG_DEBUG, "ret = %d\n", ret);
    }

#ifndef ENABLE_HUGEPAGE
#ifdef DRV_NEW_ARCH
    params.task_id = mwl->mem_id;
#endif
    params.mem_location = RC_SIDE;
    params.phy_addr = info->bus_address_rc;
    params.size = info->size;
    params.rc_kvirt = info->rc_kvirt;
    if (info->bus_address_rc != 0) {
        ret = ioctl(mwl->fd_memalloc, CB_TRANX_MEM_FREE, &params);
        av_log(NULL, AV_LOG_DEBUG, "ret = %d\n", ret);
    }
#else
    if (info->virtual_address) {
        fbtrans_free_huge_pages(info->virtual_address, info->size);
        info->virtual_address = NULL;
    }
#endif
#endif
}

static void  mwl_pic_consume(void *opaque, uint8_t *data)
{
    AVHANTROFramesContext *frame_hwctx = opaque;
    UploadInst *s;
    struct DecPicturePpu picture = *((struct DecPicturePpu *)data);

    pthread_mutex_lock(&frame_hwctx->opaque_mutex);
    s = frame_hwctx->opaque_upload;

    if(s == NULL || s->mwl_Fifo == NULL){
        av_log(NULL, AV_LOG_DEBUG, "[%s@%d], NULL, why!!! s %p, data %p, mwl_Fifo %p\n", __FUNCTION__, __LINE__, s, data, s ? s->mwl_Fifo : NULL);
        pthread_mutex_unlock(&frame_hwctx->opaque_mutex);
        if (data) av_free(data);
        return NULL;
    }
  
    for (int i = 0; i< s->mwl_nums; i++) {
        if (s->mwl_mem[i].bus_address == picture.pictures[0].luma.bus_address) {
            av_log(NULL, AV_LOG_DEBUG,"[%s@%d], push buff %d...\n", __FUNCTION__, __LINE__, i);
            FifoPush(s->mwl_Fifo, &s->mwl_mem[i], FIFO_EXCEPTION_DISABLE);
            av_log(NULL, AV_LOG_DEBUG, "[%s@%d], ======FifoPush, i %d\n", __FUNCTION__, __LINE__, i);
            break;
        }
    }

    pthread_mutex_unlock(&frame_hwctx->opaque_mutex);

    av_free(data);
}

static void* mwl_pic_get(void *opaque)
{
    HantroUploadContext *s = opaque;
    struct DWLLinearMem *mwl_mem_item;

    av_log(NULL, AV_LOG_DEBUG,"[%s@%d], request pop buff ...\n", __FUNCTION__, __LINE__);
    FifoPop(s->uploadInst->mwl_Fifo, &mwl_mem_item, FIFO_EXCEPTION_DISABLE);
    av_log(NULL, AV_LOG_DEBUG,"[%s@%d], pop out buff, bus address=%p..\n", __FUNCTION__, __LINE__, mwl_mem_item->bus_address);

    return (void *)mwl_mem_item;
}

static int hantroupload_get_enc_buffer_num(HantroUploadContext *ctx)
{
    AVHWFramesContext *hwframe_ctx;
    AVHWDeviceContext *device_ctx;
    AVHANTRODeviceContext *device_hwctx;
    int nb_frames;

    hwframe_ctx = (AVHWFramesContext*)ctx->hwframe->data;
    device_ctx = hwframe_ctx->device_ctx;
    device_hwctx = device_ctx->hwctx;
    nb_frames = device_hwctx->max_frames_delay;

    return nb_frames;
}

static int hantroupload_add_extra_buffer(HantroUploadContext *ctx, int enc_need_buffers_num,  int current_pp_buffers_num)
{
    int i = 0;
    int ext_buffers_num = enc_need_buffers_num;
    
    if(ctx == NULL || ext_buffers_num <= 0){
        av_log(NULL, AV_LOG_ERROR, "[%s@%d], enc_need_buffers_num %d, current_pp_buffers_num %d, error!\n", __FUNCTION__, __LINE__, ext_buffers_num, current_pp_buffers_num);
        return -1;
    }
    
    ctx->uploadInst->mwl_nums += ext_buffers_num;

    for (i = current_pp_buffers_num; i < current_pp_buffers_num + ext_buffers_num; i++) {
        ctx->uploadInst->mwl_mem[i].mem_type = DWL_MEM_TYPE_DPB;
        if(MWLMallocLinear(ctx->mwl, ctx->mwl_item_size, &ctx->uploadInst->mwl_mem[i]) != DWL_OK) {
          av_log(ctx, AV_LOG_ERROR, "UNABLE TO ALLOCATE STREAM BUFFER MEMORY\n");
          return -1;
        }

#ifdef HANTRO_UPLOAD_MEM_ERR_TEST
        if(UploadMemoryErrCheck(ctx) != 0){
            av_log(NULL, AV_LOG_ERROR, "[%s,%d]hantro upload force memory error in function\n", __FUNCTION__, __LINE__);
            return -1;
        }
#endif

        av_log(ctx, AV_LOG_DEBUG, "[%s@%d],out_buffer i %d, bus_address=0x%llx, bus_address_rc=0x%llx, virtual_address %p, virtual_address_ep %p, size %d \n", __FUNCTION__, __LINE__, i,
            &ctx->uploadInst->mwl_mem[i].bus_address,
            &ctx->uploadInst->mwl_mem[i].bus_address_rc,
            &ctx->uploadInst->mwl_mem[i].virtual_address,
            &ctx->uploadInst->mwl_mem[i].virtual_address_ep,
            &ctx->uploadInst->mwl_mem[i].size);
    
        FifoPush(ctx->uploadInst->mwl_Fifo, &ctx->uploadInst->mwl_mem[i], FIFO_EXCEPTION_DISABLE);
    }
    
    av_log(ctx, AV_LOG_DEBUG, "[%s@%d],,add ext_buffers_num %d, total out_buf_nums %d\n", __FUNCTION__, __LINE__,
        ext_buffers_num, ctx->uploadInst->mwl_nums);

    return 0;
}

static int hantroupload_check_buffer_number_for_trans(HantroUploadContext *ctx)
{
    int enc_need_buffers_num;
    int current_pp_buffers_num;

    enc_need_buffers_num =  hantroupload_get_enc_buffer_num(ctx);
    current_pp_buffers_num = ctx->uploadInst->mwl_nums;

    if( ctx->mwl_nums_init + enc_need_buffers_num > current_pp_buffers_num ){
      av_log(NULL, AV_LOG_DEBUG, "[%s@%d], out_buf_nums_init %d, enc_need_buffers_num %d, current_pp_buffers_num %d\n", __FUNCTION__, __LINE__,
                ctx->mwl_nums_init, enc_need_buffers_num, current_pp_buffers_num);
      return hantroupload_add_extra_buffer( ctx, enc_need_buffers_num,  current_pp_buffers_num );
    }

    return 0;
}

static av_cold void hantroupload_uninit(AVFilterContext *ctx)
{
    HantroUploadContext *s = ctx->priv;

    AVHANTROFramesContext *frame_hwctx = NULL;
    AVHWFramesContext *hwframe_ctx = NULL;

    av_log(ctx, AV_LOG_DEBUG, "%s(%d)\n", __FUNCTION__, __LINE__);
    av_log(ctx, AV_LOG_DEBUG, "s = %p, s->hwframe = %p\n", s, s->hwframe);

    if (s->hwframe) hwframe_ctx = s->hwframe->data;
    av_log(ctx, AV_LOG_DEBUG, "hwframe_ctx = %p\n", hwframe_ctx);

    
    if (hwframe_ctx)
      av_log(ctx, AV_LOG_DEBUG, "hwframe_ctx->hwctx = %p\n", hwframe_ctx->hwctx);
    if (hwframe_ctx) frame_hwctx = hwframe_ctx->hwctx;
    av_log(ctx, AV_LOG_DEBUG, "frame_hwctx = %p\n", frame_hwctx);

    if(s->edma_handle){
        TRANS_EDMA_release(s->edma_handle);
        s->edma_handle = NULL;
    }

    if (frame_hwctx) pthread_mutex_lock(&frame_hwctx->opaque_mutex);

    if(s->mwl && s->uploadInst){
        for(int i=0; i<s->uploadInst->mwl_nums; i++)
            MWLFreeLinear(s->mwl, &s->uploadInst->mwl_mem[i]);
        av_log(ctx, AV_LOG_DEBUG, "[%s@%d], do MWLFreeLinear\n", __FUNCTION__, __LINE__);
        MWLRelease(s->mwl);
        s->mwl = NULL;
        
        if(s->uploadInst->mwl_Fifo != NULL){
            FifoRelease(s->uploadInst->mwl_Fifo);
            s->uploadInst->mwl_Fifo = NULL;
        }
        av_freep(&s->uploadInst);
        if (frame_hwctx) frame_hwctx->opaque_upload = NULL;
    }
    
    if (frame_hwctx) pthread_mutex_unlock(&frame_hwctx->opaque_mutex);

    if(s->p_hugepage_buf_y != NULL){
        fbtrans_free_huge_pages(s->p_hugepage_buf_y, s->i_hugepage_size_y);
        s->p_hugepage_buf_y = NULL;
    }
    if(s->p_hugepage_buf_uv != NULL){
        fbtrans_free_huge_pages(s->p_hugepage_buf_uv, s->i_hugepage_size_uv);
        s->p_hugepage_buf_uv = NULL;
    }
    av_buffer_unref(&s->hwframe);
    av_buffer_unref(&s->hwdevice);

    av_log(ctx, AV_LOG_DEBUG, "[%s@%d]\n",__FUNCTION__, __LINE__);
}


static int hantroupload_query_formats(AVFilterContext *ctx)
{
    int ret;

    static const enum AVPixelFormat input_pix_fmts[] = {
        AV_PIX_FMT_NV12,
        AV_PIX_FMT_P010LE,
        //AV_PIX_FMT_NV21,    /*8000E can support nv21/yuv420p, but bigsea can not support it */
        //AV_PIX_FMT_YUV420P, /*for vp9 enc, nv21:144x176, 400x226, 480x720, 800x600 print invalid enc params; yuv420p all resolutions failed, try 2048 align still fail */
        AV_PIX_FMT_NONE
    };
    static const enum AVPixelFormat output_pix_fmts[] = {
        AV_PIX_FMT_HANTRO,
        AV_PIX_FMT_NONE
    };

    av_log(ctx, AV_LOG_TRACE, "enter query_formats\n");

    AVFilterFormats *in_fmts  = ff_make_format_list(input_pix_fmts);
    AVFilterFormats *out_fmts;

    ret = ff_formats_ref(in_fmts, &ctx->inputs[0]->out_formats);
    if (ret < 0)
        return ret;

    out_fmts = ff_make_format_list(output_pix_fmts);

    ret = ff_formats_ref(out_fmts, &ctx->outputs[0]->in_formats);
    if (ret < 0)
        return ret;

    return 0;
}


static int hantroupload_config_input(AVFilterLink *inlink)
{
    AVFilterContext * ctx = inlink->dst;
    HantroUploadContext * s = ctx->priv;
    
    AVHWFramesContext *hwframe_ctx;
    AVHANTROFramesContext *frame_hwctx;
    AVHWDeviceContext *device_ctx;
    AVHANTRODeviceContext *device_hwctx;

    AVFilterLink  *outlink = inlink->dst->outputs[0];
    AVFilterContext   *dst_next_pp = NULL;
    char *p_find_ppfilter          = NULL;
    
    int ext_buffers_need = 0;
    int ret = 0;
    int align_height = 0;
    int align_width = 0;

    av_log(ctx, AV_LOG_TRACE, "input res %dx%d\n", inlink->w, inlink->h);

    /* Disable upload filter alloc ext buffer at EP, when it links with pp filter */
    if(outlink != NULL){
        dst_next_pp = outlink->dst;
        p_find_ppfilter = strstr(dst_next_pp->name, "hantro_pp");
        if(p_find_ppfilter != NULL)
            s->disable_add_ext_buffer = 1;
        else
            s->disable_add_ext_buffer = 0;
        av_log(NULL, AV_LOG_DEBUG, "[%s@%d], upload filter link with %s filter!!  disable_add_ext_buffer %d\n", __FUNCTION__, __LINE__, dst_next_pp->name, s->disable_add_ext_buffer);
    }

    /* hw device & frame init */
    if(inlink->hw_frames_ctx){
        av_log(ctx, AV_LOG_TRACE, "[%s@%d], inlink->hw_frames_ctx = %p\n", __FUNCTION__, __LINE__,inlink->hw_frames_ctx);
        s->hwframe = av_buffer_ref(inlink->hw_frames_ctx);
        if (!s->hwframe) {
            ret = AVERROR(ENOMEM);
            return -1;
        }
        hwframe_ctx = (AVHWFramesContext*)s->hwframe->data;
        s->hwdevice = av_buffer_ref(hwframe_ctx->device_ref);
        if (!s->hwdevice) {
            ret = AVERROR(ENOMEM);
            return -1;
        }
    }else{
        av_log(ctx, AV_LOG_TRACE, "[%s@%d], ctx->hw_device_ctx = %p\n", __FUNCTION__, __LINE__, ctx->hw_device_ctx);
        if(ctx->hw_device_ctx){
            s->hwdevice = av_buffer_ref(ctx->hw_device_ctx);
            av_log(ctx, AV_LOG_TRACE, "[%s@%d], ctx->hwdevice = %p\n", __FUNCTION__, __LINE__, s->hwdevice);
            if(!s->hwdevice){
                ret = AVERROR(ENOMEM);
                return -1;
            }
        }else{      
            av_log(ctx, AV_LOG_TRACE, "[%s@%d], s->dev_name = %p\n", __FUNCTION__, __LINE__,s->device);
            ret = av_hwdevice_ctx_create((AVBufferRef *)&s->hwdevice, AV_HWDEVICE_TYPE_HANTRO, s->device, NULL, 0);
            if (ret < 0)
                return -1;
        }
    
        s->hwframe = av_hwframe_ctx_alloc(s->hwdevice);
        if (!s->hwframe) {
            av_log(ctx, AV_LOG_ERROR, "[%s@%d], av_hwframe_ctx_alloc failed\n", __FUNCTION__, __LINE__);
            ret = AVERROR(ENOMEM);
            return -1;
        }

#ifdef HANTRO_UPLOAD_MEM_ERR_TEST
        if(UploadMemoryErrCheck(s) != 0){
            av_log(NULL, AV_LOG_ERROR, "[%s,%d]hantro upload force memory error in function\n", __FUNCTION__, __LINE__);
            ret = AVERROR(ENOMEM);
            return -1;
        }
#endif

        hwframe_ctx = (AVHWFramesContext*)s->hwframe->data;
    }

    if (!hwframe_ctx->pool) {   
        hwframe_ctx->format = AV_PIX_FMT_HANTRO;
        hwframe_ctx->sw_format = inlink->format;
        hwframe_ctx->width  = inlink->w;
        hwframe_ctx->height = inlink->h;
        
        if ((ret = av_hwframe_ctx_init(s->hwframe)) < 0) {
            av_log(ctx, AV_LOG_ERROR, "av_hwframe_ctx_init failed\n");
            return -1;
        }
    }

    device_ctx   = hwframe_ctx->device_ctx;
    device_hwctx = device_ctx->hwctx;
    frame_hwctx  = hwframe_ctx->hwctx;
    frame_hwctx->pic_info[0].enabled = 1;
    if(inlink->format == AV_PIX_FMT_NV12)
        frame_hwctx->pic_info[0].format = AVHANTRO_FORMAT_YUV420_SEMIPLANAR;
    else if(inlink->format == AV_PIX_FMT_YUV420P)
        frame_hwctx->pic_info[0].format = AVHANTRO_FORMAT_YUV420_SEMIPLANAR_YUV420P;
    else
        frame_hwctx->pic_info[0].format = AVHANTRO_FORMAT_YUV420_SEMIPLANAR_VU;

    /* FIXME: nv12,p010(all formats) uses 32 align */
    align_width = ((inlink->w + 31)/32)*32;
    
    /*For upload filter directly link to encoder(8000E or bigsea) */
    /*Bigsea require 1024 align, so we set 1024 align for 8000E and bigsea */
    if(s->disable_add_ext_buffer == 0){
        if(AV_PIX_FMT_P010LE == inlink->format)
            //align_width = ((inlink->w + 511)/512)*512;
            align_width = (((inlink->w*2 + 1023)/1024)*1024)/2;
        else if(AV_PIX_FMT_NV12 == inlink->format)
            align_width = ((inlink->w + 1023)/1024)*1024;
        else
            align_width = ((inlink->w + 31)/32)*32;

        //For upload filter directly link to Bigsea
        if(inlink->format == AV_PIX_FMT_P010LE)
            frame_hwctx->pic_info[0].format = AVHANTRO_FORMAT_YUV420_PLANAR_10BIT_P010;
        else
            frame_hwctx->pic_info[0].format = AVHANTRO_FORMAT_YUV420_SEMIPLANAR;
    }

    frame_hwctx->pic_info[0].pic_width  = align_width;
    frame_hwctx->pic_info[0].pic_height = inlink->h;
    frame_hwctx->pic_info[0].width   = inlink->w;
    frame_hwctx->pic_info[0].height  = inlink->h;
    frame_hwctx->pic_info[0].picdata.is_interlaced    = 0;
    frame_hwctx->pic_info[0].picdata.pic_format       = 2;    //2:DEC_OUT_FRM_RASTER_SCAN
    frame_hwctx->pic_info[0].picdata.pic_pixformat    = AV_PIX_FMT_P010LE == inlink->format ? 1 : 0;    //0:DEC_OUT_PIXEL_DEFAULT, 1:DEC_OUT_PIXEL_P010
    frame_hwctx->pic_info[0].picdata.bit_depth_luma   = AV_PIX_FMT_P010LE == inlink->format ? 10 : 8;
    frame_hwctx->pic_info[0].picdata.bit_depth_chroma = AV_PIX_FMT_P010LE == inlink->format ? 10 : 8;
    frame_hwctx->pic_info[0].picdata.pic_compressed_status = 0;    //0:not compress

    if (inlink->hw_frames_ctx == NULL) {
        inlink->hw_frames_ctx = av_buffer_ref(s->hwframe);
        if (inlink->hw_frames_ctx == NULL)
            return AVERROR(ENOMEM);
    }
    av_log(ctx, AV_LOG_TRACE, "[%s@%d], hwframe_ctx %p, inlink->hw_frames_ctx %p \n", __FUNCTION__, __LINE__,hwframe_ctx,  inlink->hw_frames_ctx);

    s->device = device_hwctx->device;
    s->mem_id = frame_hwctx->task_id;
    s->priority = device_hwctx->priority;
    s->edma_handle = TRANS_EDMA_init(s->device);
    if (s->edma_handle == NULL) {
        av_log(ctx, AV_LOG_ERROR, "hwupload edma_handle init failed!\n");
        return -1;
    }

    av_log(ctx, AV_LOG_TRACE, "[%s@%d], device name %s, mem_id %d, priority %d, ctx->edma_handle %p\n",  __FUNCTION__, __LINE__, 
              s->device, s->mem_id, s->priority, s->edma_handle);

    s->uploadInst = av_mallocz(sizeof(UploadInst));
    if (s->uploadInst == NULL) {
        av_log(ctx, AV_LOG_ERROR, "uploadInst alloc failed!\n");
        return AVERROR(ENOMEM);
    }


    pthread_mutex_lock(&frame_hwctx->opaque_mutex);
    frame_hwctx->opaque_upload = s->uploadInst;
    pthread_mutex_unlock(&frame_hwctx->opaque_mutex);

    //malloc EP buffer
    struct MWLInitParam mwlParam = {DWL_CLIENT_TYPE_ST_PP, s->device, s->mem_id};
    s->mwl = MWLInit(&mwlParam, s);
    if (s->mwl == NULL) {
        av_log(ctx, AV_LOG_ERROR, "Transcode demuxer mwl init failed!\n");
        return -1;
    }

    av_log(ctx, AV_LOG_TRACE, "[%s@%d], ctx->mwl %p\n",  __FUNCTION__, __LINE__, s->mwl);

    align_height = ((inlink->h + 31) / 32) * 32;

    /*used for buffer management*/
    FifoInit(MWL_BUF_DEPTH, &s->uploadInst->mwl_Fifo);

    s->mwl_nums_init = 3;
    //ext_buffers_need = hantroupload_get_enc_buffer_num(s);
    //s->mwl_nums  = s->mwl_nums_init + ext_buffers_need;
    s->uploadInst->mwl_nums  = s->mwl_nums_init;
    av_log(ctx, AV_LOG_DEBUG, "[%s@%d], mwl_nums %d, ext_buffers_need %d\n", __FUNCTION__, __LINE__, s->uploadInst->mwl_nums, ext_buffers_need);
    if (s->uploadInst->mwl_nums > MWL_BUF_DEPTH) {
        av_log(ctx, AV_LOG_ERROR, "TOO MANY BUFFERS REQUEST!\n");
        return -1;
    }

    s->i_hugepage_size_y = align_width * align_height;
    if (AV_PIX_FMT_P010LE == inlink->format)
        s->i_hugepage_size_y *= 2;
    
    s->i_hugepage_size_uv = s->i_hugepage_size_y/2;
    s->p_hugepage_buf_y   = fbtrans_get_huge_pages(s->i_hugepage_size_y);
    s->p_hugepage_buf_uv  = fbtrans_get_huge_pages(s->i_hugepage_size_uv);

    s->mwl_item_size  = s->i_hugepage_size_y + s->i_hugepage_size_uv;
    for(int i = 0; i <s->uploadInst->mwl_nums; i++){
        s->uploadInst->mwl_mem[i].mem_type = DWL_MEM_TYPE_DPB;
        if (MWLMallocLinear(s->mwl, s->mwl_item_size, &s->uploadInst->mwl_mem[i])) {
            av_log(ctx, AV_LOG_ERROR, "No memory available for the stream buffer\n");
            return -1;
        }

#ifdef HANTRO_UPLOAD_MEM_ERR_TEST
        if(UploadMemoryErrCheck(s) != 0){
            av_log(NULL, AV_LOG_ERROR, "[%s,%d]hantro upload force memory error in function\n", __FUNCTION__, __LINE__);
            return -1;
        }
#endif

        av_log(ctx, AV_LOG_DEBUG,  "[%s@%d], mwl i %d, bus_address=0x%llx, bus_address_rc=0x%llx, size %d, align_width %d, align_height %d\n",
                __FUNCTION__, __LINE__, i, s->uploadInst->mwl_mem[i].bus_address, s->uploadInst->mwl_mem[i].bus_address_rc,
                s->uploadInst->mwl_mem[i].size, align_width, align_height);

        FifoPush(s->uploadInst->mwl_Fifo, &s->uploadInst->mwl_mem[i], FIFO_EXCEPTION_DISABLE);
    }

    return 0;
}

static int hantroupload_filter_frame(AVFilterLink *link, AVFrame *in)
{
    AVFilterContext   *dst = link->dst;
    AVFilterLink  *outlink = link->dst->outputs[0];
    HantroUploadContext *ctx = outlink->src->priv;
    AVHANTROFramesContext *frame_hwctx;
    AVHWFramesContext *hwframe_ctx;
    AVFrame *out = NULL;
    int ret = 0;
    u32 y_size,uv_size;
    unsigned long linesize32_y, linesize32_uv;
    struct DWLLinearMem *mwl_mem_item;

    //got mwl buffer from fifo
    mwl_mem_item = mwl_pic_get(ctx);

    /* Disable upload filter alloc ext buffer at EP, when it links with pp filter */
    if(ctx->disable_add_ext_buffer == 0){
        av_log(NULL, AV_LOG_DEBUG, "[%s@%d] check add buffer!!! disable_add_ext_buffer %d\n", __FUNCTION__, __LINE__, ctx->disable_add_ext_buffer);
        if( hantroupload_check_buffer_number_for_trans(ctx) < 0 )
            return AVERROR(ENOMEM);
    }

    struct DecPicturePpu *pic = av_mallocz(sizeof(*pic));
    if(!pic)
        return AVERROR(ENOMEM);

#ifdef HANTRO_UPLOAD_MEM_ERR_TEST
    if(UploadMemoryErrCheck(ctx) != 0){
        av_log(NULL, AV_LOG_ERROR, "[%s,%d]hantro upload force memory error in function\n", __FUNCTION__, __LINE__);
        return AVERROR(ENOMEM);
    }
#endif

    /* FIXME: nv12,p010(all formats) uses 32 lines align */
    linesize32_y  = ((in->linesize[0]+31)/32)*32;
    linesize32_uv = ((in->linesize[1]+31)/32)*32;

    /*For upload filter directly link to encoder(8000E or bigsea) */
    /*Bigsea require 1024 align, so we set 1024 align for 8000E and bigsea */
    if(ctx->disable_add_ext_buffer == 0){
        linesize32_y  = ((in->linesize[0]+1023)/1024)*1024;
        linesize32_uv = ((in->linesize[1]+1023)/1024)*1024;
    }

    y_size  = (((in->height+7)/8)*8) * linesize32_y;  //the height need be aligned 8 lines
    uv_size = in->height * linesize32_uv / 2;
    if(in->format == AV_PIX_FMT_YUV420P)
        uv_size = in->height * linesize32_uv;
    pic->pictures[0].luma.bus_address = mwl_mem_item->bus_address;
    pic->pictures[0].chroma.bus_address = pic->pictures[0].luma.bus_address + y_size;

    av_log(ctx, AV_LOG_DEBUG, "[%s@%d] +++ luma.bus_address %p, chroma.bus_address %p, linesize32_y %d, linesize32_uv %d, y_size %d, uv_size %d," 
              "in->height %d, in->linesize[0] %d, in->linesize[1] %d,  in->linesize[2] %d, linesize32_y %d, linesize32_uv %d\n", __FUNCTION__, __LINE__,
              pic->pictures[0].luma.bus_address, pic->pictures[0].chroma.bus_address, linesize32_y, linesize32_uv, y_size, uv_size, 
              in->height, in->linesize[0], in->linesize[1], in->linesize[2], linesize32_y, linesize32_uv);

    uint8_t *addr_offset = NULL;
    unsigned int i;
    //copy Y lines to hugepage buffer, then rc to ep
    for(i = 0; i < in->height; i++){
        addr_offset = ctx->p_hugepage_buf_y + i*linesize32_y;
        memcpy(addr_offset, in->data[0]+i*in->linesize[0], in->linesize[0]);
    }
    ret = TRANS_EDMA_RC2EP_nonlink(ctx->edma_handle, ctx->p_hugepage_buf_y, pic->pictures[0].luma.bus_address, y_size);
    if(ret){
        av_log(ctx, AV_LOG_ERROR, "[%s@%d], TRANS_EDMA_RC2EP_nonlink failed. ret %d, luma.bus_address %p, y_size %d\n", __FUNCTION__, __LINE__, 
                  ret,  pic->pictures[0].luma.bus_address, y_size);
        goto fail;
    }

#ifdef HANTRO_UPLOAD_EDMA_ERR_TEST
    if(UploadEdmaErrCheck(ctx) != 0){
        av_log(NULL, AV_LOG_ERROR, "[%s,%d]hantro upload force edma error in function\n", __FUNCTION__, __LINE__);
        ret = -1;
        goto fail;
    }
#endif

    //copy UV lines to hugepage buffer, then rc to ep. NV12 and P010le chroma: 1 plane, UV
    for(i = 0; i < in->height/2; i++){ 
        memcpy(ctx->p_hugepage_buf_uv+i*linesize32_uv, in->data[1]+i*in->linesize[1], in->linesize[1]);
    }
    ret = TRANS_EDMA_RC2EP_nonlink(ctx->edma_handle, ctx->p_hugepage_buf_uv, pic->pictures[0].chroma.bus_address, uv_size);
    if(ret){
        av_log(ctx, AV_LOG_ERROR, "[%s@%d], TRANS_EDMA_RC2EP_nonlink failed. ret %d, chroma.bus_address %p, uv_size %d\n", __FUNCTION__, __LINE__,
                    ret,  pic->pictures[0].chroma.bus_address, uv_size);
        goto fail;
    }

#ifdef HANTRO_UPLOAD_EDMA_ERR_TEST
    if(UploadEdmaErrCheck(ctx) != 0){
        av_log(NULL, AV_LOG_ERROR, "[%s,%d]hantro upload force edma error in function\n", __FUNCTION__, __LINE__);
        ret = -1;
        goto fail;
    }
#endif

#if 0
    /* dump  ep to rc buffer picture for debugging */
    av_log(NULL, AV_LOG_INFO, "[%s,%d] dump start\n", __FUNCTION__, __LINE__);
    uint8_t *pdata_y = fbtrans_get_huge_pages(y_size);
    if (pdata_y == NULL) {
        av_log(ctx, AV_LOG_ERROR,"[%s,%d]No memory available for the frame buffer\n", __FUNCTION__, __LINE__);
        return AVERROR(ENOMEM);
    }

    uint8_t *pdata_uv = fbtrans_get_huge_pages(uv_size);
    if(pdata_uv == NULL) {
        av_log(ctx, AV_LOG_ERROR,"[%s,%d]No memory available for the frame buffer\n", __FUNCTION__, __LINE__);
        return AVERROR(ENOMEM);
    }

    TRANS_EDMA_EP2RC_nonlink(ctx->edma_handle, pic->pictures[0].luma.bus_address, pdata_y, y_size);
    TRANS_EDMA_EP2RC_nonlink(ctx->edma_handle, pic->pictures[0].chroma.bus_address, pdata_uv, uv_size);

    static FILE *fp_ep2rc = NULL;
    if(fp_ep2rc == NULL)
        fp_ep2rc = fopen("dump_ep2rc.yuv", "wb");
    if(fp_ep2rc != NULL){
        fwrite(pdata_y, y_size, 1, fp_ep2rc);
        fwrite(pdata_uv, uv_size, 1, fp_ep2rc);
    }

    fbtrans_free_huge_pages(pdata_y, 8*1024); //this len is only to distinguish hugepage
    fbtrans_free_huge_pages(pdata_uv, 8*1024); //this len is only to distinguish hugepage

    av_log(NULL, AV_LOG_INFO, "[%s,%d] dump done\n", __FUNCTION__, __LINE__);
#endif

#if 0
    /* dump avframe in for debugging */
    av_log(ctx, AV_LOG_INFO, "[%s@%d], %s, %dx%d\n", __FUNCTION__, __LINE__, av_get_pix_fmt_name(in->format), in->width, in->height);
    static FILE *fp = NULL;
    static int frame_cnt = 0;
    if(fp == NULL)
        fp = fopen("dump_rawdata_hwupload.yuv", "wb");
    if(fp != NULL){
        av_log(ctx, AV_LOG_INFO, "[%s@%d], dump pp filter in avframe count %d, w %d h %d, linesize[0] %d, linesize[1] %d, linesize[2] %d, fmt %s\n", __FUNCTION__, __LINE__, 
                          frame_cnt++, in->width, in->height, in->linesize[0], in->linesize[1], in->linesize[2], av_get_pix_fmt_name(in->format));
        if(in->format == AV_PIX_FMT_YUV420P){
            for(int i=0; i<in->height; i++ )
                fwrite(in->data[0] + i*in->linesize[0], in->width,   1, fp);
            for(int j=0; j<in->height/2; j++)
                fwrite(in->data[1] + j*in->linesize[1], in->width/2, 1, fp);
            for(int k=0; k<in->height/2; k++)
                fwrite(in->data[2] + k*in->linesize[2], in->width/2, 1, fp);
        }else if(in->format == AV_PIX_FMT_NV12){
            for(int i=0; i<in->height; i++ )
                fwrite(in->data[0] + i*in->linesize[0], in->width, 1, fp);
            for(int j=0; j<in->height/2; j++)
                fwrite(in->data[1] + j*in->linesize[1], in->width, 1, fp);
        }else{
            av_log(ctx, AV_LOG_ERROR, "[%s@%d],dump avframe not support the fmt %s\n", __FUNCTION__, __LINE__, av_get_pix_fmt_name(in->format));
        }
    }
#endif

    out = av_frame_alloc();
    if(!out){
        av_log(ctx, AV_LOG_ERROR,"can not alloc \n");
        return AVERROR(ENOMEM);
    }

#ifdef HANTRO_UPLOAD_MEM_ERR_TEST
    if(UploadMemoryErrCheck(ctx) != 0){
        av_log(NULL, AV_LOG_ERROR, "[%s,%d]hantro upload force memory error in function\n", __FUNCTION__, __LINE__);
        return -1;
    }
#endif

    ret = av_frame_copy_props(out, in);
    if(ret){
        av_log(ctx, AV_LOG_ERROR,"copy props failed \n");
        goto fail;
    }

    hwframe_ctx = ctx->hwframe->data;
    av_log(ctx, AV_LOG_DEBUG, "(%s[%d])hwframe_ctx = %p\n", __FUNCTION__, __LINE__, hwframe_ctx);
    frame_hwctx = hwframe_ctx->hwctx;
    av_log(ctx, AV_LOG_DEBUG, "(%s[%d])frame_hwctx = %p\n", __FUNCTION__, __LINE__, frame_hwctx);

    out->width  = in->width;
    out->height = in->height;
    out->format = AV_PIX_FMT_HANTRO;
    out->linesize[0] = in->width;
    out->linesize[1] = in->width/2;
    
    out->data[0] = pic;
    out->buf[0] = av_buffer_create((uint8_t *)pic, sizeof(struct DecPicturePpu), mwl_pic_consume, frame_hwctx, AV_BUFFER_FLAG_READONLY);
    if (out->buf[0] == NULL) {
        ret = AVERROR(ENOMEM);
        goto fail;
    }
    out->hw_frames_ctx = av_buffer_ref(ctx->hwframe);
    if (out->hw_frames_ctx == NULL) {
      goto fail;
    }

    av_frame_free(&in);

    return ff_filter_frame(outlink, out);
fail:
    av_frame_free(&in);
    av_frame_free(&out);
    return ret;
}

#define OFFSET(x) offsetof(HantroUploadContext, x)
#define FLAGS (AV_OPT_FLAG_FILTERING_PARAM | AV_OPT_FLAG_VIDEO_PARAM)
static const AVOption hantroupload_options[] = {
#ifdef HANTRO_UPLOAD_MEM_ERR_TEST
    { "hantro_upload_mem_err_test", "hantro_upload filter error process test", OFFSET(upload_memory_err_shadow), AV_OPT_TYPE_INT, {.i64 = -1}, -1, 10000, FLAGS },
#endif
#ifdef HANTRO_UPLOAD_EDMA_ERR_TEST
    { "hantro_upload_edma_err_test", "hantro_upload filter edma error process test", OFFSET(upload_edma_err_shadow), AV_OPT_TYPE_INT, {.i64 = -1}, -1, 10000, FLAGS },
#endif
    { NULL }
};

AVFILTER_DEFINE_CLASS(hantroupload);

static const AVFilterPad hantroupload_inputs[] = {
    {
        .name         = "default",
        .type         = AVMEDIA_TYPE_VIDEO,
        .config_props = hantroupload_config_input,
        .filter_frame = hantroupload_filter_frame,
    },
    { NULL }
};

static const AVFilterPad hantroupload_outputs[] = {
    {
        .name         = "default",
        .type         = AVMEDIA_TYPE_VIDEO,
        //.config_props = hantroupload_config_output,
    },
    { NULL }
};

AVFilter ff_vf_hwupload_hantro = {
    .name        = "hwupload_hantro",
    .description = NULL_IF_CONFIG_SMALL("Upload a system memory frame to a hantro device."),

    .uninit      = hantroupload_uninit,

    .query_formats = hantroupload_query_formats,

    .priv_size  = sizeof(HantroUploadContext),
    .priv_class = &hantroupload_class,

    .inputs    = hantroupload_inputs,
    .outputs   = hantroupload_outputs,
    //.flags_internal = FF_FILTER_FLAG_HWFRAME_AWARE,
};

