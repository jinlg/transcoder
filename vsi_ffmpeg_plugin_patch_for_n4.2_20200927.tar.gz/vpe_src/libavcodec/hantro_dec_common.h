#ifndef HANTRO_DEC_COMMON_H_
#define HANTRO_DEC_COMMON_H_

#include "libavutil/opt.h"

#include "hantro_dec_tb_defs.h"
#include "dectypes.h"
#include "refbuffer.h"
#include "h264decapi.h"
#include "hevcdecapi.h"
#include "vp9decapi.h"
#include "hantro_dec_decapi.h"


#include "time.h"

#ifdef SW_PERFORMANCE
#define INIT_SW_PERFORMANCE   \
  double dec_cpu_time = 0;    \
  clock_t dec_start_time = 0; \
  clock_t dec_end_time = 0;
#else
#define INIT_SW_PERFORMANCE
#endif

#ifdef SW_PERFORMANCE
#define START_SW_PERFORMANCE dec_start_time = clock();
#else
#define START_SW_PERFORMANCE
#endif

#ifdef SW_PERFORMANCE
#define END_SW_PERFORMANCE \
  dec_end_time = clock();  \
  dec_cpu_time += ((double)(dec_end_time - dec_start_time)) / CLOCKS_PER_SEC;
#else
#define END_SW_PERFORMANCE
#endif

#ifdef SW_PERFORMANCE
#define FINALIZE_SW_PERFORMANCE printf("SW_PERFORMANCE %0.5f\n", dec_cpu_time);
#else
#define FINALIZE_SW_PERFORMANCE
#endif

#ifdef SW_PERFORMANCE
#define FINALIZE_SW_PERFORMANCE_PP \
  printf("SW_PERFORMANCE_PP %0.5f\n", dec_cpu_time);
#else
#define FINALIZE_SW_PERFORMANCE_PP
#endif



#define NUM_RETRY   100 /* how many retries after HW timeout */
#define MAX_BUFFERS 78
#define ALIGNMENT_MASK 7
#define MAX_WAIT_FOR_CONSUME_BUFFERS 100



#ifdef FB_SYSLOG_ENABLE
#include "syslog_sink.h"
#define HANTRO_DEC_INFO_PRINT(fmt, ...) FB_SYSLOG(&fb_dec_ctx->log_header,SYSLOG_SINK_LEV_INFO,fmt, ## __VA_ARGS__)
#define HANTRO_DEC_ERROR_PRINT(fmt, ...) FB_SYSLOG(&fb_dec_ctx->log_header,SYSLOG_SINK_LEV_ERROR,"%s([%d]): " fmt,\
                                    __FUNCTION__, __LINE__, ## __VA_ARGS__)
#define HANTRO_DEC_DEBUG_PRINT(fmt, ...) FB_SYSLOG(&fb_dec_ctx->log_header,SYSLOG_SINK_LEV_DEBUG_SW,"%s([%d]): " fmt,\
                                    __FUNCTION__, __LINE__, ## __VA_ARGS__)
#define HANTRO_DEC_DEBUGV_PRINT(fmt, ...) FB_SYSLOG(&fb_dec_ctx->log_header,SYSLOG_SINK_LEV_DEBUG_SW_VERBOSE,"%s([%d]): " fmt,\
                                    __FUNCTION__, __LINE__, ## __VA_ARGS__)
#endif


typedef const void *HantroDecInst;

typedef struct HantroDecPicWaitForConsume {
    struct DecPicturePpu *pic;
    u8 wait_for_consume;
}HantroDecPicWaitForConsume;



struct HnatroDecDecoderWrapper {
  void* inst;
  enum DecRet (*init)(const void** inst, struct DecConfig config,
                      const void *dwl);
  enum DecRet (*GetInfo)(void* inst, struct DecSequenceInfo* info);
  enum DecRet (*SetInfo)(void* inst, struct DecConfig info, struct DecSequenceInfo* Info);
  enum DecRet (*Decode)(void* inst, struct DWLLinearMem input, struct DecOutput* output,
                              u8* stream, u32 strm_len, u32 pic_id, void *p_user_data);
  enum DecRet (*NextPicture)(void* inst, struct DecPicturePpu* pic);
  enum DecRet (*PictureConsumed)(void* inst, struct DecPicturePpu pic);
  enum DecRet (*EndOfStream)(void* inst);
  void (*Release)(void* inst);
#ifdef USE_EXTERNAL_BUFFER
  enum DecRet (*GetBufferInfo)(void *inst, struct DecBufferInfo *buf_info);
  enum DecRet (*AddBuffer)(void *inst, struct DWLLinearMem *buf);
#endif
  enum DecRet (*UseExtraFrmBuffers)(const void *inst, u32 n);
};

typedef struct Resize_s {
  int x;
  int y;
  int cw;
  int ch;
  int sw;
  int sh;
} Resize_t;

struct DecOutput {
    u8* strm_curr_pos;
    addr_t strm_curr_bus_address;
    u32 data_left;
    u8* strm_buff;
    addr_t strm_buff_bus_address;
    u32 buff_size;
};

typedef enum HANTRO_ENC_TYPE {
    HANTRO_ENC_NONE,
    HANTRO_ENC_H264,
    HANTRO_ENC_HEVC,
    HANTRO_ENC_VP9
} HANTRO_ENC_TYPE;

typedef struct HantroDecContext {
    const AVClass *class;//should be put here!
    AVCodecContext *avctx;   

    AVBufferRef *hwdevice;
    AVBufferRef *hwframe;

#ifdef FB_SYSLOG_ENABLE
  LOG_INFO_HEADER log_header;
    char module_name[16];
#endif

	u8 *pp_setting;
    u8 *dev_name;
    u32 disable_dec400;
    u32 disable_dtrc;    
    struct TBPpUnitParams pp_units_params_from_cmd[4];
    u8 pp_units_params_from_cmd_valid;
    u32 test_fb_int;
	u8 *stream_stop ;
	u32 packetize ;
	u32 nal_unit_stream ;
	
	u32 enable_mc;
	u32 force_to_single_core ;
	/* PP only mode. Decoder is enabled only to generate PP input trace file.*/
	u32 pp_tile_out ;    /* PP tiled output */
	u32 pp_planar_out ;
	u32 ystride ;
	u32 cstride ;
	/* stream start address */
	u8 *byte_strm_start;
	u32 trace_used_stream ;
	DecPicAlignment align ;  /* default: 128 bytes alignment */
	u32 seed_rnd;
    u32 prev_width;
    u32 prev_height;    
    u32 got_package_number;

	/* output file writing disable */
	u32 disable_output_writing ;
	u32 retry ;

	u32 clock_gating ;
	u32 data_discard ;
	u32 latency_comp ;
	u32 output_picture_endian ;
	u32 bus_burst_length ;
	u32 asic_service_priority ;
	u32 output_format ;
	u32 service_merge_disable ;
    
    u32 clock_gating_runtime ;
    u32 bus_width ;
    
    u32 strm_swap ;
    u32 pic_swap ;
    u32 dirmv_swap;
    u32 tab0_swap ;
    u32 tab1_swap;
    u32 tab2_swap;
    u32 tab3_swap;
    u32 rscan_swap;
    u32 max_burst ;
    u32 double_ref_buffer ;
    u32 timeout_cycles ;    

	u32 stream_truncate ;
	u32 stream_packet_loss ;
	u32 stream_header_corrupt ;
	u32 hdrs_rdy ;
	u32 pic_rdy ;

	u32 num_errors;
    
	u32 tiled_output ;
	u32 dpb_mode ;
	u32 convert_tiled_output ;
	
	u32 use_peek_output ;
	u32 enable_mvc ;
	u32 mvc_separate_views ;
	u32 skip_non_reference ;
    u32 convert_to_frame_dpb ;

    u32 rlc_mode;
    u32 mb_error_concealment;

    u32 pp_enabled ;

    u32 scale_enabled;
    u32 scaled_w;
    u32 scaled_h;
    u32 crop_enabled;
    u32 crop_x;
    u32 crop_y;
    u32 crop_w;
    u32 crop_h;

	u32 crop_display;

	enum SCALE_MODE scale_mode;

	HantroDecInst dec_inst;
	void *dwl_inst ;
	
	u32 use_extra_buffers_num ;
	//u32 allocate_extra_buffers_in_output ;
	u32 buffer_size;
	u32 num_buffers;	/* external buffers allocated yet. */
    u32 min_buffer_num;
	//u32 add_buffer_thread_run ;
	//pthread_t add_buffer_thread;
	//pthread_mutex_t ext_buffer_contro;
	struct DWLLinearMem ext_buffers[MAX_BUFFERS];
    //u32 buffer_consumed[MAX_BUFFERS];
	//u32 buffer_release_flag;
    
	u32 error_conceal;
	
	u32 disable_output_reordering;
	u32 pic_display_number;
	u32 pic_decode_number;
	//u32 last_pic_flag;
	//u32 add_extra_flag;
	u32 res_changed;
	u32 pic_size;
	
	struct TBCfg tb_cfg;
	struct DWLInitParam dwl_init;

	enum DecRet rv;
	/* one extra stream buffer so that we can decode ahead,
	 * and be ready when core has finished
	 */
	#define MAX_STRM_BUFFERS    (MAX_ASIC_CORES + 1)
	
	struct DWLLinearMem stream_mem[MAX_STRM_BUFFERS];
	long int max_strm_len;
	u32 allocated_buffers;
	u32 stream_mem_index;

	u32 max_num_pics;
	u8 *tmp_image ;
	u32 process_end_flag;
	u32 stream_size;
	u32 low_latency;
	u32 low_latency_sim;
    
    u32 picRdy;
    int64_t pts;
    int64_t pkt_dts;
    
#define PTS_DTS_MAX_DELAY 36
    struct {
        int64_t pts_delay;
        int64_t pkt_dts_delay;
        u32 pkt_pic_id;
        int valid;
    } dec_pts_dts_delay[PTS_DTS_MAX_DELAY];
    int64_t last_pts;
	
    //sem_t buf_release_sem;
   // struct DecPicturePpu buf_list[100];
    //u32 buf_status[100];
    //u32 list_pop_index;
    //u32 list_push_index;
    int eos_flush;
	
	pthread_t release_thread;
	int output_thread_run;

    H264DecBufferInfo h264_hbuf;
    H264DecOutput h264_dec_output;
    H264DecInput h264_dec_input;

    struct HevcDecInput hevc_dec_input;
    
    struct DecOutput dec_output;
    //struct DecInput dec_input;
            
    u8 *enc_format;
    HANTRO_ENC_TYPE enc_type;
    int vce_ds_enable;
    int buffer_depth;
    
    struct DecPicturePpu pic;
    u32 cycle_count; /* Sum of average cycles/mb counts */

    u32 initialized;
    u32 closed;
    HantroDecPicWaitForConsume wait_for_consume_list[MAX_WAIT_FOR_CONSUME_BUFFERS];
    u32 wait_consume_num;
    pthread_mutex_t consume_mutex;
    void (*hantro_decode_picture_consume)(void *opaque, uint8_t *data);

    
    enum DecCodec codec;
    struct DecConfig hantro_dec_config;
    struct DecSequenceInfo  sequence_info;
    struct HnatroDecDecoderWrapper hantro_dec_wrapper;
    Resize_t resizes[4];
    int resize_num;
    int mem_err_test;
}HantroDecContext;


struct statistic {
  u32 frame_count;
  u32 cycle_mb_avg;
  double ssim_avg;
  u32 bitrate_avg;
  u32 hw_real_time_avg;
  u32 hw_real_time_avg_remove_overlap;
  i32 total_usage;
  i32 core_usage_counts[4];
};

extern const AVOption hantro_decode_options[];


void TBSetDefaultCfg(struct TBCfg* tb_cfg) ;
void SetupDefaultParams(struct TestParams* params);
u32 TBGetDecRlcModeForced(const struct TBCfg* tb_cfg);
u32 TBGetDecClockGating(const struct TBCfg* tb_cfg) ;
u32 TBGetDecDataDiscard(const struct TBCfg* tb_cfg) ;
u32 TBGetDecOutputPictureEndian(const struct TBCfg* tb_cfg) ;
u32 TBGetDecOutputFormat(const struct TBCfg* tb_cfg);
u32 TBGetDecServiceMergeDisable(const struct TBCfg* tb_cfg);
u32 TBGetDecBusWidth(const struct TBCfg* tb_cfg) ;
void TBSetRefbuMemModel( const struct TBCfg* tb_cfg, u32 *reg_base, struct refBuffer *p_refbu );
void ResolvePpParamsOverlapPPU(PpUnitConfig *ppu_cfg,struct TBPpUnitParams *pp_units_params);


void printDecodeReturn(AVCodecContext *avctx,i32 retval);
void fb_print_pic_coding_type(AVCodecContext *avctx,u32 *pic_type) ;

int hantro_dec_set_pts_dts(HantroDecContext *fb_dec_ctx, AVPacket *avpkt);

int hantro_dec_output_frame(AVCodecContext *avctx, AVFrame *out, struct DecPicturePpu *pic);
void hantro_dec_performance_report(AVCodecContext *avctx);
void hantro_dec_log_header_init(AVCodecContext *avctx);
void report_dec_pic_info(AVCodecContext *avctx, struct DecPicturePpu *picture);
void InitDecPicWaitConsumeList(HantroDecContext *fb_dec_ctx);
u32 FindDecPicWaitConsumeIndex(HantroDecContext *fb_dec_ctx,u8 *data);
u32 FindDecPicWaitConsumeEmptyIndex(HantroDecContext *fb_dec_ctx);
u32 AddDecPicWaitConsumeList(HantroDecContext *fb_dec_ctx, void *data);
u32 DelDecPicWaitConsumeList(HantroDecContext *fb_dec_ctx, u8 *data);
void FreeDecPicWaitConsumeList(HantroDecContext *fb_dec_ctx);


enum DecRet InitHantroDecDecodeWrapper(AVCodecContext *avctx,enum DecCodec codec);
void HantroDecSetDefaultDecconfig(AVCodecContext *avctx,enum DecCodec codec);
int HantroDecParseResize(AVCodecContext *avctx);
int hantro_dec_init_hwctx(AVCodecContext *avctx);
int hantro_send_avpkt_to_decode_buffer(AVCodecContext *avctx, AVPacket *avpkt, struct DWLLinearMem stream_buffer);
int hantro_set_buffer_number_for_trans(AVCodecContext *avctx);
int hantro_check_enc_format_for_trans(AVCodecContext *avctx);
int hantro_check_buffer_number_for_trans(HantroDecContext *dec_ctx);
void hantro_dec_release_ext_buffers(HantroDecContext *fb_dec_ctx);


#endif

