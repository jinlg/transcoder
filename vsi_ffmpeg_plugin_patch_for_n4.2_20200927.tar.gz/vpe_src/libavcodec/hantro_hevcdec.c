

#define UNCHECKED_BITSTREAM_READER 1

#include "libavutil/avassert.h"
#include "libavutil/display.h"
#include "libavutil/imgutils.h"
#include "libavutil/opt.h"
#include "libavutil/stereo3d.h"
#include "libavutil/timer.h"
#include "internal.h"
#include "bytestream.h"
#include "cabac.h"
#include "cabac_functions.h"
#include "error_resilience.h"
#include "avcodec.h"
#include "hantro_hevcdec.h"
#include "thread.h"
#include "hevcdecapi.h"
#include "dwl.h"
#include "hevc_container.h"
#include "decode.h"
#include "avcodec.h"
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <dectypes.h>
#include "hevcdecapi.h"
#include "hantro_dec_common.h"
#include "transcoder.h"
#include "hwaccel.h"
#include "libavutil/hwcontext_hantro.h"


static enum DecRet HevcNextPicture(void* inst, struct DecPicturePpu* pic)
{
    enum DecRet rv;
    u32 stride, stride_ch, i, bit_depth;
    struct HevcDecPicture hpic= {0};
    u32 *tile_status_virtual_address=NULL;
    addr_t tile_status_bus_address=0;
    u32 tile_status_address_offset=0;

    rv = HevcDecNextPicture(inst, &hpic);
    if (rv != DEC_PIC_RDY)
    return rv;
    memset(pic, 0, sizeof(struct DecPicturePpu));
    /*sunny add*/
    pic->pictures[0].luma_table.bus_address= hpic.output_rfc_luma_bus_address;
#ifndef	NEW_MEM_ALLOC
    pic->pictures[0].luma_table.virtual_address = hpic.output_rfc_luma_base;
#endif
    pic->pictures[0].chroma_table.bus_address= hpic.output_rfc_chroma_bus_address;
#ifndef	NEW_MEM_ALLOC
    pic->pictures[0].chroma_table.virtual_address = hpic.output_rfc_chroma_base;
#endif
    pic->pictures[0].pic_compressed_status = hpic.rfc_compressed ? 1 : 0;/*sunny add for rfc compressed status*/

    u32 pic_width_in_cbsy, pic_height_in_cbsy;
    u32 pic_width_in_cbsc, pic_height_in_cbsc;
    pic_width_in_cbsy = ((hpic.pictures[0].pic_width + 8 - 1)/8);
    pic_width_in_cbsy = NEXT_MULTIPLE(pic_width_in_cbsy, 16);
    pic_width_in_cbsc = ((hpic.pictures[0].pic_width + 16 - 1)/16);
    pic_width_in_cbsc = NEXT_MULTIPLE(pic_width_in_cbsc, 16);
    pic_height_in_cbsy = (hpic.pictures[0].pic_height + 8 - 1)/8;
    pic_height_in_cbsc = (hpic.pictures[0].pic_height/2 + 4 - 1)/4;

    u32 tbl_sizey = NEXT_MULTIPLE(pic_width_in_cbsy * pic_height_in_cbsy, 16);
    u32 tbl_sizec = NEXT_MULTIPLE(pic_width_in_cbsc * pic_height_in_cbsc, 16);

    pic->pictures[0].luma_table.size = tbl_sizey;
    pic->pictures[0].chroma_table.size = tbl_sizec;
    /*sunny add*/

    for (i = 0; i < DEC_MAX_OUT_COUNT; i++) {
        /*
        if (!hpic.pp_enabled) {
        if(hpic.pictures[0].output_format == DEC_OUT_FRM_TILED_4X4) {
        bit_depth = (hpic.bit_depth_luma == 8 && hpic.bit_depth_chroma == 8) ? 8 : 10;
        stride = hpic.pictures[0].pic_width * bit_depth / 8; 
        } else {
        stride = hpic.pictures[0].pic_stride;
        }
        stride_ch = stride;
        } else*/ 
        if ( hpic.pictures[i].pixel_format == DEC_OUT_PIXEL_RFC) {
            /* Compressed tiled data should be output without being converted to 16 bits.
            * It's treated as a special picture to output. */
            u32 bit_depth = (hpic.bit_depth_luma == 8 &&
            hpic.bit_depth_luma == 8) ? 8 : 10;
            stride = hpic.pictures[i].pic_width * 4 * bit_depth / 8;
            stride_ch = stride;
        }
        else
        {
            stride = hpic.pictures[i].pic_stride;
            stride_ch = hpic.pictures[i].pic_stride_ch;
        }
#ifndef	NEW_MEM_ALLOC
        pic->pictures[i].luma.virtual_address = (u32*)hpic.pictures[i].output_picture;
#endif
        pic->pictures[i].luma.bus_address = hpic.pictures[i].output_picture_bus_address;
#if 0
        if (hpic.output_format == DEC_OUT_FRM_RASTER_SCAN)
        hpic.pic_width = NEXT_MULTIPLE(hpic.pic_width, 16);
#endif

        if ((hpic.pictures[i].output_format == DEC_OUT_FRM_TILED_4X4) /*&& hpic.pp_enabled*/) {
#if 0
            pic->pictures[i].luma.size = stride * hpic.pictures[i].pic_height / 4;
            /*pic->pictures[i].chroma.size = stride_ch * hpic.pictures[i].pic_height / 8;*/
            if((hpic.pictures[i].pic_height / 4)&1 == 1)
                pic->pictures[i].chroma.size = stride_ch * (hpic.pictures[i].pic_height/4+1) / 2;
            else
                pic->pictures[i].chroma.size = stride_ch * hpic.pictures[i].pic_height / 8;
#else
            pic->pictures[i].luma.size = stride * NEXT_MULTIPLE(hpic.pictures[i].pic_height, 4) / 4;
            pic->pictures[i].chroma.size = stride_ch * NEXT_MULTIPLE(hpic.pictures[i].pic_height/2, 4) / 4;
#endif
        } else {
            pic->pictures[i].luma.size = stride * hpic.pictures[i].pic_height;
            pic->pictures[i].chroma.size = stride_ch * hpic.pictures[i].pic_height;
        }
        /* TODO temporal solution to set chroma base here */
#ifndef	NEW_MEM_ALLOC
        pic->pictures[i].chroma.virtual_address = (u32*)hpic.pictures[i].output_picture_chroma;
#endif
        pic->pictures[i].chroma.bus_address = hpic.pictures[i].output_picture_chroma_bus_address;
        /* TODO(vmr): find out for real also if it is B frame */
        pic->pictures[i].picture_info.pic_coding_type =
        hpic.is_idr_picture ? DEC_PIC_TYPE_I : DEC_PIC_TYPE_P;
        pic->pictures[i].picture_info.format = hpic.pictures[i].output_format;
        pic->pictures[i].picture_info.pixel_format = hpic.pictures[i].pixel_format;
        pic->pictures[i].picture_info.pic_id = hpic.pic_id;
        pic->pictures[i].picture_info.decode_id = hpic.decode_id;
        pic->pictures[i].picture_info.cycles_per_mb = hpic.cycles_per_mb;
        pic->pictures[i].sequence_info.pic_width = hpic.pictures[i].pic_width;
        pic->pictures[i].sequence_info.pic_height = hpic.pictures[i].pic_height;
        pic->pictures[i].sequence_info.crop_params.crop_left_offset =
        hpic.crop_params.crop_left_offset;
        pic->pictures[i].sequence_info.crop_params.crop_out_width =
        hpic.crop_params.crop_out_width;
        pic->pictures[i].sequence_info.crop_params.crop_top_offset =
        hpic.crop_params.crop_top_offset;
        pic->pictures[i].sequence_info.crop_params.crop_out_height =
        hpic.crop_params.crop_out_height;
        pic->pictures[i].sequence_info.sar_width = hpic.dec_info.sar_width;
        pic->pictures[i].sequence_info.sar_height = hpic.dec_info.sar_height;
        pic->pictures[i].sequence_info.video_range = hpic.dec_info.video_range;
        pic->pictures[i].sequence_info.matrix_coefficients =
        hpic.dec_info.matrix_coefficients;
        pic->pictures[i].sequence_info.is_mono_chrome =
        hpic.dec_info.mono_chrome;
        pic->pictures[i].sequence_info.is_interlaced = hpic.dec_info.interlaced_sequence;
        pic->pictures[i].sequence_info.num_of_ref_frames =
        hpic.dec_info.pic_buff_size;
        pic->pictures[i].sequence_info.bit_depth_luma = hpic.bit_depth_luma;
        pic->pictures[i].sequence_info.bit_depth_chroma = hpic.bit_depth_chroma;
        pic->pictures[i].sequence_info.main10_profile = hpic.main10_profile;
        pic->pictures[i].sequence_info.pic_stride = hpic.pictures[i].pic_stride;
        pic->pictures[i].sequence_info.pic_stride_ch = hpic.pictures[i].pic_stride_ch;
        pic->pictures[i].pic_width = hpic.pictures[i].pic_width;
        pic->pictures[i].pic_height = hpic.pictures[i].pic_height;
        pic->pictures[i].pic_stride = hpic.pictures[i].pic_stride;
        pic->pictures[i].pic_stride_ch = hpic.pictures[i].pic_stride_ch;
        pic->pictures[i].pp_enabled = hpic.pp_enabled;
        if((hpic.multi_tile_cols == 0)&&(i>0)&&(pic->pictures[i].luma.size != 0))/*mark the dpb total buffer base address*/
        {
            if(tile_status_bus_address == 0)
            {
#ifndef	NEW_MEM_ALLOC
            tile_status_virtual_address = pic->pictures[i].luma.virtual_address;
#endif
            tile_status_bus_address = pic->pictures[i].luma.bus_address;
            }
            tile_status_address_offset += pic->pictures[i].luma.size + PP_LUMA_BUF_RES;
            tile_status_address_offset += pic->pictures[i].chroma.size + PP_CHROMA_BUF_RES;
        }


    }
    /*tile_status_address_offset = NEXT_MULTIPLE(tile_status_address_offset,0x2000);*/
    for (i = 0; i < DEC_MAX_OUT_COUNT; i++) {
        if((hpic.multi_tile_cols == 0)&&(i>0)&&(pic->pictures[i].luma.size != 0)
#ifndef	NEW_MEM_ALLOC
        &&(pic->pictures[i].luma_table.virtual_address == NULL)
#else
        &&(pic->pictures[i].luma_table.bus_address== 0)
#endif
        )
        {
#ifndef	NEW_MEM_ALLOC
            pic->pictures[i].luma_table.virtual_address = (u32*)((addr_t)tile_status_virtual_address + tile_status_address_offset + DEC400_PPn_Y_TABLE_OFFSET(i-1));
#endif
            pic->pictures[i].luma_table.bus_address= tile_status_bus_address + tile_status_address_offset+ DEC400_PPn_Y_TABLE_OFFSET(i-1);
            pic->pictures[i].luma_table.size = NEXT_MULTIPLE(pic->pictures[i].luma.size/1024/4 +((pic->pictures[i].luma.size%4096)?1:0), 16);

#ifndef	NEW_MEM_ALLOC
            pic->pictures[i].chroma_table.virtual_address = (u32*)((addr_t)tile_status_virtual_address + tile_status_address_offset + DEC400_PPn_UV_TABLE_OFFSET(i-1));
#endif
            pic->pictures[i].chroma_table.bus_address= tile_status_bus_address + tile_status_address_offset+ DEC400_PPn_UV_TABLE_OFFSET(i-1);
            pic->pictures[i].chroma_table.size = NEXT_MULTIPLE(pic->pictures[i].chroma.size/1024/4 +((pic->pictures[i].chroma.size%4096)?1:0), 16);

#ifdef SUPPORT_DEC400		
            pic->pictures[i].pic_compressed_status = hpic.pictures[i].pic_compressed_status;
#else
            pic->pictures[i].pic_compressed_status = 0;
#endif
        }
    }
    //HevcDecPictureConsumed(inst, &hpic);
    return rv;
}

static void hantro_decode_hevc_picture_consume(void *opaque, uint8_t *data) 
{
    HantroDecContext *fb_dec_ctx = opaque;
    struct DecPicturePpu pic = *((struct DecPicturePpu *)data);
    struct HevcDecPicture vpic;
    u32 i;
    
    if(fb_dec_ctx->initialized)
    {
        memset(&vpic, 0, sizeof(struct HevcDecPicture));
        /* TODO chroma base needed? */
        for (i = 0; i < DEC_MAX_OUT_COUNT; i++) {
#ifndef NEW_MEM_ALLOC
            vpic.pictures[i].output_picture = pic.pictures[i].luma.virtual_address;
#endif
            vpic.pictures[i].output_picture_bus_address = pic.pictures[i].luma.bus_address;
        }
        vpic.pp_enabled = pic.pictures[0].pp_enabled;
        //av_log(NULL, AV_LOG_ERROR, "HevcPictureConsumed  vpic.pp_enabled=%d..... \n", vpic.pp_enabled);

        vpic.is_idr_picture = pic.pictures[0].picture_info.pic_coding_type == DEC_PIC_TYPE_I;
        DelDecPicWaitConsumeList(fb_dec_ctx,data);
        HevcDecPictureConsumed(fb_dec_ctx->dec_inst, &vpic);
    }
    else
        av_log(NULL, AV_LOG_DEBUG, "in %s  after close @ %p ..... \n",__FUNCTION__, data);
    if (data) av_free(data);
}

static av_cold int hantro_decode_hevc_close(AVCodecContext *avctx){

    HantroDecContext *fb_dec_ctx = avctx->priv_data;
    struct HANTRODWL *dwl = (struct HANTRODWL *)fb_dec_ctx->dwl_inst;
    int i;
    int ret;
#if 0
    if(fb_dec_ctx->initialized == 0)
    {
        av_log(avctx, AV_LOG_DEBUG, "fb_dec_ctx->initialized=%d, no inited... \n",fb_dec_ctx->initialized);
        return 0;
    }
#endif
    av_log(avctx, AV_LOG_DEBUG, "in hantro_decode_hevc_close HevcDecEndOfStream  EOS... \n");

	if(fb_dec_ctx->closed == 1)
		return 0;

//    FreeDecPicWaitConsumeList(fb_dec_ctx);
    if(fb_dec_ctx->dec_inst)
    	HevcDecEndOfStream(fb_dec_ctx->dec_inst);

    //fb_dec_ctx->last_pic_flag = 1;
    fb_dec_ctx->closed = 1;


    for(i = 0; i < fb_dec_ctx->allocated_buffers; i++) {
        if(fb_dec_ctx->stream_mem[i].mem_type == DWL_MEM_TYPE_DPB)
            fb_dec_ctx->stream_mem[i].virtual_address = NULL;
        if( fb_dec_ctx->dec_inst)
            DWLFreeLinear(fb_dec_ctx->dwl_inst, & fb_dec_ctx->stream_mem[i]);
    }
    if(fb_dec_ctx->pic_display_number > 0)
        hantro_dec_performance_report(avctx);
    if(fb_dec_ctx->dec_inst)
        HevcDecRelease(fb_dec_ctx->dec_inst);
    //ReleaseExtBuffers(avctx);
    hantro_dec_release_ext_buffers(fb_dec_ctx);
	if(fb_dec_ctx->dwl_inst)
        DWLRelease(fb_dec_ctx->dwl_inst);
    
    av_buffer_unref(&fb_dec_ctx->hwframe);
    av_buffer_unref(&fb_dec_ctx->hwdevice);

    
    av_log(avctx, AV_LOG_DEBUG, "\t\t-------------hantro_decode_hevc_close ..............\n");
    fb_dec_ctx->initialized = 0;
    
    return 0;
}

static enum DecRet fbHevcInit(HantroDecContext *fb_dec_ctx, struct DecConfig config,
                           const void *dwl) {
    enum DecPictureFormat format = config.output_format;

    struct HevcDecConfig dec_cfg;

    enum DecRet rv;

    memset(&dec_cfg,0,sizeof(struct HevcDecConfig));

    dec_cfg.use_video_freeze_concealment = 0;//config.concealment_mode;
    dec_cfg.use_video_compressor = config.use_video_compressor;
    dec_cfg.use_ringbuffer = 1;//config.use_ringbuffer;
    dec_cfg.output_format = DEC_OUT_FRM_TILED_4X4;//formast;
    dec_cfg.tile_by_tile = config.tile_by_tile;
    dec_cfg.no_output_reordering = 0;//config.disable_picture_reordering;
    dec_cfg.decoder_mode = DEC_NORMAL;

#ifdef USE_EXTERNAL_BUFFER
    dec_cfg.guard_size = 0;
    dec_cfg.use_adaptive_buffers = 0;
#endif

    av_log(NULL,AV_LOG_DEBUG, "HevcInit config.ppu_cfg[0].out_cut_8bits=%d\n",config.ppu_cfg[0].out_cut_8bits);
    /*  
    if (config.ppu_cfg[0].out_cut_8bits)
    dec_cfg.pixel_format = DEC_OUT_PIXEL_CUT_8BIT;
    else if (config.ppu_cfg[0].out_p010)
    dec_cfg.pixel_format = DEC_OUT_PIXEL_P010;
    else if (config.ppu_cfg[0].out_be)
    dec_cfg.pixel_format = DEC_OUT_PIXEL_CUSTOMER1;
    else
    */
    dec_cfg.pixel_format = DEC_OUT_PIXEL_DEFAULT;

    config.ppu_cfg[0].align = 0;

    memcpy(dec_cfg.ppu_cfg, config.ppu_cfg, sizeof(config.ppu_cfg));

    av_log(NULL,AV_LOG_DEBUG, "HevcInit before HevcDecInit !!\n");
    rv = HevcDecInit(&fb_dec_ctx->dec_inst, dwl, &dec_cfg);
    av_log(NULL,AV_LOG_DEBUG, "HevcInit after  HevcDecInit rv = %d,fb_dec_ctx->dec_inst=%p!!\n",rv,fb_dec_ctx->dec_inst);
    return rv;
}


static av_cold int hantro_decode_hevc_init(AVCodecContext *avctx)
{
    int ret;
    HantroDecContext *fb_dec_ctx = avctx->priv_data;
    struct HANTRODWL *dec_dwl;
    u32 n_cores;
    FILE *f_tbcfg;
    u32 major_version, minor_version, prod_id = 0;
    enum DecDpbFlags flags = 0;
    u32 size, i;
    enum DecRet rv;
    AVHANTRODeviceContext *device_hwctx;
    AVHANTROFramesContext *frame_hwctx;
    AVHWDeviceContext *device_ctx;
    AVHWFramesContext *hwframe_ctx;
    
    if(fb_dec_ctx->initialized == 1)
    {
        av_log(avctx, AV_LOG_DEBUG, "%s %d has initialized !!\n",__func__,__LINE__);
        return 0;
    }

    if (hantro_check_enc_format_for_trans(avctx))
        goto error;
    
    av_log(avctx, AV_LOG_TRACE, "%s(%d) avctx->hw_frames_ctx = %p\n", __FUNCTION__, __LINE__, avctx->hw_frames_ctx);
    
    ret = hantro_dec_init_hwctx(avctx);
    if(ret) goto error;
    
    hwframe_ctx = (AVHWFramesContext*)fb_dec_ctx->hwframe->data;    
    device_ctx = hwframe_ctx->device_ctx;
    device_hwctx = device_ctx->hwctx;
    frame_hwctx = hwframe_ctx->hwctx;
    
    av_log(avctx, AV_LOG_DEBUG, "device_ctx = %p, hwframe_ctx = %p\n", device_ctx, hwframe_ctx);
    av_log(avctx, AV_LOG_DEBUG, "device_hwctx = %p\n", device_hwctx);
    av_log(avctx, AV_LOG_DEBUG, "device_hwctx->internal = %p\n", device_hwctx->internal);
    av_log(avctx, AV_LOG_DEBUG, "device_hwctx->device = %s\n", device_hwctx->device);
    av_log(avctx, AV_LOG_DEBUG, "device_hwctx->priority = %d\n", device_hwctx->priority);
    
    InitHantroDecDecodeWrapper(avctx,DEC_HEVC);
    HantroDecSetDefaultDecconfig(avctx,DEC_HEVC);
    
    fb_dec_ctx->hantro_decode_picture_consume = hantro_decode_hevc_picture_consume;
    


    fb_dec_ctx->dev_name = av_strdup(device_hwctx->device);
    sprintf(fb_dec_ctx->module_name,"HEVCDEC");
    fb_dec_ctx->avctx = avctx;
    hantro_dec_log_header_init(avctx);
    
    av_log(avctx, AV_LOG_DEBUG, "to dump_ppuconfig 0\n");
    dump_ppuconfig(&fb_dec_ctx->log_header, &fb_dec_ctx->hantro_dec_config.ppu_cfg);
    
    fb_dec_ctx->stream_stop = NULL;
    fb_dec_ctx->align = DEC_ALIGN_1024B;
    fb_dec_ctx->clock_gating = DEC_X170_INTERNAL_CLOCK_GATING;
    fb_dec_ctx->data_discard = DEC_X170_DATA_DISCARD_ENABLE;
    fb_dec_ctx->latency_comp = DEC_X170_LATENCY_COMPENSATION;
    fb_dec_ctx->output_picture_endian = DEC_X170_OUTPUT_PICTURE_ENDIAN;
    fb_dec_ctx->bus_burst_length = DEC_X170_BUS_BURST_LENGTH;
    fb_dec_ctx->asic_service_priority = DEC_X170_ASIC_SERVICE_PRIORITY;
    fb_dec_ctx->output_format = DEC_X170_OUTPUT_FORMAT;
    fb_dec_ctx->service_merge_disable = DEC_X170_SERVICE_MERGE_DISABLE;
    fb_dec_ctx->tiled_output = DEC_REF_FRM_TILED_DEFAULT;
    fb_dec_ctx->dpb_mode = DEC_DPB_FRAME;
    fb_dec_ctx->pp_units_params_from_cmd_valid = 0;
    fb_dec_ctx->dwl_init.client_type = DWL_CLIENT_TYPE_HEVC_DEC;
    if(fb_dec_ctx->dev_name)
    fb_dec_ctx->dwl_init.dec_dev_name = fb_dec_ctx->dev_name;
    else
    fb_dec_ctx->dwl_init.dec_dev_name = device_hwctx->device;
    fb_dec_ctx->dwl_init.priority = device_hwctx->priority;
    avctx->pix_fmt = AV_PIX_FMT_HANTRO;//AV_PIX_FMT_HANTRO;

    //pthread_mutex_init(&fb_dec_ctx->ext_buffer_contro, NULL);

//    SetupDefaultParams(&fb_dec_ctx->params);

    memset(fb_dec_ctx->ext_buffers, 0, sizeof(fb_dec_ctx->ext_buffers));

    //fb_dec_ctx->buffer_release_flag = 1;
    fb_dec_ctx->cycle_count = 0;

    /* set test bench configuration */
    TBSetDefaultCfg(&fb_dec_ctx->tb_cfg);
    
    ResolvePpParamsOverlapPPU(fb_dec_ctx->hantro_dec_config.ppu_cfg,fb_dec_ctx->tb_cfg.pp_units_params);
    if(fb_dec_ctx->pp_setting && strlen(fb_dec_ctx->pp_setting) > 0)
    {
        if(HantroDecParseResize(avctx)) goto error;        
    }
    
    av_log(avctx, AV_LOG_DEBUG, "to dump_ppuconfig 1\n");
    dump_ppuconfig(&fb_dec_ctx->log_header, &fb_dec_ctx->hantro_dec_config.ppu_cfg);
    //ret = hantro_set_buffer_number_for_trans(avctx);
    //if(ret)goto error;
    HantroDecParsePPUCfg(avctx,fb_dec_ctx->hantro_dec_config.ppu_cfg);
    
    av_log(avctx, AV_LOG_DEBUG, "to dump_ppuconfig 2\n");
    dump_ppuconfig(&fb_dec_ctx->log_header, &fb_dec_ctx->hantro_dec_config.ppu_cfg);
    
    if (prod_id == 0x6731)
    fb_dec_ctx->max_strm_len = DEC_X170_MAX_STREAM;
    else
    fb_dec_ctx->max_strm_len = DEC_X170_MAX_STREAM_VC8000D;

    fb_dec_ctx->tb_cfg.pp_params.pipeline_e = 1;

    fb_dec_ctx->dwl_init.mem_id = frame_hwctx->task_id;

    av_log(avctx, AV_LOG_DEBUG, "device = %s\n", fb_dec_ctx->dwl_init.dec_dev_name);
    av_log(avctx, AV_LOG_DEBUG, "priority = %d\n", fb_dec_ctx->dwl_init.priority);
    av_log(avctx, AV_LOG_DEBUG, "mem_id = %d\n", fb_dec_ctx->dwl_init.mem_id);
    av_log(avctx, AV_LOG_DEBUG, "client_type = %d\n", fb_dec_ctx->dwl_init.client_type);

#if defined(ERROR_TEST_DEC_EDMA_TRANS) || defined(ERROR_TEST_DEC_EDMA_TRANS)
        if(fb_dec_ctx->mem_err_test > 0)
        {
            av_log(avctx, AV_LOG_DEBUG, "fb_dec_ctx->mem_err_test = %d\n", fb_dec_ctx->mem_err_test);
            fb_dec_ctx->dwl_init.mem_err_test = fb_dec_ctx->mem_err_test;
        }
        else
            fb_dec_ctx->dwl_init.mem_err_test = 0;
#else
        fb_dec_ctx->dwl_init.mem_err_test = 0;
#endif

    
    fb_dec_ctx->dwl_inst = DWLInit(&fb_dec_ctx->dwl_init);
    if(fb_dec_ctx->dwl_inst == NULL) {
        av_log(avctx, AV_LOG_ERROR, "DWLInit# ERROR: DWL Init failed\n");
        goto error;
    } else {
        av_log(avctx, AV_LOG_DEBUG, "DWLInit#: DWL Init OK\n");
    }	

    fb_dec_ctx->min_buffer_num = 0;

    struct DecConfig config;
    config.disable_picture_reordering = 0;
    config.concealment_mode = 0;
    config.align = DEC_ALIGN_1024B;//DEC_ALIGN_64B;
    config.decoder_mode = DEC_NORMAL;
    config.tile_by_tile = 0;
    //config.fscale_cfg = fb_dec_ctx->params.fscale_cfg;

    //memcpy(config.ppu_cfg, fb_dec_ctx->params.ppu_cfg, sizeof(config.ppu_cfg));
    ResolvePpParamsOverlapPPU(config.ppu_cfg,fb_dec_ctx->tb_cfg.pp_units_params);
    config.output_format = DEC_OUT_FRM_TILED_4X4;//DEC_OUT_FRM_TILED_4X4;
    av_log(avctx, AV_LOG_DEBUG, "Configuring hardware to output: %s\n",
    config.output_format == DEC_OUT_FRM_RASTER_SCAN
    ? "Semiplanar YCbCr 4:2:0 (four_cc 'NV12')"
    : "4x4 tiled YCbCr 4:2:0");
    config.dwl_inst = fb_dec_ctx->dwl_inst;
    config.max_num_pics_to_decode = 0;
    //config.use_8bits_output = client.test_params.force_output_8_bits; 
    //config.use_video_compressor = fb_dec_ctx->params.compress_bypass ? 0 : 1;
    config.use_video_compressor = fb_dec_ctx->disable_dtrc == 1 ? 0 : 1;
    config.use_ringbuffer =  1;/*fb_dec_ctx->params.is_ringbuffer;*/
    //config.use_p010_output = client.test_params.p010_output;

    config.mc_cfg.mc_enable = 0;
    config.mc_cfg.stream_consumed_callback = NULL;
    av_log(avctx, AV_LOG_DEBUG, "to dump_ppuconfig 3\n");
    dump_ppuconfig(&fb_dec_ctx->log_header, &config.ppu_cfg[0]);
    rv = fbHevcInit(fb_dec_ctx,config,fb_dec_ctx->dwl_inst);
    if(rv != DEC_OK) {
        av_log(avctx, AV_LOG_ERROR, "DECODER INITIALIZATION FAILED\n");
        goto error;
    } else {
        av_log(avctx, AV_LOG_DEBUG, "DECODER HevcInit Init OK\n");
    } 
    if (fb_dec_ctx->enable_mc) 
    size = 4096*1165;
    else
    //size = fb_dec_ctx->max_strm_len;
    size = 1*1024*1024;
    fb_dec_ctx->allocated_buffers = 0;

    av_log(avctx, AV_LOG_DEBUG, "begin DWLMallocLinear for stream mem!\n");
#ifdef ALWAYS_OUTPUT_REF
    HevcDecUseExtraFrmBuffers(fb_dec_ctx->dec_inst, fb_dec_ctx->use_extra_buffers_num);
#endif

    for(i = 0; i < MAX_STRM_BUFFERS; i++) {
        fb_dec_ctx->stream_mem[i].mem_type = DWL_MEM_TYPE_DPB;
        if(DWLMallocLinear(fb_dec_ctx->dwl_inst,
        size, fb_dec_ctx->stream_mem + i) != DWL_OK) {
            av_log(avctx, AV_LOG_ERROR, "UNABLE TO ALLOCATE STREAM BUFFER MEMORY\n");
            goto error;
        } else {
            fb_dec_ctx->allocated_buffers++;
            av_log(avctx, AV_LOG_DEBUG, "alloc memory for %d stream ,addr=0x%x, size is 0x%x OK\n",i,fb_dec_ctx->stream_mem[i].virtual_address,fb_dec_ctx->stream_mem[i].size);
        }
    }

    fb_dec_ctx->stream_mem_index = 0;
    fb_dec_ctx->pic_decode_number = 1;
    fb_dec_ctx->pic_display_number = 0;
    fb_dec_ctx->got_package_number = 0;
    fb_dec_ctx->prev_width = 0;
    fb_dec_ctx->prev_height = 0;
//    InitDecPicWaitConsumeList(avctx);
    fb_dec_ctx->initialized = 1;
    fb_dec_ctx->closed = 0;
    
    av_log(avctx, AV_LOG_DEBUG, "%s %d OK PID is %d!!\n",__func__,__LINE__,getpid());
    fb_dec_ctx->initialized = 1;   
    return 0;

error:
    hantro_decode_hevc_close(avctx);
    return AVERROR_UNKNOWN;
}

static u32 FindExtBufferIndex(AVCodecContext *avctx,u32 *addr) {
    u32 i;
    HantroDecContext *fb_dec_ctx = avctx->priv_data;
    for (i = 0; i < fb_dec_ctx->num_buffers; i++) {
        if (fb_dec_ctx->ext_buffers[i].bus_address == addr)
            break;
    }

    ASSERT(i < fb_dec_ctx->num_buffers);
    return i;
}

static  u32 FindEmptyIndex(AVCodecContext *avctx) {
    u32 i;
    HantroDecContext *fb_dec_ctx = avctx->priv_data;
    for (i = 0; i < MAX_BUFFERS; i++) {
        if (fb_dec_ctx->ext_buffers[i].bus_address == 0)
        break;
    }

    ASSERT(i < MAX_BUFFERS);
    return i;
}

#if 0
static void ReleaseExtBuffers(AVCodecContext *avctx) {

    HantroDecContext *fb_dec_ctx = avctx->priv_data;

    int i;
    pthread_mutex_lock(&fb_dec_ctx->ext_buffer_contro);
    for(i=0; i<fb_dec_ctx->num_buffers; i++) {
        av_log(avctx, AV_LOG_DEBUG,"Freeing buffer %p\n", (void *)fb_dec_ctx->ext_buffers[i].virtual_address);
        if (fb_dec_ctx->pp_enabled)
            DWLFreeLinear(fb_dec_ctx->dwl_inst, &fb_dec_ctx->ext_buffers[i]);
        else
            DWLFreeRefFrm(fb_dec_ctx->dwl_inst, &fb_dec_ctx->ext_buffers[i]);

        DWLmemset(&fb_dec_ctx->ext_buffers[i], 0, sizeof(fb_dec_ctx->ext_buffers[i]));
    }
    pthread_mutex_unlock(&fb_dec_ctx->ext_buffer_contro);
}
#endif
static enum DecRet HevcDecode(void* inst, struct DWLLinearMem input, struct DecOutput* output,
                              u8* stream, u32 strm_len, u32 pic_id) {
    enum DecRet rv;
    struct HevcDecInput hevc_input;
    struct HevcDecOutput hevc_output;
    u32 data_consumed = 0;
    memset(&hevc_input, 0, sizeof(hevc_input));
    memset(&hevc_output, 0, sizeof(hevc_output));
    hevc_input.stream = (u8*)stream;
    hevc_input.stream_bus_address = input.bus_address + ((addr_t)stream - (addr_t)input.virtual_address);
    hevc_input.data_len = strm_len;
    hevc_input.buffer = (u8 *)input.virtual_address;
    hevc_input.buffer_bus_address = input.bus_address;
    hevc_input.buff_len = strm_len;
    hevc_input.pic_id = pic_id;
    /* TODO(vmr): hevc must not acquire the resources automatically after
    *            successful header decoding. */
    rv = HevcDecDecode(inst, &hevc_input, &hevc_output);
    output->strm_curr_pos = hevc_output.strm_curr_pos;
    output->strm_curr_bus_address = hevc_output.strm_curr_bus_address;
    output->data_left = hevc_output.data_left;
    return rv;
}




static int hantro_decode_hevc_decode_frame(AVCodecContext *avctx, void *data,
                             int *got_frame, AVPacket *avpkt)
{
//    if(avpkt)
//    av_log(avctx, AV_LOG_DEBUG, " begin hantro_decode_hevc_decode_frame...  avpkt->size = %d,avpkt->pts=%lx,avpkt->dts=%ld\n", avpkt->size,avpkt->pts,avpkt->dts);

    const uint8_t *buf = avpkt->data;
    int buf_size       = avpkt->size;
    HantroDecContext *fb_dec_ctx  = avctx->priv_data;
    AVFrame *out = ( AVFrame *)data;
    struct HANTRODWL *dwl = (struct HANTRODWL *)fb_dec_ctx->dwl_inst;
    AVFrame *pict = ( AVFrame *)data;
    int buf_index;
    enum DecRet ret;
    u32 tmp;
    int i,j;
    u8 *image_data;
    struct HevcDecInput dec_input;

    *got_frame = 0;
    if(avpkt)
   av_log(avctx, AV_LOG_DEBUG, " begin hantro_decode_hevc_decode_frame...  avpkt->size = %d,avpkt->pts=%lx,avpkt->dts=%ld\n", avpkt->size,avpkt->pts,avpkt->dts);

	if(avpkt->size > fb_dec_ctx->stream_mem[fb_dec_ctx->stream_mem_index].size)
	{
		av_log(avctx, AV_LOG_DEBUG, "avpkt->size is too large(%d > %d @%d), re-allocing... \n",avpkt->size,fb_dec_ctx->stream_mem[fb_dec_ctx->stream_mem_index].size,fb_dec_ctx->stream_mem_index);
		fb_dec_ctx->stream_mem[fb_dec_ctx->stream_mem_index].virtual_address = NULL;
		DWLFreeLinear(fb_dec_ctx->dwl_inst, &fb_dec_ctx->stream_mem[fb_dec_ctx->stream_mem_index]);
		//alloc again
		av_log(avctx, AV_LOG_DEBUG, "alloc again(%d), re-allocing... \n",avpkt->size);
		fb_dec_ctx->stream_mem[fb_dec_ctx->stream_mem_index].mem_type = DWL_MEM_TYPE_DPB;
        if(DWLMallocLinear(fb_dec_ctx->dwl_inst, avpkt->size, fb_dec_ctx->stream_mem + fb_dec_ctx->stream_mem_index) != DWL_OK) {
            av_log(avctx, AV_LOG_ERROR, "UNABLE TO ALLOCATE STREAM BUFFER MEMORY\n");
            HevcDecEndOfStream(fb_dec_ctx->dec_inst);
            goto err_exit;
        }
		else
			av_log(avctx, AV_LOG_DEBUG, "after alloc size=%d @%d, re-allocing... \n",fb_dec_ctx->stream_mem[fb_dec_ctx->stream_mem_index].size,fb_dec_ctx->stream_mem_index);
	}

	if((avpkt->size == 0) ||(fb_dec_ctx->eos_flush == 1))
    {
        av_log(avctx, AV_LOG_DEBUG, "in hantro_decode_hevc_decode_frame HevcDecEndOfStream  EOS... \n");

        HevcDecEndOfStream(fb_dec_ctx->dec_inst);
        
        ret = HevcNextPicture(fb_dec_ctx->dec_inst,&fb_dec_ctx->pic);
        av_log(avctx, AV_LOG_DEBUG, "HevcNextPicture ret %d\n",ret);
        if(ret == DEC_PIC_RDY) {

            for (i = 0; i < DEC_MAX_OUT_COUNT; i++) {
                av_log(avctx, AV_LOG_DEBUG, "DEC_PIC_RDY pic %d -> %d x %d\n",i,fb_dec_ctx->pic.pictures[i].pic_width,fb_dec_ctx->pic.pictures[i].pic_height);
            }
 
            av_log(avctx, AV_LOG_DEBUG, "%s %d fb_dec_ctx->picRdy = %d\n",__func__,__LINE__, fb_dec_ctx->picRdy);

            fb_dec_ctx->picRdy = 1;
            fb_dec_ctx->pts = avpkt->pts;
            fb_dec_ctx->pkt_dts = avpkt->dts;
            if(hantro_dec_output_frame(avctx,out,&fb_dec_ctx->pic)) goto err_exit;        
            *got_frame = fb_dec_ctx->picRdy;

            if(*got_frame == 1)
            {
                fb_dec_ctx->picRdy = 0;
                fb_dec_ctx->pic_display_number++;
                av_log(avctx, AV_LOG_DEBUG, "******** %d got frame :data[0]=%p,data[1]=%p buf[0]=%p,buf[1]=%p \n",fb_dec_ctx->pic_display_number,out->data[0],out->data[1],out->buf[0],out->buf[1]);

            }
            return 1;
        } 
        else if(ret == DEC_END_OF_STREAM) {
            //fb_dec_ctx->last_pic_flag = 1;
            av_log(avctx, AV_LOG_DEBUG, "END-OF-STREAM received in output thread\n");
            //fb_dec_ctx->add_buffer_thread_run = 0;
            return 0;
        } else if(ret < 0) {
            goto err_exit;
        }
        return 0;
    }	

    fb_dec_ctx->got_package_number++;

    if(hantro_send_avpkt_to_decode_buffer(avctx,avpkt,fb_dec_ctx->stream_mem[fb_dec_ctx->stream_mem_index])) goto err_exit;
    fb_dec_ctx->stream_mem[fb_dec_ctx->stream_mem_index].virtual_address = avpkt->data;
    dec_input.stream = fb_dec_ctx->stream_mem[fb_dec_ctx->stream_mem_index].virtual_address;
    dec_input.stream_bus_address = fb_dec_ctx->stream_mem[fb_dec_ctx->stream_mem_index].bus_address;
    dec_input.data_len = avpkt->size;
    
	if (hantro_dec_set_pts_dts(fb_dec_ctx, avpkt) < 0) {
        av_log(avctx, AV_LOG_ERROR, "ERROR: hantro_dec_set_pts_dts!\n");
        goto err_exit;
	}
    
    if (fb_dec_ctx->enc_type != HANTRO_ENC_NONE) {
        if (hantro_check_buffer_number_for_trans(fb_dec_ctx) < 0)
            goto err_exit;
    }

    do{
        fb_dec_ctx->hevc_dec_input.pic_id = fb_dec_ctx->pic_decode_number;

        //        do{
        ret = HevcDecode(fb_dec_ctx->dec_inst,  fb_dec_ctx->stream_mem[fb_dec_ctx->stream_mem_index], &fb_dec_ctx->dec_output,dec_input.stream,avpkt->size,fb_dec_ctx->pic_decode_number);

		av_log(avctx, AV_LOG_DEBUG, " %d in %s, HevcDecDecode ret=%d\n",fb_dec_ctx->got_package_number,__func__,ret);

		printDecodeReturn(avctx,ret);
        switch (ret) {
        case DEC_STREAM_NOT_SUPPORTED: {
            av_log(avctx, AV_LOG_DEBUG, "ERROR: UNSUPPORTED STREAM!\n");
            goto end;
        }
        case DEC_HDRS_RDY: {
            /* Stream headers were successfully decoded
            * -> stream information is available for query now */            

            struct HevcDecInfo dec_info;
            START_SW_PERFORMANCE;
            tmp = HevcDecGetInfo(fb_dec_ctx->dec_inst, &dec_info);
            fb_dec_ctx->rv = fb_dec_ctx->hantro_dec_wrapper.GetInfo(fb_dec_ctx->dec_inst,&fb_dec_ctx->sequence_info);
            END_SW_PERFORMANCE;
            if (tmp != DEC_OK) {
                av_log(avctx, AV_LOG_DEBUG, "ERROR in getting stream info!\n");
                goto end;
            }
 			
            if(HantroDecModifyConfigBySeqeuenceInfo(avctx)) goto err_exit;
            fb_dec_ctx->rv = fb_dec_ctx->hantro_dec_wrapper.SetInfo(fb_dec_ctx->dec_inst,fb_dec_ctx->hantro_dec_config,&fb_dec_ctx->sequence_info);
#ifdef USE_EXTERNAL_BUFFER
			struct Vp9DecBufferInfo hbuf;
            if (dec_info.pic_buff_size != fb_dec_ctx->min_buffer_num ||
            (dec_info.pic_width * dec_info.pic_height > fb_dec_ctx->prev_width * fb_dec_ctx->prev_height)) {
                /* Reset buffers added and stop adding extra buffers when a new header comes. */
                //ReleaseExtBuffers(avctx);
                hantro_dec_release_ext_buffers(fb_dec_ctx);
                fb_dec_ctx->num_buffers = 0;
                //fb_dec_ctx->add_extra_flag = 0;
                //fb_dec_ctx->extra_buffer_num = 0;
            }      
#endif
            fb_dec_ctx->prev_width = dec_info.pic_width;
            fb_dec_ctx->prev_height = dec_info.pic_height;
            fb_dec_ctx->min_buffer_num = dec_info.pic_buff_size;

            //dpb_mode = dec_info.dpb_mode;
            /* Decoder output frame size in planar YUV 4:2:0 */
            fb_dec_ctx->pic_size = dec_info.pic_width * dec_info.pic_height;
            fb_dec_ctx->pic_size = (3 * fb_dec_ctx->pic_size) / 2;

            /* No data consumed when returning DEC_HDRS_RDY. */
            fb_dec_ctx->dec_output.data_left = dec_input.data_len;
            fb_dec_ctx->dec_output.strm_curr_pos = dec_input.stream;

            break;
        }
        case DEC_ADVANCED_TOOLS: {
            /* ASO/STREAM ERROR was noticed in the stream. The decoder has to
            * reallocate resources */
            assert(fb_dec_ctx->dec_output.data_left);
            /* we should have some data left */ /* Used to indicate that picture
                             decoding needs to finalized
                             prior to corrupting next
                             picture */

            /* Used to indicate that picture decoding needs to finalized prior to
            * corrupting next picture
            * pic_rdy = 0; */
        break;
        }
        case DEC_PIC_DECODED:
            /* If enough pictures decoded -> force decoding to end
            * by setting that no more stream is available */
            //if (pic_decode_number == max_num_pics) fb_dec_ctx->hevc_dec_input.data_len = 0;

            //av_log(avctx, AV_LOG_DEBUG, "DECODED PICTURE %d\n", fb_dec_ctx->pic_decode_number);
            /* Increment decoding number for every decoded picture */
            fb_dec_ctx->pic_decode_number++;
            fb_dec_ctx->dec_output.data_left = 0;
			break;
        case DEC_PENDING_FLUSH:
            /* case DEC_FREEZED_PIC_RDY: */
            /* Picture is now ready */
            fb_dec_ctx->pic_rdy = 1;
			fb_dec_ctx->eos_flush = 1;
            /* use function HevcDecNextPicture() to obtain next picture
            * in display order. Function is called until no more images
            * are ready for display */
			fb_dec_ctx->dec_output.data_left = 0;
            fb_dec_ctx->retry = 0;
			//goto hevcnextpic;
        break;

        case DEC_STRM_PROCESSED:
        case DEC_NONREF_PIC_SKIPPED:
        case DEC_STRM_ERROR: {
            /* Used to indicate that picture decoding needs to finalized prior to
            * corrupting next picture
            * pic_rdy = 0; */
            
            fb_dec_ctx->dec_output.data_left = 0;

            break;
        }
        case DEC_WAITING_FOR_BUFFER: {
#ifdef USE_EXTERNAL_BUFFER
            av_log(avctx, AV_LOG_DEBUG, "Waiting for frame buffers\n");
#if 0
			struct Vp9DecBufferInfo hbuf;
            av_log(avctx, AV_LOG_DEBUG, "Waiting for frame buffers\n");
            struct DWLLinearMem mem;
            int alloc_buffer_num;

            fb_dec_ctx->rv = HevcDecGetBufferInfo(fb_dec_ctx->dec_inst, &hbuf);
            av_log(avctx, AV_LOG_DEBUG, "HevcDecGetBufferInfo ret %d\n", fb_dec_ctx->rv);
            av_log(avctx, AV_LOG_DEBUG, "buf_to_free %p, next_buf_size %d, buf_num %d\n",
            (void *)hbuf.buf_to_free.virtual_address, hbuf.next_buf_size, hbuf.buf_num);

                /* For HEVC, all external buffers will be freed after new headers comes. */
                if (fb_dec_ctx->rv == DEC_WAITING_FOR_BUFFER && hbuf.buf_to_free.bus_address) {
                    DWLFreeLinear(fb_dec_ctx->dwl_inst, &hbuf.buf_to_free);
                    u32 id = FindExtBufferIndex(avctx,hbuf.buf_to_free.bus_address);
                    fb_dec_ctx->ext_buffers[id].virtual_address = NULL;
                    fb_dec_ctx->ext_buffers[id].bus_address = 0;
                    if (id == fb_dec_ctx->num_buffers - 1)
                    fb_dec_ctx->num_buffers--;
                }
                if(hbuf.next_buf_size) {
                    /* Only add minimum required buffers at first. */
                    //extra_buffer_num = hbuf.buf_num - fb_dec_ctx->min_buffer_num;
                    fb_dec_ctx->buffer_size = hbuf.next_buf_size;
#ifdef ALWAYS_OUTPUT_REF
                    alloc_buffer_num = hbuf.buf_num;
#else
                    alloc_buffer_num = hbuf.buf_num + fb_dec_ctx->use_extra_buffers_num;
#endif
                    for (int i=0; i<alloc_buffer_num; i++) {
                        mem.mem_type = DWL_MEM_TYPE_DPB;
                        av_log(avctx, AV_LOG_DEBUG, "DWLMallocLinear %d DWL_MEM_TYPE_DPB size=%d\n",i, hbuf.next_buf_size);
                        ret = DWLMallocLinear(fb_dec_ctx->dwl_inst, hbuf.next_buf_size, &mem);
                        if(ret)
                        {
                            fb_dec_ctx->num_buffers = i;
                            goto err_exit;
                        }
                        fb_dec_ctx->rv = HevcDecAddBuffer(fb_dec_ctx->dec_inst, &mem);

                        u32 id = FindEmptyIndex(avctx);
                        fb_dec_ctx->ext_buffers[id] = mem;
                        fb_dec_ctx->buffer_consumed[id] = 1;
                        if (id >= fb_dec_ctx->num_buffers) fb_dec_ctx->num_buffers++;
                    }
                    /* Extra buffers are allowed when minimum required buffers have been added.*/
                    //num_buffers = fb_dec_ctx->min_buffer_num;
                    if (fb_dec_ctx->num_buffers >= fb_dec_ctx->min_buffer_num)
                    fb_dec_ctx->add_extra_flag = 1;
                }
                /* No data consumed when returning DEC_WAITING_FOR_BUFFER. */
                fb_dec_ctx->dec_output.data_left = dec_input.data_len;
                fb_dec_ctx->dec_output.strm_curr_pos = dec_input.stream;
#else
            if (hantro_check_buffer_number_for_trans(fb_dec_ctx) < 0)
                goto err_exit;
#endif
#endif
        }
        break;
        case DEC_OK:
        /* nothing to do, just call again */
        break;
        case DEC_HW_TIMEOUT:
            av_log(avctx, AV_LOG_DEBUG, "Timeout\n");
        case DEC_MEMFAIL:
        case DEC_SYSTEM_ERROR:
        case DEC_FATAL_SYSTEM_ERROR:
            av_log(avctx, AV_LOG_ERROR, "---DEC SYS ERROR---\n");
            HevcDecEndOfStream(fb_dec_ctx->dec_inst);
            goto err_exit;
        case DEC_NO_DECODING_BUFFER:
            av_log(avctx, AV_LOG_DEBUG, "---DEC_NO_DECODING_BUFFER---, waiting.....\n");
            continue;
		case DEC_RESOLUTION_CHANGE:
            av_log(avctx, AV_LOG_WARNING, "hantro decoder NOT SUPPORT header changing in sequence,flush and exit......\n");
			//fb_dec_ctx->eos_flush = 1;
			//break;
        default:
            av_log(avctx, AV_LOG_DEBUG, "FATAL ERROR: %d\n", ret);
            goto err_exit;
        }
hevcnextpic:

        ret = HevcNextPicture(fb_dec_ctx->dec_inst,&fb_dec_ctx->pic);
        av_log(avctx, AV_LOG_DEBUG, "HevcNextPicture ret %d\n",ret);
        if(ret == DEC_PIC_RDY) {

            for (i = 0; i < DEC_MAX_OUT_COUNT; i++) {
                av_log(avctx, AV_LOG_DEBUG, "DEC_PIC_RDY pic %d -> %d x %d,luma_bus=0x%x\n",i,fb_dec_ctx->pic.pictures[i].pic_width,fb_dec_ctx->pic.pictures[i].pic_height,fb_dec_ctx->pic.pictures[i].luma.bus_address);
            }

            fb_dec_ctx->picRdy = 1;
            if(hantro_dec_output_frame(avctx,out,&fb_dec_ctx->pic)) goto err_exit;
           // goto end;;///////////////
        } else if(ret == DEC_END_OF_STREAM) {
            //fb_dec_ctx->last_pic_flag = 1;
            av_log(avctx, AV_LOG_DEBUG, "END-OF-STREAM received in output thread\n");
            //fb_dec_ctx->add_buffer_thread_run = 0;
            goto end;
        } else if(ret < 0) {
            goto err_exit;
        }
        av_log(avctx, AV_LOG_DEBUG, " fb_dec_ctx->picRdy = %d\n", fb_dec_ctx->picRdy);
    }while(fb_dec_ctx->dec_output.data_left);

    fb_dec_ctx->stream_mem_index++;
    if(fb_dec_ctx->stream_mem_index == fb_dec_ctx->allocated_buffers)
    fb_dec_ctx->stream_mem_index = 0;

    *got_frame = fb_dec_ctx->picRdy;

    if(*got_frame == 1)
    {
        fb_dec_ctx->picRdy = 0;
        fb_dec_ctx->pic_display_number++;
        av_log(avctx, AV_LOG_DEBUG, "******** %d got frame :data[0]=%p,data[1]=%p buf[0]=%p,buf[1]=%p \n",fb_dec_ctx->pic_display_number,out->data[0],out->data[1],out->buf[0],out->buf[1]);

    }			

    av_log(avctx, AV_LOG_DEBUG, "in %s return:avpkt->size = %d,fb_dec_ctx->dec_output.data_left=%d.........\n",__func__,avpkt->size,fb_dec_ctx->dec_output.data_left);

end:
    return avpkt->size - fb_dec_ctx->dec_output.data_left;

err_exit:
    av_log(avctx, AV_LOG_ERROR, "error !!! end of %s...  \n",__func__);
    return AVERROR_EOF;
}

#if 0
#define OFFSET(x) offsetof(HantroDecContext, x)
#define VD AV_OPT_FLAG_VIDEO_PARAM | AV_OPT_FLAG_DECODING_PARAM
static const AVOption hantro_decode_hevc_options[] = {
    { "pp_set", "set pp configure", OFFSET(pp_setting), AV_OPT_TYPE_STRING, {.str=""}, 0, 0, VD },
    { "dev_name", "set device name", OFFSET(dev_name), AV_OPT_TYPE_STRING, {.str="/dev/transcoder0"}, 0, 0, VD },    
//    { "disable-dec400", "disable DEC400 compress function", OFFSET(disable_dec400), AV_OPT_TYPE_INT, {.i64 = 0}, 0, 1, VD },
//    { "disable-dtrc", "disable DTRC compress function", OFFSET(disable_dtrc), AV_OPT_TYPE_INT, {.i64 = 0}, 0, 1, VD },        
    { "enc-format", "give the target format in encode, h264 hevc or vp9", OFFSET(enc_format), AV_OPT_TYPE_STRING, {.str=""}, 0, 0, VD },
    { "buffer-depth", "bufffer depth for transcode", OFFSET(buffer_depth), AV_OPT_TYPE_INT, {.i64 = 0}, 0, 40, VD },
    { NULL },
};
#endif

static const AVClass hantro_decode_hevc_class = {
    .class_name = "FB Hevc Decoder",
    .item_name  = av_default_item_name,
    .option     = hantro_decode_options,
    .version    = LIBAVUTIL_VERSION_INT,
};
    
static const AVCodecHWConfigInternal *hantro_hw_configs[] = {
    &(const AVCodecHWConfigInternal) {
        .public = {
            .pix_fmt     = AV_PIX_FMT_HANTRO,
            .methods     = AV_CODEC_HW_CONFIG_METHOD_HW_DEVICE_CTX |
                           AV_CODEC_HW_CONFIG_METHOD_HW_FRAMES_CTX |
                           AV_CODEC_HW_CONFIG_METHOD_INTERNAL,
            .device_type = AV_HWDEVICE_TYPE_HANTRO,
        },
        .hwaccel = NULL,
    },
    NULL
};


AVCodec ff_hevc_hantro_decoder = {
    .name                  = "hevcdec_hantro",
    .long_name             = NULL_IF_CONFIG_SMALL("HEVC (HANTRO VC8000D)"),
    .type                  = AVMEDIA_TYPE_VIDEO,
    .id                    = AV_CODEC_ID_HEVC,
    .priv_data_size        = sizeof(HantroDecContext),
    .init                  = hantro_decode_hevc_init,
    .close                 = hantro_decode_hevc_close,
    .decode                = hantro_decode_hevc_decode_frame,
    .capabilities          = AV_CODEC_CAP_DELAY | AV_CODEC_CAP_HARDWARE | AV_CODEC_CAP_AVOID_PROBING,
    .priv_class            = &hantro_decode_hevc_class,
    .pix_fmts       = (const enum AVPixelFormat[]) {
        AV_PIX_FMT_HANTRO,
        AV_PIX_FMT_NONE
  	},		
  	.hw_configs         = &hantro_hw_configs,
  	.bsfs               = "hevc_mp4toannexb",
};
