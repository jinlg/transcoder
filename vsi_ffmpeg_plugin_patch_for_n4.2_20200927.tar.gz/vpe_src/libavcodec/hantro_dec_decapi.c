/**
 * hantro dec decapi - suntongqiang
 */

#ifdef _WIN32
#include <windows.h>
#endif


#include "hevcdecapi.h"
#include "h264decapi.h"
#include "vp9decapi.h"
#ifdef _WIN32
#include <io.h>
#include <process.h>
#else
#include <unistd.h>
#endif
#include<stdlib.h>
#include <string.h>
#include<stdio.h>
#define MAX_FIFO_CAPACITY (6)

#ifdef _ASSERT_USED
#ifndef ASSERT
#include <assert.h>
#define ASSERT(expr) assert(expr)
#endif
#else
#define ASSERT(expr)
#endif
#include "avcodec.h"

//#include "hantro_dec_decapi.h"
#include "hantro_dec_common.h"


u32 is_mono_chrome = 0;



struct DecSwHwBuild HantroDecGetBuild(const void* dwl) {
  struct DecSwHwBuild build;

  (void)DWLmemset(&build, 0, sizeof(build));

  build.sw_build = HANTRO_DEC_SW_BUILD;
  build.hw_build = DWLReadAsicID(dwl,DWL_CLIENT_TYPE_HEVC_DEC);

  DWLReadAsicConfig(dwl,build.hw_config, DWL_CLIENT_TYPE_HEVC_DEC);

  return build;
}

static void dump_ppu(AVCodecContext *avctx,PpUnitConfig *ppu_cfg)
{
    int i;
    av_log(avctx,AV_LOG_DEBUG,"%s(%d)\n",__FUNCTION__,__LINE__);
    for(i=0;i<4;i++)
    {
        av_log(avctx,AV_LOG_DEBUG,"ppu_cfg[%d].enabled = %d\n",i,ppu_cfg[i].enabled);
        av_log(avctx,AV_LOG_DEBUG,"ppu_cfg[%d].tiled_e = %d\n",i,ppu_cfg[i].tiled_e);
        av_log(avctx,AV_LOG_DEBUG,"ppu_cfg[%d].crop.enabled = %d\n",i,ppu_cfg[i].crop.enabled);
        av_log(avctx,AV_LOG_DEBUG,"ppu_cfg[%d].crop.x = %d\n",i,ppu_cfg[i].crop.x);
        av_log(avctx,AV_LOG_DEBUG,"ppu_cfg[%d].crop.y = %d\n",i,ppu_cfg[i].crop.y);
        av_log(avctx,AV_LOG_DEBUG,"ppu_cfg[%d].crop.width = %d\n",i,ppu_cfg[i].crop.width);
        av_log(avctx,AV_LOG_DEBUG,"ppu_cfg[%d].crop.height = %d\n",i,ppu_cfg[i].crop.height);
        av_log(avctx,AV_LOG_DEBUG,"ppu_cfg[%d].scale.enabled = %d\n",i,ppu_cfg[i].scale.enabled);
        av_log(avctx,AV_LOG_DEBUG,"ppu_cfg[%d].scale.width = %d\n",i,ppu_cfg[i].scale.width);
        av_log(avctx,AV_LOG_DEBUG,"ppu_cfg[%d].scale.height = %d\n",i,ppu_cfg[i].scale.height);
        av_log(avctx,AV_LOG_DEBUG,"ppu_cfg[%d].out_p010 = %d\n",i,ppu_cfg[i].out_p010);
        av_log(avctx,AV_LOG_DEBUG,"ppu_cfg[%d].align = %d\n",i,ppu_cfg[i].align);
        av_log(avctx,AV_LOG_DEBUG,"ppu_cfg[%d].shaper_enabled = %d\n",i,ppu_cfg[i].shaper_enabled);
        av_log(avctx,AV_LOG_DEBUG,"\n");
    }
}

int HantroDecParsePPUCfg(AVCodecContext *avctx,PpUnitConfig *ppu_cfg)
{
    HantroDecContext *fb_dec_ctx  = avctx->priv_data;

    int pp_enabled,pp_count,pp_index;
    Resize_t * pResizes;
    int resizes_num;
    int i;

    memset(ppu_cfg,0,sizeof(PpUnitConfig)*4);
    pp_enabled = 0;
    pp_count = 0;
   

    pResizes = fb_dec_ctx->resizes;
    resizes_num = fb_dec_ctx->resize_num;
#ifdef ALWAYS_OUTPUT_REF  
    //when h264 live encode: 8 bit use rfc, 10bit use pp0
    //enabled = 2;shaper_enabled = 2 means decode adaptive decide its value is 0 or 1 in HantroDecModifyConfigBySeqeuenceInfo
    if (fb_dec_ctx->enc_type == HANTRO_ENC_VP9)
    {
          pp_enabled = 1;
          ppu_cfg[0].enabled = 1;
          ppu_cfg[0].tiled_e = 1;
          ppu_cfg[0].align = 10;
          ppu_cfg[0].shaper_enabled = 2;
    }
    else if (fb_dec_ctx->enc_type == HANTRO_ENC_H264)
    {
       if (fb_dec_ctx->dwl_init.priority == 0)
       {
          pp_enabled = 1;
          ppu_cfg[0].enabled = 2;
          ppu_cfg[0].tiled_e = 1;
#ifndef BUILD_CMODEL
          ppu_cfg[0].align = 10;
          ppu_cfg[0].shaper_enabled = 2;
#endif
       }
    }
#else
    //when no use rfc ,pp0 always on
    pp_enabled = 1;
    ppu_cfg[0].enabled = 1;
    ppu_cfg[0].tiled_e = 1;
    if (fb_dec_ctx->enc_type == HANTRO_ENC_VP9) {
        ppu_cfg[0].align = 10;
        ppu_cfg[0].shaper_enabled = 2;
    } else {
    // for vce compressed performance is better
#ifndef BUILD_CMODEL
        ppu_cfg[0].align = 10;
        ppu_cfg[0].shaper_enabled = 1;
#endif
     }
#endif

#ifdef BUILD_CMODEL
    pp_enabled = 1;
    ppu_cfg[0].enabled = 1;
    ppu_cfg[0].tiled_e = 1;
    ppu_cfg[0].out_p010 = pDecParam->in_10bit;
#else
#ifndef SUPPORT_TCACHE
    pp_enabled = 2;
    ppu_cfg[0].enabled = 2;
    ppu_cfg[0].tiled_e = 1;
    ppu_cfg[0].align = 10;
#ifdef SUPPORT_DEC400
    ppu_cfg[0].shaper_enabled = 1;
#endif
#endif
#endif

    for (i = pp_count; i < resizes_num; i++) {
        
        if (pResizes[i].x == 0 && pResizes[i].y == 0
            && pResizes[i].cw == 0 && pResizes[i].ch == 0
            && pResizes[i].sw == 0 && pResizes[i].sh == 0) {
          continue;
        }
            
        av_log(avctx,AV_LOG_DEBUG,"pp %d resize %d get param\n", i, i);
        pp_enabled = 1;
        pp_index = i;
        ppu_cfg[pp_index].enabled = 1;
        ppu_cfg[pp_index].tiled_e = 1;
        
        if (!(pResizes[i].x == 0 && pResizes[i].y == 0
            && pResizes[i].cw == 0 && pResizes[i].ch == 0)) {
            ppu_cfg[pp_index].crop.enabled = 1;
            ppu_cfg[pp_index].crop.x = pResizes[i].x;
            ppu_cfg[pp_index].crop.y = pResizes[i].y;
            ppu_cfg[pp_index].crop.width = pResizes[i].cw;
            ppu_cfg[pp_index].crop.height = pResizes[i].ch;
        }
        if (!(pResizes[i].sw == 0 && pResizes[i].sh == 0)) {
          ppu_cfg[pp_index].scale.enabled = 1;
          ppu_cfg[pp_index].scale.width = pResizes[i].sw;
          ppu_cfg[pp_index].scale.height = pResizes[i].sh;
        }
#ifndef BUILD_CMODEL
        ppu_cfg[pp_index].align = 10;
        ppu_cfg[pp_index].shaper_enabled = 1;
#endif
        if (strcmp(fb_dec_ctx->enc_format, "vp9") == 0) {
    	    ppu_cfg[pp_index].align = 10;
    	    ppu_cfg[pp_index].shaper_enabled = 1;
        }
    }

    fb_dec_ctx->pp_enabled = pp_enabled;

#if 0
    av_log(avctx, AV_LOG_DEBUG, "ppu_cfg[0].shaper_enabled = %d\n", ppu_cfg[0].shaper_enabled);
    av_log(avctx, AV_LOG_DEBUG, "ppu_cfg[1].shaper_enabled = %d\n", ppu_cfg[1].shaper_enabled);
#else
    dump_ppu(avctx, ppu_cfg);
#endif
    return 0;
}


int HantroDecModifyConfigBySeqeuenceInfo(AVCodecContext *avctx)
{
    HantroDecContext *fb_dec_ctx  = avctx->priv_data;
    enum DecRet rv_info = DEC_OK;
    
    /* process pp size -1/-2/-4/-8. */
    av_log(NULL, AV_LOG_DEBUG, "%s\n", __FUNCTION__);

    struct DecConfig *config = &fb_dec_ctx->hantro_dec_config;
    
    int i;
    u32 alignh = fb_dec_ctx->sequence_info.is_interlaced ? 4 : 2;
    u32 alignw = 2;
    
    av_log(avctx,AV_LOG_DEBUG,"sequence_info: %dx%d, (%d,%d,%dx%d)\n",
            fb_dec_ctx->sequence_info.pic_width,
            fb_dec_ctx->sequence_info.pic_height,
            fb_dec_ctx->sequence_info.crop_params.crop_left_offset,
            fb_dec_ctx->sequence_info.crop_params.crop_top_offset,
            fb_dec_ctx->sequence_info.crop_params.crop_out_width,
            fb_dec_ctx->sequence_info.crop_params.crop_out_height);
    dump_ppu(avctx, config->ppu_cfg);
    
    if (config->ppu_cfg[0].scale.enabled
            && ((config->ppu_cfg[0].scale.width != config->ppu_cfg[0].crop.width)
            || (config->ppu_cfg[0].scale.height != config->ppu_cfg[0].crop.height))) {
        av_log(avctx, AV_LOG_ERROR, "pp0 do not support scale!\n");
        return -1;
    }
    
    for (i = 1; i < 4; i++) {
        if (config->ppu_cfg[i].scale.width == -1 || config->ppu_cfg[i].scale.width == -2
                || config->ppu_cfg[i].scale.width == -4 || config->ppu_cfg[i].scale.width == -8
                || config->ppu_cfg[i].scale.height == -1 || config->ppu_cfg[i].scale.height == -2
                || config->ppu_cfg[i].scale.height == -4 || config->ppu_cfg[i].scale.height == -8) {
            u32 original_width = fb_dec_ctx->sequence_info.pic_width;
            u32 original_height = fb_dec_ctx->sequence_info.pic_height;
            if (config->ppu_cfg[i].scale.width == -1 && config->ppu_cfg[i].scale.height == -1) {
                av_log(avctx,AV_LOG_ERROR,"ppu_cfg[%d] scale width and scale height should not be -1 at the same time\n", i);
                rv_info = DEC_INFOPARAM_ERROR;
                break;
            }
            if (fb_dec_ctx->sequence_info.crop_params.crop_out_width != original_width)
                original_width = fb_dec_ctx->sequence_info.crop_params.crop_out_width;
            if (fb_dec_ctx->sequence_info.crop_params.crop_out_height != original_height)
                original_height = fb_dec_ctx->sequence_info.crop_params.crop_out_height;
            if (config->ppu_cfg[i].crop.enabled) {
                if (config->ppu_cfg[i].crop.width != original_width) {
                    original_width = config->ppu_cfg[i].crop.width;
                }
                if (config->ppu_cfg[i].crop.height != original_height) {
                    original_height = config->ppu_cfg[i].crop.height;
                }
            }
            av_log(avctx,AV_LOG_DEBUG,"original_width = %d, original_height = %d\n", original_width, original_height);
            if (config->ppu_cfg[i].scale.width == -1) {
                config->ppu_cfg[i].scale.width = NEXT_MULTIPLE((original_width * config->ppu_cfg[i].scale.height)/original_height, alignw);
                config->ppu_cfg[i].scale.height = NEXT_MULTIPLE(config->ppu_cfg[i].scale.height, alignh);
            } else if (config->ppu_cfg[i].scale.height == -1) {
                config->ppu_cfg[i].scale.width = NEXT_MULTIPLE(config->ppu_cfg[i].scale.width, alignw);
                config->ppu_cfg[i].scale.height = NEXT_MULTIPLE((original_height * config->ppu_cfg[i].scale.width)/original_width, alignh);
            } else if (config->ppu_cfg[i].scale.width == -2 && config->ppu_cfg[i].scale.height == -2) {
                config->ppu_cfg[i].scale.width = NEXT_MULTIPLE(original_width / 2, alignw);
                config->ppu_cfg[i].scale.height = NEXT_MULTIPLE(original_height / 2, alignh);
            } else if (config->ppu_cfg[i].scale.width == -4 && config->ppu_cfg[i].scale.height == -4) {
                config->ppu_cfg[i].scale.width = NEXT_MULTIPLE(original_width / 4, alignw);
                config->ppu_cfg[i].scale.height = NEXT_MULTIPLE(original_height / 4, alignh);
            } else if (config->ppu_cfg[i].scale.width == -8 && config->ppu_cfg[i].scale.height == -8) {
                config->ppu_cfg[i].scale.width = NEXT_MULTIPLE(original_width / 8, alignw);
                config->ppu_cfg[i].scale.height = NEXT_MULTIPLE(original_height / 8, alignh);
            } else {
                av_log(avctx,AV_LOG_ERROR,"pp %d scale setting error!!!\n", i);
                rv_info = DEC_INFOPARAM_ERROR;
                break;
            }
            av_log(avctx,AV_LOG_DEBUG,"config->ppu_cfg[%d].scale.width = %d, config->ppu_cfg[%d].scale.height = %d\n",
                    i, config->ppu_cfg[i].scale.width, i, config->ppu_cfg[i].scale.height);
       }
    }
    if (rv_info == DEC_INFOPARAM_ERROR) {
        return -1;
    }

    /* Ajust user cropping params based on cropping params from sequence info. */
    if (fb_dec_ctx->sequence_info.crop_params.crop_left_offset != 0 ||
            fb_dec_ctx->sequence_info.crop_params.crop_top_offset != 0 ||
            fb_dec_ctx->sequence_info.crop_params.crop_out_width != fb_dec_ctx->sequence_info.pic_width ||
            fb_dec_ctx->sequence_info.crop_params.crop_out_height != fb_dec_ctx->sequence_info.pic_height) {
        av_log(avctx,AV_LOG_DEBUG,"%s(%d)\n",__FUNCTION__,__LINE__);
        for (i = 1; i < 4; i++) {
            if (!config->ppu_cfg[i].enabled) continue;

            if (!config->ppu_cfg[i].crop.enabled) {
                config->ppu_cfg[i].crop.x = fb_dec_ctx->sequence_info.crop_params.crop_left_offset;
                config->ppu_cfg[i].crop.y = fb_dec_ctx->sequence_info.crop_params.crop_top_offset;
                config->ppu_cfg[i].crop.width = NEXT_MULTIPLE(fb_dec_ctx->sequence_info.crop_params.crop_out_width, 2);
                config->ppu_cfg[i].crop.height = NEXT_MULTIPLE(fb_dec_ctx->sequence_info.crop_params.crop_out_height, 2);
            } else {
                config->ppu_cfg[i].crop.x += fb_dec_ctx->sequence_info.crop_params.crop_left_offset;
                config->ppu_cfg[i].crop.y += fb_dec_ctx->sequence_info.crop_params.crop_top_offset;
                if(!config->ppu_cfg[i].crop.width)
                    config->ppu_cfg[i].crop.width = fb_dec_ctx->sequence_info.crop_params.crop_out_width;
                if(!config->ppu_cfg[i].crop.height)
                    config->ppu_cfg[i].crop.height = fb_dec_ctx->sequence_info.crop_params.crop_out_height;
            }
            config->ppu_cfg[i].enabled = 1;
            config->ppu_cfg[i].crop.enabled = 1;
            
            av_log(avctx,AV_LOG_DEBUG,"config->ppu_cfg[%d].crop.x = %d, config->ppu_cfg[%d].crop.x = %d, config->ppu_cfg[%d].crop.width = %d, config->ppu_cfg[%d].crop.height = %d\n",
                    i, config->ppu_cfg[i].crop.x, i, config->ppu_cfg[i].crop.x,
                    i, config->ppu_cfg[i].crop.width, i, config->ppu_cfg[i].crop.height);
        }
    }

    {
        // for bypass mode or 10bit case use pp0 datapath for performance
        if (config->ppu_cfg[0].enabled == 2) {
            av_log(avctx,AV_LOG_DEBUG,"fb_dec_ctx->sequence_info.bit_depth_luma = %d, fb_dec_ctx->sequence_info.bit_depth_chroma = %d\n",
                fb_dec_ctx->sequence_info.bit_depth_luma, fb_dec_ctx->sequence_info.bit_depth_chroma);
            if (fb_dec_ctx->sequence_info.bit_depth_luma > 8 || fb_dec_ctx->sequence_info.bit_depth_chroma > 8) {
                av_log(avctx,AV_LOG_DEBUG,"adaptive to enable pp0\n");
                config->ppu_cfg[0].enabled = 1;
            } else {
                av_log(avctx,AV_LOG_DEBUG,"adaptive to disable pp0\n");
                config->ppu_cfg[0].enabled = 0;
            }
        }
    }

    double SR[4],SR_sum=0;
    double SR_P[4],SR_P_sum=0;
    int maxInputPicH = 1080; // for FB, this is 1080.
    int maxOutputPicH[4] = {0, 1080, 720, 360}; // for FB, it is {0, 1080, 720, 360}
    int ppmaxOutputPicH[4] = {0, 0, 1280, 640}; // for FB, it is {0, 1080, 720, 360}
    int shaper_en_num=0;

    //check PP setting legal
    for(i=0; i<4; i++)
    {
        if(config->ppu_cfg[i].enabled == 1)
        {
            if(ppmaxOutputPicH[i] == 0 )
            {
             if(config->ppu_cfg[i].scale.height > fb_dec_ctx->sequence_info.pic_height)
             {
                 av_log(avctx,AV_LOG_ERROR,"PP[%d] Height setting is illegal: %d > MAX (%d)\n",i,config->ppu_cfg[i].scale.height,fb_dec_ctx->sequence_info.pic_height);
                 rv_info = DEC_INFOPARAM_ERROR;
                 break;
             }
             if (config->ppu_cfg[i].scale.width > fb_dec_ctx->sequence_info.pic_width)
             {
                 av_log(avctx,AV_LOG_ERROR,"PP[%d] Width setting is illegal: %d > MAX (%d)\n",i,config->ppu_cfg[i].scale.width,fb_dec_ctx->sequence_info.pic_width);
                 rv_info = DEC_INFOPARAM_ERROR;
                 break;
             }
          }
          else
          {
             if(config->ppu_cfg[i].scale.height > ppmaxOutputPicH[i])
             {
                 av_log(avctx,AV_LOG_ERROR,"PP[%d] Height setting is illegal: %d > MAX (%d)\n",i,config->ppu_cfg[i].scale.height,ppmaxOutputPicH[i]);
                 rv_info = DEC_INFOPARAM_ERROR;
                 break;
             }
             if (config->ppu_cfg[i].scale.width > ppmaxOutputPicH[i])
             {
                 av_log(avctx,AV_LOG_ERROR,"PP[%d] Width setting is illegal: %d > MAX (%d)\n",i,config->ppu_cfg[i].scale.width,ppmaxOutputPicH[i]);
                 rv_info = DEC_INFOPARAM_ERROR;
                 break;
             }
          }
       }
    }
    if (rv_info == DEC_INFOPARAM_ERROR) {
        return -1;
    }

    if(fb_dec_ctx->disable_dec400)
    {
        //disable all shaper for pp 
        HantroDecDisableAllPPShaper(&fb_dec_ctx->hantro_dec_config);
    }
    else
    {
        //check SR ratio capability  
        if(fb_dec_ctx->sequence_info.pic_height > 1088)
            shaper_en_num = 3;
        else
            shaper_en_num = 2;

        for(i=0; i<4; i++)
        {
            SR[i] = (double)maxOutputPicH[i]/maxInputPicH;
            SR_sum += SR[i];
        }

        for(i=0; i<4; i++)
            {
              if(config->ppu_cfg[i].enabled == 1)
              {
                //10bit stream disable shaper when shaper_enabled = 2
                if((i == 0)&&(config->ppu_cfg[i].shaper_enabled == 2))
                {           
                    if((fb_dec_ctx->sequence_info.bit_depth_luma > 8)||(fb_dec_ctx->sequence_info.bit_depth_chroma > 8))
                    {
                        config->ppu_cfg[i].shaper_enabled = 0;//disable when 10bit
                        av_log(avctx, AV_LOG_DEBUG, "ppu_cfg[%d].shaper_enabled disabled\n", i);
                        continue;
                    }
                    else
                    {
                        config->ppu_cfg[i].shaper_enabled = 1;//enable when 8bit
                    }
                }
                
                if (config->ppu_cfg[i].scale.enabled == 0) {
                    SR_P[i] = 1;
                } else if (config->ppu_cfg[i].crop.enabled) {
                    SR_P[i] = (double)config->ppu_cfg[i].scale.height/config->ppu_cfg[i].crop.height;
                } else {
                    SR_P[i] = (double)config->ppu_cfg[i].scale.height/fb_dec_ctx->sequence_info.pic_height;
                }
                SR_P_sum += SR_P[i];
              }
              av_log(avctx,AV_LOG_DEBUG,"PP%d enabled=%d,SR_sum=%f,SR_P_sum=%f\n",i,config->ppu_cfg[i].enabled,SR_sum,SR_P_sum);
              if((shaper_en_num > 0)&&(SR_P_sum < SR_sum)&&(config->ppu_cfg[i].enabled == 1))
              {
                  config->ppu_cfg[i].shaper_enabled = 1;
                  shaper_en_num --;
              }
              else {
                config->ppu_cfg[i].shaper_enabled = 0;
                av_log(avctx, AV_LOG_DEBUG, "ppu_cfg[%d].shaper_enabled disabled\n", i);
              }
            }

    }
    //for(i=0;i<4;i++)
    //  printf("\n\nSR[%d] = %f,SR_P[%d] = %f,client->test_params.ppu_cfg[%d].shaper_enabled=%d\n\n",i,SR[i],i,SR_P[i],i,config->ppu_cfg[i].shaper_enabled);
    //printf("SR_sum=%f,SR_P_sum=%f\n\n",SR_sum,SR_P_sum);
    av_log(avctx,AV_LOG_DEBUG,"in %s : %d ppu cfg :\n",__func__,__LINE__);
    
    //if((fb_dec_ctx->enc_format == NULL) || (strcmp(fb_dec_ctx->enc_format, "h264") && strcmp(fb_dec_ctx->enc_format, "vp9") && strcmp(fb_dec_ctx->enc_format, "hevc")))
    if (fb_dec_ctx->enc_type == HANTRO_ENC_NONE)
    {        
        config->ppu_cfg[0].enabled = 1;
        for(int i=0;i<4;i++)
        {
          if(config->ppu_cfg[i].enabled == 1)
          {
            config->ppu_cfg[i].tiled_e = 0;
            config->ppu_cfg[i].shaper_enabled = 0;
            av_log(avctx, AV_LOG_DEBUG, "ppu_cfg[%d].shaper_enabled disabled\n", i);
            config->ppu_cfg[i].align = DEC_ALIGN_1B;
            config->ppu_cfg[i].out_p010 = 1;
          }
        }
    }
    else if(fb_dec_ctx->sequence_info.is_interlaced)
    {
      //struct DecConfig *config = &inst->current_command->params.config;
      config->ppu_cfg[0].enabled = 1;
      for(int i=0;i<4;i++)
      {
        if(config->ppu_cfg[i].enabled == 1)
        {
          config->ppu_cfg[i].tiled_e = 0;
          config->ppu_cfg[i].shaper_enabled = 0;
          config->ppu_cfg[i].align = DEC_ALIGN_1024B;
        }
      }
    }

#if 0
    for(i=0;i<4;i++)
    {
        av_log(avctx,AV_LOG_DEBUG,"ppu_cfg[%d].enabled = %d\n",i,config->ppu_cfg[i].enabled);
        av_log(avctx,AV_LOG_DEBUG,"ppu_cfg[%d].tiled_e = %d\n",i,config->ppu_cfg[i].tiled_e);
        av_log(avctx,AV_LOG_DEBUG,"ppu_cfg[%d].crop.enabled = %d\n",i,config->ppu_cfg[i].crop.enabled);
        av_log(avctx,AV_LOG_DEBUG,"ppu_cfg[%d].crop.x = %d\n",i,config->ppu_cfg[i].crop.x);
        av_log(avctx,AV_LOG_DEBUG,"ppu_cfg[%d].crop.y = %d\n",i,config->ppu_cfg[i].crop.y);
        av_log(avctx,AV_LOG_DEBUG,"ppu_cfg[%d].crop.width = %d\n",i,config->ppu_cfg[i].crop.width);
        av_log(avctx,AV_LOG_DEBUG,"ppu_cfg[%d].crop.height = %d\n",i,config->ppu_cfg[i].crop.height);
        av_log(avctx,AV_LOG_DEBUG,"ppu_cfg[%d].scale.enabled = %d\n",i,config->ppu_cfg[i].scale.enabled);
        av_log(avctx,AV_LOG_DEBUG,"ppu_cfg[%d].scale.width = %d\n",i,config->ppu_cfg[i].scale.width);
        av_log(avctx,AV_LOG_DEBUG,"ppu_cfg[%d].scale.height = %d\n",i,config->ppu_cfg[i].scale.height);
        av_log(avctx,AV_LOG_DEBUG,"ppu_cfg[%d].out_p010 = %d\n",i,config->ppu_cfg[i].out_p010);
        av_log(avctx,AV_LOG_DEBUG,"ppu_cfg[%d].align = %d\n",i,config->ppu_cfg[i].align);
        av_log(avctx,AV_LOG_DEBUG,"ppu_cfg[%d].shaper_enabled = %d\n",i,config->ppu_cfg[i].shaper_enabled);
        av_log(avctx,AV_LOG_DEBUG,"\n");
    }
#else
    dump_ppu(avctx, config->ppu_cfg);
#endif

    return 0;
}

void HantroDecDisableAllPPShaper(struct DecConfig *config)
{
    int i;
    if(!config)
        return;
    av_log(NULL, AV_LOG_DEBUG, "%s\n", __FUNCTION__);
    for(i=0;i<4;i++)
        config->ppu_cfg[i].shaper_enabled = 0;
}



enum DecRet HantroDecHevcInit(const void** inst, struct DecConfig config,
                            const void *dwl) {
  struct HevcDecConfig dec_cfg;
  dec_cfg.no_output_reordering = config.disable_picture_reordering;
  dec_cfg.use_video_freeze_concealment = config.concealment_mode;
  dec_cfg.use_video_compressor = config.use_video_compressor;
  dec_cfg.use_ringbuffer = config.use_ringbuffer;
  dec_cfg.output_format = config.output_format;
  dec_cfg.decoder_mode = config.decoder_mode;
  dec_cfg.tile_by_tile = config.tile_by_tile;
#ifdef USE_EXTERNAL_BUFFER
  dec_cfg.guard_size = 0;
  dec_cfg.use_adaptive_buffers = 0;
#endif
  if (config.ppu_cfg[0].out_cut_8bits)
    dec_cfg.pixel_format = DEC_OUT_PIXEL_CUT_8BIT;
  else if (config.ppu_cfg[0].out_p010)
    dec_cfg.pixel_format = DEC_OUT_PIXEL_P010;
  else if (config.ppu_cfg[0].out_be)
    dec_cfg.pixel_format = DEC_OUT_PIXEL_CUSTOMER1;
  else
    dec_cfg.pixel_format = DEC_OUT_PIXEL_DEFAULT;
  memcpy(dec_cfg.ppu_cfg, config.ppu_cfg, sizeof(config.ppu_cfg));
  return HevcDecInit(inst, dwl, &dec_cfg);
}

enum DecRet HantroDecHevcGetInfo(void* inst, struct DecSequenceInfo* info) {
  struct HevcDecInfo hevc_info;
  enum DecRet rv = HevcDecGetInfo(inst, &hevc_info);
  info->pic_width = hevc_info.pic_width;
  info->pic_height = hevc_info.pic_height;
  info->sar_width = hevc_info.sar_width;
  info->sar_height = hevc_info.sar_height;
  info->crop_params.crop_left_offset = hevc_info.crop_params.crop_left_offset;
  info->crop_params.crop_out_width = hevc_info.crop_params.crop_out_width;
  info->crop_params.crop_top_offset = hevc_info.crop_params.crop_top_offset;
  info->crop_params.crop_out_height = hevc_info.crop_params.crop_out_height;
  info->video_range = hevc_info.video_range;
  info->matrix_coefficients = hevc_info.matrix_coefficients;
  info->is_mono_chrome = hevc_info.mono_chrome;
  info->is_interlaced = hevc_info.interlaced_sequence;
  info->num_of_ref_frames = hevc_info.pic_buff_size;
  info->bit_depth_luma = info->bit_depth_chroma = hevc_info.bit_depth;
  return rv;
}

enum DecRet HantroDecHevcSetInfo(void* inst, struct DecConfig config, struct DecSequenceInfo* info) {
  struct HevcDecConfig dec_cfg;
  dec_cfg.no_output_reordering = config.disable_picture_reordering;
  dec_cfg.use_video_freeze_concealment = config.concealment_mode;
  dec_cfg.use_video_compressor = config.use_video_compressor;
  dec_cfg.use_ringbuffer = config.use_ringbuffer;
  dec_cfg.output_format = config.output_format;
#ifdef USE_EXTERNAL_BUFFER
  dec_cfg.guard_size = 0;
  dec_cfg.use_adaptive_buffers = 0;
#endif
  if (config.ppu_cfg[0].out_cut_8bits)
    dec_cfg.pixel_format = DEC_OUT_PIXEL_CUT_8BIT;
  else if (config.ppu_cfg[0].out_p010)
    dec_cfg.pixel_format = DEC_OUT_PIXEL_P010;
  else if (config.ppu_cfg[0].out_be)
    dec_cfg.pixel_format = DEC_OUT_PIXEL_CUSTOMER1;
  else
    dec_cfg.pixel_format = DEC_OUT_PIXEL_DEFAULT;
#if 0
  if (config.crop_cfg.crop_enabled) {
    dec_cfg.crop.enabled = 1;
    dec_cfg.crop.x = config.crop_cfg.crop_x;
    dec_cfg.crop.y = config.crop_cfg.crop_y;
    dec_cfg.crop.width = config.crop_cfg.crop_w;
    dec_cfg.crop.height = config.crop_cfg.crop_h;
  } else {
    dec_cfg.crop.enabled = 0;
    dec_cfg.crop.x = 0;
    dec_cfg.crop.y = 0;
    dec_cfg.crop.width = 0;
    dec_cfg.crop.height = 0;
  }
  dec_cfg.scale.enabled = config.scale_cfg.scale_enabled;
  if (config.scale_cfg.scale_mode == FIXED_DOWNSCALE) {
    dec_cfg.scale.width = Info->pic_width / config.scale_cfg.down_scale_x;
    dec_cfg.scale.height = Info->pic_height / config.scale_cfg.down_scale_y;
    dec_cfg.scale.width = ((dec_cfg.scale.width >> 1) << 1);
    dec_cfg.scale.height = ((dec_cfg.scale.height >> 1) << 1);
  } else {
    dec_cfg.scale.width = config.scale_cfg.scaled_w;
    dec_cfg.scale.height = config.scale_cfg.scaled_h;
  }
#else
  memcpy(dec_cfg.ppu_cfg, config.ppu_cfg, sizeof(config.ppu_cfg));
  if (config.fscale_cfg.fixed_scale_enabled) {
    /* Convert fixed ratio scale to ppu_cfg[0] */
    dec_cfg.ppu_cfg[0].enabled = 1;
    if (!config.ppu_cfg[0].crop.enabled) {
      dec_cfg.ppu_cfg[0].crop.enabled = 1;
      dec_cfg.ppu_cfg[0].crop.x = info->crop_params.crop_left_offset;
      dec_cfg.ppu_cfg[0].crop.y = info->crop_params.crop_top_offset;
      dec_cfg.ppu_cfg[0].crop.width = info->crop_params.crop_out_width;
      dec_cfg.ppu_cfg[0].crop.height = info->crop_params.crop_out_height;
    }
    if (!config.ppu_cfg[0].scale.enabled) {
      dec_cfg.ppu_cfg[0].scale.enabled = 1;
      dec_cfg.ppu_cfg[0].scale.width = dec_cfg.ppu_cfg[0].crop.width / config.fscale_cfg.down_scale_x;
      dec_cfg.ppu_cfg[0].scale.height = dec_cfg.ppu_cfg[0].crop.height / config.fscale_cfg.down_scale_y;
    }
  }
#endif
  dec_cfg.align = config.align;
  /* TODO(min): assume 1-byte aligned is only applied for pp output */
  if (dec_cfg.align == DEC_ALIGN_1B)
    dec_cfg.align = DEC_ALIGN_64B;
  return HevcDecSetInfo(inst, &dec_cfg);
}

enum DecRet HantroDecHevcNextPicture(void* inst, struct DecPicturePpu* pic) {
  enum DecRet rv;
  u32 stride, stride_ch, i, bit_depth;
  struct HevcDecPicture hpic;
  u32 *tile_status_virtual_address=NULL;
  addr_t tile_status_bus_address=0;
  u32 tile_status_address_offset=0;

  rv = HevcDecNextPicture(inst, &hpic);
	if (rv != DEC_PIC_RDY)
    return rv;
  memset(pic, 0, sizeof(struct DecPicturePpu));
  /*sunny add*/
  pic->pictures[0].luma_table.bus_address= hpic.output_rfc_luma_bus_address;
	#ifndef	NEW_MEM_ALLOC
  pic->pictures[0].luma_table.virtual_address = hpic.output_rfc_luma_base;
	#endif
  pic->pictures[0].chroma_table.bus_address= hpic.output_rfc_chroma_bus_address;
	#ifndef	NEW_MEM_ALLOC
  pic->pictures[0].chroma_table.virtual_address = hpic.output_rfc_chroma_base;
	#endif
  pic->pictures[0].pic_compressed_status = hpic.rfc_compressed ? 1 : 0;/*sunny add for rfc compressed status*/
  
  u32 pic_width_in_cbsy, pic_height_in_cbsy;
  u32 pic_width_in_cbsc, pic_height_in_cbsc;
  pic_width_in_cbsy = ((hpic.pictures[0].pic_width + 8 - 1)/8);
  pic_width_in_cbsy = NEXT_MULTIPLE(pic_width_in_cbsy, 16);
  pic_width_in_cbsc = ((hpic.pictures[0].pic_width + 16 - 1)/16);
  pic_width_in_cbsc = NEXT_MULTIPLE(pic_width_in_cbsc, 16);
  pic_height_in_cbsy = (hpic.pictures[0].pic_height + 8 - 1)/8;
  pic_height_in_cbsc = (hpic.pictures[0].pic_height/2 + 4 - 1)/4;
  
  u32 tbl_sizey = NEXT_MULTIPLE(pic_width_in_cbsy * pic_height_in_cbsy, 16);
  u32 tbl_sizec = NEXT_MULTIPLE(pic_width_in_cbsc * pic_height_in_cbsc, 16);
/*  
  printf("~~~in %s %d, pic_width=%d\n",__FUNCTION__,__LINE__,hpic.pictures[0].pic_width);
  printf("~~~in %s %d, pic_height=%d\n",__FUNCTION__,__LINE__,hpic.pictures[0].pic_height);  
  printf("~~~in %s %d, pic_width_in_cbsy=%d\n",__FUNCTION__,__LINE__,pic_width_in_cbsy);
  printf("~~~in %s %d, pic_width_in_cbsc=%d\n",__FUNCTION__,__LINE__,pic_width_in_cbsc);
  printf("~~~in %s %d, pic_height_in_cbsy=%d\n",__FUNCTION__,__LINE__,pic_height_in_cbsy);
  printf("~~~in %s %d, pic_height_in_cbsc=%d\n",__FUNCTION__,__LINE__,pic_height_in_cbsc);
  printf("~~~in %s %d, tbl_sizey=%d\n",__FUNCTION__,__LINE__,tbl_sizey);
  printf("~~~in %s %d, tbl_sizec=%d\n",__FUNCTION__,__LINE__,tbl_sizec);
  */
  pic->pictures[0].luma_table.size = tbl_sizey;
  pic->pictures[0].chroma_table.size = tbl_sizec;
  /*sunny add*/

  for (i = 0; i < DEC_MAX_OUT_COUNT; i++) {
		/*
    if (!hpic.pp_enabled) {
      if(hpic.pictures[0].output_format == DEC_OUT_FRM_TILED_4X4) {
        bit_depth = (hpic.bit_depth_luma == 8 && hpic.bit_depth_chroma == 8) ? 8 : 10;
        stride = hpic.pictures[0].pic_width * bit_depth / 8; 
      } else {
        stride = hpic.pictures[0].pic_stride;
      }
			stride_ch = stride;
    } else*/ 
		if ( hpic.pictures[i].pixel_format == DEC_OUT_PIXEL_RFC) {
			/* Compressed tiled data should be output without being converted to 16 bits.
			* It's treated as a special picture to output. */
			u32 bit_depth = (hpic.bit_depth_luma == 8 &&
			               hpic.bit_depth_luma == 8) ? 8 : 10;
			stride = hpic.pictures[i].pic_width * 4 * bit_depth / 8;
			stride_ch = stride;
		}
		else
		{
      stride = hpic.pictures[i].pic_stride;
      stride_ch = hpic.pictures[i].pic_stride_ch;
    }
		#ifndef	NEW_MEM_ALLOC
    pic->pictures[i].luma.virtual_address = (u32*)hpic.pictures[i].output_picture;
		#endif
    pic->pictures[i].luma.bus_address = hpic.pictures[i].output_picture_bus_address;
#if 0
  if (hpic.output_format == DEC_OUT_FRM_RASTER_SCAN)
    hpic.pic_width = NEXT_MULTIPLE(hpic.pic_width, 16);
#endif

    if ((hpic.pictures[i].output_format == DEC_OUT_FRM_TILED_4X4) /*&& hpic.pp_enabled*/) {
#if 0
      pic->pictures[i].luma.size = stride * hpic.pictures[i].pic_height / 4;
      /*pic->pictures[i].chroma.size = stride_ch * hpic.pictures[i].pic_height / 8;*/
	  if((hpic.pictures[i].pic_height / 4)&1 == 1)
	  	pic->pictures[i].chroma.size = stride_ch * (hpic.pictures[i].pic_height/4+1) / 2;
	  else
	  	pic->pictures[i].chroma.size = stride_ch * hpic.pictures[i].pic_height / 8;
#else
      pic->pictures[i].luma.size = stride * NEXT_MULTIPLE(hpic.pictures[i].pic_height, 4) / 4;
      pic->pictures[i].chroma.size = stride_ch * NEXT_MULTIPLE(hpic.pictures[i].pic_height/2, 4) / 4;
#endif
    } else {
      pic->pictures[i].luma.size = stride * hpic.pictures[i].pic_height;
      pic->pictures[i].chroma.size = stride_ch * hpic.pictures[i].pic_height;
    }
#if 0
		printf("\t\t in %s,pci %d Y size=0x%x(%d),UV size=0x%x(%d),stride=%d,stride_ch=%d\n",
			__func__,
			i,
			pic->pictures[i].luma.size,
			pic->pictures[i].luma.size,
			pic->pictures[i].chroma.size,
			pic->pictures[i].chroma.size,
			stride,
			stride_ch);
#endif
    /* TODO temporal solution to set chroma base here */
		#ifndef	NEW_MEM_ALLOC
    pic->pictures[i].chroma.virtual_address = (u32*)hpic.pictures[i].output_picture_chroma;
		#endif
	if((hpic.multi_tile_cols == 0)&&(i>0)&&(pic->pictures[i].luma.size != 0))/*mark the dpb total buffer base address*/
	{
		if(tile_status_bus_address == 0)
		{
		#ifndef	NEW_MEM_ALLOC
			tile_status_virtual_address = pic->pictures[i].luma.virtual_address;
		#endif
			tile_status_bus_address = pic->pictures[i].luma.bus_address;
		}
/*		printf("--in %s,%d,found pp %d  stride = 0x%x ,stride_ch= 0x%x ,pic_height=%d, luma.size=0x%x,chroma.size=0x%x\n",__FUNCTION__,__LINE__,i, stride  ,stride_ch ,hpic.pictures[i].pic_height,pic->pictures[i].luma.size,pic->pictures[i].chroma.size);*/
		

		tile_status_address_offset += pic->pictures[i].luma.size + PP_LUMA_BUF_RES;
		tile_status_address_offset += pic->pictures[i].chroma.size + PP_CHROMA_BUF_RES;
		
		/*

		tile_status_address_offset += NEXT_MULTIPLE(pic->pictures[i].luma.size + 0x2000,0x2000);
		tile_status_address_offset += NEXT_MULTIPLE(pic->pictures[i].chroma.size + 0x2000,0x2000);
		*/
		/*if((hpic.pictures[i].pic_height/4)&1 == 1)
			tile_status_address_offset += stride_ch/2;*/
	}

	pic->pictures[i].chroma.bus_address = hpic.pictures[i].output_picture_chroma_bus_address;
    /* TODO(vmr): find out for real also if it is B frame */
    pic->pictures[i].picture_info.pic_coding_type =
      hpic.is_idr_picture ? DEC_PIC_TYPE_I : DEC_PIC_TYPE_P;
    pic->pictures[i].picture_info.format = hpic.pictures[i].output_format;
    pic->pictures[i].picture_info.pixel_format = hpic.pictures[i].pixel_format;
    pic->pictures[i].picture_info.pic_id = hpic.pic_id;
    pic->pictures[i].picture_info.decode_id = hpic.decode_id;
    pic->pictures[i].picture_info.cycles_per_mb = hpic.cycles_per_mb;
    pic->pictures[i].sequence_info.pic_width = hpic.pictures[i].pic_width;
    pic->pictures[i].sequence_info.pic_height = hpic.pictures[i].pic_height;
    pic->pictures[i].sequence_info.crop_params.crop_left_offset =
      hpic.crop_params.crop_left_offset;
    pic->pictures[i].sequence_info.crop_params.crop_out_width =
      hpic.crop_params.crop_out_width;
    pic->pictures[i].sequence_info.crop_params.crop_top_offset =
      hpic.crop_params.crop_top_offset;
    pic->pictures[i].sequence_info.crop_params.crop_out_height =
      hpic.crop_params.crop_out_height;
    pic->pictures[i].sequence_info.sar_width = hpic.dec_info.sar_width;
    pic->pictures[i].sequence_info.sar_height = hpic.dec_info.sar_height;
    pic->pictures[i].sequence_info.video_range = hpic.dec_info.video_range;
    pic->pictures[i].sequence_info.matrix_coefficients =
      hpic.dec_info.matrix_coefficients;
    pic->pictures[i].sequence_info.is_mono_chrome =
      hpic.dec_info.mono_chrome;
    pic->pictures[i].sequence_info.is_interlaced = hpic.dec_info.interlaced_sequence;
    pic->pictures[i].sequence_info.num_of_ref_frames =
      hpic.dec_info.pic_buff_size;
    pic->pictures[i].sequence_info.bit_depth_luma = hpic.bit_depth_luma;
    pic->pictures[i].sequence_info.bit_depth_chroma = hpic.bit_depth_chroma;
    pic->pictures[i].sequence_info.main10_profile = hpic.main10_profile;
    pic->pictures[i].sequence_info.pic_stride = hpic.pictures[i].pic_stride;
    pic->pictures[i].sequence_info.pic_stride_ch = hpic.pictures[i].pic_stride_ch;
    pic->pictures[i].pic_width = hpic.pictures[i].pic_width;
    pic->pictures[i].pic_height = hpic.pictures[i].pic_height;
    pic->pictures[i].pic_stride = hpic.pictures[i].pic_stride;
    pic->pictures[i].pic_stride_ch = hpic.pictures[i].pic_stride_ch;
    pic->pictures[i].pp_enabled = hpic.pp_enabled;
  }
  /*tile_status_address_offset = NEXT_MULTIPLE(tile_status_address_offset,0x2000);*/
  for (i = 0; i < DEC_MAX_OUT_COUNT; i++) {
  	if((hpic.multi_tile_cols == 0)&&(i>0)&&(pic->pictures[i].luma.size != 0)
			#ifndef	NEW_MEM_ALLOC
			&&(pic->pictures[i].luma_table.virtual_address == NULL)
			#else
			&&(pic->pictures[i].luma_table.bus_address== 0)
			#endif
			)
	{
	#ifndef	NEW_MEM_ALLOC
		pic->pictures[i].luma_table.virtual_address = (u32*)((addr_t)tile_status_virtual_address + tile_status_address_offset + DEC400_PPn_Y_TABLE_OFFSET(i-1));
	#endif
		pic->pictures[i].luma_table.bus_address= tile_status_bus_address + tile_status_address_offset+ DEC400_PPn_Y_TABLE_OFFSET(i-1);
		pic->pictures[i].luma_table.size = NEXT_MULTIPLE(pic->pictures[i].luma.size/1024/4 +((pic->pictures[i].luma.size%4096)?1:0), 16);

	#ifndef	NEW_MEM_ALLOC
		pic->pictures[i].chroma_table.virtual_address = (u32*)((addr_t)tile_status_virtual_address + tile_status_address_offset + DEC400_PPn_UV_TABLE_OFFSET(i-1));
	#endif
		pic->pictures[i].chroma_table.bus_address= tile_status_bus_address + tile_status_address_offset+ DEC400_PPn_UV_TABLE_OFFSET(i-1);
		pic->pictures[i].chroma_table.size = NEXT_MULTIPLE(pic->pictures[i].chroma.size/1024/4 +((pic->pictures[i].chroma.size%4096)?1:0), 16);

#ifdef SUPPORT_DEC400		
		pic->pictures[i].pic_compressed_status = hpic.pictures[i].pic_compressed_status;;
#else
		pic->pictures[i].pic_compressed_status = 0;
#endif
#if 0
		printf("--in %s,%d,tile_status_address_offset = 0x%x ,tile_status_bus_address=0x%x,DEC400_PPn_Y_TABLE_OFFSET(i-1)=0x%x!!!!!!!!!!!!!!!!!\n",__FUNCTION__,__LINE__,tile_status_address_offset,tile_status_bus_address,DEC400_PPn_Y_TABLE_OFFSET(i-1));
		printf("--in %s,%d,setting pic->pictures[%d].luma_table.bus_address = 0x%x !!!!!!!!!!!!!!!!!\n",__FUNCTION__,__LINE__,i,pic->pictures[i].luma_table.bus_address);
		printf("--in %s,%d,setting pic->pictures[%d].luma_table.size = 0x%x(%d) !!!!!!!!!!!!!!!!!\n",__FUNCTION__,__LINE__,i,pic->pictures[i].luma_table.size,pic->pictures[i].luma_table.size);
#endif		
	}
  }
  return rv;
}

enum DecRet HantroDecHevcPictureConsumed(void* inst, struct DecPicturePpu pic) {
  struct HevcDecPicture hpic;
  u32 i;
  memset(&hpic, 0, sizeof(struct HevcDecPicture));
  /* TODO update chroma luma/chroma base */
  for (i = 0; i < DEC_MAX_OUT_COUNT; i++) {
	#ifndef	NEW_MEM_ALLOC
    hpic.pictures[i].output_picture = pic.pictures[i].luma.virtual_address;
	#endif
    hpic.pictures[i].output_picture_bus_address = pic.pictures[i].luma.bus_address;
  }
  hpic.is_idr_picture = pic.pictures[0].picture_info.pic_coding_type == DEC_PIC_TYPE_I;
  return HevcDecPictureConsumed(inst, &hpic);
}

enum DecRet HantroDecHevcEndOfStream(void* inst) {
  return HevcDecEndOfStream(inst);
}

#ifdef USE_EXTERNAL_BUFFER
enum DecRet HantroDecHevcGetBufferInfo(void *inst, struct DecBufferInfo *buf_info) {
  struct HevcDecBufferInfo hbuf;
  enum DecRet rv;

  rv = HevcDecGetBufferInfo(inst, &hbuf);
  buf_info->buf_to_free = hbuf.buf_to_free;
  buf_info->next_buf_size = hbuf.next_buf_size;
  buf_info->buf_num = hbuf.buf_num;
#ifdef ASIC_TRACE_SUPPORT
  buf_info->is_frame_buffer = hbuf.is_frame_buffer;
#endif
  return rv;
}

enum DecRet HantroDecHevcAddBuffer(void *inst, struct DWLLinearMem *buf) {
  return HevcDecAddBuffer(inst, buf);
}
#endif

void HantroDecHevcRelease(void* inst) {
  HevcDecRelease(inst);
}



enum DecRet HantroDecH264Init(const void** inst, struct DecConfig config,
                            const void *dwl) {
  struct H264DecConfig dec_cfg;
  H264DecMCConfig mcinit_cfg;
  mcinit_cfg.mc_enable = config.mc_cfg.mc_enable;
  mcinit_cfg.stream_consumed_callback = config.mc_cfg.stream_consumed_callback;

  dec_cfg.no_output_reordering = config.disable_picture_reordering;
  dec_cfg.error_handling = DEC_EC_FAST_FREEZE; //config.concealment_mode;
  //dec_cfg.use_video_compressor = config.use_video_compressor;
  //dec_cfg.use_ringbuffer = 0; //config.use_ringbuffer;
  //dec_cfg.output_format = config.output_format;
  dec_cfg.decoder_mode = config.decoder_mode;
  dec_cfg.dpb_flags = DEC_REF_FRM_TILED_DEFAULT;
  dec_cfg.use_display_smoothing = 0;
  //dec_cfg.tile_by_tile = config.tile_by_tile;
#ifdef USE_EXTERNAL_BUFFER
  dec_cfg.guard_size = 0;
  dec_cfg.use_adaptive_buffers = 0;
#endif
#if 0
  if (config.use_8bits_output)
    dec_cfg.pixel_format = DEC_OUT_PIXEL_CUT_8BIT;
  else if (config.use_p010_output)
    dec_cfg.pixel_format = DEC_OUT_PIXEL_P010;
  else if (config.use_1010_output)
    dec_cfg.pixel_format = DEC_OUT_PIXEL_1010;
  else if (config.use_bige_output)
    dec_cfg.pixel_format = DEC_OUT_PIXEL_CUSTOMER1;
  else
    dec_cfg.pixel_format = DEC_OUT_PIXEL_DEFAULT;
#endif
  memcpy(dec_cfg.ppu_config, config.ppu_cfg, sizeof(config.ppu_cfg));
  return (enum DecRet)H264DecInit(inst, dwl, dec_cfg.decoder_mode,
                                  dec_cfg.no_output_reordering,
                                  dec_cfg.error_handling,
                                  dec_cfg.use_display_smoothing,
                                  dec_cfg.dpb_flags,
                                  0,
                                  //dec_cfg.use_video_compressor,
                                  dec_cfg.use_adaptive_buffers,
                                  dec_cfg.guard_size,
                                  &mcinit_cfg);
}

enum DecRet HantroDecH264GetInfo(void* inst, struct DecSequenceInfo* info) {
  H264DecInfo h264_info;
  enum DecRet rv = (enum DecRet)H264DecGetInfo(inst, &h264_info);
  info->pic_width = h264_info.pic_width;
  info->pic_height = h264_info.pic_height;
  info->sar_width = h264_info.sar_width;
  info->sar_height = h264_info.sar_height;
  info->crop_params.crop_left_offset = h264_info.crop_params.crop_left_offset;
  info->crop_params.crop_out_width = h264_info.crop_params.crop_out_width;
  info->crop_params.crop_top_offset = h264_info.crop_params.crop_top_offset;
  info->crop_params.crop_out_height = h264_info.crop_params.crop_out_height;
  info->video_range = h264_info.video_range;
  info->matrix_coefficients = h264_info.matrix_coefficients;
  info->is_mono_chrome = h264_info.mono_chrome;
  is_mono_chrome = h264_info.mono_chrome;
  info->is_interlaced = h264_info.interlaced_sequence;
  info->num_of_ref_frames = h264_info.pic_buff_size;
  info->bit_depth_luma = h264_info.bit_depth_luma;
  info->bit_depth_chroma = h264_info.bit_depth_chroma;
  return rv;
}

enum DecRet HantroDecH264SetInfo(void* inst, struct DecConfig config, struct DecSequenceInfo* info) {
  struct H264DecConfig dec_cfg;
  dec_cfg.no_output_reordering = config.disable_picture_reordering;
  //dec_cfg.use_video_freeze_concealment = config.concealment_mode;
  //dec_cfg.use_video_compressor = config.use_video_compressor;
  //dec_cfg.use_ringbuffer = config.use_ringbuffer;
  //dec_cfg.output_format = config.output_format;
  dec_cfg.decoder_mode = config.decoder_mode;
#ifdef USE_EXTERNAL_BUFFER
  dec_cfg.guard_size = 0;
  dec_cfg.use_adaptive_buffers = 0;
#endif
  memcpy(dec_cfg.ppu_config, config.ppu_cfg, sizeof(config.ppu_cfg));

	
//	printf("\n\n					^^^^^^^^^^^^^^^^^^^ in H264SetInfo is_interlaced=%d,config.output_format=%d\n\n\n",
//			info->is_interlaced,
//			config.output_format);
	/*add overlap pp setting for interlace cases*/
/*
	if(info->is_interlaced)
	{
        dec_cfg.ppu_config[0].enabled = 1;
		for(int i=0;i<4;i++)
		{
			if(dec_cfg.ppu_config[i].enabled == 1)
			{
				dec_cfg.ppu_config[i].tiled_e = 0;
				dec_cfg.ppu_config[i].shaper_enabled = 0;
				//dec_cfg.ppu_config[i].align = DEC_ALIGN_16B;
				dec_cfg.ppu_config[i].align = DEC_ALIGN_1024B;
			}
		}
	}
	
*/
  if (config.fscale_cfg.fixed_scale_enabled) {
    /* Convert fixed ratio scale to ppu_config[0] */
    dec_cfg.ppu_config[0].enabled = 1;
    if (!config.ppu_cfg[0].crop.enabled) {
      dec_cfg.ppu_config[0].crop.enabled = 1;
      dec_cfg.ppu_config[0].crop.x = info->crop_params.crop_left_offset;
      dec_cfg.ppu_config[0].crop.y = info->crop_params.crop_top_offset;
      dec_cfg.ppu_config[0].crop.width = info->crop_params.crop_out_width;
      dec_cfg.ppu_config[0].crop.height = info->crop_params.crop_out_height;
    }
    if (!config.ppu_cfg[0].scale.enabled) {
      dec_cfg.ppu_config[0].scale.enabled = 1;
      dec_cfg.ppu_config[0].scale.width = dec_cfg.ppu_config[0].crop.width / config.fscale_cfg.down_scale_x;
      dec_cfg.ppu_config[0].scale.height = dec_cfg.ppu_config[0].crop.height / config.fscale_cfg.down_scale_y;
    }
  }
  dec_cfg.align = config.align;
  dec_cfg.error_conceal = 0;
  /* TODO(min): assume 1-byte aligned is only applied for pp output */
  if (dec_cfg.align == DEC_ALIGN_1B)
    dec_cfg.align = DEC_ALIGN_64B;
#if 0
printf("--------------------debug------------------\n");
for(int i=0;i<4;i++)
{
    printf("ppu_config[%d].enabled = %d \n",i,dec_cfg.ppu_config[i].enabled);
    printf("ppu_config[%d].tiled_e = %d \n",i,dec_cfg.ppu_config[i].tiled_e);
    printf("ppu_config[%d].cr_first = %d \n",i,dec_cfg.ppu_config[i].cr_first);
    printf("ppu_config[%d].shaper_enabled = %d \n",i,dec_cfg.ppu_config[i].shaper_enabled);
    printf("ppu_config[%d].planar = %d \n",i,dec_cfg.ppu_config[i].planar);
    printf("ppu_config[%d].align = %d \n",i,dec_cfg.ppu_config[i].align);
    printf("ppu_config[%d].ystride = %d \n",i,dec_cfg.ppu_config[i].ystride);
    printf("ppu_config[%d].cstride = %d \n",i,dec_cfg.ppu_config[i].cstride);
    printf("ppu_config[%d].monochrome = %d \n",i,dec_cfg.ppu_config[i].monochrome);
    printf("ppu_config[%d].out_p010 = %d \n",i,dec_cfg.ppu_config[i].out_p010);
    printf("ppu_config[%d].out_cut_8bits = %d \n",i,dec_cfg.ppu_config[i].out_cut_8bits);
    printf("ppu_config[%d].out_be = %d \n",i,dec_cfg.ppu_config[i].out_be);
    printf("ppu_config[%d].out_format = %d \n",i,dec_cfg.ppu_config[i].out_format);
    printf("ppu_config[%d].enabled = %d \n",i,dec_cfg.ppu_config[i].enabled);

    printf("ppu_config[%d].crop.enabled = %d \n",i,dec_cfg.ppu_config[i].crop.enabled);
    printf("ppu_config[%d].crop.x = %d \n",i,dec_cfg.ppu_config[i].crop.x);                                                        
    printf("ppu_config[%d].crop.y = %d \n",i,dec_cfg.ppu_config[i].crop.y);                                        
    printf("ppu_config[%d].crop.width = %d \n",i,dec_cfg.ppu_config[i].crop.width);                    
    printf("ppu_config[%d].crop.height = %d \n",i,dec_cfg.ppu_config[i].crop.height);    
    printf("ppu_config[%d].scale.enabled = %d \n",i,dec_cfg.ppu_config[i].scale.enabled);
    printf("ppu_config[%d].scale.width = %d \n",i,dec_cfg.ppu_config[i].scale.width);
    printf("ppu_config[%d].scale.height = %d \n",i,dec_cfg.ppu_config[i].scale.height);
    printf("\n\n");

}
#endif

  
  return (enum DecRet)H264DecSetInfo(inst, &dec_cfg);
}

enum DecRet HantroDecH264NextPicture(void* inst, struct DecPicturePpu* pic) {
  enum DecRet rv;
  u32 stride, stride_ch, i;
  H264DecPicture hpic;
  rv = H264DecNextPicture(inst, &hpic, 0);
  memset(pic, 0, sizeof(struct DecPicturePpu));
  if (rv != DEC_PIC_RDY)
    return rv;
  for (i = 0; i < DEC_MAX_OUT_COUNT; i++) {
    stride = hpic.pictures[i].pic_stride;
    stride_ch = hpic.pictures[i].pic_stride_ch;
		#ifndef NEW_MEM_ALLOC
    pic->pictures[i].luma.virtual_address = (u32*)hpic.pictures[i].output_picture;
		#endif
    pic->pictures[i].luma.bus_address = hpic.pictures[i].output_picture_bus_address;
#if 0
  if (hpic.output_format == DEC_OUT_FRM_RASTER_SCAN)
    hpic.pic_width = NEXT_MULTIPLE(hpic.pic_width, 16);
#endif
    if (hpic.pictures[i].output_format == DEC_OUT_FRM_TILED_4X4) {
      pic->pictures[i].luma.size = stride * hpic.pictures[i].pic_height / 4;
			/*sunny correct*/
		  if((hpic.pictures[i].pic_height / 4)&1 == 1)
		  	pic->pictures[i].chroma.size = stride_ch * (hpic.pictures[i].pic_height/4+1) / 2;
		  else
		  	pic->pictures[i].chroma.size = stride_ch * hpic.pictures[i].pic_height / 8;
			
      /*pic->pictures[i].chroma.size = stride_ch * hpic.pictures[i].pic_height / 8;*/
    } else {
      pic->pictures[i].luma.size = stride * hpic.pictures[i].pic_height;
      pic->pictures[i].chroma.size = stride_ch * hpic.pictures[i].pic_height/2;
    }
    /* TODO temporal solution to set chroma base here */
		#ifndef NEW_MEM_ALLOC
    pic->pictures[i].chroma.virtual_address = (u32*)hpic.pictures[i].output_picture_chroma;
		#endif
    pic->pictures[i].chroma.bus_address = hpic.pictures[i].output_picture_chroma_bus_address;
	
    /* TODO(vmr): find out for real also if it is B frame */
    pic->pictures[i].picture_info.pic_coding_type =
      hpic.is_idr_picture[0] ? DEC_PIC_TYPE_I : DEC_PIC_TYPE_P;
    pic->pictures[i].picture_info.format = hpic.pictures[i].output_format;
    pic->pictures[i].picture_info.pixel_format = DEC_OUT_PIXEL_DEFAULT; //hpic.pictures[i].pixel_format;
    pic->pictures[i].picture_info.pic_id = hpic.pic_id;
    pic->pictures[i].picture_info.decode_id = hpic.decode_id[0];
    pic->pictures[i].picture_info.cycles_per_mb = hpic.cycles_per_mb;
    pic->pictures[i].sequence_info.pic_width = hpic.pictures[i].pic_width;
    pic->pictures[i].sequence_info.pic_height = hpic.pictures[i].pic_height;
    pic->pictures[i].sequence_info.crop_params.crop_left_offset =
      hpic.crop_params.crop_left_offset;
    pic->pictures[i].sequence_info.crop_params.crop_top_offset =
      hpic.crop_params.crop_top_offset;
    if (hpic.interlaced) {
        if (hpic.crop_params.crop_out_width <= hpic.pictures[i].pic_width) {
            pic->pictures[i].sequence_info.crop_params.crop_out_width =
              hpic.crop_params.crop_out_width;
        } else {
          pic->pictures[i].sequence_info.crop_params.crop_out_width =
            hpic.pictures[i].pic_width;
        }
        if (hpic.crop_params.crop_out_height <= hpic.pictures[i].pic_height) {
            pic->pictures[i].sequence_info.crop_params.crop_out_height =
              hpic.crop_params.crop_out_height;
        } else {
          pic->pictures[i].sequence_info.crop_params.crop_out_height =
            hpic.pictures[i].pic_height;
        }
    } else {
        pic->pictures[i].sequence_info.crop_params.crop_out_width =
          hpic.crop_params.crop_out_width;
        pic->pictures[i].sequence_info.crop_params.crop_out_height =
          hpic.crop_params.crop_out_height;
    }
    pic->pictures[i].sequence_info.sar_width = hpic.sar_width;
    pic->pictures[i].sequence_info.sar_height = hpic.sar_height;
    pic->pictures[i].sequence_info.video_range = 0; //hpic.video_range;
    pic->pictures[i].sequence_info.matrix_coefficients =
      0; //hpic.matrix_coefficients;
    pic->pictures[i].sequence_info.is_mono_chrome = is_mono_chrome;
     // 0; //hpic.mono_chrome;
    pic->pictures[i].sequence_info.is_interlaced = hpic.interlaced;
    pic->pictures[i].sequence_info.num_of_ref_frames =
      0; //hpic.dec_info.pic_buff_size;
    pic->pictures[i].sequence_info.bit_depth_luma = hpic.bit_depth_luma;
    pic->pictures[i].sequence_info.bit_depth_chroma = hpic.bit_depth_chroma;
    pic->pictures[i].sequence_info.pic_stride = hpic.pictures[i].pic_stride;
    pic->pictures[i].sequence_info.pic_stride_ch = hpic.pictures[i].pic_stride_ch;
    pic->pictures[i].pic_width = hpic.pictures[i].pic_width;
    pic->pictures[i].pic_height = hpic.pictures[i].pic_height;
    pic->pictures[i].pic_stride = hpic.pictures[i].pic_stride;
    pic->pictures[i].pic_stride_ch = hpic.pictures[i].pic_stride_ch;
    pic->pictures[i].pp_enabled = 0; //hpic.pp_enabled;
  }

  #ifdef SUPPORT_DEC400

	  /*add for dec400 tables*/
		addr_t dec400_table_bus_address_base = 0; 
		const u32 *dec400_table_base =NULL;
		int dec400_table_offset=0;
		u32 y_size=0,uv_size=0;
		for(i=0;i<DEC_MAX_OUT_COUNT;i++)
		{
			pic->pictures[i].pic_compressed_status = hpic.pictures[i].pic_compressed_status;
			#ifndef NEW_MEM_ALLOC
			if(pic->pictures[i].luma.virtual_address != NULL)
			#else
			if(pic->pictures[i].luma.bus_address != 0)
			#endif
			{
				if(i == 0)
				{
#if 0
					y_size = pic->pictures[i].pic_height/4 * pic->pictures[i].pic_stride;
					if((pic->pictures[i].pic_height/4) & 1 ==1)
						uv_size = (pic->pictures[i].pic_height/4+1)/2 * pic->pictures[i].pic_stride_ch;
					else
						uv_size = pic->pictures[i].pic_height/4/2 * pic->pictures[i].pic_stride_ch;
#else
					y_size = NEXT_MULTIPLE(pic->pictures[i].pic_height, 4)/4 * pic->pictures[i].pic_stride;
					uv_size = NEXT_MULTIPLE(pic->pictures[i].pic_height/2, 4)/4 * pic->pictures[i].pic_stride_ch;
#endif
					#ifndef NEW_MEM_ALLOC
					pic->pictures[i].luma_table.virtual_address= (u32*)((u8*)pic->pictures[i].luma.virtual_address-DEC400_PP_TABLE_SIZE);
					#endif
					pic->pictures[i].luma_table.bus_address= pic->pictures[i].luma.bus_address-DEC400_PP_TABLE_SIZE;					
					pic->pictures[i].luma_table.size = NEXT_MULTIPLE(y_size/1024/4 +((y_size%4096)?1:0), 16);
					#ifndef NEW_MEM_ALLOC
					pic->pictures[i].chroma_table.virtual_address= (u32*)((u8*)pic->pictures[i].luma.virtual_address-DEC400_YUV_TABLE_SIZE);
					#endif
					pic->pictures[i].chroma_table.bus_address= pic->pictures[i].luma.bus_address-DEC400_YUV_TABLE_SIZE;					
					pic->pictures[i].chroma_table.size= NEXT_MULTIPLE(uv_size/1024/4 +((uv_size%4096)?1:0), 16);
				}
				else
				{
					if(dec400_table_bus_address_base == 0)
					{
						dec400_table_bus_address_base = pic->pictures[i].luma.bus_address;
						#ifndef NEW_MEM_ALLOC
						dec400_table_base = pic->pictures[i].luma.virtual_address;
						#endif
/*						printf("\n\n--in %s : %d found base at %d pp,bus=0x%x,v=%p\n",__FUNCTION__,__LINE__,i,dec400_table_bus_address_base,dec400_table_base);*/
					}
#if 0
					y_size = pic->pictures[i].pic_height/4 * pic->pictures[i].pic_stride;
					if((pic->pictures[i].pic_height/4) & 1 ==1)
						uv_size = (pic->pictures[i].pic_height/4+1)/2 * pic->pictures[i].pic_stride_ch;
					else
						uv_size = pic->pictures[i].pic_height/4/2 * pic->pictures[i].pic_stride_ch;
#else
          y_size = NEXT_MULTIPLE(pic->pictures[i].pic_height, 4)/4 * pic->pictures[i].pic_stride;
          uv_size = NEXT_MULTIPLE(pic->pictures[i].pic_height/2, 4)/4 * pic->pictures[i].pic_stride_ch;
#endif
					pic->pictures[i].luma_table.size = NEXT_MULTIPLE(y_size/1024/4 +((y_size%4096)?1:0), 16);
					pic->pictures[i].chroma_table.size = NEXT_MULTIPLE(uv_size/1024/4 +((uv_size%4096)?1:0), 16);
					dec400_table_offset +=y_size + PP_LUMA_BUF_RES;
					dec400_table_offset +=uv_size + PP_CHROMA_BUF_RES;
				}

			}
		}
		/*printf("\n\n--in %s : %d dec400_table_bus_address_base=0x%x,dec400_table_offset=0x%x\n",__FUNCTION__,__LINE__,dec400_table_bus_address_base,dec400_table_offset);*/
		for(i=1;i<DEC_MAX_OUT_COUNT;i++)
		{
			#ifndef NEW_MEM_ALLOC
			if(pic->pictures[i].luma.virtual_address!= NULL)
			#else
			if(pic->pictures[i].luma.bus_address!= 0)
			#endif
			{
			#ifndef NEW_MEM_ALLOC
				pic->pictures[i].luma_table.virtual_address = (u32 *)((u8 *)dec400_table_base + dec400_table_offset + DEC400_PPn_Y_TABLE_OFFSET(i-1));
			#endif
				pic->pictures[i].luma_table.bus_address = dec400_table_bus_address_base + dec400_table_offset + DEC400_PPn_Y_TABLE_OFFSET(i-1);
			#ifndef NEW_MEM_ALLOC
				pic->pictures[i].chroma_table.virtual_address = (u32 *)((u8 *)dec400_table_base + dec400_table_offset + DEC400_PPn_UV_TABLE_OFFSET(i-1));
			#endif
				pic->pictures[i].chroma_table.bus_address = dec400_table_bus_address_base + dec400_table_offset + DEC400_PPn_UV_TABLE_OFFSET(i-1);
			}

		}
		/*	
		for(i=0;i<DEC_MAX_OUT_COUNT;i++)
		{
			if(pic->pictures[i].luma.virtual_address != NULL)
			{		
			printf("\n--in %s : %d pic%d Y_table =%p(0x%x),size=%d,UV_table =%p(0x%x),size=%d\n",
					__FUNCTION__,
					__LINE__,
					i,
					pic->pictures[i].luma_table.virtual_address,
					pic->pictures[i].luma_table.bus_address,
					pic->pictures[i].luma_table.size,
					pic->pictures[i].chroma_table.virtual_address,
					pic->pictures[i].chroma_table.bus_address,
					pic->pictures[i].chroma_table.size);
			}
		}*/
#else
	u32 y_size=0;

	for(i=0;i<DEC_MAX_OUT_COUNT;i++)
	{
		pic->pictures[i].pic_compressed_status = 0;
	}

#endif

  return rv;
}

enum DecRet HantroDecH264PictureConsumed(void* inst, struct DecPicturePpu pic) {
  H264DecPicture hpic;
  u32 i;
  memset(&hpic, 0, sizeof(H264DecPicture));
  /* TODO update chroma luma/chroma base */
  for (i = 0; i < DEC_MAX_OUT_COUNT; i++) {
		#ifndef NEW_MEM_ALLOC
    hpic.pictures[i].output_picture = pic.pictures[i].luma.virtual_address;
		#endif
    hpic.pictures[i].output_picture_bus_address = pic.pictures[i].luma.bus_address;
  }
  hpic.is_idr_picture[0] = pic.pictures[0].picture_info.pic_coding_type == DEC_PIC_TYPE_I;
  return H264DecPictureConsumed(inst, &hpic);
}

enum DecRet HantroDecH264EndOfStream(void* inst) {
  return H264DecEndOfStream(inst, 1);
}

#ifdef USE_EXTERNAL_BUFFER
enum DecRet HantroDecH264GetBufferInfo(void *inst, struct DecBufferInfo *buf_info) {
  H264DecBufferInfo hbuf;
  enum DecRet rv;

  rv = H264DecGetBufferInfo(inst, &hbuf);
  buf_info->buf_to_free = hbuf.buf_to_free;
  buf_info->next_buf_size = hbuf.next_buf_size;
  buf_info->buf_num = hbuf.buf_num;
#ifdef ASIC_TRACE_SUPPORT
  buf_info->is_frame_buffer = 1; //hbuf.is_frame_buffer;
#endif
  return rv;
}

enum DecRet HantroDecH264AddBuffer(void *inst, struct DWLLinearMem *buf) {
  return H264DecAddBuffer(inst, buf);
}
#endif

void HantroDecH264Release(void* inst) {
  H264DecRelease(inst);
}


enum DecRet HantroDecVp9Init(const void** inst, struct DecConfig config,
                           const void *dwl) {
  enum DecPictureFormat format = config.output_format;

  struct Vp9DecConfig dec_cfg;
  dec_cfg.use_video_freeze_concealment = config.concealment_mode;
  dec_cfg.num_frame_buffers = 9;
  dec_cfg.dpb_flags = 4;
  dec_cfg.use_video_compressor = config.use_video_compressor;
  dec_cfg.use_ringbuffer = config.use_ringbuffer;
  dec_cfg.output_format = format;
  dec_cfg.tile_by_tile = config.tile_by_tile;
  if (config.ppu_cfg[0].out_cut_8bits)
    dec_cfg.pixel_format = DEC_OUT_PIXEL_CUT_8BIT;
  else if (config.ppu_cfg[0].out_p010)
    dec_cfg.pixel_format = DEC_OUT_PIXEL_P010;
  else if (config.ppu_cfg[0].out_be)
    dec_cfg.pixel_format = DEC_OUT_PIXEL_CUSTOMER1;
  else
    dec_cfg.pixel_format = DEC_OUT_PIXEL_DEFAULT;
  memcpy(dec_cfg.ppu_cfg, config.ppu_cfg, sizeof(config.ppu_cfg));
  return Vp9DecInit(inst, dwl, &dec_cfg);
}

enum DecRet HantroDecVp9GetInfo(void* inst, struct DecSequenceInfo* info) {
  struct Vp9DecInfo vp9_info = {0};
  enum DecRet rv = Vp9DecGetInfo(inst, &vp9_info);
  info->pic_width = vp9_info.frame_width;
  info->pic_height = vp9_info.frame_height;
  info->sar_width = 1;
  info->sar_height = 1;
  info->crop_params.crop_left_offset = 0;
  info->crop_params.crop_out_width = vp9_info.coded_width;
  info->crop_params.crop_top_offset = 0;
  info->crop_params.crop_out_height = vp9_info.coded_height;
  /* TODO(vmr): Consider adding scaled_width & scaled_height. */
  /* TODO(vmr): output_format? */
  info->num_of_ref_frames = vp9_info.pic_buff_size;
  info->video_range = DEC_VIDEO_RANGE_NORMAL;
  info->matrix_coefficients = 0;
  info->is_mono_chrome = 0;
  info->is_interlaced = 0;
  info->bit_depth_luma = info->bit_depth_chroma = vp9_info.bit_depth;
  return rv;
}

enum DecRet HantroDecVp9SetInfo(void* inst, struct DecConfig config, struct DecSequenceInfo* Info) {
  struct Vp9DecConfig dec_cfg;
  dec_cfg.use_video_freeze_concealment = config.concealment_mode;
  dec_cfg.num_frame_buffers = 9;
  dec_cfg.dpb_flags = 4;
  dec_cfg.use_video_compressor = config.use_video_compressor;
  dec_cfg.use_ringbuffer = config.use_ringbuffer;
  if (config.ppu_cfg[0].out_cut_8bits)
    dec_cfg.pixel_format = DEC_OUT_PIXEL_CUT_8BIT;
  else if (config.ppu_cfg[0].out_p010)
    dec_cfg.pixel_format = DEC_OUT_PIXEL_P010;
  else if (config.ppu_cfg[0].out_be)
    dec_cfg.pixel_format = DEC_OUT_PIXEL_CUSTOMER1;
  else
    dec_cfg.pixel_format = DEC_OUT_PIXEL_DEFAULT;

  memcpy(dec_cfg.ppu_cfg, config.ppu_cfg, sizeof(config.ppu_cfg));
  if (config.fscale_cfg.fixed_scale_enabled) {
    /* Convert fixed ratio scale to ppu_cfg[0] */
    dec_cfg.ppu_cfg[0].enabled = 1;
    if (!config.ppu_cfg[0].crop.enabled) {
      dec_cfg.ppu_cfg[0].crop.enabled = 1;
      dec_cfg.ppu_cfg[0].crop.x = 0;
      dec_cfg.ppu_cfg[0].crop.y = 0;
      dec_cfg.ppu_cfg[0].crop.width = Info->pic_width;
      dec_cfg.ppu_cfg[0].crop.height = Info->pic_height;
    }
    if (!config.ppu_cfg[0].scale.enabled) {
      dec_cfg.ppu_cfg[0].scale.enabled = 1;
      dec_cfg.ppu_cfg[0].scale.width = dec_cfg.ppu_cfg[0].crop.width / config.fscale_cfg.down_scale_x;
      dec_cfg.ppu_cfg[0].scale.height = dec_cfg.ppu_cfg[0].crop.height / config.fscale_cfg.down_scale_y;
    }
  }
  dec_cfg.output_format = config.output_format;
  dec_cfg.align = config.align;
  dec_cfg.fixed_scale_enabled = config.fscale_cfg.fixed_scale_enabled;
  /* TODO(min): assume 1-byte aligned is only applied for pp output */
  if (dec_cfg.align == DEC_ALIGN_1B)
    dec_cfg.align = DEC_ALIGN_64B;
  return Vp9DecSetInfo(inst, &dec_cfg);
}

/* function copied from the libvpx */
void HantroDecParseSuperframeIndex(const u8* data, size_t data_sz,
                                 const u8* buf, size_t buf_sz,
                                 u32 sizes[8], i32* count) {
  u8 marker;
  u8* buf_end = (u8*)buf + buf_sz;
  if ((data + data_sz - 1) < buf_end)
    marker = DWLPrivateAreaReadByte(data + data_sz - 1);
  else
    marker = DWLPrivateAreaReadByte(data + (i32)data_sz - 1 - (i32)buf_sz);
  //marker = data[data_sz - 1];
  *count = 0;

  if ((marker & 0xe0) == 0xc0) {
    const u32 frames = (marker & 0x7) + 1;
    const u32 mag = ((marker >> 3) & 0x3) + 1;
    const u32 index_sz = 2 + mag * frames;
    u8 index_value;
    u32 turn_around = 0;
    if((data + data_sz - index_sz) < buf_end)
      index_value = DWLPrivateAreaReadByte(data + data_sz - index_sz);
    else {
      index_value = DWLPrivateAreaReadByte(data + data_sz - index_sz - buf_sz);
      turn_around = 1;
    }

    if (data_sz >= index_sz && index_value == marker) {
      /* found a valid superframe index */
      u32 i, j;
      const u8* x = data + data_sz - index_sz + 1;
      if(turn_around)
        x = data + data_sz - index_sz + 1 - buf_sz;

      for (i = 0; i < frames; i++) {
        u32 this_sz = 0;

        for (j = 0; j < mag; j++) {
          if (x == buf + buf_sz)
            x = buf;
          this_sz |= DWLPrivateAreaReadByte(x) << (j * 8);
          x++;
        }
        sizes[i] = this_sz;
      }

      *count = frames;
    }
  }
}
#if 0
enum DecRet HantroDecVp9Decode(void* inst, struct DWLLinearMem input, struct DecOutput* output,
                             u8* stream, u32 strm_len, u32 pic_id, void *p_user_data) {
  enum DecRet rv;
  struct Vp9DecInput vp9_input;
  struct Vp9DecOutput vp9_output;
  memset(&vp9_input, 0, sizeof(vp9_input));
  memset(&vp9_output, 0, sizeof(vp9_output));
  vp9_input.stream = (u8*)stream;
  vp9_input.stream_bus_address = input.bus_address + ((addr_t)stream - (addr_t)input.virtual_address);
  vp9_input.data_len = strm_len;
  vp9_input.buffer = (u8*)input.virtual_address;
  vp9_input.buffer_bus_address = input.bus_address;
  vp9_input.buff_len = input.size;
  vp9_input.pic_id = pic_id;
  static u32 sizes[8];
  static i32 frames_this_pts, frame_count = 0;
  u32 data_sz = vp9_input.data_len;
  u32 data_len = vp9_input.data_len;
  u32 consumed_sz = 0;
  const u8* data_start = vp9_input.stream;
  const u8* buf_end = vp9_input.buffer + vp9_input.buff_len;
  //const u8* data_end = data_start + data_sz;

  /* TODO(vmr): vp9 must not acquire the resources automatically after
   *            successful header decoding. */

  /* TODO: Is this correct place to handle superframe indexes? */
  HantroDecParseSuperframeIndex(vp9_input.stream, data_sz,
                       vp9_input.buffer, input.size,
                       sizes, &frames_this_pts);

  do {
    /* Skip over the superframe index, if present */
    if (data_sz && (DWLPrivateAreaReadByte(data_start) & 0xe0) == 0xc0) {
      const u8 marker = DWLPrivateAreaReadByte(data_start);
      const u32 frames = (marker & 0x7) + 1;
      const u32 mag = ((marker >> 3) & 0x3) + 1;
      const u32 index_sz = 2 + mag * frames;
      u8 index_value;
      if(data_start + index_sz - 1 < buf_end)
        index_value = DWLPrivateAreaReadByte(data_start + index_sz - 1);
      else
        index_value = DWLPrivateAreaReadByte(data_start + (i32)index_sz - 1 - (i32)vp9_input.buff_len);

      if (data_sz >= index_sz && index_value == marker) {
        data_start += index_sz;
        if (data_start >= buf_end)
          data_start -= vp9_input.buff_len;
        consumed_sz += index_sz;
        data_sz -= index_sz;
        if (consumed_sz < data_len)
          continue;
        else {
          frames_this_pts = 0;
          frame_count = 0;
          break;
        }
      }
    }

    /* Use the correct size for this frame, if an index is present. */
    if (frames_this_pts) {
      u32 this_sz = sizes[frame_count];

      if (data_sz < this_sz) {
        /* printf("Invalid frame size in index\n"); */
        return DEC_STRM_ERROR;
      }

      data_sz = this_sz;
      // frame_count++;
    }

    vp9_input.stream_bus_address =
      input.bus_address + (addr_t)data_start - (addr_t)input.virtual_address;
    vp9_input.stream = (u8*)data_start;
    vp9_input.data_len = data_sz;
    // Once "DEC_NO_DECODING_BUFFER" is returned, continue decoding the same stream.
    do {
      rv = Vp9DecDecode(inst, &vp9_input, &vp9_output);
      if (rv == DEC_NO_DECODING_BUFFER) {
#ifdef _WIN32
        Sleep(1);
#else
        usleep(10);
#endif
      }
    } while (rv == DEC_NO_DECODING_BUFFER);
    /* Headers decoded or error occurred */
    if (rv == DEC_HDRS_RDY || rv != DEC_PIC_DECODED) break;
    else if (frames_this_pts) frame_count++;

    data_start += data_sz;
    consumed_sz += data_sz;
    if (data_start >= buf_end)
      data_start -= vp9_input.buff_len;

    /* Account for suboptimal termination by the encoder. */
    while (consumed_sz < data_len && *data_start == 0) {
      data_start++;
      consumed_sz++;
      if (data_start >= buf_end)
        data_start -= vp9_input.buff_len;
    }

    data_sz = data_len - consumed_sz;

  } while (consumed_sz < data_len);

  /* TODO(vmr): output is complete garbage on on VP9. Fix in the code decoding
   *            the frame headers. */
  /*output->strm_curr_pos = vp9_output.strm_curr_pos;
    output->strm_curr_bus_address = vp9_output.strm_curr_bus_address;
    output->data_left = vp9_output.data_left;*/
  switch (rv) {/* Workaround */
  case DEC_HDRS_RDY:
    output->strm_curr_pos = (u8*)vp9_input.stream;
    output->strm_curr_bus_address = vp9_input.stream_bus_address;
    output->data_left = vp9_input.data_len;
    break;
#ifdef USE_EXTERNAL_BUFFER
  case DEC_WAITING_FOR_BUFFER:
    output->strm_curr_pos = (u8*)vp9_input.stream;
    output->strm_curr_bus_address = vp9_input.stream_bus_address;
    output->data_left = data_len - consumed_sz;
    break;
#endif
  default:
    if ((vp9_input.stream + vp9_input.data_len) >= buf_end) {
      output->strm_curr_pos = (u8*)(vp9_input.stream + vp9_input.data_len
                                    - vp9_input.buff_len);
      output->strm_curr_bus_address = vp9_input.stream_bus_address + vp9_input.data_len
                                      - vp9_input.buff_len;
    } else {
      output->strm_curr_pos = (u8*)(vp9_input.stream + vp9_input.data_len);
      output->strm_curr_bus_address = vp9_input.stream_bus_address + vp9_input.data_len;
    }
    output->data_left = 0;
    break;
  }
  return rv;
}
#endif
enum DecRet HantroDecVp9NextPicture(void* inst, struct DecPicturePpu* pic) {
  enum DecRet rv;
  u32 stride, stride_ch, i, bit_depth;
  struct Vp9DecPicture vpic = {0};
  
  u32 *tile_status_virtual_address=NULL;
  addr_t tile_status_bus_address=0;
  u32 tile_status_address_offset=0;
  
  rv = Vp9DecNextPicture(inst, &vpic);
	if (rv != DEC_PIC_RDY)
    return rv;
  memset(pic, 0, sizeof(struct DecPicture));
  /*sunny add*/
  pic->pictures[0].luma_table.bus_address= vpic.output_rfc_luma_bus_address;
	#ifndef NEW_MEM_ALLOC
  pic->pictures[0].luma_table.virtual_address = vpic.output_rfc_luma_base;
	#endif
  pic->pictures[0].chroma_table.bus_address= vpic.output_rfc_chroma_bus_address;
	#ifndef NEW_MEM_ALLOC
  pic->pictures[0].chroma_table.virtual_address = vpic.output_rfc_chroma_base;
	#endif
  pic->pictures[0].pic_compressed_status = vpic.use_video_compressor? 1 : 0;/*sunny add for rfc compressed status*/
  
  u32 pic_width_in_cbsy, pic_height_in_cbsy;
  u32 pic_width_in_cbsc, pic_height_in_cbsc;
  pic_width_in_cbsy = ((vpic.pictures[0].frame_width + 8 - 1)/8);
  pic_width_in_cbsy = NEXT_MULTIPLE(pic_width_in_cbsy, 16);
  pic_width_in_cbsc = ((vpic.pictures[0].frame_width + 16 - 1)/16);
  pic_width_in_cbsc = NEXT_MULTIPLE(pic_width_in_cbsc, 16);
  pic_height_in_cbsy = (vpic.pictures[0].frame_height + 8 - 1)/8;
  pic_height_in_cbsc = (vpic.pictures[0].frame_height/2 + 4 - 1)/4;
  
  u32 tbl_sizey = NEXT_MULTIPLE(pic_width_in_cbsy * pic_height_in_cbsy, 16);
  u32 tbl_sizec = NEXT_MULTIPLE(pic_width_in_cbsc * pic_height_in_cbsc, 16);
/*  
  printf("~~~in %s %d, pic_width=%d\n",__FUNCTION__,__LINE__,hpic.pictures[0].pic_width);
  printf("~~~in %s %d, pic_height=%d\n",__FUNCTION__,__LINE__,hpic.pictures[0].pic_height);  
  printf("~~~in %s %d, pic_width_in_cbsy=%d\n",__FUNCTION__,__LINE__,pic_width_in_cbsy);
  printf("~~~in %s %d, pic_width_in_cbsc=%d\n",__FUNCTION__,__LINE__,pic_width_in_cbsc);
  printf("~~~in %s %d, pic_height_in_cbsy=%d\n",__FUNCTION__,__LINE__,pic_height_in_cbsy);
  printf("~~~in %s %d, pic_height_in_cbsc=%d\n",__FUNCTION__,__LINE__,pic_height_in_cbsc);
  printf("~~~in %s %d, tbl_sizey=%d\n",__FUNCTION__,__LINE__,tbl_sizey);
  printf("~~~in %s %d, tbl_sizec=%d\n",__FUNCTION__,__LINE__,tbl_sizec);
  */
  pic->pictures[0].luma_table.size = tbl_sizey;
  pic->pictures[0].chroma_table.size = tbl_sizec;

  for (i = 0; i < DEC_MAX_OUT_COUNT; i++) {
/*
		if (!vpic.pp_enabled) {
      if (vpic.pictures[0].output_format == DEC_OUT_FRM_TILED_4X4) {
        bit_depth = (vpic.bit_depth_luma == 8 && vpic.bit_depth_chroma == 8) ? 8 : 10;
        stride = vpic.pictures[0].frame_width * bit_depth / 8;
      } else {
        stride = vpic.pictures[0].pic_stride;
      } 
				stride_ch = stride;
    } else */

		if ( vpic.pictures[i].pixel_format == DEC_OUT_PIXEL_RFC) {
			/* Compressed tiled data should be output without being converted to 16 bits.
			* It's treated as a special picture to output. */
			u32 bit_depth = (vpic.bit_depth_luma == 8 &&
			               vpic.bit_depth_luma == 8) ? 8 : 10;
			stride = vpic.pictures[i].frame_width * 4 * bit_depth / 8;
			stride_ch = stride;
		}
		else
		{
      stride = vpic.pictures[i].pic_stride;
      stride_ch = vpic.pictures[i].pic_stride_ch;
    }
		#ifndef NEW_MEM_ALLOC
    pic->pictures[i].luma.virtual_address = (u32*)vpic.pictures[i].output_luma_base;
		#endif
    pic->pictures[i].luma.bus_address = vpic.pictures[i].output_luma_bus_address;
    if (/*vpic.pp_enabled &&*/ (vpic.pictures[i].output_format == DEC_OUT_FRM_TILED_4X4)) {
#if 0
      pic->pictures[i].luma.size = stride * vpic.pictures[i].frame_height / 4;
	  /*sunny correct*/
	  if((vpic.pictures[i].frame_height / 4)&1 == 1)
	  	pic->pictures[i].chroma.size = stride_ch * (vpic.pictures[i].frame_height/4+1) / 2;
	  else
	  	pic->pictures[i].chroma.size = stride_ch * vpic.pictures[i].frame_height / 8;
#else
      pic->pictures[i].luma.size = stride * NEXT_MULTIPLE(vpic.pictures[i].frame_height, 4) / 4;
      pic->pictures[i].chroma.size = stride_ch * NEXT_MULTIPLE(vpic.pictures[i].frame_height/2, 4)/4;
#endif
   } else {
      pic->pictures[i].luma.size = stride * vpic.pictures[i].frame_height;
      pic->pictures[i].chroma.size = stride_ch * vpic.pictures[i].frame_height;
   }
   #ifndef NEW_MEM_ALLOC
    pic->pictures[i].chroma.virtual_address = (u32*)vpic.pictures[i].output_chroma_base;
	 #endif
    pic->pictures[i].chroma.bus_address = vpic.pictures[i].output_chroma_bus_address;
    /*sunny pic->pictures[i].chroma.size = pic->pictures[i].luma.size / 2;*/
	pic->pictures[i].chroma.size = pic->pictures[i].chroma.size;
	
    pic->pictures[i].pic_width = vpic.pictures[i].frame_width;
    pic->pictures[i].pic_height = vpic.pictures[i].frame_height;
    pic->pictures[i].pic_stride = vpic.pictures[i].pic_stride;
    pic->pictures[i].pic_stride_ch = vpic.pictures[i].pic_stride_ch;

    /* TODO(vmr): find out for real also if it is B frame */
    pic->pictures[i].picture_info.pic_coding_type =
      vpic.is_intra_frame ? DEC_PIC_TYPE_I : DEC_PIC_TYPE_P;
    pic->pictures[i].sequence_info.pic_width = vpic.pictures[i].frame_width;
    pic->pictures[i].sequence_info.pic_height = vpic.pictures[i].frame_height;
    pic->pictures[i].sequence_info.sar_width = 1;
    pic->pictures[i].sequence_info.sar_height = 1;
    pic->pictures[i].sequence_info.crop_params.crop_left_offset = 0;
    pic->pictures[i].sequence_info.crop_params.crop_out_width = vpic.coded_width;
    pic->pictures[i].sequence_info.crop_params.crop_top_offset = 0;
    pic->pictures[i].sequence_info.crop_params.crop_out_height = vpic.coded_height;
    pic->pictures[i].sequence_info.video_range = DEC_VIDEO_RANGE_NORMAL;
    pic->pictures[i].sequence_info.matrix_coefficients = 0;
    pic->pictures[i].sequence_info.is_mono_chrome = 0;
    pic->pictures[i].sequence_info.is_interlaced = 0;
    pic->pictures[i].sequence_info.num_of_ref_frames = pic->pictures[i].sequence_info.num_of_ref_frames;
    pic->pictures[i].picture_info.format = vpic.pictures[i].output_format;
    pic->pictures[i].picture_info.pixel_format = vpic.pictures[i].pixel_format;
    pic->pictures[i].picture_info.pic_id = vpic.pic_id;
    pic->pictures[i].picture_info.decode_id = vpic.decode_id;
    pic->pictures[i].picture_info.cycles_per_mb = vpic.cycles_per_mb;
    pic->pictures[i].sequence_info.bit_depth_luma = vpic.bit_depth_luma;
    pic->pictures[i].sequence_info.bit_depth_chroma = vpic.bit_depth_chroma;
    pic->pictures[i].sequence_info.pic_stride = vpic.pictures[i].pic_stride;
    pic->pictures[i].sequence_info.pic_stride_ch = vpic.pictures[i].pic_stride_ch;
    pic->pictures[i].pp_enabled = vpic.pp_enabled;

	if((vpic.multi_tile_cols == 0)&&(i>0)&&(pic->pictures[i].luma.size != 0))/*mark the dpb total buffer base address*/
	{
		if(tile_status_bus_address == 0)
		{
			#ifndef NEW_MEM_ALLOC
			tile_status_virtual_address = pic->pictures[i].luma.virtual_address;
			#endif
			tile_status_bus_address = pic->pictures[i].luma.bus_address;
		}
//		printf("--in %s,%d,found pp %d  stride = 0x%x ,stride_ch= 0x%x ,pic_height=%d, luma.size=0x%x,chroma.size=0x%x\n",__FUNCTION__,__LINE__,i, stride  ,stride_ch ,vpic.pictures[i].frame_height,pic->pictures[i].luma.size,pic->pictures[i].chroma.size);

		tile_status_address_offset += pic->pictures[i].luma.size + PP_LUMA_BUF_RES;
		tile_status_address_offset += pic->pictures[i].chroma.size + PP_CHROMA_BUF_RES;
		/*if((hpic.pictures[i].pic_height/4)&1 == 1)
			tile_status_address_offset += stride_ch/2;*/
	}

  }
  for (i = 0; i < DEC_MAX_OUT_COUNT; i++) {
  	if((vpic.multi_tile_cols == 0)&&(i>0)&&(pic->pictures[i].luma.size != 0)/*&&(pic->pictures[i].luma_table.virtual_address == NULL)*/)
	{
		#ifndef NEW_MEM_ALLOC
		pic->pictures[i].luma_table.virtual_address = (u32*)((addr_t)tile_status_virtual_address + tile_status_address_offset + DEC400_PPn_Y_TABLE_OFFSET(i-1));
		#endif
		pic->pictures[i].luma_table.bus_address= tile_status_bus_address + tile_status_address_offset+ DEC400_PPn_Y_TABLE_OFFSET(i-1);
		pic->pictures[i].luma_table.size = NEXT_MULTIPLE(pic->pictures[i].luma.size/1024/4 +((pic->pictures[i].luma.size%4096)?1:0), 16);

		#ifndef NEW_MEM_ALLOC
		pic->pictures[i].chroma_table.virtual_address = (u32*)((addr_t)tile_status_virtual_address + tile_status_address_offset + DEC400_PPn_UV_TABLE_OFFSET(i-1));
		#endif
		pic->pictures[i].chroma_table.bus_address= tile_status_bus_address + tile_status_address_offset+ DEC400_PPn_UV_TABLE_OFFSET(i-1);
		pic->pictures[i].chroma_table.size = NEXT_MULTIPLE(pic->pictures[i].chroma.size/1024/4 +((pic->pictures[i].chroma.size%4096)?1:0), 16);

#ifdef SUPPORT_DEC400		
		pic->pictures[i].pic_compressed_status = vpic.pictures[i].pic_compressed_status;
#else
		pic->pictures[i].pic_compressed_status = 0;
#endif
#if 0
		printf("--in %s,%d,tile_status_address_offset = 0x%x ,tile_status_bus_address=0x%x,tile_status_virtual_address=%p!!!!!!!!!!!!!!!!!\n",__FUNCTION__,__LINE__,tile_status_address_offset,tile_status_bus_address,tile_status_virtual_address);
		printf("--in %s,%d,setting pic->pictures[%d].luma_table.virtual_address = %p !!!!!!!!!!!!!!!!!\n",__FUNCTION__,__LINE__,i,pic->pictures[i].luma_table.virtual_address);
		printf("--in %s,%d,setting pic->pictures[%d].luma_table.bus_address = 0x%x !!!!!!!!!!!!!!!!!\n",__FUNCTION__,__LINE__,i,pic->pictures[i].luma_table.bus_address);
		printf("--in %s,%d,setting pic->pictures[%d].luma_table.size = 0x%x(%d) !!!!!!!!!!!!!!!!!\n",__FUNCTION__,__LINE__,i,pic->pictures[i].luma_table.size,pic->pictures[i].luma_table.size);
#endif
	}
  	}
  return rv;
}


enum DecRet HantroDecVp9PictureConsumed(void* inst, struct DecPicturePpu pic) {
  struct Vp9DecPicture vpic;
  u32 i;
  memset(&vpic, 0, sizeof(struct Vp9DecPicture));
  /* TODO chroma base needed? */
  for (i = 0; i < DEC_MAX_OUT_COUNT; i++) {
		#ifndef NEW_MEM_ALLOC
    vpic.pictures[i].output_luma_base = pic.pictures[i].luma.virtual_address;
		#endif
    vpic.pictures[i].output_luma_bus_address = pic.pictures[i].luma.bus_address;
  }
  vpic.pp_enabled = pic.pictures[0].pp_enabled;
  vpic.is_intra_frame = pic.pictures[0].picture_info.pic_coding_type == DEC_PIC_TYPE_I;
  return Vp9DecPictureConsumed(inst, &vpic);
}

enum DecRet HantroDecVp9EndOfStream(void* inst) {
  return Vp9DecEndOfStream(inst);
}

#ifdef USE_EXTERNAL_BUFFER
enum DecRet HantroDecVp9GetBufferInfo(void *inst, struct DecBufferInfo *buf_info) {
  struct Vp9DecBufferInfo vbuf;
  enum DecRet rv;

  rv = Vp9DecGetBufferInfo(inst, &vbuf);
  if (rv == DEC_OK) {
    memset(buf_info, 0, sizeof(*buf_info));
  } else {
    buf_info->buf_to_free = vbuf.buf_to_free;
    buf_info->next_buf_size = vbuf.next_buf_size;
    buf_info->buf_num = vbuf.buf_num;
#ifdef ASIC_TRACE_SUPPORT
    buf_info->is_frame_buffer = vbuf.is_frame_buffer;
#endif
  }
  return rv;
}

enum DecRet HantroDecVp9AddBuffer(void *inst, struct DWLLinearMem *buf) {
  return Vp9DecAddBuffer(inst, buf);
}
#endif
void HantroDecVp9Release(void* inst) {
  Vp9DecRelease(inst);
}

