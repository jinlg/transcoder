#ifndef __HANTRO_DEC_DECAPI_H__
#define __HANTRO_DEC_DECAPI_H__

#include "avcodec.h"
#include "decapi.h"

#include "decapi_trace.h"
#include "fifo.h"
#include "sw_util.h"
#include "version.h"
#include "dwl.h"



struct DecSwHwBuild DecGetBuild(const void* dwl);

#define HANTRO_DEC_SW_BUILD_MAJOR 7
#define HANTRO_DEC_SW_BUILD_MINOR 3

#define HANTRO_DEC_SW_BUILD \
  ((HANTRO_DEC_SW_BUILD_MAJOR << 16) + HANTRO_DEC_SW_BUILD_MINOR)




struct DecSwHwBuild HantroDecGetBuild(const void* dwl);
int HantroDecParsePPUCfg(AVCodecContext *avctx,PpUnitConfig *ppu_cfg);
int HantroDecModifyConfigBySeqeuenceInfo(AVCodecContext *avctx);
void HantroDecDisableAllPPShaper(struct DecConfig *config);


/* Hevc codec wrappers. */
enum DecRet HantroDecHevcInit(const void** inst, struct DecConfig config,
                     const void *dwl);
enum DecRet HantroDecHevcGetInfo(void* inst, struct DecSequenceInfo* info);
enum DecRet HantroDecHevcSetInfo(void* inst, struct DecConfig config, struct DecSequenceInfo* Info);
//enum DecRet HantroDecHevcDecode(void* inst, struct DWLLinearMem input, struct DecOutput* output,
//                              u8* stream, u32 strm_len, u32 pic_id, void *p_user_data);
enum DecRet HantroDecHevcNextPicture(void* inst, struct DecPicturePpu* pic);
enum DecRet HantroDecHevcPictureConsumed(void* inst, struct DecPicturePpu pic);
enum DecRet HantroDecHevcEndOfStream(void* inst);
#ifdef USE_EXTERNAL_BUFFER
enum DecRet HantroDecHevcGetBufferInfo(void *inst, struct DecBufferInfo *buf_info);
enum DecRet HantroDecHevcAddBuffer(void *inst, struct DWLLinearMem *buf);

void HantroDecHevcRelease(void* inst);
#endif /* ENABLE_HEVC_SUPPORT */

/* H264 codec wrappers. */
enum DecRet HantroDecH264Init(const void** inst, struct DecConfig config,
                     const void *dwl);
enum DecRet HantroDecH264GetInfo(void* inst, struct DecSequenceInfo* info);
enum DecRet HantroDecH264SetInfo(void* inst, struct DecConfig config, struct DecSequenceInfo* Info);
//enum DecRet HantroDecH264Decode(void* inst, struct DWLLinearMem input, struct DecOutput* output,
//                       u8* stream, u32 strm_len,u32 pic_id, void *p_user_data);
enum DecRet HantroDecH264NextPicture(void* inst, struct DecPicturePpu* pic);
enum DecRet HantroDecH264PictureConsumed(void* inst, struct DecPicturePpu pic);
enum DecRet HantroDecH264EndOfStream(void* inst);
#ifdef USE_EXTERNAL_BUFFER
enum DecRet HantroDecH264GetBufferInfo(void *inst, struct DecBufferInfo *buf_info);
enum DecRet HantroDecH264AddBuffer(void *inst, struct DWLLinearMem *buf);
#endif
void HantroDecH264Release(void* inst);

/* VP9 codec wrappers. */
enum DecRet HantroDecVp9Init(const void** inst, struct DecConfig config,
                    const void *dwl);
enum DecRet HantroDecVp9GetInfo(void* inst, struct DecSequenceInfo* info);
enum DecRet HantroDecVp9SetInfo(void* inst, struct DecConfig config, struct DecSequenceInfo* Info);
void HantroDecParseSuperframeIndex(const u8* data, size_t data_sz,
                                 const u8* buf, size_t buf_sz,
                                 u32 sizes[8], i32* count);

//enum DecRet HantroDecVp9Decode(void* inst, struct DWLLinearMem input, struct DecOutput* output,
//                      u8* stream, u32 strm_len,u32 pic_id, void *p_user_data);
enum DecRet HantroDecVp9NextPicture(void* inst, struct DecPicturePpu* pic);
enum DecRet HantroDecVp9PictureConsumed(void* inst, struct DecPicturePpu pic);
enum DecRet HantroDecVp9EndOfStream(void* inst);
#ifdef USE_EXTERNAL_BUFFER
enum DecRet HantroDecVp9GetBufferInfo(void *inst, struct DecBufferInfo *buf_info);
enum DecRet HantroDecVp9AddBuffer(void *inst, struct DWLLinearMem *buf);
#endif
void HantroDecVp9Release(void* inst);


 

#endif
