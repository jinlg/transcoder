
#ifndef AVCODEC_HANTRO_HEVCDEC_H
#define AVCODEC_HANTRO_HEVCDEC_H

#include "libavutil/buffer.h"
#include "libavutil/intreadwrite.h"
#include "libavutil/thread.h"

#include "cabac.h"
#include "error_resilience.h"
#include "internal.h"
#include "mpegutils.h"
#include "parser.h"
#include "qpeldsp.h"
#include "rectangle.h"
#include "videodsp.h"

#include "hevcdecapi.h"
#include "dwl.h"
#include "dwlthread.h"

#include "hevc_container.h"
#include "regdrv.h"
#include "deccfg.h"
#include "hantro_dec_tb_defs.h"
#include "hantro_dec_common.h"


//#include "hevc_parse.h"


/* Low latency : Frame Mode by default */
#if 0 
#define LOW_LATENCY_FRAME_MODE
#define LOW_LATENCY_PACKET_SIZE 256

#define BUFFER_ALIGN_MASK 0xF
#endif
/*
static void ResolvePpParamsOverlap(struct TestParams* params,
                           struct TBPpUnitParams *pp_units_params,
                           u32 standalone);
*/
//static void ReleaseExtBuffers(AVCodecContext *avctx);


/**
 * Submit a slice for decoding.
 *
 * Parse the slice header, starting a new field/frame if necessary. If any
 * slices are queued for the previous field, they are decoded.
 */

enum DecRet HevcDecAddBuffer(HevcDecInst dec_inst,
                            struct DWLLinearMem *info);


static enum DecRet HevcDecode(void* inst, struct DWLLinearMem input, struct DecOutput* output,u8* stream, u32 strm_len, u32 pic_id);


static enum DecRet fbHevcInit(HantroDecContext *fb_dec_ctx, struct DecConfig config,
                      const void *dwl);

static u32 FindExtBufferIndex(AVCodecContext *avctx,u32 *addr);

static  u32 FindEmptyIndex(AVCodecContext *avctx);


#endif /* AVCODEC_H264DEC_H */
