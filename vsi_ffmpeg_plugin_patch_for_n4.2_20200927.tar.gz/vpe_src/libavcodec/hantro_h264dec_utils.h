#include "hantro_h264dec.h"
#include "hantro_dec_common.h"

enum DecRet H264NextPicture(void* inst, struct DecPicturePpu* pic);

enum DecRet H264PictureConsumedNoDWL(void* inst, struct DecPicturePpu pic);
													 
//void fb_h264_release_ext_buffers(HantroDecContext *fb_dec_ctx);
void fb_h264_handle_fatal_error() ;
//void ReleaseExtBuffers(AVCodecContext *avctx);
