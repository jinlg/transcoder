
#include "libavutil/avassert.h"
#include "libavutil/common.h"
#include "libavutil/internal.h"
#include "libavutil/opt.h"
#include "libavutil/pixfmt.h"
#include "libavutil/imgutils.h"

#include "hantro_h26xenc.h"
#include "hantro_enc.h"

static av_cold int hantro_encode_h26x_init(AVCodecContext *avctx)
{
    int ret = 0;
	
    av_log(avctx, AV_LOG_TRACE, "%s\n", __FUNCTION__);

    ret = hantro_encode_init(avctx);
    return ret;
}

static int hantro_encode_h26x_encode_frame(AVCodecContext *avctx, AVPacket *pkt,
                        const AVFrame *pict, int *got_packet)
{
    HANTROH26xEncContext *ctx = (HANTROH26xEncContext *)avctx->priv_data;
    struct test_bench * tb = (struct test_bench *)&ctx->tb;

    int ret = 0;
    int flushRet = 0;
    int streamSize = 0;

    ENC_TB_DEBUG_PRINT("pict = %p\n", pict);

    *got_packet = 0;

#if 0    
    ret = hantro_encode_open(avctx, pict);
    if (ret != 0) {
        av_log(NULL, AV_LOG_ERROR, "hantro_encode_open error. ret = %d\n", ret);
        return ret;
    } else if (ctx->EncoderIsOpen == HANTRO_FALSE) {
        av_log(NULL, AV_LOG_DEBUG, "the first frame is NULL, continue...\n");
        return 0;
    }
#endif

    if (pict == NULL) {
again:
        switch (ctx->flushState) {
        case HANTRO_FLUSH_IDLE:
            ctx->TransFlushPic = HANTRO_FALSE;
            flushRet = hantro_encode_encode(avctx, pkt, pict, (int *)&streamSize);
            ENC_TB_DEBUG_PRINT("+++ hantro_encode_encode ret = %d\n", flushRet);
            ENC_TB_DEBUG_PRINT("+++ ctx->TransFlushPic = %d\n", ctx->TransFlushPic);
     
            if (flushRet != -1) {
                /* should set got_packet to 1 to make sure encoder continue */
                ENC_TB_DEBUG_PRINT("flushRet = %d\n", flushRet);
                *got_packet = 1;
                ret = 0;
            } else {
                /* need error process */
                ret = -1;
            }

            if (ctx->TransFlushPic == HANTRO_TRUE) {
                ENC_TB_DEBUG_PRINT("to HANTRO_FLUSH_PREPARE\n");
                ctx->flushState = HANTRO_FLUSH_PREPARE;
            }
			
            break;

		case HANTRO_FLUSH_PREPARE:
            ENC_TB_DEBUG_PRINT("HANTRO_FLUSH_PREPARE\n");
            hantro_trans_flush_set(avctx);
            *got_packet = 1;
            ret = 0;
            break;

		case HANTRO_FLUSH_TRANSPIC: /* flush data in dec fifo */
            flushRet = hantro_encode_encode(avctx, pkt, pict, (int *)&streamSize);
            ENC_TB_DEBUG_PRINT("hantro_encode_encode ret = %d\n", flushRet);

            if (flushRet != -1) {
                *got_packet = 1;
                ret = 0;
            } else {
                /* need error process */
                ret = -1;
            }

            break;	

        case HANTRO_FLUSH_ENCDATA:
			ret = hantro_encode_flush(avctx, (int *)&streamSize, pkt, got_packet);
            ENC_TB_DEBUG_PRINT("ret = %d\n", ret);
            if (ret < 0) {
                av_log(NULL, AV_LOG_ERROR, "hantro_encode_flush error. ret = %d\n", ret);
      	        //return ret;
            } else if (ctx->flushState == HANTRO_FLUSH_FINISH) {
                ENC_TB_DEBUG_PRINT("\n");
                goto again;
            }
            break;

        case HANTRO_FLUSH_FINISH:
            ret = hantro_encode_end(avctx, (int *)&streamSize, pkt, got_packet);
            ENC_TB_DEBUG_PRINT("ret = %d\n", ret);
            if (ret != 0) {
                av_log(NULL, AV_LOG_ERROR, "hantro_encode_end error. ret = %d\n", ret);
      	        return ret;
            }
            //av_grow_packet(pkt, ctx->outPkt->size);
            //memcpy(pkt->data+pkt->size, ctx->outPkt->data, ctx->outPkt->size);
            av_packet_unref(ctx->outPkt);
            *got_packet = 0;
			break;
        }

        if (ret == 0 && pkt->size == 0 && *got_packet == 1)
            goto again;
            
        ENC_TB_DEBUG_PRINT("got_packet %d size %d\n", *got_packet, (*got_packet)? pkt->size : 0);
        if (*got_packet)
        ENC_TB_DEBUG_PRINT("pts %ld, dts %ld, duration %ld\n", pkt->pts, pkt->dts, pkt->duration);

        return ret;

  	} else {

	    //av_log(avctx, AV_LOG_TRACE, "+++ data[0]=%p,data[1]=%p  buf[0]=%p,buf[1]=%p\n", pict->data[0], pict->data[1], pict->buf[0], pict->buf[1]);
        //av_log(avctx, AV_LOG_DEBUG, "frame ref count %d for %p\n", av_buffer_get_ref_count(pict->buf[0]), pict->buf[0]->data);

        ENC_TB_DEBUG_PRINT("pict->key_frame = %d\n", pict->key_frame);

#if 0
        /* add for IDR */
        ret = hantro_receive_pic(avctx, pict);
        ENC_TB_DEBUG_PRINT("\n");

        if (ret != 0) {
          av_log(avctx, AV_LOG_ERROR, "hantro_receive_pic error\n");
          return -1;
        }
#endif

        if ((ctx->injectFrameCnt >= 1) && (ctx->injectFrameCnt <= (ctx->gopLength + 1)) && ctx->forced_idr) {
          ctx->injectFrameCnt++;
          *got_packet = 0; //1; //???
          return 0;
        }

        ENC_TB_DEBUG_PRINT("pict->key_frame = %d\n", pict->key_frame);

#if 0 /*do in codec init*/
        if (ctx->EncoderIsStart == HANTRO_FALSE) {  
          ctx->EncoderIsStart = HANTRO_TRUE;
          ret = hantro_encode_start(avctx, pkt, (int *)&streamSize);
          if (ret != 0) {
            av_log(NULL, AV_LOG_ERROR, "hantro_encode_start error. ret = %d\n", ret);
            return ret;
      	  } else {
            //*got_packet = 1;
            ctx->injectFrameCnt = 1; /* add for IDR */

            if (ctx->outPkt->size) {
                av_log(avctx, AV_LOG_ERROR, "%s(%d)\n", __FUNCTION__,__LINE__);
                avctx->extradata = av_malloc(ctx->outPkt->size);
                if (avctx->extradata == NULL) {
                    return AVERROR(ENOMEM);
                }
                memcpy(avctx->extradata, ctx->outPkt->data, ctx->outPkt->size);
                avctx->extradata_size = ctx->outPkt->size;
                av_packet_unref(ctx->outPkt);
            }
            av_log(avctx, AV_LOG_TRACE, "%s(%d) got_packet %d size %d\n", __FUNCTION__,__LINE__, *got_packet, (*got_packet)? pkt->size : 0);
            if (*got_packet)
            av_log(avctx, AV_LOG_TRACE, "%s(%d) pts %ld, dts %ld, duration %ld\n", __FUNCTION__,__LINE__, pkt->pts, pkt->dts, pkt->duration);

            return 0;
      	  }
        }
#endif

        ret = hantro_encode_encode(avctx, pkt, pict, (int *)&streamSize);
        if (ret == VCENC_FRAME_READY) {
          *got_packet = 1;
        } else if ((ret == 0)||(ret == VCENC_FRAME_ENQUEUE)) {
          *got_packet = 0;
        } else {
          /* need error process */
          return -1;
        }

        ENC_TB_DEBUG_PRINT("\n");

        //av_buffer_unref(&pict->buf[0]);
        ENC_TB_DEBUG_PRINT("pict->buf[0] = %p\n", pict->buf[0]);
        //av_log(avctx, AV_LOG_DEBUG, "frame ref count %d for %p\n", av_buffer_get_ref_count(pict->buf[0]), pict->buf[0]->data);

	  }
    ENC_TB_DEBUG_PRINT("got_packet %d size %d\n", *got_packet, (*got_packet)? pkt->size : 0);
    if (*got_packet)
    ENC_TB_DEBUG_PRINT("pts %ld, dts %ld, duration %ld\n", pkt->pts, pkt->dts, pkt->duration);

    return 0;
}

static av_cold int hantro_encode_h26x_close(AVCodecContext *avctx)
{
    av_log(avctx, AV_LOG_TRACE, "%s\n", __FUNCTION__);

  	hantro_encode_uninit(avctx);

    if (avctx->extradata)
        av_freep(&avctx->extradata);

    return 0;
}

static int hantro_encode_send_frame(AVCodecContext *avctx, const AVFrame *frame)
{
  HANTROH26xEncContext *ctx = (HANTROH26xEncContext *)avctx->priv_data;
  struct test_bench * tb = (struct test_bench *)&ctx->tb;

  int ret = 0;
  int streamSize = 0;

  ENC_TB_DEBUG_PRINT("enter...\n");

  //ctx->frame_rdy_cnt++;
  //av_log(avctx, AV_LOG_DEBUG, "%s call num is %d\n", __FUNCTION__, ctx->frame_rdy_cnt);

  if (frame) {

    while (1) {
      ret = hantro_receive_pic(avctx, frame);
      if (ret == VCENC_OUTPUT_BUFFER_OVERFLOW) {
        usleep(100);
        continue;
      } else if (ret == 0) {
#if 0
        if ((ctx->injectFrameCnt >= 1) && (ctx->injectFrameCnt <= (ctx->gopLength + 1)) && ctx->forced_idr) {
          ctx->injectFrameCnt++;
        }
#endif
        if (ctx->forced_idr) {
          pthread_mutex_lock(&ctx->rcv_packet_mutex);
          ctx->injectFrameCnt++;
          pthread_mutex_unlock(&ctx->rcv_packet_mutex);
        }

        break;
      } else {
        av_log(avctx, AV_LOG_ERROR, "hantro_receive_pic error, ret = %d\n", ret);

        if (ctx->forced_idr) {
          pthread_mutex_lock(&ctx->rcv_packet_mutex);
          ctx->injectFrameCnt = ctx->holdBufNum + 1; //ctx->gopLength + 2;
          pthread_mutex_unlock(&ctx->rcv_packet_mutex);
        }

        ctx->EncProcessTerm = HANTRO_TRUE;
        SendEosToEnc(ctx->hantro_encoder);
        return -1;
      }
    }

  } else {
    ENC_TB_DEBUG_PRINT("need flush, now ctx->TransFlushPic = %d\n", ctx->TransFlushPic);
    if (ctx->forced_idr) {
      pthread_mutex_lock(&ctx->rcv_packet_mutex);
      ctx->injectFrameCnt = ctx->holdBufNum + 1; //ctx->gopLength + 2;
      pthread_mutex_unlock(&ctx->rcv_packet_mutex);
    }
		
    ctx->EncoderFlushPic = HANTRO_TRUE;
  }

  return 0;
}

static int hantro_encode_receive_packet(AVCodecContext *avctx, AVPacket *pkt)
{
  HANTROH26xEncContext *ctx = (HANTROH26xEncContext *)avctx->priv_data;
  struct test_bench * tb = (struct test_bench *)&ctx->tb;
  int ret = 0;
  int streamSize = 0;
  int *got_packet = 0;
  int *flushRet = NULL;
  
  ENC_TB_DEBUG_PRINT("enter...\n");

  //ctx->output_rdy_cnt++;
  //av_log(avctx, AV_LOG_DEBUG, "%s call num is %d\n", __FUNCTION__, ctx->output_rdy_cnt);
   
  ret = hantro_packet_rcv(avctx, pkt);

      //////////////////////////////////////////////////
	  /* printf pkt data */
      #if 0
      if (ret == 0) {
        int kk = 0;
        //uint8_t *pp = (uint8_t *)tb->outbufMem[0]->rc_virtualAddress;
        uint8_t *pp = pkt->data;
        
        av_log(NULL, AV_LOG_INFO, "\nin hantro_encode_receive_packet\n");
        for (kk = 0; kk < pkt->size; kk++) {
        av_log(NULL, AV_LOG_INFO, "0x%x ", *(pp+kk));
        if (kk%16==15)
          av_log(NULL, AV_LOG_INFO, "\n");
        }
        av_log(NULL, AV_LOG_INFO, "\n");
      }
      #endif  
      //////////////////////////////////////////////////

  /* it occurs error when ret is -1 */
  if (ret == -1) {
    av_log(avctx, AV_LOG_DEBUG, "%s\n", __FUNCTION__);
    ctx->EncProcessTerm = HANTRO_TRUE;
    SendEosToEnc(ctx->hantro_encoder);
  }
  
  return ret;

}

#include "hantro_enc_options.c"

static const AVClass hantro_encode_h264_class = {
    .class_name = "h264e_hantro",
    .item_name  = av_default_item_name,
    .option     = hantro_encode_options,
    .version    = LIBAVUTIL_VERSION_INT,
};

static const AVClass hantro_encode_hevc_class = {
    .class_name = "hevce_hantro",
    .item_name  = av_default_item_name,
    .option     = hantro_encode_options,
    .version    = LIBAVUTIL_VERSION_INT,
};

AVCodec ff_h264_hantro_encoder = {
    .name           = "h264enc_hantro",
    .long_name      = NULL_IF_CONFIG_SMALL("H264 (HANTRO VC8000E)"),
    .type           = AVMEDIA_TYPE_VIDEO,
    .id             = AV_CODEC_ID_H264,
    .priv_data_size = sizeof(HANTROH26xEncContext),
    .init           = &hantro_encode_h26x_init,
    .send_frame     = &hantro_encode_send_frame,
    .receive_packet = &hantro_encode_receive_packet,
    //.encode2        = &hantro_encode_h26x_encode_frame,
    .close          = &hantro_encode_h26x_close,
    .priv_class     = &hantro_encode_h264_class,
    .capabilities   = AV_CODEC_CAP_DELAY | AV_CODEC_CAP_HARDWARE,
    .defaults       = hantro_encode_h264_defaults,
    .pix_fmts       = (const enum AVPixelFormat[]) {
        AV_PIX_FMT_HANTRO,
        AV_PIX_FMT_YUV420P,
        AV_PIX_FMT_NONE
  	},
    .wrapper_name   = "hantro",
};

AVCodec ff_hevc_hantro_encoder = {
    .name           = "hevcenc_hantro",
    .long_name      = NULL_IF_CONFIG_SMALL("HEVC (HANTRO VC8000E)"),
    .type           = AVMEDIA_TYPE_VIDEO,
    .id             = AV_CODEC_ID_HEVC,
    .priv_data_size = sizeof(HANTROH26xEncContext),
    .init           = &hantro_encode_h26x_init,
    .send_frame     = &hantro_encode_send_frame,
    .receive_packet = &hantro_encode_receive_packet,
    //.encode2        = &hantro_encode_h26x_encode_frame,
    .close          = &hantro_encode_h26x_close,
    .priv_class     = &hantro_encode_hevc_class,
    .capabilities   = AV_CODEC_CAP_DELAY | AV_CODEC_CAP_HARDWARE,
    .defaults       = hantro_encode_hevc_defaults,
    .pix_fmts       = (const enum AVPixelFormat[]) {
        AV_PIX_FMT_HANTRO,
        AV_PIX_FMT_YUV420P,
        AV_PIX_FMT_NONE
  	},
    .wrapper_name   = "hantro",
};



