#include "hantro_h26xenc.h"
#include <float.h>
#include <limits.h>
#include <stdlib.h>

//#define OFFSET(x) offsetof(HANTROH26xEncContext, x)
#define OFFSET(x) offsetof(HANTROH26xEncContext, options) + offsetof(HANTROH26xEncOptions, x)
#define OFFSETOPT(x) offsetof(HANTROH26xEncContext, x)

#define FLAGS (AV_OPT_FLAG_ENCODING_PARAM | AV_OPT_FLAG_VIDEO_PARAM | AV_OPT_FLAG_EXPORT)

static const AVOption hantro_encode_options[] = {
#if 0
    { "device",    "point to hardware device node.", OFFSET(device), AV_OPT_TYPE_STRING, { .str = "/dev/transcoder0"}, .flags = FLAGS},
	{ "priority",  "transcoder priority: LIVE/VOD.", OFFSET(priority),  AV_OPT_TYPE_INT, { .i64 = 1},  0, 1, FLAGS},
#endif
    //{ "bitPerSecond",    "Set bitRate [10000..levelMax]",  OFFSET(bitPerSecond),    AV_OPT_TYPE_INT, { .i64 = DEFAULT}, -255,  INT_MAX, FLAGS},
    //{ "inputRateNumer",  "Set input pic rate number",      OFFSET(inputRateNumer),  AV_OPT_TYPE_INT, { .i64 = 30},      0x01,  0xFFFFF, FLAGS},
    //{ "inputRateDenom",  "Set input pic rate denom",       OFFSET(inputRateDenom),  AV_OPT_TYPE_INT, { .i64 = 1},       0x01,  0xFFFFF, FLAGS},
    //{ "outputRateNumer", "Set output pic rate number",     OFFSET(outputRateNumer), AV_OPT_TYPE_INT, { .i64 = DEFAULT}, -255,  0xFFFFF, FLAGS},  
    //{ "outputRateDenom", "Set output pic rate denom",      OFFSET(outputRateDenom), AV_OPT_TYPE_INT, { .i64 = DEFAULT}, -255,  0xFFFFF, FLAGS},  
#if 0
    { "intraPicRate",    "Intra picture rate in frames",   OFFSET(intraPicRate),    AV_OPT_TYPE_INT, { .i64 = 0},          0,       60, FLAGS},
    { "bitrateWindow",   "Bitrate window length in frames [1..300]",  OFFSET(bitrateWindow), AV_OPT_TYPE_INT, { .i64 = DEFAULT}, -255, 300, FLAGS},
    { "intraQpDelta",    "Set intraQpDelta. (default [26], -1..51)",  OFFSET(intraQpDelta),  AV_OPT_TYPE_INT, { .i64 = DEFAULT}, -255, 51, FLAGS},  
    { "qpHdr",           "Set qpHdr default [-1]",         OFFSET(qpHdr),       AV_OPT_TYPE_INT, { .i64 = DEFAULT}, -255, 255, FLAGS},
    { "qpMin",           "Set qpMin (default [0], 0..51)", OFFSET(qpMin),       AV_OPT_TYPE_INT, { .i64 = DEFAULT}, -255, 51, FLAGS},
    { "qpMax",           "Set qpMax (default [51], 0..51)",OFFSET(qpMax),       AV_OPT_TYPE_INT, { .i64 = DEFAULT}, -255, 51, FLAGS},
    { "fixedIntraQp",    "Fixed Intra QP, 0 = disabled. (default [0], 0..51)", OFFSET(fixedIntraQp),       AV_OPT_TYPE_INT, { .i64 = 0}, 0, 51, FLAGS},
    { "picSkip",         "Enable picture skip rate control", OFFSET(picSkip),       AV_OPT_TYPE_INT, { .i64 = 0}, 0, 1, FLAGS},

    //{ "profile",         "Set encode profile. HEVC:0-2; H264:9-12",   OFFSET(profile),     AV_OPT_TYPE_INT, { .i64 = DEFAULT},  -255, 12,  FLAGS},
    //{ "level",           "Set encode level",                          OFFSET(level),       AV_OPT_TYPE_INT, { .i64 = DEFAULT},  -255, 153, FLAGS},
    { "tier",            "Set tier(default [0], 0..1)",               OFFSET(tier),        AV_OPT_TYPE_INT, { .i64 = DEFAULT},  -255,  1, FLAGS},
    { "byteStream",      "Set stream byte",                           OFFSET(byteStream),  AV_OPT_TYPE_INT, { .i64 = 1}, 0,  1, FLAGS},
    { "videoRange",      "Set videoRangehash(default [0], 0..1)",     OFFSET(videoRange),  AV_OPT_TYPE_INT, { .i64 = 0}, 0, 1, FLAGS},
    { "sei",             "Enable SEI message",                        OFFSET(sei),         AV_OPT_TYPE_INT, { .i64 = 0}, 0, INT_MAX,  FLAGS},
    { "disableCabac",    "0 for cavlc, 1 for cabac.",                 OFFSET(enableCabac), AV_OPT_TYPE_INT, { .i64 = 1}, 0, 1,  FLAGS},
	{ "sliceSize",       "slice size in number of CTU rows. (default [0], 0..height/ctu_size)", OFFSET(sliceSize), AV_OPT_TYPE_INT, { .i64 = 0}, 0, INT_MAX, FLAGS},
    { "bitVarRangeI",    "percent variations over average bits per frame for I frame", OFFSET(bitVarRangeI), AV_OPT_TYPE_INT, { .i64 = 10000}, 10, 10000, FLAGS},
    { "bitVarRangeP",    "percent variations over average bits per frame for P frame", OFFSET(bitVarRangeP), AV_OPT_TYPE_INT, { .i64 = 10000}, 10, 10000, FLAGS},
    { "bitVarRangeB",    "percent variations over average bits per frame for B frame", OFFSET(bitVarRangeB), AV_OPT_TYPE_INT, { .i64 = 10000}, 10, 10000, FLAGS},
    { "enablePicRc",     "enable picRc", OFFSET(picRc), AV_OPT_TYPE_INT, { .i64 = DEFAULT}, -255, 1, FLAGS},
    { "ctbRc",           "CTB QP adjustment mode for Rate Control and Subjective Quality. (default [0], 0..3)", OFFSET(ctbRc), AV_OPT_TYPE_INT, { .i64 = DEFAULT}, -255, 3, FLAGS},
    { "tolCtbRcInter",   "Tolerance of Ctb Rate Control for INTER frames. (float point number)", OFFSET(tolCtbRcInter), AV_OPT_TYPE_FLOAT, { .dbl = DEFAULT}, -255, FLT_MAX,  FLAGS},
    { "tolCtbRcIntra",   "Tolerance of Ctb Rate Control for INTRA frames. (float point number)", OFFSET(tolCtbRcIntra), AV_OPT_TYPE_FLOAT, { .dbl = DEFAULT}, -255, FLT_MAX,  FLAGS},
    { "ctbRowQpStep",    "The maximum accumulated QP adjustment step per CTB Row allowed by Ctb Rate Control.",    OFFSET(ctbRcRowQpStep), AV_OPT_TYPE_INT, { .i64 = DEFAULT}, -255, INT_MAX,  FLAGS},
    { "picQpDeltaRange", "Min:Max Qp_Delta Range in Picture RC. Min: -1..-10 ; Max:  1..10 ",    OFFSET(picQpDeltaMin),  AV_OPT_TYPE_INT, { .i64 = DEFAULT}, -255, 10, FLAGS},
    { "hrdConformance",  "enable HRD conformance. Uses standard defined model to limit bitrate variance.", OFFSET(hrdConformance), AV_OPT_TYPE_INT,    { .i64 = 0}, 0, 1,  FLAGS},
    { "cpbSize",         "HRD Coded Picture Buffer size in bits. (default [1000000], suggest 2*bitrate).", OFFSET(cpbSize),        AV_OPT_TYPE_INT,    { .i64 = 1000000}, 0, INT_MAX, FLAGS},
    { "gopSize",         "Set GOP size. default[0],0 for adaptive GOP size; 1~7 for fixed GOP size",       OFFSET(gopSize),        AV_OPT_TYPE_INT,    { .i64 = DEFAULT},   -255,  8, FLAGS},
    { "gopConfig",       "GOP configuration file by user,",                                                OFFSET(gopCfg),         AV_OPT_TYPE_STRING, { .str = NULL},  .flags = FLAGS},
    { "gopLowdelay",     "Enable default lowDelay GOP configuration if --gopConfig not specified, only valid for GOP size <= 4.",  OFFSET(gopLowdelay),        AV_OPT_TYPE_INT,    { .i64 = 0}, 0, 1, FLAGS},
 
    { "qpMinI",           "Set qpMin for I Slice(default [0], 0..51)", OFFSET(qpMinI),       AV_OPT_TYPE_INT, { .i64 = DEFAULT}, -255, 51, FLAGS},
    { "qpMaxI",           "Set qpMax for I Slice(default [51], 0..51)",OFFSET(qpMaxI),       AV_OPT_TYPE_INT, { .i64 = DEFAULT}, -255, 51, FLAGS},
    { "bFrameQpDelta",    "BFrame QP Delta. (default [-1], -1..51).",  OFFSET(bFrameQpDelta),  AV_OPT_TYPE_INT, { .i64 = -1}, -1, 51, FLAGS},
    { "chromaQpOffset",   "Chroma QP offset. (default [0], -12..12).", OFFSET(chromaQpOffset), AV_OPT_TYPE_INT, { .i64 = 0}, -12, 12, FLAGS},

    { "vbr",         "enable variable Bit Rate Control by qpMin.", OFFSET(vbr), AV_OPT_TYPE_INT, { .i64 = 0}, 0, 1,  FLAGS},
    { "userData",    "SEI User data file name. File is read and inserted as SEI message before first frame.",       OFFSET(userData),         AV_OPT_TYPE_STRING, { .str = NULL}, .flags = FLAGS},
    { "intraArea",   "left:top:right:bottom. CTB coordinates\nspecifying rectangular area of CTBs to force encoding in intra mode.", OFFSET(intraAreaLeft), AV_OPT_TYPE_INT, { .i64 = -1}, -1, INT_MAX,  FLAGS},
    { "ipcm1Area",   "left:top:right:bottom. CTB coordinates\nspecifying rectangular area of CTBs to force encoding in IPCM mode.",  OFFSET(ipcm1AreaLeft), AV_OPT_TYPE_INT, { .i64 = -1}, -1, INT_MAX,  FLAGS},
    { "ipcm2Area",   "left:top:right:bottom. CTB coordinates\nspecifying rectangular area of CTBs to force encoding in IPCM mode.",  OFFSET(ipcm2AreaLeft), AV_OPT_TYPE_INT, { .i64 = -1}, -1, INT_MAX,  FLAGS},
    { "enableConstChroma", "enable setting chroma a constant pixel value.",  OFFSET(constChromaEn), AV_OPT_TYPE_INT, { .i64 = 0}, 0, 1,  FLAGS},
 
    { "constCb",  "The constant pixel value for Cb. for 8bit default [128], 0..255, for 10bit default [512], 0..1023)",   OFFSET(constCb),  AV_OPT_TYPE_INT, { .i64 = DEFAULT}, -255, 1023, FLAGS},
    { "constCr",  "The constant pixel value for Cr. for 8bit default [128], 0..255, for 10bit default [512], 0..1023)",   OFFSET(constCr),  AV_OPT_TYPE_INT, { .i64 = DEFAULT}, -255, 1023, FLAGS},
    { "rdoLevel", "Programable HW RDO Level",  OFFSET(rdoLevel),       AV_OPT_TYPE_INT, { .i64 = DEFAULT},   -255,  3, FLAGS},

	{ "disable-ssim",         "Disable SSIM Calculation",              OFFSET(ssim),                   AV_OPT_TYPE_INT, { .i64 = 1}, 0, 1,  FLAGS},
    { "disableVuiTimingInfo", "Disable Write VUI timing info in SPS",  OFFSET(vui_timing_info_enable), AV_OPT_TYPE_INT, { .i64 = 1}, 0, 1,  FLAGS},
	{ "lookaheadDepth",       "Set lookaheadDepth",        OFFSET(lookaheadDepth), AV_OPT_TYPE_INT, { .i64 = DEFAULT},   -255, 40, FLAGS},
#endif	
    { "crf",                  "VCE Constant rate factor mode. Works with lookahead turned on.",  OFFSET(crf), AV_OPT_TYPE_INT, { .i64 = -1}, -1, 51, FLAGS},
    

    { "preset",       "Set the encoding preset",      OFFSETOPT(preset),       AV_OPT_TYPE_STRING,   { .str = NULL }, .flags = FLAGS},
    //{ "force8bit",    "force to output 8bit stream",  OFFSETOPT(force_8bit),   AV_OPT_TYPE_INT,      { .i64 = 0 },          0, 1, FLAGS},
    //{ "bitdepth",     "Bitdepth. 0=8-bit, 1=10-bit.", OFFSETOPT(bitdepth),     AV_OPT_TYPE_INT,      { .i64 = DEFAULT }, -255, 1, FLAGS},

    { "profile",         "Set encode profile",   OFFSETOPT(profile),     AV_OPT_TYPE_STRING, { .str = NULL},  .flags = FLAGS},
    { "level",           "Set encode level",                          OFFSETOPT(level),       AV_OPT_TYPE_STRING, { .str = NULL},  .flags = FLAGS},

    { "forced-idr",      "If forcing keyframes, force them as IDR frames.", OFFSETOPT(forced_idr),  AV_OPT_TYPE_INT, { .i64 = 0},  0, 1, .flags = FLAGS},

    { "hantro-params",  "Override the hantro h264/hevc configuration using a :-separated list of key=value parameters", OFFSETOPT(hantro_params), AV_OPT_TYPE_STRING, { .str = NULL}, .flags = FLAGS},

#ifdef VCE_MEM_ERR_TEST
    { "vce_mem_err_test", "vce error process test", OFFSET(vce_memory_err_shadow), AV_OPT_TYPE_INT, {.i64 = -1}, -1, 10000, FLAGS},
#endif

#ifdef VCE_EDMA_ERR_TEST
    { "vce_edma_err_test", "vce edma error process test", OFFSET(vce_edma_err_shadow), AV_OPT_TYPE_INT, {.i64 = -1}, -1, 10000, FLAGS},
#endif

    { NULL },
};

static const AVCodecDefault hantro_encode_h264_defaults[] = {
    { NULL },
};

static const AVCodecDefault hantro_encode_hevc_defaults[] = {
    { NULL },
};


#define OPT_FLAG_VCE        (1 << 0)
#define OPT_FLAG_CTX        (1 << 1)

#define OPT_FLAG_EN         (1 << 4)
#define OPT_FLAG_DIS        (1 << 5)
#define OPT_FLAG_MULTI      (1 << 6)


#define OFFSETM_VCE(x)    offsetof(HANTROH26xEncOptions, x)
HantroParamsDef_t HantroParamTable[] = 
{
  //{"help",                          'h',       TYPE_NOARG,  NOCARE, NOCARE, -1,                              0,                                                  "Print command line parameters help info."},

  {"force8bit",                     'U',       TYPE_INT,    0,      1,      OFFSETOPT(force_8bit),          { .i64 = 0 },      OPT_FLAG_CTX | OPT_FLAG_EN,                                        "force to output 8bit stream."},

  //{"preset",                        'S',       TYPE_STRING, NOCARE, NOCARE, OFFSETOPT(preset),              { .str = NULL },   OPT_FLAG_CTX | OPT_FLAG_MULTI,                                     "specific encoder preset. (default [none], valid: superfast/fast/medium/slow/superslow)"},

  {"intraPicRate",                  COM_SHORT, TYPE_INT,    0,      NOCARE, OFFSETM_VCE(intraPicRate),      { .i64 = 0},       OPT_FLAG_VCE | OPT_FLAG_MULTI,    "[VC8000E|Bigsea] Intra picture rate in frames. (default [0])\nForces every Nth frame to be encoded as intra frame."},
  {"bitrateWindow",                 COM_SHORT, TYPE_INT,    -255,   300,    OFFSETM_VCE(bitrateWindow),     { .i64 = DEFAULT}, OPT_FLAG_VCE | OPT_FLAG_MULTI,    "[VC8000E|Bigsea] Bitrate window length in frames. (default [intraPicRate])."},
  {"intraQpDelta",                  COM_SHORT, TYPE_INT,    -255,   127,    OFFSETM_VCE(intraQpDelta),      { .i64 = DEFAULT}, OPT_FLAG_VCE | OPT_FLAG_MULTI,    "[VC8000E] Intra QP delta. (default [26], -1..51).\n[Bigsea] Intra QP delta. (default [0], -127..127)."},
  {"qpHdr",                         COM_SHORT, TYPE_INT,    -1,     255,    OFFSETM_VCE(qpHdr),             { .i64 = DEFAULT}, OPT_FLAG_VCE | OPT_FLAG_MULTI,    "[VC8000E] Initial QP used for the first frame. (default [-1], -1..51).\n[Bigsea] Initial QP used for the first frame. (default [-1 or 50], -1..255)."},
  {"qpMin",                         COM_SHORT, TYPE_INT,    0,      255,    OFFSETM_VCE(qpMin),             { .i64 = DEFAULT}, OPT_FLAG_VCE | OPT_FLAG_MULTI,    "[VC8000E] Minimum frame header QP for any slices. (default [0], 0..51).\n[Bigsea] Minimum frame header QP. (default [10], 0..255)."},
  {"qpMax",                         COM_SHORT, TYPE_INT,    0,      255,    OFFSETM_VCE(qpMax),             { .i64 = DEFAULT}, OPT_FLAG_VCE | OPT_FLAG_MULTI,    "[VC8000E] Maximum frame header QP for any slices. (default [51], 0..51).\n[Bigsea] Maximum frame header QP. (default [255], 0..255)"},
  {"fixedIntraQp",                  COM_SHORT, TYPE_INT,    0,      255,    OFFSETM_VCE(fixedIntraQp),      { .i64 = 0},       OPT_FLAG_VCE | OPT_FLAG_MULTI,    "[VC8000E] Fixed Intra QP, 0 = disabled. (default [0], 0..51).\n[Bigsea] Fixed Intra QP, 0 = disabled. (default [0], 0..255)."},
  {"picSkip",                       COM_SHORT, TYPE_INT,    0,      1,      OFFSETM_VCE(picSkip),           { .i64 = 0},       OPT_FLAG_VCE | OPT_FLAG_MULTI | OPT_FLAG_EN, "[VC8000E|Bigsea] Enable picture skip rate control."},
  {"bitdepth",                      COM_SHORT, TYPE_INT,    0,      1,      OFFSETOPT(bitdepth),            { .i64 = DEFAULT}, OPT_FLAG_CTX | OPT_FLAG_MULTI,    "[VC8000E|Bigsea] Bitdepth. 0=8-bit, 1=10-bit. [default: keep the same as input]."},

  //{"profile",                       COM_SHORT, TYPE_INT,    NOCARE, NOCARE, OFFSETM_VCE(profile),           OPT_FLAG_VCE | OPT_FLAG_MULTI,                      "[VC8000E/HEVC] encoder profile (default [0])\n0  -main profile\n1  -main still picture profile\n2  -main 10 profile\n[VC8000E/H264] encoder profile (default [11])\n9   -baseline profile\n10  -main profile\n11  -high profile\n12  -high10 profile"},
  //{"level",                         COM_SHORT, TYPE_INT,    NOCARE, NOCARE, OFFSETM_VCE(level),             OPT_FLAG_VCE | OPT_FLAG_MULTI,                      "[VC8000E/HEVC] level (default [180])\n30  -Level1.0\n60  -Level2.0\n63  -Level2.1\n90  -Level3.0\n93  -Level3.1\n120 -Level4.0\n123 -Level4.1\n150 -Level5.0\n153 -Level5.1\n[VC8000E/H264] level (default [51])\n10 -H264_LEVEL_1\n99 -H264_LEVEL_1_b\n11 -H264_LEVEL_1_1\n12 -H264_LEVEL_1_2\n13 -H264_LEVEL_1_3\n20 -H264_LEVEL_2\n21 -H264_LEVEL_2_1\n22 -H264_LEVEL_2_2\n30 -H264_LEVEL_3\n31 -H264_LEVEL_3_1\n32 -H264_LEVEL_3_2\n40 -H264_LEVEL_4\n41 -H264_LEVEL_4_1\n42 -H264_LEVEL_4_2\n50 -H264_LEVEL_5\n51 -H264_LEVEL_5_1\n52 -H264_LEVEL_5_2"},
  {"tier",                          COM_SHORT, TYPE_INT,    0,      1,      OFFSETM_VCE(tier),              { .i64 = DEFAULT}, OPT_FLAG_VCE | OPT_FLAG_MULTI,                      "[VC8000E/HEVC] encoder only (default [0], 0..1)\n0  -main tier\n1  -high tier"},
  {"byteStream",                    COM_SHORT, TYPE_INT,    0,      1,      OFFSETM_VCE(byteStream),        { .i64 = 1},       OPT_FLAG_VCE | OPT_FLAG_MULTI,                      "[VC8000E] stream type (default [1], 0..1)\n0 - NAL units. Nal sizes returned in <nal_sizes.txt>\n1 - byte stream according to Hevc Standard Annex B."},
  {"videoRange",                    COM_SHORT, TYPE_INT,    0,      1,      OFFSETM_VCE(videoRange),        { .i64 = 0},       OPT_FLAG_VCE | OPT_FLAG_MULTI,                      "[VC8000E/HEVC] Video signal sample range value in Hevc stream. (default [0], 0..1)\n0 - Y range in [16..235] Cb,Cr in [16..240]\n1 - Y,Cb,Cr range in [0..255]"},
  {"sei",                           COM_SHORT, TYPE_INT,    NOCARE, NOCARE, OFFSETM_VCE(sei),               { .i64 = 0},       OPT_FLAG_VCE | OPT_FLAG_MULTI | OPT_FLAG_EN,        "[VC8000E] enable SEI messages."},
  {"cabac",                         COM_SHORT, TYPE_INT,    0,      1,      OFFSETM_VCE(enableCabac),       { .i64 = 1},       OPT_FLAG_VCE | OPT_FLAG_MULTI | OPT_FLAG_DIS,       "[VC8000E] 0 - cavlc, 1 - cabac. (default [1], 0..1)."},
  {"sliceSize",                     COM_SHORT, TYPE_INT,    0,      NOCARE, OFFSETM_VCE(sliceSize),         { .i64 = 0},       OPT_FLAG_VCE | OPT_FLAG_MULTI,                      "[VC8000E] slice size in number of CTU rows. (default [0], 0..height/ctu_size)\n0 - to encode each picture in one slice\n1..height/ctu_size - to each slice with N CTU row"},
  {"cpbSize",                       COM_SHORT, TYPE_INT,    NOCARE, NOCARE, OFFSETM_VCE(cpbSize),           { .i64 = 0},       OPT_FLAG_VCE | OPT_FLAG_MULTI,                      "[VC8000E] HRD Coded Picture Buffer size in bits. (default [max CPB of current level], suggest 2*bitrate)."},
  {"tolMovingBitRate",              COM_SHORT, TYPE_INT,    0,      2000,   OFFSETM_VCE(tolMovingBitRate),  { .i64 = 2000},    OPT_FLAG_VCE | OPT_FLAG_MULTI,                      "[VC8000E] percent tolerance over target bitrate of moving bit rate (default [2000], 0..2000%%)."},
  {"bitVarRangeI",                  COM_SHORT, TYPE_INT,    10,     10000,  OFFSETM_VCE(bitVarRangeI),      { .i64 = 10000},   OPT_FLAG_VCE | OPT_FLAG_MULTI,                      "[VC8000E] percent variations over average bits per frame for I frame. (default [10000], 10..10000%%)."},
  {"bitVarRangeP",                  COM_SHORT, TYPE_INT,    10,     10000,  OFFSETM_VCE(bitVarRangeP),      { .i64 = 10000},   OPT_FLAG_VCE | OPT_FLAG_MULTI,                      "[VC8000E] percent variations over average bits per frame for P frame. (default [10000], 10..10000%%)."},
  {"bitVarRangeB",                  COM_SHORT, TYPE_INT,    10,     10000,  OFFSETM_VCE(bitVarRangeB),      { .i64 = 10000},   OPT_FLAG_VCE | OPT_FLAG_MULTI,                      "[VC8000E] percent variations over average bits per frame for B frame. (default [10000], 10..10000%%)."},
  {"picRc",                         COM_SHORT, TYPE_INT,    -255,   1,      OFFSETM_VCE(picRc),             { .i64 = DEFAULT}, OPT_FLAG_VCE | OPT_FLAG_MULTI | OPT_FLAG_EN,        "[VC8000E] 0 - disable, 1 - enable picture rate control. Calculates new target QP for every frame. (default [0], 0..1)."},
  {"ctbRc",                         COM_SHORT, TYPE_INT,    0,      3,      OFFSETM_VCE(ctbRc),             { .i64 = DEFAULT}, OPT_FLAG_VCE | OPT_FLAG_MULTI | OPT_FLAG_EN,        "[VC8000E] CTB QP adjustment mode for Rate Control and Subjective Quality. (default [0], 0..3).\n0 = No CTB QP adjustment (best PSNR).\n1 = CTB QP adjustment for Subjective Quality only.\n2 = CTB QP adjustment for Rate Control only(suggest, best bitrate).\n3 = CTB QP adjustment for both Subjective Quality and Rate Control."},
  {"tolCtbRcInter",                 COM_SHORT, TYPE_FLOAT,  NOCARE, NOCARE, OFFSETM_VCE(tolCtbRcInter),     { .dbl = DEFAULT}, OPT_FLAG_VCE | OPT_FLAG_MULTI,                      "[VC8000E] Tolerance of Ctb Rate Control for INTER frames. (float point number). (default [0.0])\nCtb Rc will try to limit INTER frame bits within the range of:\n\t[targetPicSize/(1+tolCtbRcInter), targetPicSize*(1+tolCtbRcInter)]."},
  {"tolCtbRcIntra",                 COM_SHORT, TYPE_FLOAT,  NOCARE, NOCARE, OFFSETM_VCE(tolCtbRcIntra),     { .dbl = DEFAULT}, OPT_FLAG_VCE | OPT_FLAG_MULTI,                      "[VC8000E] Tolerance of Ctb Rate Control for INTRA frames. (float point number). (default [-1.0])"},
  {"ctbRowQpStep",                  COM_SHORT, TYPE_INT,    NOCARE, NOCARE, OFFSETM_VCE(ctbRcRowQpStep),    { .i64 = DEFAULT}, OPT_FLAG_VCE | OPT_FLAG_MULTI,                      "[VC8000E] The maximum accumulated QP adjustment step per CTB Row allowed by Ctb Rate Control.\nDefault value is [4] for H264 and [16] for HEVC.\nQP_step_per_CTB = (ctbRowQpStep / Ctb_per_Row) and limited by maximum = 4."},
  {"picQpDeltaRange",               COM_SHORT, TYPE_COLON2, NOCARE, NOCARE, OFFSETM_VCE(picQpDeltaMin),     { .colon2 = {DEFAULT, DEFAULT}}, OPT_FLAG_VCE | OPT_FLAG_MULTI,         "[VC8000E] Min:Max. Qp_Delta Range in Picture RC.\nMin: -1..-10 Minimum Qp_Delta in Picture RC. [-2]\nMax:  1..10  Maximum Qp_Delta in Picture RC. [3]"},
  {"hrdConformance",                COM_SHORT, TYPE_INT,    0,      1,      OFFSETM_VCE(hrdConformance),    { .i64 = 0},       OPT_FLAG_VCE | OPT_FLAG_MULTI | OPT_FLAG_EN,        "[VC8000E] enable HRD conformance. Uses standard defined model to limit bitrate variance."},
  //{"cpbSize",                       COM_SHORT, TYPE_INT,    NOCARE, NOCARE, OFFSETM_VCE(cpbSize),           { .i64 = 1000000}, OPT_FLAG_VCE | OPT_FLAG_MULTI,                      "[VC8000E] HRD Coded Picture Buffer size in bits. (default [1000000], suggest 2*bitrate)."},
  {"gopSize",                       COM_SHORT, TYPE_INT,    0,      8,      OFFSETM_VCE(gopSize),           { .i64 = DEFAULT}, OPT_FLAG_VCE | OPT_FLAG_MULTI,                      "[VC8000E] GOP Size. (default [0], 0..8).\n0 for adaptive GOP size; 1~7 for fixed GOP size."},
  //{"gopConfig",                     COM_SHORT, TYPE_STRING, NOCARE, NOCARE, OFFSETM_VCE(gopCfg),            { .str = NULL},    OPT_FLAG_VCE | OPT_FLAG_MULTI,                      "[VC8000E] GOP configuration file by user, which defines the GOP structure table."},
  {"gopLowdelay",                   COM_SHORT, TYPE_INT,    0,      1,      OFFSETM_VCE(gopLowdelay),       { .i64 = 0},       OPT_FLAG_VCE | OPT_FLAG_MULTI,                      "[VC8000E] Enable default lowDelay GOP configuration if --gopConfig not specified, only valid for GOP size <= 4."},
  {"qpMinI",                        COM_SHORT, TYPE_INT,    0,      51,     OFFSETM_VCE(qpMinI),            { .i64 = DEFAULT}, OPT_FLAG_VCE | OPT_FLAG_MULTI,                      "[VC8000E] minimum frame header QP overriding qpMin for I slices. (default [0], 0..51)."},
  {"qpMaxI",                        COM_SHORT, TYPE_INT,    0,      51,     OFFSETM_VCE(qpMaxI),            { .i64 = DEFAULT}, OPT_FLAG_VCE | OPT_FLAG_MULTI,                      "[VC8000E] maximum frame header QP overriding qpMax for I slices. (default [51], 0..51)."},
  {"bFrameQpDelta",                 COM_SHORT, TYPE_INT,    -1,     51,     OFFSETM_VCE(bFrameQpDelta),     { .i64 = -1},      OPT_FLAG_VCE | OPT_FLAG_MULTI,                      "[VC8000E] BFrame QP Delta. (default [-1], -1..51)."},
  {"chromaQpOffset",                COM_SHORT, TYPE_INT,    -12,    12,     OFFSETM_VCE(chromaQpOffset),    { .i64 = 0},       OPT_FLAG_VCE | OPT_FLAG_MULTI,                      "[VC8000E] Chroma QP offset. (default [0], -12..12)."},
  {"vbr",                           COM_SHORT, TYPE_INT,    0,      1,      OFFSETM_VCE(vbr),               { .i64 = 0},       OPT_FLAG_VCE | OPT_FLAG_MULTI | OPT_FLAG_EN,        "[VC8000E] enable variable Bit Rate Control by qpMin."},
  {"userData",                      COM_SHORT, TYPE_STRING, NOCARE, NOCARE, OFFSETM_VCE(userData),          { .str = NULL},    OPT_FLAG_VCE | OPT_FLAG_MULTI,                      "[VC8000E] SEI User data file name. File is read and inserted as SEI message before first frame."},
  {"intraArea",                     COM_SHORT, TYPE_INT,    NOCARE, NOCARE, OFFSETM_VCE(intraAreaLeft),     { .i64 = -1},      OPT_FLAG_VCE | OPT_FLAG_MULTI,                      "[VC8000E] left:top:right:bottom. CTB coordinates\nspecifying rectangular area of CTBs to force encoding in intra mode."},
  {"ipcm1Area",                     COM_SHORT, TYPE_INT,    NOCARE, NOCARE, OFFSETM_VCE(ipcm1AreaLeft),     { .i64 = -1},      OPT_FLAG_VCE | OPT_FLAG_MULTI,                      "[VC8000E] left:top:right:bottom. CTB coordinates\nspecifying rectangular area of CTBs to force encoding in IPCM mode."},
  {"ipcm2Area",                     COM_SHORT, TYPE_INT,    NOCARE, NOCARE, OFFSETM_VCE(ipcm2AreaLeft),     { .i64 = -1},      OPT_FLAG_VCE | OPT_FLAG_MULTI,                      "[VC8000E] left:top:right:bottom. CTB coordinates\nspecifying rectangular area of CTBs to force encoding in IPCM mode."},
  {"constChroma",                   COM_SHORT, TYPE_INT,    0,      1,      OFFSETM_VCE(constChromaEn),     { .i64 = 0},       OPT_FLAG_VCE | OPT_FLAG_MULTI | OPT_FLAG_EN,        "[VC8000E] 0 - disable, 1 - enable setting chroma a constant pixel value. (default [0], 0..1)."},
  {"constCb",                       COM_SHORT, TYPE_INT,    0,      1023,   OFFSETM_VCE(constCb),           { .i64 = DEFAULT}, OPT_FLAG_VCE | OPT_FLAG_MULTI,                      "[VC8000E] The constant pixel value for Cb.\n(for 8bit default [128], 0..255, for 10bit default [512], 0..1023)."},
  {"constCr",                       COM_SHORT, TYPE_INT,    0,      1023,   OFFSETM_VCE(constCr),           { .i64 = DEFAULT}, OPT_FLAG_VCE | OPT_FLAG_MULTI,                      "[VC8000E] The constant pixel value for Cr.\n(for 8bit default [128], 0..255, for 10bit default [512], 0..1023)."},
  {"rdoLevel",                      COM_SHORT, TYPE_INT,    1,      3,      OFFSETM_VCE(rdoLevel),          { .i64 = DEFAULT}, OPT_FLAG_VCE | OPT_FLAG_MULTI,                      "[VC8000E/HEVC] programable HW RDO Level (default [1], 1..3)."},
  {"ssim",                          COM_SHORT, TYPE_INT,    0,      1,      OFFSETM_VCE(ssim),              { .i64 = 1},       OPT_FLAG_VCE | OPT_FLAG_MULTI | OPT_FLAG_DIS,       "[VC8000E] 0 - disable, 1 - enable SSIM Calculation. (default [1], 0..1)."},
  {"vuiTimingInfo",                 COM_SHORT, TYPE_INT,    0,      1,      OFFSETM_VCE(vui_timing_info_enable), { .i64 = 1},  OPT_FLAG_VCE | OPT_FLAG_MULTI | OPT_FLAG_DIS,       "[VC8000E] 0 - disable, 1 - enable Write VUI timing info in SPS. (default [1], 0..1)."},
  {"lookaheadDepth",                COM_SHORT, TYPE_INT,    0,      40,     OFFSETM_VCE(lookaheadDepth),    { .i64 = DEFAULT}, OPT_FLAG_VCE | OPT_FLAG_MULTI,                      "Number of frames to lookahead. Up to 40. [0]"},
  //{"crf",                           COM_SHORT, TYPE_INT,    0,      51,     OFFSETM_VCE(crf),               OPT_FLAG_VCE | OPT_FLAG_MULTI,                      "VCE Constant rate factor mode. Works with lookahead turned on."},
  //{"cutree_blkratio",               COM_SHORT, TYPE_INT,    0,      1,      OFFSETM_VCE(cutree_blkratio),   OPT_FLAG_VCE | OPT_FLAG_MULTI,                      "down sample encode mode turned on."},
  { NULL },
};

static int ParseTypeArg(HantroParamsDef_t *pHantroParamsLine, void *p)
{
  if (pHantroParamsLine->type == TYPE_INT) {
    int value = pHantroParamsLine->default_val.i64;
    *((int *)p) = value;
    av_log(NULL, AV_LOG_DEBUG, "%s default set to %d\n", pHantroParamsLine->name, *((int *)p));
  } else if (pHantroParamsLine->type == TYPE_FLOAT) {
  	float value = pHantroParamsLine->default_val.dbl;
    *((float *)p) = value;
  } else if (pHantroParamsLine->type == TYPE_STRING) {
    *((char **)p) = pHantroParamsLine->default_val.str;
    av_log(NULL, AV_LOG_DEBUG, "%s default set to %s\n", pHantroParamsLine->name, *((char **)p));
  } else if (pHantroParamsLine->type == TYPE_COLON2) {
    av_log(NULL, AV_LOG_DEBUG, "%s default are %d:%d\n", pHantroParamsLine->name, pHantroParamsLine->default_val.colon2.min, pHantroParamsLine->default_val.colon2.max);
    *((int *)p) = pHantroParamsLine->default_val.colon2.min;
    *((int *)p+1) = pHantroParamsLine->default_val.colon2.max;
    av_log(NULL, AV_LOG_DEBUG, "%s default set to %d:%d\n", pHantroParamsLine->name, *((int *)p), *((int *)p+1));
  }

  return 0;
}

int GetDefaultHantroParams(HANTROH26xEncContext *ctx)
{
  HantroParamsDef_t *pHantroParamsLine;
  HANTROH26xEncOptions *options = (HANTROH26xEncOptions *)&ctx->options;
  int i;
  u8 *p = NULL;

  for (i = 0; i < ARRAY_COUNT(HantroParamTable); i++) {
    pHantroParamsLine = &HantroParamTable[i];

    if (pHantroParamsLine->flag & OPT_FLAG_CTX) {
      p = (u8 *)ctx;
    } else {
      p = (u8 *)options;
    }
    p += pHantroParamsLine->offset;
    if (ParseTypeArg(pHantroParamsLine, p) < 0)
      return -1;
  }

  return 0;
}

static const HantroParamsDef_t *FindOption(const HantroParamsDef_t *po, const char *name)
{
  int len = strlen(name);
  int flag = 0;  

  while (po->name) {
    if (!strncmp(name, po->name, len) && strlen(po->name) == len) {
      flag = 1;
      break;
    }
    po++;
  }
  return ((flag == 1) ? po : NULL);
}

static int split_string(char ** tgt, int max, char * src, char * split)
{
  int count;
  char * currp;
  char * p;
  char c;
  int i;
  int last;

  //printf("string is %s\n", src);
  //printf("split is %s\n", split);

  currp = src;
  count = 0;
  i = 0;
  last = 0;
  while ((c = *currp++) != '\0') {
    if ((p = strchr(split, c)) == NULL) {
      if (count < max) {
        tgt[count][i++] = c;
        //printf("%d %d %c\n", count, i-1, c);
      } else {
        av_log(NULL, AV_LOG_ERROR, "the split count exceeds max num\n");
        return -1;
      }
      last = 1; // 1 means non split char, 0 means split char
    } else {
      if (last == 1) {
        tgt[count][i] = '\0';
        //printf("split %d: %s\n", count, &tgt[count][0]);
        count++;
        i = 0;
      }
      last = 0; // 1 means non split char, 0 means split char
    }
  }
  if (last == 1) {
    tgt[count][i] = '\0';
    //printf("split %d: %s\n", count, &tgt[count][0]);
    count++;
  }

  return count;
}


int GetHantroParamsFromCmd(HANTROH26xEncContext *ctx, const char *name, const char *inputValue)
{
  HANTROH26xEncOptions *options = (HANTROH26xEncOptions *)&ctx->options;
  HantroParamsDef_t *pHantroParamsLine = NULL;
  u8 *p = NULL;
  
  av_log(NULL, AV_LOG_DEBUG, "%s value is %s\n", name, inputValue);

  pHantroParamsLine = FindOption(ctx->hantroParamTable, name);
  if (!pHantroParamsLine)
    return -1;

  if (pHantroParamsLine->flag & OPT_FLAG_CTX) {
    p = (u8 *)ctx;
  } else {
    p = (u8 *)options;
  }

  p += pHantroParamsLine->offset;

  if (pHantroParamsLine->type == TYPE_INT) {
    int64_t value = atoi(inputValue);
    if (pHantroParamsLine->min != NOCARE) {
      if (value < pHantroParamsLine->min) {
        if (value != 0 && value != DEFAULT_VALUE) {
          av_log(NULL, AV_LOG_WARNING,"option %s value %d less than min %d or not 0 nor DEFAULT_VALUE!\n", pHantroParamsLine->name, value, pHantroParamsLine->min);
          return -1;
        }
      }
    }
    if (pHantroParamsLine->max != NOCARE) {
      if (value > pHantroParamsLine->max) {
        av_log(NULL, AV_LOG_WARNING,"option %s value %d greater than max %d!\n", pHantroParamsLine->name, value, pHantroParamsLine->max);
        return -1;
      }
    }
    *((int *)p) = value;
    av_log(NULL, AV_LOG_DEBUG,"%s set to %d\n", pHantroParamsLine->name, *((int *)p));
  } else if (pHantroParamsLine->type == TYPE_FLOAT) {
    *((float *)p) = atof(inputValue);
  } else if (pHantroParamsLine->type == TYPE_STRING) {
    *((char **)p) = inputValue;
    av_log(NULL, AV_LOG_DEBUG,"%s set to %s\n", pHantroParamsLine->name, *((char **)p));
  } else if (pHantroParamsLine->type == TYPE_COLON2 || pHantroParamsLine->type == TYPE_COLON4) {
  #define MAX_SEG_NUM 4
  #define MAX_CHAR 256
    char strs[MAX_SEG_NUM][MAX_CHAR];
    char * pstrs[MAX_SEG_NUM];
    int i, seg_num;
    for (i = 0; i < MAX_SEG_NUM; i++) {
      pstrs[i] = &strs[i][0];
    }
    seg_num = split_string(&pstrs, MAX_SEG_NUM, inputValue, ":");
    if (seg_num < 0) {
      av_log(NULL, AV_LOG_ERROR, "error seg_num %d\n", seg_num);
      return -1;
    }
    if (pHantroParamsLine->type == TYPE_COLON2 && seg_num != 2) {
      av_log(NULL, AV_LOG_ERROR, "seg_num %d not match TYPE_COLON2\n", seg_num);
      return -1;
    }
    if (pHantroParamsLine->type == TYPE_COLON4 && seg_num != 4) {
      av_log(NULL, AV_LOG_ERROR, "seg_num %d not match TYPE_COLON4\n", seg_num);
      return -1;
    }
    for (i = 0; i < seg_num; i++) {
      *((int *)p) = atoi(pstrs[i]);
      av_log(NULL, AV_LOG_DEBUG, "%s %d set to %d\n", pHantroParamsLine->name, i, *((int *)p));
      p += 4;
    }
  }
  return 0;
}



