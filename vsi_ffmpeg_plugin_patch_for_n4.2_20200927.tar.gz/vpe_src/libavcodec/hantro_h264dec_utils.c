
#include "hantro_h264dec_utils.h"
#include "h264decapi.h"




enum DecRet H264NextPicture(void* inst, struct DecPicturePpu* pic) {

    enum DecRet rv;
    u32 stride, stride_ch, i;
    H264DecPicture hpic;
  
    rv = H264DecNextPicture(inst, &hpic, 0);
    memset(pic, 0, sizeof(struct DecPicturePpu));
    if (rv != DEC_PIC_RDY)
        return rv;
  
    for (i = 0; i < DEC_MAX_OUT_COUNT; i++) {
        stride = hpic.pictures[i].pic_stride;
        stride_ch = hpic.pictures[i].pic_stride_ch;
#ifndef NEW_MEM_ALLOC
        pic->pictures[i].luma.virtual_address = (u32*)hpic.pictures[i].output_picture;
#endif
        pic->pictures[i].luma.bus_address = hpic.pictures[i].output_picture_bus_address;
#if 0
        if (hpic.output_format == DEC_OUT_FRM_RASTER_SCAN)
        hpic.pic_width = NEXT_MULTIPLE(hpic.pic_width, 16);
#endif
        if (hpic.pictures[i].output_format == DEC_OUT_FRM_TILED_4X4) {
            pic->pictures[i].luma.size = stride * hpic.pictures[i].pic_height / 4;
            /*sunny correct*/
            if((hpic.pictures[i].pic_height / 4)&1 == 1)
            pic->pictures[i].chroma.size = stride_ch * (hpic.pictures[i].pic_height/4+1) / 2;
            else
            pic->pictures[i].chroma.size = stride_ch * hpic.pictures[i].pic_height / 8;

            /*pic->pictures[i].chroma.size = stride_ch * hpic.pictures[i].pic_height / 8;*/
        } else {
            pic->pictures[i].luma.size = stride * hpic.pictures[i].pic_height;
            pic->pictures[i].chroma.size = stride_ch * hpic.pictures[i].pic_height/2;
        }
        /* TODO temporal solution to set chroma base here */
#ifndef NEW_MEM_ALLOC
        pic->pictures[i].chroma.virtual_address = (u32*)hpic.pictures[i].output_picture_chroma;
#endif
        pic->pictures[i].chroma.bus_address = hpic.pictures[i].output_picture_chroma_bus_address;

        /* TODO(vmr): find out for real also if it is B frame */
        pic->pictures[i].picture_info.pic_coding_type =
            hpic.is_idr_picture[0] ? DEC_PIC_TYPE_I : DEC_PIC_TYPE_P;
        pic->pictures[i].picture_info.format = hpic.pictures[i].output_format;
        pic->pictures[i].picture_info.pixel_format = DEC_OUT_PIXEL_DEFAULT; //hpic.pictures[i].pixel_format;
        pic->pictures[i].picture_info.pic_id = hpic.pic_id;
        pic->pictures[i].picture_info.decode_id = hpic.decode_id[0];
        pic->pictures[i].picture_info.cycles_per_mb = hpic.cycles_per_mb;
        pic->pictures[i].sequence_info.pic_width = hpic.pictures[i].pic_width;
        pic->pictures[i].sequence_info.pic_height = hpic.pictures[i].pic_height;
        pic->pictures[i].sequence_info.crop_params.crop_left_offset =
          hpic.crop_params.crop_left_offset;
        pic->pictures[i].sequence_info.crop_params.crop_top_offset =
          hpic.crop_params.crop_top_offset;
        if (hpic.interlaced) {
            if (hpic.crop_params.crop_out_width <= hpic.pictures[i].pic_width) {
                pic->pictures[i].sequence_info.crop_params.crop_out_width =
                  hpic.crop_params.crop_out_width;
            } else {
              pic->pictures[i].sequence_info.crop_params.crop_out_width =
                hpic.pictures[i].pic_width;
            }
            if (hpic.crop_params.crop_out_height <= hpic.pictures[i].pic_height) {
                pic->pictures[i].sequence_info.crop_params.crop_out_height =
                  hpic.crop_params.crop_out_height;
            } else {
              pic->pictures[i].sequence_info.crop_params.crop_out_height =
                hpic.pictures[i].pic_height;
            }
        } else {
            pic->pictures[i].sequence_info.crop_params.crop_out_width =
              hpic.crop_params.crop_out_width;
            pic->pictures[i].sequence_info.crop_params.crop_out_height =
              hpic.crop_params.crop_out_height;
        }

        pic->pictures[i].sequence_info.sar_width = hpic.sar_width;
        pic->pictures[i].sequence_info.sar_height = hpic.sar_height;
        pic->pictures[i].sequence_info.video_range = 0; //hpic.video_range;
        pic->pictures[i].sequence_info.matrix_coefficients = 0; //hpic.matrix_coefficients;
        pic->pictures[i].sequence_info.is_mono_chrome = 0; //hpic.mono_chrome;
        pic->pictures[i].sequence_info.is_interlaced = hpic.interlaced;
        pic->pictures[i].sequence_info.num_of_ref_frames = 0; //hpic.dec_info.pic_buff_size;
        pic->pictures[i].sequence_info.bit_depth_luma = hpic.bit_depth_luma;
        pic->pictures[i].sequence_info.bit_depth_chroma = hpic.bit_depth_chroma;
        pic->pictures[i].sequence_info.pic_stride = hpic.pictures[i].pic_stride;
        pic->pictures[i].sequence_info.pic_stride_ch = hpic.pictures[i].pic_stride_ch;
        pic->pictures[i].pic_width = hpic.pictures[i].pic_width;
        pic->pictures[i].pic_height = hpic.pictures[i].pic_height;
        pic->pictures[i].pic_stride = hpic.pictures[i].pic_stride;
        pic->pictures[i].pic_stride_ch = hpic.pictures[i].pic_stride_ch;
        pic->pictures[i].pp_enabled = 0; //hpic.pp_enabled;
    }


  #ifdef SUPPORT_DEC400

	  /*add for dec400 tables*/
		addr_t dec400_table_bus_address_base = 0; 
		const u32 *dec400_table_base =NULL;
		int dec400_table_offset=0;
		u32 y_size=0,uv_size=0;
		for(i=0;i<DEC_MAX_OUT_COUNT;i++)
		{
			pic->pictures[i].pic_compressed_status = hpic.pictures[i].pic_compressed_status;
			#ifndef NEW_MEM_ALLOC
			if(pic->pictures[i].luma.virtual_address != NULL)
			#else
			if(pic->pictures[i].luma.bus_address != 0)
			#endif
			{
				if(i == 0)
				{
#if 0                    
					y_size = pic->pictures[i].pic_height/4 * pic->pictures[i].pic_stride;
					if((pic->pictures[i].pic_height/4) & 1 ==1)
						uv_size = (pic->pictures[i].pic_height/4+1)/2 * pic->pictures[i].pic_stride_ch;
					else
						uv_size = pic->pictures[i].pic_height/4/2 * pic->pictures[i].pic_stride_ch;
#else
					y_size = NEXT_MULTIPLE(pic->pictures[i].pic_height, 4)/4 * pic->pictures[i].pic_stride;
					uv_size = NEXT_MULTIPLE(pic->pictures[i].pic_height/2, 4)/4 * pic->pictures[i].pic_stride_ch;
#endif                    
					#ifndef NEW_MEM_ALLOC
					pic->pictures[i].luma_table.virtual_address= (u32*)((u8*)pic->pictures[i].luma.virtual_address-DEC400_PP_TABLE_SIZE);
					#endif
					pic->pictures[i].luma_table.bus_address= pic->pictures[i].luma.bus_address-DEC400_PP_TABLE_SIZE;					
					pic->pictures[i].luma_table.size = NEXT_MULTIPLE(y_size/1024/4 +((y_size%4096)?1:0), 16);
					#ifndef NEW_MEM_ALLOC
					pic->pictures[i].chroma_table.virtual_address= (u32*)((u8*)pic->pictures[i].luma.virtual_address-DEC400_YUV_TABLE_SIZE);
					#endif
					pic->pictures[i].chroma_table.bus_address= pic->pictures[i].luma.bus_address-DEC400_YUV_TABLE_SIZE;					
					pic->pictures[i].chroma_table.size= NEXT_MULTIPLE(uv_size/1024/4 +((uv_size%4096)?1:0), 16);
				}
				else
				{
					if(dec400_table_bus_address_base == 0)
					{
						dec400_table_bus_address_base = pic->pictures[i].luma.bus_address;
						#ifndef NEW_MEM_ALLOC
						dec400_table_base = pic->pictures[i].luma.virtual_address;
						#endif
/*						printf("\n\n--in %s : %d found base at %d pp,bus=0x%x,v=%p\n",__FUNCTION__,__LINE__,i,dec400_table_bus_address_base,dec400_table_base);*/
					}	
#if 0                    
					y_size = pic->pictures[i].pic_height/4 * pic->pictures[i].pic_stride;
					if((pic->pictures[i].pic_height/4) & 1 ==1)
						uv_size = (pic->pictures[i].pic_height/4+1)/2 * pic->pictures[i].pic_stride_ch;
					else
						uv_size = pic->pictures[i].pic_height/4/2 * pic->pictures[i].pic_stride_ch;
#else
          y_size = NEXT_MULTIPLE(pic->pictures[i].pic_height, 4)/4 * pic->pictures[i].pic_stride;
          uv_size = NEXT_MULTIPLE(pic->pictures[i].pic_height/2, 4)/4 * pic->pictures[i].pic_stride_ch;
#endif					
					pic->pictures[i].luma_table.size = NEXT_MULTIPLE(y_size/1024/4 +((y_size%4096)?1:0), 16);
					pic->pictures[i].chroma_table.size = NEXT_MULTIPLE(uv_size/1024/4 +((uv_size%4096)?1:0), 16);
					dec400_table_offset +=y_size + PP_LUMA_BUF_RES;
					dec400_table_offset +=uv_size + PP_CHROMA_BUF_RES;
				}

			}
		}
		/*printf("\n\n--in %s : %d dec400_table_bus_address_base=0x%x,dec400_table_offset=0x%x\n",__FUNCTION__,__LINE__,dec400_table_bus_address_base,dec400_table_offset);*/
		for(i=1;i<DEC_MAX_OUT_COUNT;i++)
		{
			#ifndef NEW_MEM_ALLOC
			if(pic->pictures[i].luma.virtual_address!= NULL)
			#else
			if(pic->pictures[i].luma.bus_address!= 0)
			#endif
			{
			#ifndef NEW_MEM_ALLOC
				pic->pictures[i].luma_table.virtual_address = (u32 *)((u8 *)dec400_table_base + dec400_table_offset + DEC400_PPn_Y_TABLE_OFFSET(i-1));
			#endif
				pic->pictures[i].luma_table.bus_address = dec400_table_bus_address_base + dec400_table_offset + DEC400_PPn_Y_TABLE_OFFSET(i-1);
			#ifndef NEW_MEM_ALLOC
				pic->pictures[i].chroma_table.virtual_address = (u32 *)((u8 *)dec400_table_base + dec400_table_offset + DEC400_PPn_UV_TABLE_OFFSET(i-1));
			#endif
				pic->pictures[i].chroma_table.bus_address = dec400_table_bus_address_base + dec400_table_offset + DEC400_PPn_UV_TABLE_OFFSET(i-1);
			}

		}
		/*	
		for(i=0;i<DEC_MAX_OUT_COUNT;i++)
		{
			if(pic->pictures[i].luma.virtual_address != NULL)
			{		
			printf("\n--in %s : %d pic%d Y_table =%p(0x%x),size=%d,UV_table =%p(0x%x),size=%d\n",
					__FUNCTION__,
					__LINE__,
					i,
					pic->pictures[i].luma_table.virtual_address,
					pic->pictures[i].luma_table.bus_address,
					pic->pictures[i].luma_table.size,
					pic->pictures[i].chroma_table.virtual_address,
					pic->pictures[i].chroma_table.bus_address,
					pic->pictures[i].chroma_table.size);
			}
		}*/
#else
    u32 y_size=0;

    for(i=0;i<DEC_MAX_OUT_COUNT;i++)
    {
        pic->pictures[i].pic_compressed_status = 0;
    }

#endif

    return rv;
}

enum DecRet H264PictureConsumedNoDWL(void* inst, struct DecPicturePpu pic) {
    H264DecPicture hpic;
    u32 i;
    
    memset(&hpic, 0, sizeof(H264DecPicture));
    /* TODO update chroma luma/chroma base */
    for (i = 0; i < DEC_MAX_OUT_COUNT; i++) {
#ifndef NEW_MEM_ALLOC
        hpic.pictures[i].output_picture = pic.pictures[i].luma.virtual_address;
#endif
        hpic.pictures[i].output_picture_bus_address = pic.pictures[i].luma.bus_address;
    }
    hpic.is_idr_picture[0] = pic.pictures[0].picture_info.pic_coding_type == DEC_PIC_TYPE_I;
    
    return H264DecPictureConsumed(inst, &hpic);
}
#if 0
void fb_h264_release_ext_buffers(HantroDecContext *fb_dec_ctx) {
    int i;
    
    pthread_mutex_lock(&fb_dec_ctx->ext_buffer_contro);
    for(i=0; i<fb_dec_ctx->num_buffers; i++) {
    av_log(NULL, AV_LOG_DEBUG, "Freeing buffer %p\n", (void *)fb_dec_ctx->ext_buffers[i].virtual_address);
    if (fb_dec_ctx->pp_enabled)
    DWLFreeLinear(fb_dec_ctx->dwl_inst, &fb_dec_ctx->ext_buffers[i]);
    else
    DWLFreeRefFrm(fb_dec_ctx->dwl_inst, &fb_dec_ctx->ext_buffers[i]);

    DWLmemset(&fb_dec_ctx->ext_buffers[i], 0, sizeof(fb_dec_ctx->ext_buffers[i]));
    }
    pthread_mutex_unlock(&fb_dec_ctx->ext_buffer_contro);
}
#endif

void fb_h264_handle_fatal_error() {
    av_log(NULL, AV_LOG_DEBUG, "Fatal system error\n");
}
#if 0
void ReleaseExtBuffers(AVCodecContext *avctx) {

    HantroDecContext *fb_dec_ctx = avctx->priv_data;
    int i;
    
    pthread_mutex_lock(&fb_dec_ctx->ext_buffer_contro);
    for(i=0; i<fb_dec_ctx->num_buffers; i++) {
        if (fb_dec_ctx->pp_enabled)
            DWLFreeLinear(fb_dec_ctx->dwl_inst, &fb_dec_ctx->ext_buffers[i]);
        else
            DWLFreeRefFrm(fb_dec_ctx->dwl_inst, &fb_dec_ctx->ext_buffers[i]);

        DWLmemset(&fb_dec_ctx->ext_buffers[i], 0, sizeof(fb_dec_ctx->ext_buffers[i]));
    }
    pthread_mutex_unlock(&fb_dec_ctx->ext_buffer_contro);
}
#endif
