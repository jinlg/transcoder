/*------------------------------------------------------------------------------
--                                                                                                                               --
--       This software is confidential and proprietary and may be used                                   --
--        only as expressly authorized by a licensing agreement from                                     --
--                                                                                                                               --
--                            Verisilicon.                                                                                    --
--                                                                                                                               --
--                   (C) COPYRIGHT 2014 VERISILICON                                                            --
--                            ALL RIGHTS RESERVED                                                                    --
--                                                                                                                               --
--                 The entire notice above must be reproduced                                                 --
--                  on all copies and should not be removed.                                                    --
--                                                                                                                               --
--------------------------------------------------------------------------------*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#ifdef _WIN32
#include <io.h>
#include <process.h>
#else
#include <pthread.h>
#include <unistd.h>
#include <sys/wait.h>
#include <sys/time.h>
#endif

#include "base_type.h"
#include "error.h"
#include "hevcencapi.h"
#include "encasiccontroller.h"
#include "instance.h"
#include "enccommon.h"
#include "hantro_h26xenc.h"

#ifdef INTERNAL_TEST
#include "sw_test_id.h"
#endif
#ifdef TEST_DATA
#include "enctrace.h"
#endif
#include "tools.h"

#ifdef SUPPORT_TCACHE
#include "dtrc_api.h"
#endif


#include "libavutil/avassert.h"
#include "libavutil/common.h"
#include "libavutil/internal.h"
#include "libavutil/opt.h"
#include "libavutil/pixfmt.h"
#include "libavutil/imgutils.h"


#include "hantro_enc_options.h"
#include "hantro_enc_pic_config.h"
#include "hantro_enc_utils.h"

#include "ewl.h"
#include "trans_mem_api.h"


#define MAX_LINE_LENGTH_BLOCK 512*8

//           Type POC QPoffset  QPfactor  num_ref_pics ref_pics  used_by_cur
char *RpsDefault_GOPSize_1[] = {
    "Frame1:  P    1   0        0.578     0      1        -1         1",
    NULL,
};
char *RpsDefault_H264_GOPSize_1[] = {
    "Frame1:  P    1   0        0.4     0      1        -1         1",
    NULL,
};

char *RpsDefault_GOPSize_2[] = {
    "Frame1:  P    2   0        0.6     0      1        -2         1",
    "Frame2:  B    1   0        0.68    0      2        -1 1       1 1",
    NULL,
};

char *RpsDefault_GOPSize_3[] = {
    "Frame1:  P    3   0        0.5     0      1        -3         1   ",
    "Frame2:  B    1   0        0.5     0      2        -1 2       1 1 ",
    "Frame3:  B    2   0        0.68    0      2        -1 1       1 1 ",
    NULL,
};


char *RpsDefault_GOPSize_4[] = {
    "Frame1:  P    4   0        0.5      0     1       -4         1 ",
    "Frame2:  B    2   0        0.3536   0     2       -2 2       1 1", 
    "Frame3:  B    1   0        0.5      0     3       -1 1 3     1 1 0", 
    "Frame4:  B    3   0        0.5      0     2       -1 1       1 1 ",
    NULL,
};

char *RpsDefault_GOPSize_5[] = {
    "Frame1:  P    5   0        0.442    0     1       -5         1 ",
    "Frame2:  B    2   0        0.3536   0     2       -2 3       1 1", 
    "Frame3:  B    1   0        0.68     0     3       -1 1 4     1 1 0", 
    "Frame4:  B    3   0        0.3536   0     2       -1 2       1 1 ",
    "Frame5:  B    4   0        0.68     0     2       -1 1       1 1 ",
    NULL,
};

char *RpsDefault_GOPSize_6[] = {
    "Frame1:  P    6   0        0.442    0     1       -6         1 ",
    "Frame2:  B    3   0        0.3536   0     2       -3 3       1 1", 
    "Frame3:  B    1   0        0.3536   0     3       -1 2 5     1 1 0", 
    "Frame4:  B    2   0        0.68     0     3       -1 1 4     1 1 0",
    "Frame5:  B    4   0        0.3536   0     2       -1 2       1 1 ",
    "Frame6:  B    5   0        0.68     0     2       -1 1       1 1 ",
    NULL,
};

char *RpsDefault_GOPSize_7[] = {
    "Frame1:  P    7   0        0.442    0     1       -7         1 ",
    "Frame2:  B    3   0        0.3536   0     2       -3 4       1 1", 
    "Frame3:  B    1   0        0.3536   0     3       -1 2 6     1 1 0", 
    "Frame4:  B    2   0        0.68     0     3       -1 1 5     1 1 0",
    "Frame5:  B    5   0        0.3536   0     2       -2 2       1 1 ",
    "Frame6:  B    4   0        0.68     0     3       -1 1 3     1 1 0",
    "Frame7:  B    6   0        0.68     0     2       -1 1       1 1 ",
    NULL,
};

char *RpsDefault_GOPSize_8[] = {
    "Frame1:  P    8   0        0.442    0  1           -8        1 ",
    "Frame2:  B    4   0        0.3536   0  2           -4 4      1 1 ",
    "Frame3:  B    2   0        0.3536   0  3           -2 2 6    1 1 0 ",
    "Frame4:  B    1   0        0.68     0  4           -1 1 3 7  1 1 0 0",
    "Frame5:  B    3   0        0.68     0  3           -1 1 5    1 1 0",
    "Frame6:  B    6   0        0.3536   0  2           -2 2      1 1",
    "Frame7:  B    5   0        0.68     0  3           -1 1 3    1 1 0",
    "Frame8:  B    7   0        0.68     0  2           -1 1      1 1",
    NULL,
};

char *RpsDefault_Interlace_GOPSize_1[] = {
    "Frame1:  P    1   0        0.8       0   2           -1 -2     0 1",
    NULL,
};

char *RpsLowdelayDefault_GOPSize_1[] = {
    "Frame1:  B    1   0        0.65      0     2       -1 -2         1 1",
    NULL,
};

char *RpsLowdelayDefault_GOPSize_2[] = {
    "Frame1:  B    1   0        0.4624    0     2       -1 -3         1 1",
    "Frame2:  B    2   0        0.578     0     2       -1 -2         1 1", 
    NULL,
};

char *RpsLowdelayDefault_GOPSize_3[] = {
    "Frame1:  B    1   0        0.4624    0     2       -1 -4         1 1",
    "Frame2:  B    2   0        0.4624    0     2       -1 -2         1 1", 
    "Frame3:  B    3   0        0.578     0     2       -1 -3         1 1", 
    NULL,
};

char *RpsLowdelayDefault_GOPSize_4[] = {
    "Frame1:  B    1   0        0.4624    0     2       -1 -5         1 1",
    "Frame2:  B    2   0        0.4624    0     2       -1 -2         1 1", 
    "Frame3:  B    3   0        0.4624    0     2       -1 -3         1 1", 
    "Frame4:  B    4   0        0.578     0     2       -1 -4         1 1",
    NULL,
};

char *RpsPass2_GOPSize_4[] = {
    "Frame1:  B    4   0        0.5      0     2       -4 -8      1 1",
    "Frame2:  B    2   0        0.3536   0     2       -2 2       1 1",
    "Frame3:  B    1   0        0.5      0     3       -1 1 3     1 1 0",
    "Frame4:  B    3   0        0.5      0     3       -1 -3 1    1 0 1",
    NULL,
};

char *RpsPass2_GOPSize_8[] = {
    "Frame1:  B    8   0        0.442    0  2           -8 -16    1 1",
    "Frame2:  B    4   0        0.3536   0  2           -4 4      1 1",
    "Frame3:  B    2   0        0.3536   0  3           -2 2 6    1 1 0",
    "Frame4:  B    1   0        0.68     0  4           -1 1 3 7  1 1 0 0",
    "Frame5:  B    3   0        0.68     0  4           -1 -3 1 5 1 0 1 0",
    "Frame6:  B    6   0        0.3536   0  3           -2 -6 2   1 0 1",
    "Frame7:  B    5   0        0.68     0  4           -1 -5 1 3 1 0 1 0",
    "Frame8:  B    7   0        0.68     0  3           -1 -7 1   1 0 1",
    NULL,
};

char *RpsPass2_GOPSize_2[] = {
    "Frame1:  B    2   0        0.6     0      2        -2 -4      1 1",
    "Frame2:  B    1   0        0.68    0      2        -1 1       1 1",
    NULL,
};

static FILE *yuv_out = NULL;

/*------------------------------------------------------------------------------
  open_file
------------------------------------------------------------------------------*/
FILE *open_file(char *name, char *mode)
{
  FILE *fp;

  if (!(fp = fopen(name, mode)))
  {
    //Error(4, ERR, name, ", ", SYSERR);
  }

  return fp;
}


/*------------------------------------------------------------------------------

    WriteStrm
        Write encoded stream to file

    Params:
        fout    - file to write
        strbuf  - data to be written
        size    - amount of data to write
        endian  - data endianess, big or little

------------------------------------------------------------------------------*/
void WriteNals(FILE *fout, u32 *strmbuf, const u32 *pNaluSizeBuf, u32 numNalus, u32 hdrSize, u32 endian)
{
  const u8 start_code_prefix[4] = {0x0, 0x0, 0x0, 0x1};
  u32 count = 0;
  u32 offset = 0;
  u32 size;
  u8  *stream;

#ifdef NO_OUTPUT_WRITE
  return;
#endif

  ASSERT(endian == 0); //FIXME: not support abnormal endian now.

  stream = (u8 *)strmbuf;
  while (count++ < numNalus && *pNaluSizeBuf != 0)
  {
    fwrite(start_code_prefix, 1, 4, fout);
    size = *pNaluSizeBuf++;
    fwrite(stream + offset + size-hdrSize, 1, hdrSize, fout);
    fwrite(stream + offset, 1, size-hdrSize, fout);
    offset += size;
  }

}

#if 0
/*------------------------------------------------------------------------------
    WriteNalSizesToFile
        Dump NAL size to a file

    Params:
        file         - file name where toi dump
        pNaluSizeBuf - buffer where the individual NAL size are (return by API)
        numNalus     - amount of NAL units in the above buffer
------------------------------------------------------------------------------*/
void WriteNalSizesToFile(FILE *file, const u32 *pNaluSizeBuf,
                         u32 numNalus)
{
  u32 offset = 0;


  while (offset++ < numNalus && *pNaluSizeBuf != 0)
  {
    fprintf(file, "%d\n", *pNaluSizeBuf++);
  }


}
#endif


/*------------------------------------------------------------------------------

    WriteStrm
        Write encoded stream to file

    Params:
        fout    - file to write
        strbuf  - data to be written
        size    - amount of data to write
        endian  - data endianess, big or little

------------------------------------------------------------------------------*/
void WriteStrm(FILE *fout, u32 *strmbuf, u32 size, u32 endian)
{
  void * tb = NULL;
#ifdef NO_OUTPUT_WRITE
  return;
#endif

  if (!fout || !strmbuf || !size) return;

  /* Swap the stream endianess before writing to file if needed */
  if (endian == 1)
  {
    u32 i = 0, words = (size + 3) / 4;

    while (words)
    {
      u32 val = strmbuf[i];
      u32 tmp = 0;

      tmp |= (val & 0xFF) << 24;
      tmp |= (val & 0xFF00) << 8;
      tmp |= (val & 0xFF0000) >> 8;
      tmp |= (val & 0xFF000000) >> 24;
      strmbuf[i] = tmp;
      words--;
      i++;
    }

  }
  ENC_TB_DEBUGV_PRINT("Write out stream size %d \n", size);
  /* Write the stream to file */
  fwrite(strmbuf, 1, size, fout);
}

/*------------------------------------------------------------------------------

    WriteStrmBufs
        Write encoded stream to file

    Params:
        fout - file to write
        bufs - stream buffers
        offset - stream buffer offset
        size - amount of data to write
        endian - data endianess, big or little

------------------------------------------------------------------------------*/
void writeStrmBufs (FILE *fout, VCEncStrmBufs *bufs, u32 offset, u32 size, u32 endian)
{
  u8 *buf0 = bufs->buf[0];
  u8 *buf1 = bufs->buf[1];
  u32 buf0Len = bufs->bufLen[0];

  if (!buf0) return;
  
  if (offset < buf0Len)
  {
    u32 size0 = MIN(size, buf0Len-offset);
    WriteStrm(fout, (u32 *)(buf0 + offset), size0, endian);
    if ((size0 < size) && buf1)
      WriteStrm(fout, (u32 *)buf1, size-size0, endian);
  }
  else if (buf1)
  {
    WriteStrm(fout, (u32 *)(buf1 + offset - buf0Len), size, endian);
  }  
}

/*------------------------------------------------------------------------------

    WriteNalsBufs
        Write encoded stream to file

    Params:
        fout - file to write
        bufs - stream buffers
        pNaluSizeBuf - nalu size buffer
        numNalus - the number of nalu
        offset - stream buffer offset
        hdrSize - header size
        endian - data endianess, big or little

------------------------------------------------------------------------------*/
void writeNalsBufs (FILE *fout, VCEncStrmBufs *bufs, const u32 *pNaluSizeBuf, u32 numNalus, u32 offset, u32 hdrSize, u32 endian)
{
  const u8 start_code_prefix[4] = {0x0, 0x0, 0x0, 0x1};
  u32 count = 0;
  u32 size;
  u8  *stream;

#ifdef NO_OUTPUT_WRITE
  return;
#endif

  ASSERT(endian == 0); //FIXME: not support abnormal endian now.

  while (count++ < numNalus && *pNaluSizeBuf != 0)
  {
    fwrite(start_code_prefix, 1, 4, fout);
    size = *pNaluSizeBuf++;

    writeStrmBufs (fout, bufs, offset + size - hdrSize, hdrSize,        endian);
    writeStrmBufs (fout, bufs, offset,                  size - hdrSize, endian);

    offset += size;
  }
}

void getStreamBufs (VCEncStrmBufs *bufs, struct test_bench *tb, HANTROH26xEncOptions *options, bool encoding)
{
  i32 i;
  for (i = 0; i < MAX_STRM_BUF_NUM; i ++)
  {
#ifdef USE_OLD_DRV
    bufs->buf[i]    = tb->outbufMem[i] ? (u8 *)tb->outbufMem[i]->virtualAddress : NULL;
#else
    bufs->buf[i]    = tb->outbufMem[i] ? (u8 *)tb->outbufMem[i]->rc_virtualAddress : NULL;
#endif
    bufs->bufLen[i] = tb->outbufMem[i] ? tb->outbufMem[i]->size : 0;
  }

#ifdef INTERNAL_TEST
  if (encoding && (options->testId == TID_INT) && options->streamBufChain && (options->parallelCoreNum <= 1))
    HevcStreamBufferLimitTest(NULL, bufs);
#endif
}

/*------------------------------------------------------------------------------

    WriteScaled
        Write scaled image to file "scaled_wxh.yuyv", support interleaved yuv422 only.

    Params:
        strbuf  - data to be written
        inst    - encoder instance

------------------------------------------------------------------------------*/
void WriteScaled(u32 *strmbuf, VCEncInst inst)
{

#ifdef NO_OUTPUT_WRITE
  return;
#endif

  struct vcenc_instance *vcenc_instance = (struct vcenc_instance *)inst;
  if (!strmbuf || !vcenc_instance)
    return;

  u32 format = vcenc_instance->preProcess.scaledOutputFormat;
  u32 width = vcenc_instance->preProcess.scaledWidth;
  u32 height = vcenc_instance->preProcess.scaledHeight;
  u32 size =  width * height * 2;
  if (format == 1)
    size = width * height * 3 / 2;
    
  if (!size)
    return;

  char fname[100];
  if (format == 0)
    sprintf(fname, "scaled_%dx%d.yuyv", width, height);
  else
    sprintf(fname, "scaled_%dx%d.yuv", width, height);

  FILE *fout = fopen(fname, "ab+");
  if (fout == NULL)
    return;

  fwrite(strmbuf, 1, size, fout);

  fclose(fout);
}

static void writeFlags2Memory(char flag, u8* memory,u16 column,u16 row,u16 blockunit,u16 width, u16 ctb_size, u32 ctb_per_row, u32 ctb_per_column)
{
  u32 blks_per_ctb = ctb_size/8;
  u32 blks_per_unit = 1<<(3-blockunit);
  u32 ctb_row_number    = row*blks_per_unit    / blks_per_ctb;
  u32 ctb_column_number = column*blks_per_unit / blks_per_ctb;
  u32 ctb_row_stride = ctb_per_row * blks_per_ctb * blks_per_ctb;  
  u32 xoffset = (column*blks_per_unit) % blks_per_ctb;
  u32 yoffset = (row*blks_per_unit) % blks_per_ctb;
  u32 stride = blks_per_ctb;
  u32 columns, rows, r, c;

  rows = columns = blks_per_unit;
  if(blks_per_ctb < blks_per_unit)
  {
    rows = MIN(rows, ctb_per_column*blks_per_ctb - row*blks_per_unit);
    columns = MIN(columns, ctb_per_row*blks_per_ctb - column*blks_per_unit);
    rows /= blks_per_ctb;
    columns *= blks_per_ctb;
    stride = ctb_row_stride;
  }

  // ctb addr --> blk addr
  memory += ctb_row_number*ctb_row_stride + ctb_column_number*(blks_per_ctb*blks_per_ctb);
  memory += yoffset * stride + xoffset;
  for(r=0;r<rows;r++)
  {
    u8 *dst = memory + r*stride;
    u8 val;
    for(c=0;c<columns;c++)
    {
      val = *dst;
      *dst++ = (val&0x7f) | (flag << 7);
    }
  }
}

static void writeFlagsRowData2Memory(char* rowStartAddr,u8* memory,u16 width,u16 rowNumber,u16 blockunit, u16 ctb_size, u32 ctb_per_row, u32 ctb_per_column)
{
  int i;
  i=0;
  while(i<width)
  {
    writeFlags2Memory(*rowStartAddr,memory,i,rowNumber,blockunit,width, ctb_size, ctb_per_row, ctb_per_column);
    rowStartAddr++;
    i++;
  }
}

static void writeQpValue2Memory(char qpDelta, u8* memory,u16 column,u16 row,u16 blockunit,u16 width, u16 ctb_size, u32 ctb_per_row, u32 ctb_per_column)
{
  u32 blks_per_ctb = ctb_size/8;
  u32 blks_per_unit = 1<<(3-blockunit);
  u32 ctb_row_number    = row*blks_per_unit    / blks_per_ctb;
  u32 ctb_column_number = column*blks_per_unit / blks_per_ctb;
  u32 ctb_row_stride = ctb_per_row * blks_per_ctb * blks_per_ctb;  
  u32 xoffset = (column*blks_per_unit) % blks_per_ctb;
  u32 yoffset = (row*blks_per_unit) % blks_per_ctb;
  u32 stride = blks_per_ctb;
  u32 columns, rows, r, c;

  rows = columns = blks_per_unit;
  if(blks_per_ctb < blks_per_unit)
  {
    rows = MIN(rows, ctb_per_column*blks_per_ctb - row*blks_per_unit);
    columns = MIN(columns, ctb_per_row*blks_per_ctb - column*blks_per_unit);
    rows /= blks_per_ctb;
    columns *= blks_per_ctb;
    stride = ctb_row_stride;
  }

  // ctb addr --> blk addr
  memory += ctb_row_number*ctb_row_stride + ctb_column_number*(blks_per_ctb*blks_per_ctb);
  memory += yoffset * stride + xoffset;
  for(r=0;r<rows;r++)
  {
    u8 *dst = memory + r*stride;
    for(c=0;c<columns;c++)
      *dst++ = qpDelta;
  }
}


static void writeQpDeltaData2Memory(char qpDelta,u8* memory,u16 column,u16 row,u16 blockunit,u16 width, u16 ctb_size, u32 ctb_per_row, u32 ctb_per_column)
{
  u8 twoBlockDataCombined;
  int r,c;
  u32 blks_per_ctb = ctb_size/8;
  u32 blks_per_unit = (1<<(3-blockunit));
  u32 ctb_row_number=row*blks_per_unit/blks_per_ctb;
  u32 ctb_row_stride=ctb_per_row*(blks_per_ctb*blks_per_ctb)/2;
  u32 ctb_row_offset=(blks_per_ctb < blks_per_unit ? 0 : row-(row/(blks_per_ctb/blks_per_unit))*(blks_per_ctb/blks_per_unit))*blks_per_unit;
  u32 internal_ctb_stride=blks_per_ctb/2;
  u32 ctb_column_number;
  u8* rowMemoryStartPtr=memory+ctb_row_number*ctb_row_stride;
  u8* ctbMemoryStartPtr, *curMemoryStartPtr;
  u32 columns,rows;
  u32 xoffset;

  {
    ctb_column_number=column*blks_per_unit/blks_per_ctb;
    ctbMemoryStartPtr=rowMemoryStartPtr+ctb_column_number*(blks_per_ctb*blks_per_ctb)/2;
    switch(blockunit)
    {
      case 0:
        twoBlockDataCombined=(-qpDelta&0X0F)|(((-qpDelta&0X0F))<<4);
        rows=8;
        columns=4;
        xoffset=0;
        break;
      case 1:
        twoBlockDataCombined=(-qpDelta&0X0F)|(((-qpDelta&0X0F))<<4);
        rows=4;
        columns=2;
        xoffset=column%((ctb_size+31)/32);
        xoffset=xoffset<<1;
        break;
      case 2:
        twoBlockDataCombined=(-qpDelta&0X0F)|(((-qpDelta&0X0F))<<4);
        rows=2;
        columns=1;
        xoffset=column%((ctb_size+15)/16);
        break;
      case 3:
        xoffset=column>>1;
        xoffset=xoffset%((ctb_size+15)/16);
        curMemoryStartPtr=ctbMemoryStartPtr+ctb_row_offset*internal_ctb_stride + xoffset;
        twoBlockDataCombined=*curMemoryStartPtr;
        if(column%2)
        {
          twoBlockDataCombined=(twoBlockDataCombined&0x0f)|(((-qpDelta&0X0F))<<4);
        }
        else
        {
          twoBlockDataCombined=(twoBlockDataCombined&0xf0)|(-qpDelta&0X0F);
        }
        rows=1;
        columns=1;
        break;
      default:
        rows=0;
        twoBlockDataCombined=0;
        columns=0;
        xoffset=0;
        break;
    }
    u32 stride = internal_ctb_stride;
    if(blks_per_ctb < blks_per_unit) {
      rows = MIN(rows, ctb_per_column*blks_per_ctb-row*blks_per_unit);
      columns = MIN(columns, (ctb_per_row*blks_per_ctb-column*blks_per_unit)/2);
      rows /= blks_per_ctb;
      columns *= blks_per_ctb;
      stride = ctb_row_stride;
    }
    for(r=0;r<rows;r++)
    {
      curMemoryStartPtr=ctbMemoryStartPtr+(ctb_row_offset+r)*stride + xoffset;
      for(c=0;c<columns;c++)
      {
        *curMemoryStartPtr++=twoBlockDataCombined;
      }
    }
  }
}

static void writeQpDeltaRowData2Memory(char* qpDeltaRowStartAddr,u8* memory,u16 width,u16 rowNumber,u16 blockunit, u16 ctb_size, u32 ctb_per_row, u32 ctb_per_column, i32 roiMapVersion)
{
  i32 i = 0;
  while(i<width)
  {
    if (roiMapVersion >= 1)
      writeQpValue2Memory(*qpDeltaRowStartAddr,memory,i,rowNumber,blockunit,width, ctb_size, ctb_per_row, ctb_per_column);
    else
      writeQpDeltaData2Memory(*qpDeltaRowStartAddr,memory,i,rowNumber,blockunit,width, ctb_size, ctb_per_row, ctb_per_column);

    qpDeltaRowStartAddr++;
    i++;
  }
}

static i32 copyQPDelta2Memory (HANTROH26xEncOptions *options, VCEncInst enc, struct test_bench *tb, i32 roiMapVersion)
{
#define MAX_LINE_LENGTH_BLOCK 512*8

  i32 ret = OK;
  u32 ctb_per_row = ((options->width+options->max_cu_size-1)/ (options->max_cu_size));
  u32 ctb_per_column = ((options->height+options->max_cu_size-1)/ (options->max_cu_size));
  FILE *roiMapFile = tb->roiMapFile;
#ifdef USE_OLD_DRV
  u8* memory = (u8*)tb->roiMapDeltaQpMem->virtualAddress;
#else
  u8* memory = (u8*)tb->roiMapDeltaQpMem->rc_virtualAddress;
#endif
  u16 block_unit;
  switch(options->roiMapDeltaQpBlockUnit)
  {
    case 0:
      block_unit=64;
      break;
    case 1:
      block_unit=32;
      break;
    case 2:
      block_unit=16;
      break;
    case 3:
      block_unit=8;
      break;
    default:
      block_unit=64;
      break;
  }
  u16 width = (((options->width+options->max_cu_size-1)& (~(options->max_cu_size - 1)))+block_unit-1)/block_unit;
  u16 height = (((options->height+options->max_cu_size-1)& (~(options->max_cu_size - 1)))+block_unit-1)/block_unit;
  u16 blockunit = options->roiMapDeltaQpBlockUnit;
  u16 ctb_size = options->max_cu_size;
  char rowbuffer[1024];
  i32 line_idx = 0, i;
  i32 qpdelta, qptype, qpdelta_num=0;
  char* rowbufferptr;
  char *achParserBuffer = (char *)EWLmalloc(sizeof(char) * MAX_LINE_LENGTH_BLOCK);

  if (achParserBuffer == NULL)
  {
    ENC_TB_ERROR_PRINT("Qp delta config Error: fail to alloc buffer!\n");
    ret = NOK;
    goto copyEnd;
  }

  if (roiMapFile == NULL)
  {
    //printf("Qp delta config: Error, Can Not Open File %s\n", fname );
    ret = NOK;
    goto copyEnd;
  }
  
  while (line_idx < height)
  {
    achParserBuffer[0] = '\0';
    // Read one line
    char *line = fgets ((char *) achParserBuffer, MAX_LINE_LENGTH_BLOCK, roiMapFile);
    if (feof (roiMapFile))
    {
        fseek(roiMapFile,0L,SEEK_SET);
        if (!line)
          continue;
    }

    if (!line) break;
    //handle line end
    char* s = strpbrk(line, "#\n");
    if(s) *s = '\0';
  
    if (line)
    {
      i=0;
      rowbufferptr=rowbuffer;
      memset(rowbufferptr, 0, 1024);
      while(i<width)
      {
        // read data from file
        if (roiMapVersion)
        {
          //format: a%d: absolute QP; %d: QP delta 
          qptype = 0;
          if (*line == 'a')
          {
            qptype = 1;
            line ++;
          }
          sscanf (line, "%d", &qpdelta);
          if (qptype)
          {
            qpdelta = CLIP3(0,51,qpdelta);
#if 0
            if (qpdelta<0 || qpdelta>51)
            {
              printf("ROI Map File Error: Absolute Qp out of range: %d\n", qpdelta);
              ret = NOK;
              goto copyEnd;
            }
#endif
          }
          else
          {
            qpdelta = CLIP3(-31,32,qpdelta);
#if 0
            if (qpdelta<-31 || qpdelta>32)
            {
              printf("ROI Map File Error: Qp Delta out of range: %d\n", qpdelta);
              ret = NOK;
              goto copyEnd;
            }
#endif
            qpdelta = -qpdelta;
          }
          /* setup the map value */
          qpdelta &= 0x3f;
          if (roiMapVersion == 1)
          {
            qpdelta = (qpdelta << 1) | qptype;
          }
          else if (roiMapVersion == 2)
          {
            qpdelta |= (qptype ? 0 : 0x40);
          }
        }
        else
        {
          sscanf (line, "%d", &qpdelta);
          qpdelta = CLIP3(-15,0,qpdelta);
#if 0
          if(qpdelta>0||qpdelta<-15)
          {
            printf("Qp Delta out of range.\n");
              ret = NOK;
              goto copyEnd;
          }
#endif
        }

        // get qpdelta
        *(rowbufferptr++)=(char)qpdelta;
        i++;
        qpdelta_num++;

        // find next qpdelta
        line= strchr(line, ',');
        if (line)
        {
          while ((*line == ',') || (*line == ' ')) line ++;
          if (*line == '\0') break;
        }
        else
          break;
      }
      writeQpDeltaRowData2Memory(rowbuffer, memory, width, line_idx, 
                                 blockunit, ctb_size, ctb_per_row, ctb_per_column,
                                 roiMapVersion);
      line_idx ++;
    }
  }
  //fclose(fIn);
  if (qpdelta_num != width*height)
  {
    ENC_TB_ERROR_PRINT("QP delta Config: Error, Parsing File Failed\n");
    ret = NOK;
  }

copyEnd:
#ifndef USE_OLD_DRV
  if (EWLTransDataRC2EP(tb->ewl, tb->roiMapDeltaQpMem, tb->roiMapDeltaQpMem, tb->roiMapDeltaQpMem->size))
    ret = NOK;
#endif
  if(achParserBuffer) EWLfree (achParserBuffer);
  return ret;
}


static i32 clearQpDeltaMap(HANTROH26xEncOptions *options, VCEncInst enc, struct test_bench *tb)
{
  i32 ret = OK;
  i32 block_size=((options->width+options->max_cu_size-1)& (~(options->max_cu_size - 1)))*((options->height+options->max_cu_size-1)& (~(options->max_cu_size - 1)))/(8*8*2);
  if (((struct vcenc_instance *)enc)->asic.regs.asicCfg.roiMapVersion >= 1)
    block_size *= 2;
#ifdef USE_OLD_DRV
  memset(tb->roiMapDeltaQpMem->virtualAddress, 0, block_size);
#else
  memset(tb->roiMapDeltaQpMem->rc_virtualAddress, 0, block_size);
  if(EWLTransDataRC2EP(tb->ewl, tb->roiMapDeltaQpMem, tb->roiMapDeltaQpMem, tb->roiMapDeltaQpMem->size))
    ret = NOK;
#endif
  return ret;
}

static int copyFlagsMap2Memory(HANTROH26xEncOptions *options, VCEncInst enc, struct test_bench *tb)
{
  u32 ctb_per_row = ((options->width+options->max_cu_size-1)/ (options->max_cu_size));
  u32 ctb_per_column = ((options->height+options->max_cu_size-1)/ (options->max_cu_size));
#ifdef USE_OLD_DRV
  u8* memory = (u8*)tb->roiMapDeltaQpMem->virtualAddress;
#else
  u8* memory = (u8*)tb->roiMapDeltaQpMem->rc_virtualAddress;
#endif
  u16 ctb_size = options->max_cu_size;
  u16 blockunit;
  char achParserBuffer[MAX_LINE_LENGTH_BLOCK];
  char rowbuffer[MAX_LINE_LENGTH_BLOCK];
  int line_idx = 0,i;
  int flag, flag_num=0;
  char* rowbufferptr;
  u16 width, height, block_unit_size;
  i32 roiMapVersion = ((struct vcenc_instance *)enc)->asic.regs.asicCfg.roiMapVersion;
  FILE *mapFile = NULL;

  if(roiMapVersion == 3)
    roiMapVersion = options->RoiQpDeltaVer;
  
  if (roiMapVersion == 1)
  {
    mapFile = tb->ipcmMapFile;
    blockunit = (ctb_size == 64 ? 0 : 2);
  }
  else if (roiMapVersion == 2)
  {
    i32 blockUnitMax = IS_H264(options->codecFormat) ? 2 : 1;
    mapFile = tb->skipMapFile;
    blockunit = options->skipMapBlockUnit;
    if (blockunit > blockUnitMax)
    {
      ENC_TB_DEBUG_PRINT("SKIP Map Config: Error, Block size too small, changed to %dx%d\n", 8<<(3-blockUnitMax), 8<<(3-blockUnitMax));
      blockunit = blockUnitMax;
    }
  }

  if (mapFile == NULL)
  {
    //printf("Qp delta config: Error, Can Not Open File %s\n", fname );
    return -1;
  }

  block_unit_size = 8 << (3-blockunit);  
  width = (((options->width+options->max_cu_size-1)& (~(options->max_cu_size - 1)))+block_unit_size-1)/block_unit_size;
  height = (((options->height+options->max_cu_size-1)& (~(options->max_cu_size - 1)))+block_unit_size-1)/block_unit_size;

  if (!tb->roiMapFile)
  {
    i32 block_size = ((options->width+options->max_cu_size-1)& (~(options->max_cu_size - 1)))*((options->height+options->max_cu_size-1)& (~(options->max_cu_size - 1)))/(8*8*2);
    if (roiMapVersion)
      block_size *= 2;
#ifdef USE_OLD_DRV
    memset(tb->roiMapDeltaQpMem->virtualAddress, 0, block_size);
#else
    memset(tb->roiMapDeltaQpMem->rc_virtualAddress, 0, block_size);
    if (EWLTransDataRC2EP(tb->ewl, tb->roiMapDeltaQpMem, tb->roiMapDeltaQpMem, tb->roiMapDeltaQpMem->size))
      return -1;
#endif
  }

  while (line_idx < height)
  {
    achParserBuffer[0] = '\0';
    // Read one line
    char *line = fgets ((char *) achParserBuffer, MAX_LINE_LENGTH_BLOCK, mapFile);    
    if (feof (mapFile))
    {
        fseek(mapFile,0L,SEEK_SET);
        if (!line)
          continue;
    }

    if (!line) break;
    //handle line end
    char* s = strpbrk(line, "#\n");
    if(s) *s = '\0';
  
    if (line)
    {
      i=0;
      rowbufferptr=rowbuffer;
      memset(rowbufferptr, 0, MAX_LINE_LENGTH_BLOCK);
      
      while(i<width)
      {
        sscanf (line, "%d", &flag);
        if(flag < 0 || flag > 1)
        {
          ENC_TB_ERROR_PRINT("Invalid IPCM/SKIP map entry.\n");
          return -1;
        }
        *(rowbufferptr++)=(char)flag;
        i++;
        flag_num++;
        line= strchr(line, ',');
        if (line)
        {
          while (*line == ',') line ++;
          if (*line == '\0') break;
        }
        else
          break;
      }
      writeFlagsRowData2Memory(rowbuffer,memory,width,line_idx,blockunit, ctb_size, ctb_per_row, ctb_per_column);      
      line_idx ++;
    }
  }

  if (flag_num != width*height)
  {
    ENC_TB_ERROR_PRINT("IPCM/SKIP Map Config: Error, Parsing File Failed\n");
    return -1;
  }

  return 0;
}

float getPixelWidthInByte(VCEncPictureType type)
{
  switch (type)
  {
    case VCENC_YUV420_PLANAR_10BIT_PACKED_PLANAR:
      return 1.25;
    case VCENC_YUV420_10BIT_PACKED_Y0L2:
      return 2;
    case VCENC_YUV420_PLANAR_10BIT_I010:
    case VCENC_YUV420_PLANAR_10BIT_P010:
      return 2;
    case VCENC_YUV420_PLANAR:
    case VCENC_YUV420_SEMIPLANAR:
    case VCENC_YUV420_SEMIPLANAR_VU:
    case VCENC_YUV422_INTERLEAVED_YUYV:
    case VCENC_YUV422_INTERLEAVED_UYVY:
    case VCENC_RGB565:
    case VCENC_BGR565:
    case VCENC_RGB555:
    case VCENC_BGR555:
    case VCENC_RGB444:
    case VCENC_BGR444:
    case VCENC_RGB888:
    case VCENC_BGR888:
    case VCENC_RGB101010:
    case VCENC_BGR101010:
    case VCENC_YUV420_SEMIPLANAR_101010:
      return 1;
    default:
      return 1;
  }
}

void getAlignedPicSizebyFormat(i32 type,u32 width, u32 height, u32 alignment,
                               u32 *luma_Size,u32 *chroma_Size,u32 *picture_Size)
{
  u32 luma_stride=0, chroma_stride = 0;
  u32 lumaSize = 0, chromaSize = 0, pictureSize = 0;

  VCEncGetAlignedStride(width,type,&luma_stride,&chroma_stride,alignment);
  switch(type)
  {
    case VCENC_YUV420_PLANAR:
     lumaSize = luma_stride * height;
     chromaSize = chroma_stride * height/2*2;
     break;
    case VCENC_YUV420_SEMIPLANAR:
    case VCENC_YUV420_SEMIPLANAR_VU:
     lumaSize = luma_stride * height;
     chromaSize = chroma_stride * height/2;
     break;
    case VCENC_YUV422_INTERLEAVED_YUYV:
    case VCENC_YUV422_INTERLEAVED_UYVY:
    case VCENC_RGB565:
    case VCENC_BGR565:
    case VCENC_RGB555:
    case VCENC_BGR555:
    case VCENC_RGB444:
    case VCENC_BGR444:
    case VCENC_RGB888:
    case VCENC_BGR888:
    case VCENC_RGB101010:
    case VCENC_BGR101010:
     lumaSize = luma_stride * height;
     chromaSize = 0;
     break;
    case VCENC_YUV420_PLANAR_10BIT_I010:
     lumaSize = luma_stride * height;
     chromaSize = chroma_stride * height/2*2;
     break;
    case VCENC_YUV420_PLANAR_10BIT_P010:

     lumaSize = luma_stride * height;
     chromaSize = chroma_stride * height/2;
     break;
    case VCENC_YUV420_PLANAR_10BIT_PACKED_PLANAR:
     lumaSize = luma_stride *10/8 * height;
     chromaSize = chroma_stride *10/8* height/2*2;
     break;
    case VCENC_YUV420_10BIT_PACKED_Y0L2:
     lumaSize = luma_stride *2*2* height/2;
     chromaSize = 0;
     break;
    case VCENC_YUV420_PLANAR_8BIT_DAHUA_HEVC:
     lumaSize = luma_stride * ((height + 32 - 1) & (~(32 - 1)));
     chromaSize = lumaSize/2;
     break;
    case VCENC_YUV420_PLANAR_8BIT_DAHUA_H264:
     lumaSize = luma_stride * height * 2* 12/ 8;
     chromaSize = 0;
     break; 
    case VCENC_YUV420_SEMIPLANAR_8BIT_FB:
    case VCENC_YUV420_SEMIPLANAR_VU_8BIT_FB:
     lumaSize = luma_stride * ((height+3)/4);
     chromaSize = chroma_stride * (((height/2)+3)/4);
     break;
    case VCENC_YUV420_PLANAR_10BIT_P010_FB:
     lumaSize = luma_stride * ((height+3)/4);
     chromaSize = chroma_stride * (((height/2)+3)/4);
     break;
    case VCENC_YUV420_SEMIPLANAR_101010:
     lumaSize = luma_stride * height;
     chromaSize = chroma_stride * height/2;
     break;
    case VCENC_YUV420_8BIT_TILE_64_4:
    case VCENC_YUV420_UV_8BIT_TILE_64_4:
     lumaSize = luma_stride *  ((height+3)/4);
     chromaSize = chroma_stride * (((height/2)+3)/4);
     break;
    case VCENC_YUV420_10BIT_TILE_32_4:
     lumaSize = luma_stride * ((height+3)/4);
     chromaSize = chroma_stride * (((height/2)+3)/4);
     break;
    case VCENC_YUV420_10BIT_TILE_48_4:
    case VCENC_YUV420_VU_10BIT_TILE_48_4:
     lumaSize = luma_stride * ((height+3)/4);
     chromaSize = chroma_stride * (((height/2)+3)/4);
     break;
    case VCENC_YUV420_8BIT_TILE_128_2:
    case VCENC_YUV420_UV_8BIT_TILE_128_2:
     lumaSize = luma_stride * ((height+1)/2);
     chromaSize = chroma_stride * (((height/2)+1)/2);
     break;
    case VCENC_YUV420_10BIT_TILE_96_2:
    case VCENC_YUV420_VU_10BIT_TILE_96_2:
     lumaSize = luma_stride * ((height+1)/2);
     chromaSize = chroma_stride * (((height/2)+1)/2);
     break;
	 
	/* fb format */ 
    case INPUT_FORMAT_PP_YUV420_SEMIPLANNAR_YUV420P:
    case INPUT_FORMAT_PP_YUV420_SEMIPLANNAR:
    case INPUT_FORMAT_PP_YUV420_SEMIPLANNAR_VU:
     luma_stride = STRIDE(width, alignment);
	 chroma_stride = STRIDE(width, alignment);
	 
     lumaSize = luma_stride * height;
     chromaSize = chroma_stride * height/2;
     break;	
	 
    case INPUT_FORMAT_PP_YUV420_PLANAR_10BIT_P010:
#ifdef SUPPORT_TCACHE
    case INPUT_FORMAT_YUV420_SEMIPLANAR_10BIT_P010BE:
#endif
     luma_stride = STRIDE(width*2, alignment);
	 chroma_stride = STRIDE(width*2, alignment);  

     lumaSize = luma_stride * height;
     chromaSize = chroma_stride * height/2;
     break;
	 
#ifdef SUPPORT_DEC400
    case INPUT_FORMAT_YUV420_SEMIPLANAR_8BIT_COMPRESSED_FB:
    case INPUT_FORMAT_YUV420_SEMIPLANAR_VU_8BIT_COMPRESSED_FB:
     luma_stride = STRIDE(width*4, alignment);
	 chroma_stride = STRIDE(width*4, alignment); 
	 
     lumaSize = luma_stride * ((height+3)/4);
     chromaSize = chroma_stride * (((height/2)+3)/4);
     break;

    case INPUT_FORMAT_YUV420_PLANAR_10BIT_P010_COMPRESSED_FB:
     luma_stride = STRIDE(width*4*2, alignment);
	 chroma_stride = STRIDE(width*4*2, alignment); 
	 
	 lumaSize = luma_stride * ((height+3)/4);
     chromaSize = chroma_stride * (((height/2)+3)/4);
     break;
#endif

#ifdef SUPPORT_TCACHE

    case INPUT_FORMAT_RFC_8BIT_COMPRESSED_FB:
	    luma_stride = STRIDE(width, DTRC_INPUT_WIDTH_ALIGNMENT);
	    lumaSize = luma_stride * STRIDE(height,DTRC_INPUT_HEIGHT_ALIGNMENT);
      //lumaSize = luma_stride * ((height+3)/4);
	    chromaSize = lumaSize/2;
	    break;
    case INPUT_FORMAT_RFC_10BIT_COMPRESSED_FB:
	    luma_stride = STRIDE(width, DTRC_INPUT_WIDTH_ALIGNMENT);
	    lumaSize = luma_stride * STRIDE(height,DTRC_INPUT_HEIGHT_ALIGNMENT)*10/8;
	    chromaSize = lumaSize/2;
	    break;
    case INPUT_FORMAT_YUV420_PLANAR_10BIT_P010LE:
    case INPUT_FORMAT_YUV420_PLANAR_10BIT_P010BE:
        luma_stride = STRIDE(width*2, alignment);
        chroma_stride = STRIDE((width/2)*2, alignment);
	    lumaSize = luma_stride * height;
	    chromaSize = chroma_stride * (height/2) * 2;
	    break;
    case INPUT_FORMAT_ARGB_FB:
    case INPUT_FORMAT_ABGR_FB:
    case INPUT_FORMAT_RGBA_FB:
    case INPUT_FORMAT_BGRA_FB:
      luma_stride = STRIDE(width*4, alignment);
      lumaSize = luma_stride * height;
      chromaSize = 0;
     break;
    case INPUT_FORMAT_RGB24_FB:
    case INPUT_FORMAT_BGR24_FB:
      luma_stride = STRIDE(width*3, alignment);
      lumaSize = luma_stride * height;
      chromaSize = 0;
      break;
    case INPUT_FORMAT_YUV422P:
      luma_stride = STRIDE(width, alignment);
      chroma_stride = STRIDE(width/2, alignment);
      lumaSize = luma_stride * height;
      chromaSize = chroma_stride * height * 2;
      break;
    case INPUT_FORMAT_YUV422P10LE:
    case INPUT_FORMAT_YUV422P10BE:
      luma_stride = STRIDE(width*2, alignment);
      chroma_stride = STRIDE((width/2)*2, alignment);
      lumaSize = luma_stride * height;
      chromaSize = chroma_stride * height * 2;
      break;
    case INPUT_FORMAT_YUV444P:
      luma_stride = STRIDE(width*2, alignment);
      lumaSize = luma_stride * height;
      chromaSize = lumaSize*2;
      break;

#endif

    default:
     printf("not support this format\n");
     chromaSize = lumaSize = 0;
     break;
  }
  
  pictureSize = lumaSize + chromaSize;
  if (luma_Size != NULL)
    *luma_Size = lumaSize;
  if (chroma_Size != NULL)
    *chroma_Size = chromaSize;
  if (picture_Size != NULL)
    *picture_Size = pictureSize;
  
}

void ChangeToCustomizedFormat(HANTROH26xEncOptions *options,VCEncPreProcessingCfg *preProcCfg)
{
  if ((options->formatCustomizedType == 0)&&(options->inputFormat==VCENC_YUV420_PLANAR))
  {
    if (IS_HEVC(options->codecFormat))
      preProcCfg->inputType = VCENC_YUV420_PLANAR_8BIT_DAHUA_HEVC;
    else
      preProcCfg->inputType = VCENC_YUV420_PLANAR_8BIT_DAHUA_H264;
    preProcCfg->origWidth = ((preProcCfg->origWidth + 16 - 1) & (~(16 - 1)));
  }
  
  if ((options->formatCustomizedType == 1)&&
     ((options->inputFormat==VCENC_YUV420_SEMIPLANAR)||(options->inputFormat==VCENC_YUV420_SEMIPLANAR_VU)||(options->inputFormat==VCENC_YUV420_PLANAR_10BIT_P010)))
  {
   if (options->inputFormat==VCENC_YUV420_SEMIPLANAR)
     preProcCfg->inputType = VCENC_YUV420_SEMIPLANAR_8BIT_FB;
   else if (options->inputFormat==VCENC_YUV420_SEMIPLANAR_VU)
     preProcCfg->inputType = VCENC_YUV420_SEMIPLANAR_VU_8BIT_FB;
   else
     preProcCfg->inputType = VCENC_YUV420_PLANAR_10BIT_P010_FB;
  }
  
  if ((options->formatCustomizedType == 2)&&(options->inputFormat==VCENC_YUV420_PLANAR))
  {
    preProcCfg->inputType = VCENC_YUV420_SEMIPLANAR_101010;
    preProcCfg->xOffset = preProcCfg->xOffset /6 *6;
  }

  if ((options->formatCustomizedType == 3)&&(options->inputFormat==VCENC_YUV420_PLANAR))
  {
    preProcCfg->inputType = VCENC_YUV420_8BIT_TILE_64_4;
    preProcCfg->xOffset = preProcCfg->xOffset /64 *64;
    preProcCfg->yOffset = preProcCfg->yOffset /4 *4;
  }

  if ((options->formatCustomizedType == 4)&&(options->inputFormat==VCENC_YUV420_PLANAR))
  {
    preProcCfg->inputType = VCENC_YUV420_UV_8BIT_TILE_64_4;
    preProcCfg->xOffset = preProcCfg->xOffset /64 *64;
    preProcCfg->yOffset = preProcCfg->yOffset /4 *4;
  }

  if ((options->formatCustomizedType == 5)&&(options->inputFormat==VCENC_YUV420_PLANAR))
  {
    preProcCfg->inputType = VCENC_YUV420_10BIT_TILE_32_4;
    preProcCfg->xOffset = preProcCfg->xOffset /32 *32;
    preProcCfg->yOffset = preProcCfg->yOffset /4 *4;
  }

  if ((options->formatCustomizedType == 6)&&(options->inputFormat==VCENC_YUV420_PLANAR))
  {
    preProcCfg->inputType = VCENC_YUV420_10BIT_TILE_48_4;
    preProcCfg->xOffset = preProcCfg->xOffset /48 *48;
    preProcCfg->yOffset = preProcCfg->yOffset /4 *4;    
  }

  if ((options->formatCustomizedType == 7)&&(options->inputFormat==VCENC_YUV420_PLANAR))
  {
    preProcCfg->inputType = VCENC_YUV420_VU_10BIT_TILE_48_4;
    preProcCfg->xOffset = preProcCfg->xOffset /48 *48;
    preProcCfg->yOffset = preProcCfg->yOffset /4 *4;
  }

  if ((options->formatCustomizedType == 8)&&(options->inputFormat==VCENC_YUV420_PLANAR))
  {
    preProcCfg->inputType = VCENC_YUV420_8BIT_TILE_128_2;
    preProcCfg->xOffset = preProcCfg->xOffset /128 *128;
  }

  if ((options->formatCustomizedType == 9)&&(options->inputFormat==VCENC_YUV420_PLANAR))
  {
    preProcCfg->inputType = VCENC_YUV420_UV_8BIT_TILE_128_2;
    preProcCfg->xOffset = preProcCfg->xOffset /128 *128;
  }

  if ((options->formatCustomizedType == 10)&&(options->inputFormat==VCENC_YUV420_PLANAR))
  {
    preProcCfg->inputType = VCENC_YUV420_10BIT_TILE_96_2;
    preProcCfg->xOffset = preProcCfg->xOffset /96 *96;
  }

  if ((options->formatCustomizedType == 11)&&(options->inputFormat==VCENC_YUV420_PLANAR))
  {
    preProcCfg->inputType = VCENC_YUV420_VU_10BIT_TILE_96_2;
    preProcCfg->xOffset = preProcCfg->xOffset /96 *96;
  }
  
}

void ChangeCmlCustomizedFormat(HANTROH26xEncOptions *options)
{
  if ((options->formatCustomizedType == 0)&&(options->inputFormat==VCENC_YUV420_PLANAR))
  {
    if (IS_H264(options->codecFormat))
    {
      if (options->verOffsetSrc!=DEFAULT)
        options->verOffsetSrc = options->verOffsetSrc&(~(16-1));
      if (options->horOffsetSrc!=DEFAULT)
        options->horOffsetSrc = options->horOffsetSrc&(~(16-1));
    }
    else
    {
      if (options->verOffsetSrc!=DEFAULT)
        options->verOffsetSrc = options->verOffsetSrc&(~(32-1));
      if (options->horOffsetSrc!=DEFAULT)
        options->horOffsetSrc = options->horOffsetSrc&(~(32-1));
    }
    options->width = options->width&(~(16-1));
    options->height = options->height&(~(16-1));
    options->scaledWidth = options->scaledWidth&(~(16-1));
    options->scaledHeight = options->scaledHeight&(~(16-1));
  }

  if ((options->formatCustomizedType == 1)&&
       ((options->inputFormat==VCENC_YUV420_SEMIPLANAR)||(options->inputFormat==VCENC_YUV420_SEMIPLANAR_VU)||(options->inputFormat==VCENC_YUV420_PLANAR_10BIT_P010)))
  {
    options->verOffsetSrc = 0;
    options->horOffsetSrc = 0;
    if (options->testId == 16)
      options->testId = 0;
    
    options->rotation = 0;
  }
  else if (options->formatCustomizedType == 1)
  {
    options->formatCustomizedType = -1;
  }

  if (((options->formatCustomizedType >= 2) && (options->formatCustomizedType <= 11))&&(options->inputFormat==VCENC_YUV420_PLANAR))
  {
    if (options->testId == 16)
      options->testId = 0;
    options->rotation = 0;
  }
  else
    options->formatCustomizedType = -1;
  
}

static void transYUVtoFBformat(struct test_bench *tb, HANTROH26xEncOptions *options, i32 *ret)
{
   u8 *transform_buf;
   u32 x,y;
   VCEncIn *pEncIn = &(tb->encIn);
#ifdef USE_OLD_DRV
   transform_buf = (u8 *)tb->transformMem->virtualAddress;
#else
   transform_buf = (u8 *)tb->transformMem->rc_virtualAddress;
#endif
   u32 alignment = (tb->input_alignment == 0 ? 1 : tb->input_alignment);
   u32 byte_per_compt = 0;

   if (options->inputFormat==VCENC_YUV420_SEMIPLANAR || options->inputFormat==VCENC_YUV420_SEMIPLANAR_VU)
     byte_per_compt = 1;
   else if (options->inputFormat==VCENC_YUV420_PLANAR_10BIT_P010)
     byte_per_compt = 2;

   printf("transform YUV to FB format\n");

   if ((options->inputFormat==VCENC_YUV420_SEMIPLANAR)||(options->inputFormat==VCENC_YUV420_SEMIPLANAR_VU)||
       (options->inputFormat==VCENC_YUV420_PLANAR_10BIT_P010) )
   {
     u32 stride = (options->lumWidthSrc*4*byte_per_compt + alignment - 1) & (~(alignment - 1));

     //luma
     for (x = 0; x < options->lumWidthSrc/4; x++)
     {
       for (y = 0; y < options->lumHeightSrc; y++)
         memcpy(transform_buf + y%4*4*byte_per_compt + stride*(y/4) + x*16*byte_per_compt, tb->lum + y*((options->lumWidthSrc+15)&(~15))*byte_per_compt + x*4*byte_per_compt, 4*byte_per_compt);
     }

     transform_buf += stride * options->lumHeightSrc/4;
     
     //chroma
     for (x = 0; x < options->lumWidthSrc/4; x++)
     {
       for (y = 0; y < ((options->lumHeightSrc/2)+3)/4*4; y++)
         memcpy(transform_buf + y%4*4*byte_per_compt + stride*(y/4) + x*16*byte_per_compt, tb->cb + y*((options->lumWidthSrc+15)&(~15))*byte_per_compt + x*4*byte_per_compt, 4*byte_per_compt);
     }
   }
 
    {
      u32 size_lum = ((options->lumWidthSrc*4*byte_per_compt + alignment - 1) & (~(alignment - 1))) * options->lumHeightSrc/4;
      //u32 size_ch = ((options->lumWidthSrc*4*byte_per_compt + tb->alignment - 1) & (~(tb->alignment - 1))) * options->lumHeightSrc/4/2;
      
      pEncIn->busLuma = tb->transformMem->busAddress;
      //tb->lum = (u8 *)tb->transformMem.virtualAddress;
  
      pEncIn->busChromaU = pEncIn->busLuma + (u32)size_lum;
      //tb->cb = tb->lum + (u32)((float)size_lum*getPixelWidthInByte(options->inputFormat));
      //pEncIn->busChromaV = pEncIn->busChromaU + (u32)size_ch;
      //tb->cr = tb->cb + (u32)((float)size_ch*getPixelWidthInByte(options->inputFormat));
    }
    *ret = OK;
#ifndef USE_OLD_DRV
    if(EWLTransDataRC2EP(tb->ewl, tb->transformMem, tb->transformMem, tb->transformMem->size))
       *ret = NOK;
#endif

}
#if 0
i32 ChangeInputToTransYUV(struct test_bench *tb, VCEncInst encoder, HANTROH26xEncOptions *options,VCEncIn *pEncIn)
{ 
  u32 frameCntTotal = 0,src_img_size = 0;
  FILE *transfile = NULL;
  VCEncRet ret;
  
  while((options->exp_of_input_alignment > 0)&& (((options->formatCustomizedType >= 2)&&(options->formatCustomizedType <= 11))&&(options->inputFormat==VCENC_YUV420_PLANAR)))
  {
    GetFreeIOBuffer(tb);
    src_img_size = SetupInputBuffer(tb,options, pEncIn);
    if (read_picture(tb, options->inputFormat, src_img_size, options->lumWidthSrc, options->lumHeightSrc) == 0)
    {
      transfile = FormatCustomizedYUV(tb, options, &ret);
      if(ret) return NOK;
      frameCntTotal++;
      tb->encIn.picture_cnt++;
    }
    else
      break;
  }

  if (transfile != NULL)
  {
    fclose(transfile);
    fclose(tb->in);
    tb->in = fopen("daj_transformed_format.yuv","rb");
    printf("change input file into daj_transformed_format.yuv\n");
    frameCntTotal = 0;
    tb->encIn.picture_cnt = 0;
    if ((options->formatCustomizedType == 2)&&(options->inputFormat==VCENC_YUV420_PLANAR))
    {
      options->inputFormat = VCENC_YUV420_SEMIPLANAR_101010;
    }
  
    if ((options->formatCustomizedType == 3)&&(options->inputFormat==VCENC_YUV420_PLANAR))
    {
      options->inputFormat = VCENC_YUV420_8BIT_TILE_64_4;
    }
  
    if ((options->formatCustomizedType == 4)&&(options->inputFormat==VCENC_YUV420_PLANAR))
    {
      options->inputFormat = VCENC_YUV420_UV_8BIT_TILE_64_4;
    }
  
    if ((options->formatCustomizedType == 5)&&(options->inputFormat==VCENC_YUV420_PLANAR))
    {
      options->inputFormat = VCENC_YUV420_10BIT_TILE_32_4;
    }
  
    if ((options->formatCustomizedType == 6)&&(options->inputFormat==VCENC_YUV420_PLANAR))
    {
      options->inputFormat = VCENC_YUV420_10BIT_TILE_48_4;
    }
  
    if ((options->formatCustomizedType == 7)&&(options->inputFormat==VCENC_YUV420_PLANAR))
    {
      options->inputFormat = VCENC_YUV420_VU_10BIT_TILE_48_4;
    }
  
    if ((options->formatCustomizedType == 8)&&(options->inputFormat==VCENC_YUV420_PLANAR))
    {
      options->inputFormat = VCENC_YUV420_8BIT_TILE_128_2;
    }
  
    if ((options->formatCustomizedType == 9)&&(options->inputFormat==VCENC_YUV420_PLANAR))
    {
      options->inputFormat = VCENC_YUV420_UV_8BIT_TILE_128_2;
    }
  
    if ((options->formatCustomizedType == 10)&&(options->inputFormat==VCENC_YUV420_PLANAR))
    {
      options->inputFormat = VCENC_YUV420_10BIT_TILE_96_2;
    }
  
    if ((options->formatCustomizedType == 11)&&(options->inputFormat==VCENC_YUV420_PLANAR))
    {
      options->inputFormat = VCENC_YUV420_VU_10BIT_TILE_96_2;
    }

    
    for(u32 coreIdx =0; coreIdx < tb->parallelCoreNum; coreIdx++)
      if (tb->pictureMemFactory[coreIdx].virtualAddress != NULL)
        EWLFreeLinear(((struct vcenc_instance *)encoder)->asic.ewl, &tb->pictureMemFactory[coreIdx]);

    u32 lumaSize = 0,chromaSize = 0,pictureSize = 0;
    getAlignedPicSizebyFormat(options->inputFormat,options->lumWidthSrc,options->lumHeightSrc,tb->input_alignment,&lumaSize,&chromaSize,&pictureSize);

    tb->lumaSize = lumaSize;
    tb->chromaSize = chromaSize;

    options->formatCustomizedType = -1;
    tb->formatCustomizedType = -1;

    for(u32 coreIdx =0; coreIdx < tb->parallelCoreNum; coreIdx++)
    {
      ret = EWLMallocLinear(((struct vcenc_instance *)encoder)->asic.ewl, pictureSize,tb->input_alignment,
                            &tb->pictureMemFactory[coreIdx]);
      if (ret != EWL_OK)
      {
        tb->pictureMemFactory[coreIdx].virtualAddress = NULL;
      }
    }
  }
  return OK;
}
#endif
i32 readConfigFiles(struct test_bench *tb, HANTROH26xEncOptions *options)
{
  i32 i;

  if ((options->roiMapDeltaQpEnable)&&(options->roiMapDeltaQpFile != NULL))
  {
    tb->roiMapFile = fopen (options->roiMapDeltaQpFile, "r");
    if (tb->roiMapFile == NULL)
    {
      ENC_TB_DEBUG_PRINT("ROI map Qp delta config: Error, Can Not Open File %s\n", options->roiMapDeltaQpFile );
      //return -1;
    }
  }

  if (options->roiMapDeltaQpEnable && options->roiMapDeltaQpBinFile)
  {
    tb->roiMapBinFile = fopen (options->roiMapDeltaQpBinFile, "rb");
    if (tb->roiMapBinFile == NULL)
    {
      ENC_TB_DEBUG_PRINT("ROI map Qp delta config: Error, Can Not Open File %s\n", options->roiMapDeltaQpBinFile );
    }
  }

  if ((options->ipcmMapEnable)&&(options->ipcmMapFile != NULL))
  {
    tb->ipcmMapFile = fopen (options->ipcmMapFile, "r");
    if (tb->ipcmMapFile == NULL)
    {
      ENC_TB_DEBUG_PRINT("IPCM map config: Error, Can Not Open File %s\n", options->ipcmMapFile );
      //return -1;
    }
  }

  for (i = 0; i < 2; i ++)
  {
    if (options->gmvFileName[i])
    {
      tb->gmvFile[i] = fopen (options->gmvFileName[i], "r");
      if (!tb->gmvFile[i]) {
        ENC_TB_DEBUG_PRINT("GMV config: Error, Can Not Open File %s\n", options->gmvFileName[i]);
      }
    }
  }
  
  if (options->skipMapEnable && options->skipMapFile && (tb->skipMapFile == NULL))
  {
    tb->skipMapFile = fopen (options->skipMapFile, "r");
    if (tb->skipMapFile == NULL)
    {
      ENC_TB_DEBUG_PRINT("SKIP map config: Error, Can Not Open File %s\n", options->skipMapFile );
    }
  }

  if (options->roiMapInfoBinFile && (tb->roiMapInfoBinFile == NULL))
  {
    tb->roiMapInfoBinFile = fopen (options->roiMapInfoBinFile, "rb");
    if (tb->roiMapInfoBinFile == NULL)
    {
      printf("ROI map config: Error, Can Not Open File %s\n", options->roiMapInfoBinFile );
    }
  }

  if (options->RoimapCuCtrlInfoBinFile && (tb->RoimapCuCtrlInfoBinFile == NULL))
  {
    tb->RoimapCuCtrlInfoBinFile = fopen (options->RoimapCuCtrlInfoBinFile, "rb");
    if (tb->RoimapCuCtrlInfoBinFile == NULL)
    {
      printf("ROI map cu ctrl config: Error, Can Not Open File %s\n", options->RoimapCuCtrlInfoBinFile );
    }
  }

  if (options->RoimapCuCtrlIndexBinFile && (tb->RoimapCuCtrlIndexBinFile == NULL))
  {
    tb->RoimapCuCtrlIndexBinFile = fopen (options->RoimapCuCtrlIndexBinFile, "rb");
    if (tb->RoimapCuCtrlIndexBinFile == NULL)
    {
      printf("ROI map cu ctrl index config: Error, Can Not Open File %s\n", options->RoimapCuCtrlIndexBinFile );
    }
  }

  return 0;
}

/*------------------------------------------------------------------------------
    WriteCuInformation
        Write cu encoding information into a file.
        Information format is defined by VCEncCuInfo struct.
------------------------------------------------------------------------------*/
void WriteCuInformation (struct test_bench *tb, VCEncInst encoder, VCEncOut *pEncOut, HANTROH26xEncOptions *options, i32 frame, i32 poc)
{
    bool bWrite = options->enableOutputCuInfo == 2;
#ifdef TEST_DATA
    if (options->enableOutputCuInfo == 1 && EncTraceCuInfoCheck())
      bWrite = HANTRO_TRUE;
#endif
    if (!bWrite)
      return;

    if (!tb->fmv)
    {
      if(!(tb->fmv = open_file("cuInfo.txt", "wb")))
        return;
    }

    FILE *file = tb->fmv;
    i32 width = options->width;
    i32 height = options->interlacedFrame ? options->height/2 : options->height;
    i32 ctuPerRow = (width+options->max_cu_size-1)/options->max_cu_size;
    i32 ctuPerCol = (height+options->max_cu_size-1)/options->max_cu_size;
    i32 ctuPerFrame = ctuPerRow * ctuPerCol;
    VCEncCuInfo cuInfo;
    u32 *ctuTable = pEncOut->cuOutData.ctuOffset;
    char *picType[] = {"I", "P", "B", "Not-Known"};
    char *cuType[] = {"INTER", "INTRA", "IPCM"};
    char *intraPart[] = {"2Nx2N", "NxN"};
    char *intraPartH264[] = {"16x16", "8x8", "4x4"};
    char *interDir[] = {"PRED_L0","PRED_L1","PRED_BI"};
    i32 iCtuX, iCtuY, iCu, iPu = 0;
    i32 iCtu = 0;

    if (!file || !pEncOut || !options)
        return;

#if 0
    if (frame == 0)
      fprintf(file, "Encoding Information of %s. MV in 1/4 pixel.\n", options->input);
#endif
    fprintf(file, "\n#Pic %d %s-Frame have %d CTU(%dx%d). Poc %d.\n",
        frame, picType[pEncOut->codingType], ctuPerFrame, ctuPerRow, ctuPerCol, poc);

    for (iCtuY = 0; iCtuY < ctuPerCol; iCtuY ++)
      for (iCtuX = 0; iCtuX < ctuPerRow; iCtuX ++)
      {
        i32 nCu = ctuTable[iCtu];
        if (iCtu)
          nCu -= ctuTable[iCtu - 1]; 

        /*
            HEVC: HW generate ctuIdx table
                       sw reads num of CUs from the table
            H264:   HW not write anything to ctuIdx table(C-Model write 1 CU per CTU),
                        HW is not same as C-Model, ctr sw need fill nCu itself, not dependent on 
                        ctuIdx
        */
        if(IS_H264(options->codecFormat))
            nCu =1;
        
        fprintf(file, "\n*CTU %d at (%2d,%2d) have %2d CU:\n", iCtu, iCtuX*options->max_cu_size, iCtuY*options->max_cu_size, nCu);      

        for (iCu = 0; iCu < nCu; iCu ++)
        {
          VCEncGetCuInfo(encoder, &pEncOut->cuOutData, &cuInfo, iCtu, iCu);
          fprintf(file, "  CU %2dx%-2d at (%2d,%2d)  %s %-7s",
            cuInfo.cuSize, cuInfo.cuSize, cuInfo.cuLocationX, cuInfo.cuLocationY, cuType[cuInfo.cuMode],
            cuInfo.cuMode ? (IS_H264(options->codecFormat) ? intraPartH264[cuInfo.intraPartMode] : intraPart[cuInfo.intraPartMode]) : interDir[cuInfo.interPredIdc]);
          fprintf (file, "  Cost=%-8d",cuInfo.cost);

          // 0:inter; 1:intra; 2:IPCM
          if (cuInfo.cuMode == 1)
          {
            if(IS_H264(options->codecFormat)) {
              fprintf(file, "   Intra_Mode:");
              for(iPu = 0; iPu < (1<<(2*cuInfo.intraPartMode)); iPu++)
                fprintf(file, " %2d", cuInfo.intraPredMode[iPu]);
            } else
            if (cuInfo.intraPartMode)
              fprintf(file, "   Intra_Mode: %2d %2d %2d %2d",
                cuInfo.intraPredMode[0],cuInfo.intraPredMode[1],cuInfo.intraPredMode[2],cuInfo.intraPredMode[3]);
            else              
              fprintf(file, "   Intra_Mode: %2d         ",cuInfo.intraPredMode[0]);
          }
          else if (cuInfo.cuMode == 0)
          {
            char mvstring[20];
            if (cuInfo.interPredIdc != 1)
            {
              sprintf(mvstring, "(%d,%d)", cuInfo.mv[0].mvX,cuInfo.mv[0].mvY);
              fprintf(file, " List0_Motion: refIdx=%-2d MV=%-14s", cuInfo.mv[0].refIdx, mvstring);
            }
            
            if (cuInfo.interPredIdc != 0)
            {
              sprintf(mvstring, "(%d,%d)", cuInfo.mv[1].mvX,cuInfo.mv[1].mvY);
              fprintf(file, " List1_Motion: refIdx=%-2d MV=%-14s", cuInfo.mv[1].refIdx, mvstring);
            }
          }

          if(((struct vcenc_instance *)encoder)->asic.regs.asicCfg.cuInforVersion >= 1)
          {
            u32 interCost = cuInfo.cuMode ? cuInfo.costOfOtherMode : cuInfo.cost;
            u32 intraCost = cuInfo.cuMode ? cuInfo.cost : cuInfo.costOfOtherMode;
            fprintf(file, " Mean %-4d Variance %-8d Qp %-2d INTRA Cost %-8d INTER Cost %-8d INTRA Satd %-8d INTER Satd %-8d",
                cuInfo.mean, cuInfo.variance, cuInfo.qp, intraCost, interCost, cuInfo.costIntraSatd, cuInfo.costInterSatd);
          }
          fprintf(file, "\n");
        }

        iCtu ++;
      }
}


static i32 parseGmvFile (FILE *fIn, i16 *hor, i16 *ver, i32 list)
{
  char achParserBuffer[4096];
  char *buf = &(achParserBuffer[0]);

  if (!fIn) return -1;
  if (feof (fIn)) return -1;

  // Read one line
  buf[0] = '\0';
  char *line = fgets (buf, 4096, fIn);
  if (!line) return -1;
  //handle line end
  char* s = strpbrk(line, "#\n");
  if(s) *s = '\0';

  line = nextIntToken(line, hor);
  if (!line)
    return -1;
    
  line = nextIntToken(line, ver);
  if (!line)
    return -1;
  
#ifdef SEARCH_RANGE_ROW_OFFSET_TEST
  extern char gmvConfigLine[2][4096];
  memcpy(&(gmvConfigLine[list][0]), &(achParserBuffer[0]), 4096);
#endif

  return 0;
}


i32 readGmv(struct test_bench *tb, VCEncIn *pEncIn, HANTROH26xEncOptions *options)
{
  i16 mvx, mvy, i;

  for (i = 0; i < 2; i ++)
  {
    if (tb->gmvFile[i])
    {
      if (parseGmvFile (tb->gmvFile[i], &mvx, &mvy, i) == 0)
      {
        pEncIn->gmv[i][0] = mvx;
        pEncIn->gmv[i][1] = mvy;
      }
    }
    else
    {      
      pEncIn->gmv[i][0] = options->gmv[i][0];
      pEncIn->gmv[i][1] = options->gmv[i][1];
    }
  }

  return 0;
}

static i32 getSmartOpt (char *line, char *opt, i32 *val)
{
  char *p = strstr(line, opt);
  if (!p)
    return NOK;
    
  p = strchr(line, '=');
  if (!p)
    return NOK;

  p ++;
  while (*p == ' ') p ++;
  if (*p == '\0')
    return NOK;

  sscanf(p, "%d", val);
  return OK;
}

i32 ParsingSmartConfig (char *fname, HANTROH26xEncOptions *options)
{
  void * tb = NULL;
#define MAX_LINE_LENGTH 1024
  char achParserBuffer[MAX_LINE_LENGTH];
  FILE *fIn = fopen (fname, "r");
  if (fIn == NULL)
  {
    ENC_TB_ERROR_PRINT("Smart Config: Error, Can Not Open File %s\n", fname );
    return -1;
  }

  while (1)
  {
    if (feof (fIn)) break;

    achParserBuffer[0] = '\0';
    // Read one line
    char *line = fgets ((char *) achParserBuffer, MAX_LINE_LENGTH, fIn);
    if (!line) break;
    //handle line end
    char* s = strpbrk(line, "#\n");
    if(s) *s = '\0';

    if (getSmartOpt(line, "smart_Mode_Enable",                &options->smartModeEnable) == OK) continue;

    if (getSmartOpt(line, "smart_H264_Qp",                    &options->smartH264Qp) == OK) continue;
    if (getSmartOpt(line, "smart_H264_Luma_DC_Th",            &options->smartH264LumDcTh) == OK) continue;
    if (getSmartOpt(line, "smart_H264_Cb_DC_Th",              &options->smartH264CbDcTh) == OK) continue;
    if (getSmartOpt(line, "smart_H264_Cr_DC_Th",              &options->smartH264CrDcTh) == OK) continue;

    if (getSmartOpt(line, "smart_Hevc_Luma_Qp",               &options->smartHevcLumQp) == OK) continue;
    if (getSmartOpt(line, "smart_Hevc_Chroma_Qp",             &options->smartHevcChrQp) == OK) continue;

    if (getSmartOpt(line, "smart_Hevc_CU8_Luma_DC_Th",        &(options->smartHevcLumDcTh[0])) == OK) continue;
    if (getSmartOpt(line, "smart_Hevc_CU16_Luma_DC_Th",       &(options->smartHevcLumDcTh[1])) == OK) continue;
    if (getSmartOpt(line, "smart_Hevc_CU32_Luma_DC_Th",       &(options->smartHevcLumDcTh[2])) == OK) continue;
    if (getSmartOpt(line, "smart_Hevc_CU8_Chroma_DC_Th",      &(options->smartHevcChrDcTh[0])) == OK) continue;
    if (getSmartOpt(line, "smart_Hevc_CU16_Chroma_DC_Th",     &(options->smartHevcChrDcTh[1])) == OK) continue;
    if (getSmartOpt(line, "smart_Hevc_CU32_Chroma_DC_Th",     &(options->smartHevcChrDcTh[2])) == OK) continue;

    if (getSmartOpt(line, "smart_Hevc_CU8_Luma_AC_Num_Th",    &(options->smartHevcLumAcNumTh[0])) == OK) continue;
    if (getSmartOpt(line, "smart_Hevc_CU16_Luma_AC_Num_Th",   &(options->smartHevcLumAcNumTh[1])) == OK) continue;
    if (getSmartOpt(line, "smart_Hevc_CU32_Luma_AC_Num_Th",   &(options->smartHevcLumAcNumTh[2])) == OK) continue;
    if (getSmartOpt(line, "smart_Hevc_CU8_Chroma_AC_Num_Th",  &(options->smartHevcChrAcNumTh[0])) == OK) continue;
    if (getSmartOpt(line, "smart_Hevc_CU16_Chroma_AC_Num_Th", &(options->smartHevcChrAcNumTh[1])) == OK) continue;
    if (getSmartOpt(line, "smart_Hevc_CU32_Chroma_AC_Num_Th", &(options->smartHevcChrAcNumTh[2])) == OK) continue;

    if (getSmartOpt(line, "smart_Mean_Th0",                   &(options->smartMeanTh[0])) == OK) continue;
    if (getSmartOpt(line, "smart_Mean_Th1",                   &(options->smartMeanTh[1])) == OK) continue;
    if (getSmartOpt(line, "smart_Mean_Th2",                   &(options->smartMeanTh[2])) == OK) continue;
    if (getSmartOpt(line, "smart_Mean_Th3",                   &(options->smartMeanTh[3])) == OK) continue;
    if (getSmartOpt(line, "smart_Pixel_Num_Cnt_Th",           &options->smartPixNumCntTh) == OK) continue;
  }

  fclose(fIn);

  ENC_TB_INFO_PRINT("======== Smart Algorithm Configuration ========\n");
  ENC_TB_INFO_PRINT("smart_Mode_Enable = %d\n",                options->smartModeEnable);

  ENC_TB_INFO_PRINT("smart_H264_Qp = %d\n",                    options->smartH264Qp);
  ENC_TB_INFO_PRINT("smart_H264_Luma_DC_Th = %d\n",            options->smartH264LumDcTh);
  ENC_TB_INFO_PRINT("smart_H264_Cb_DC_Th = %d\n",              options->smartH264CbDcTh);
  ENC_TB_INFO_PRINT("smart_H264_Cr_DC_Th = %d\n",              options->smartH264CrDcTh);
  
  ENC_TB_INFO_PRINT("smart_Hevc_Luma_Qp = %d\n",               options->smartHevcLumQp);
  ENC_TB_INFO_PRINT("smart_Hevc_Chroma_Qp = %d\n",             options->smartHevcChrQp);

  ENC_TB_INFO_PRINT("smart_Hevc_CU8_Luma_DC_Th = %d\n",        (options->smartHevcLumDcTh[0]));
  ENC_TB_INFO_PRINT("smart_Hevc_CU16_Luma_DC_Th = %d\n",       (options->smartHevcLumDcTh[1]));
  ENC_TB_INFO_PRINT("smart_Hevc_CU32_Luma_DC_Th = %d\n",       (options->smartHevcLumDcTh[2]));
  ENC_TB_INFO_PRINT("smart_Hevc_CU8_Chroma_DC_Th = %d\n",      (options->smartHevcChrDcTh[0]));
  ENC_TB_INFO_PRINT("smart_Hevc_CU16_Chroma_DC_Th = %d\n",     (options->smartHevcChrDcTh[1]));
  ENC_TB_INFO_PRINT("smart_Hevc_CU32_Chroma_DC_Th = %d\n",     (options->smartHevcChrDcTh[2]));

  ENC_TB_INFO_PRINT("smart_Hevc_CU8_Luma_AC_Num_Th = %d\n",    (options->smartHevcLumAcNumTh[0]));
  ENC_TB_INFO_PRINT("smart_Hevc_CU16_Luma_AC_Num_Th = %d\n",   (options->smartHevcLumAcNumTh[1]));
  ENC_TB_INFO_PRINT("smart_Hevc_CU32_Luma_AC_Num_Th = %d\n",   (options->smartHevcLumAcNumTh[2]));
  ENC_TB_INFO_PRINT("smart_Hevc_CU8_Chroma_AC_Num_Th = %d\n",  (options->smartHevcChrAcNumTh[0]));
  ENC_TB_INFO_PRINT("smart_Hevc_CU16_Chroma_AC_Num_Th = %d\n", (options->smartHevcChrAcNumTh[1]));
  ENC_TB_INFO_PRINT("smart_Hevc_CU32_Chroma_AC_Num_Th = %d\n", (options->smartHevcChrAcNumTh[2]));

  ENC_TB_INFO_PRINT("smart_Mean_Th0 = %d\n",                   (options->smartMeanTh[0]));
  ENC_TB_INFO_PRINT("smart_Mean_Th1 = %d\n",                   (options->smartMeanTh[1]));
  ENC_TB_INFO_PRINT("smart_Mean_Th2 = %d\n",                   (options->smartMeanTh[2]));
  ENC_TB_INFO_PRINT("smart_Mean_Th3 = %d\n",                   (options->smartMeanTh[3]));
  ENC_TB_INFO_PRINT("smart_Pixel_Num_Cnt_Th = %d\n",           options->smartPixNumCntTh);
  ENC_TB_INFO_PRINT("===============================================\n");

  return 0;
}




/*------------------------------------------------------------------------------
  file_read
------------------------------------------------------------------------------*/
static i32 file_read(FILE *file, u8 *data, u64 seek, size_t size)
{
  if ((file == NULL) || (data == NULL)) return NOK;

  fseeko(file, seek, SEEK_SET);
  if (fread(data, sizeof(u8), size, file) < size)
  {
    if (!feof(file))
    {
      //Error(2, ERR, SYSERR);
    }
    return NOK;
  }

  return OK;
}

/*------------------------------------------------------------------------------
  next_picture calculates next input picture depending input and output
  frame rates.
------------------------------------------------------------------------------*/
u64 next_picture(struct test_bench *tb, int picture_cnt)
{
  u64 numer, denom;

  numer = (u64)tb->inputRateNumer * (u64)tb->outputRateDenom;
  denom = (u64)tb->inputRateDenom * (u64)tb->outputRateNumer;

  return numer * (picture_cnt / (1 << tb->interlacedFrame)) / denom;
}

/*------------------------------------------------------------------------------
  read_picture
------------------------------------------------------------------------------*/
i32 read_picture(struct test_bench *tb, u32 inputFormat, u32 src_img_size, u32 src_width, u32 src_height)
{
  i32 num;
  u64 seek;
  i32 w;
  i32 h;
  u8 *lum;
  u8 *cb;
  u8 *cr;
  i32 i;
  u32 luma_stride;
  u32 chroma_stride;
  u32 alignment;
  u32 src_img_size_ds = tb->src_img_size_ds;
  u32 src_width_ds = src_width / 2;
  u32 src_height_ds = src_height / 2;
  u8 *lum_ds;
  u8 *cb_ds;
  u8 *cr_ds;
  u64 seek_ds;
  u32 luma_stride_ds;
  u32 chroma_stride_ds;

  num = next_picture(tb, tb->encIn.picture_cnt) + tb->firstPic;

  if (num > tb->lastPic) return NOK;
  ENC_TB_DEBUGV_PRINT("src_img_size = %d, num = %d\n", src_img_size, num);
  seek     = ((u64)num) * ((u64)src_img_size);
  seek_ds  = ((u64)num) * ((u64)src_img_size_ds);
  lum = tb->lum;
  cb = tb->cb;
  cr = tb->cr;
  lum_ds = tb->lumDS;
  cb_ds = tb->cbDS;
  cr_ds = tb->crDS;
  alignment = (tb->formatCustomizedType != -1? 0 : tb->input_alignment);
  VCEncGetAlignedStride(src_width,inputFormat,&luma_stride,&chroma_stride,alignment);
  VCEncGetAlignedStride(src_width_ds,inputFormat,&luma_stride_ds,&chroma_stride_ds,alignment);
  
  if (tb->formatCustomizedType == 0 && inputFormat==VCENC_YUV420_PLANAR)
    memset(lum,0,luma_stride*src_height*3/2);

  switch(inputFormat)
  {
    case VCENC_YUV420_PLANAR:
    {
      /* Lum */
      for (i = 0; i < src_height; i++)
      {
        if (file_read(tb->in, lum , seek, src_width)) return NOK;
        seek += src_width;
        lum += luma_stride;
      }
      if(tb->inDS) {
        for (i = 0; i < src_height_ds; i++)
        {
          if (file_read(tb->inDS, lum_ds , seek_ds, src_width_ds)) return NOK;
          seek_ds += src_width_ds;
          lum_ds += luma_stride_ds;
        }
      }
      
      w = ((src_width + 1) >> 1);
      h = ((src_height + 1) >> 1);
      /* Cb */
      for (i = 0; i < h; i++)
      {
        if (file_read(tb->in, cb, seek, w)) return NOK;
        seek += w;
        cb += chroma_stride;
      }
    
      /* Cr */
      for (i = 0; i < h; i++)
      {
        if (file_read(tb->in, cr, seek, w)) return NOK;
    
        seek += w;
        cr += chroma_stride;
      }
      if(tb->inDS) {
        w = ((src_width_ds + 1) >> 1);
        h = ((src_height_ds + 1) >> 1);
        for (i = 0; i < h; i++)
        {
          if (file_read(tb->inDS, cb_ds, seek_ds, w)) return NOK;
          seek_ds += w;
          cb_ds += chroma_stride_ds;
        }

        /* Cr */
        for (i = 0; i < h; i++)
        {
          if (file_read(tb->inDS, cr_ds, seek_ds, w)) return NOK;

          seek_ds += w;
          cr_ds += chroma_stride_ds;
        }
      }
      break;
    }
    case VCENC_YUV420_SEMIPLANAR:
    case VCENC_YUV420_SEMIPLANAR_VU:
    {
      /* Lum */
	    ENC_TB_DEBUGV_PRINT("%d, %d, %d\n", src_width, src_height, luma_stride);
      for (i = 0; i < src_height; i++)
      {
        if (file_read(tb->in, lum , seek, src_width)) return NOK;
        seek += src_width;
        lum += luma_stride;
      }
      
      /* CbCr */
      ENC_TB_DEBUGV_PRINT("%d, %d, %d\n", src_width, src_height/2, chroma_stride);
      for (i = 0; i < (src_height / 2); i++)
      {
        if (file_read(tb->in, cb, seek, src_width)) return NOK;
        seek += src_width;
        cb += chroma_stride;
      }
      break;
    }
    case VCENC_YUV422_INTERLEAVED_YUYV:
    case VCENC_YUV422_INTERLEAVED_UYVY:
    case VCENC_RGB565:
    case VCENC_BGR565:
    case VCENC_RGB555:
    case VCENC_BGR555:
    case VCENC_RGB444:
    case VCENC_BGR444: 
    {
      for (i = 0; i < src_height; i++)
      {
        if (file_read(tb->in, lum , seek, src_width * 2)) return NOK;
        seek += src_width * 2;
        lum += luma_stride;
      }
      break;
    }
    case VCENC_RGB888:
    case VCENC_BGR888:
    case VCENC_RGB101010:
    case VCENC_BGR101010:
    {
      for (i = 0; i < src_height; i++)
      {
        if (file_read(tb->in, lum , seek, src_width * 4)) return NOK;
        seek += src_width * 4;
        lum += luma_stride;
      }
      break;
    }
    case VCENC_YUV420_PLANAR_10BIT_I010:
    {
      /* Lum */
      for (i = 0; i < src_height; i++)
      {
        if (file_read(tb->in, lum , seek, src_width*2)) return NOK;
        seek += src_width*2;
        lum += luma_stride;
      }
      
      w = ((src_width + 1) >> 1);
      h = ((src_height + 1) >> 1);
      /* Cb */
      for (i = 0; i < h; i++)
      {
        if (file_read(tb->in, cb, seek, w*2)) return NOK;
        seek += w*2;
        cb += chroma_stride;
      }
    
      /* Cr */
      for (i = 0; i < h; i++)
      {
        if (file_read(tb->in, cr, seek, w*2)) return NOK;
        seek += w*2;
        cr += chroma_stride;
      }
      break;
    }
    case VCENC_YUV420_PLANAR_10BIT_P010:
    {
      /* Lum */
	  
      ENC_TB_DEBUGV_PRINT("%d, %d, %d\n", src_width*2, src_height, luma_stride);
	  
      for (i = 0; i < src_height; i++)
      {
        if (file_read(tb->in, lum , seek, src_width*2)) return NOK;
        seek += src_width*2;
        lum += luma_stride;
      }
    
      h = ((src_height + 1) >> 1);
      /* CbCr */
	  
      ENC_TB_DEBUGV_PRINT("%d, %d, %d\n", src_width*2, h, chroma_stride);
	  
      for (i = 0; i < h; i++)
      {
        if (file_read(tb->in, cb, seek, src_width*2)) return NOK;
        seek += src_width*2;
        cb += chroma_stride;
      }
      break;
    }
    case VCENC_YUV420_PLANAR_10BIT_PACKED_PLANAR:
    { 
      /* Lum */
      for (i = 0; i < src_height; i++)
      {
        if (file_read(tb->in, lum , seek, src_width*10/8)) return NOK;
        seek += src_width*10/8;
        lum += luma_stride*10/8;
      }
      w = ((src_width + 1) >> 1);
      h = ((src_height + 1) >> 1);
      /* Cb */
      for (i = 0; i < h; i++)
      {
        if (file_read(tb->in, cb, seek, w*10/8)) return NOK;
        seek += w*10/8;
        cb += chroma_stride*10/8;
      }

      /* Cr */
      for (i = 0; i < h; i++)
      {
        if (file_read(tb->in, cr, seek, w*10/8)) return NOK;

        seek += w*10/8;
        cr += chroma_stride*10/8;
      }
      break;
    }
    case VCENC_YUV420_10BIT_PACKED_Y0L2:
    {
      for (i = 0; i < src_height/2; i++)
      {
      
        if (file_read(tb->in, lum , seek, src_width * 2*2)) return NOK;
        seek += src_width * 2*2;
        lum += luma_stride * 2*2;
      }
      break;
    }
    case VCENC_YUV420_PLANAR_8BIT_DAHUA_HEVC:
    case VCENC_YUV420_PLANAR_8BIT_DAHUA_H264:
    {
      if (file_read(tb->in, lum , seek, src_img_size)) return NOK;
          break;
    }
    case VCENC_YUV420_SEMIPLANAR_8BIT_FB:
    case VCENC_YUV420_SEMIPLANAR_VU_8BIT_FB:
    case VCENC_YUV420_PLANAR_10BIT_P010_FB:
    {
      ENC_TB_DEBUGV_PRINT("read size = %d\n", src_img_size);
      if (file_read(tb->in, lum , seek, src_img_size)) return NOK;
      break;
    }
    case VCENC_YUV420_SEMIPLANAR_101010:
    case VCENC_YUV420_8BIT_TILE_64_4:
    case VCENC_YUV420_UV_8BIT_TILE_64_4:
    case VCENC_YUV420_10BIT_TILE_32_4:
    case VCENC_YUV420_10BIT_TILE_48_4:
    case VCENC_YUV420_VU_10BIT_TILE_48_4:
    case VCENC_YUV420_8BIT_TILE_128_2:
    case VCENC_YUV420_UV_8BIT_TILE_128_2:
    case VCENC_YUV420_10BIT_TILE_96_2:
    case VCENC_YUV420_VU_10BIT_TILE_96_2:
    {
      u32 tile_stride = 0,tile_h = 0;
      if (inputFormat == VCENC_YUV420_SEMIPLANAR_101010)
      {
        tile_stride = (src_width + 2)/3*4;
        tile_h = 1;
      }
      else if (inputFormat == VCENC_YUV420_8BIT_TILE_64_4 || inputFormat == VCENC_YUV420_UV_8BIT_TILE_64_4)
      {
        tile_stride = STRIDE(src_width,64)*4;
        tile_h = 4;
      }
      else if (inputFormat == VCENC_YUV420_10BIT_TILE_32_4)
      {
        tile_stride = STRIDE(src_width,32)*2*4;
        tile_h = 4;
      }
      else if (inputFormat == VCENC_YUV420_10BIT_TILE_48_4 || inputFormat == VCENC_YUV420_VU_10BIT_TILE_48_4)
      {
        tile_stride = (src_width + 47)/48*48/3* 4*4;
        tile_h = 4;
      }
      else if (inputFormat == VCENC_YUV420_8BIT_TILE_128_2 || inputFormat == VCENC_YUV420_UV_8BIT_TILE_128_2)
      {
        tile_stride = STRIDE(src_width,128)*2;
        tile_h = 2;
      }
      else if (inputFormat == VCENC_YUV420_10BIT_TILE_96_2 || inputFormat == VCENC_YUV420_VU_10BIT_TILE_96_2)
      {
        tile_stride = (src_width + 95)/96*96/3* 4*2;
        tile_h = 2;
      }
    
      /* Lum */
      for (i = 0; i < STRIDE(src_height,tile_h)/tile_h; i++)
      {
        if (file_read(tb->in, lum , seek, tile_stride)) return NOK;
        seek += tile_stride;
        lum += luma_stride;
      }
      /* Cb */
      for (i = 0; i < STRIDE(src_height/2,tile_h)/tile_h; i++)
      {
        if (file_read(tb->in, cb, seek, tile_stride)) return NOK;
        seek += tile_stride;
        cb += chroma_stride;
      }
    
      break;
    }
#if defined(SUPPORT_DEC400) || defined(SUPPORT_TCACHE)		
    case INPUT_FORMAT_YUV420_SEMIPLANAR_8BIT_COMPRESSED_FB:
    case INPUT_FORMAT_YUV420_SEMIPLANAR_VU_8BIT_COMPRESSED_FB:
    case INPUT_FORMAT_YUV420_PLANAR_10BIT_P010_COMPRESSED_FB:
    case INPUT_FORMAT_RFC_8BIT_COMPRESSED_FB:
    case INPUT_FORMAT_RFC_10BIT_COMPRESSED_FB:
    {
      if (file_read(tb->in, lum , seek, src_img_size)) 
        return NOK;
      break;
    }	

    case INPUT_FORMAT_ARGB_FB:
    case INPUT_FORMAT_ABGR_FB:
    case INPUT_FORMAT_RGBA_FB:
    case INPUT_FORMAT_BGRA_FB:
    case INPUT_FORMAT_RGB24_FB:
    case INPUT_FORMAT_BGR24_FB:
    case INPUT_FORMAT_YUV420_PLANAR_10BIT_P010LE:
    case INPUT_FORMAT_YUV420_PLANAR_10BIT_P010BE:  			
    case INPUT_FORMAT_YUV420_SEMIPLANAR_10BIT_P010BE:	
    case INPUT_FORMAT_YUV422P:			
    case INPUT_FORMAT_YUV422P10LE:
    case INPUT_FORMAT_YUV422P10BE:
    case INPUT_FORMAT_YUV444P:
    {      
      /* first plane */
      if (inputFormat < INPUT_FORMAT_RGB24_FB)
        w = src_width*4;
      else if (inputFormat < INPUT_FORMAT_YUV420_PLANAR_10BIT_P010LE)
        w = src_width*3;
      else if (inputFormat == INPUT_FORMAT_YUV422P || inputFormat == INPUT_FORMAT_YUV444P)
        w = src_width;
      else
        w = src_width*2;
        //stride = STRIDE(w, alignment);
        h = src_height;
        
        ENC_TB_DEBUGV_PRINT("w = %d, h = %d, stride = %d\n", w, h, luma_stride);

        for (i = 0; i < h; i++)
        {
          if (file_read(tb->in, lum , seek, w)) return NOK;
          seek += w;
          lum += luma_stride;
        }

        if (inputFormat > INPUT_FORMAT_BGR24_FB) {
          /* second plane */          
          if (inputFormat != INPUT_FORMAT_YUV420_SEMIPLANAR_10BIT_P010BE
            && inputFormat != INPUT_FORMAT_YUV444P) {
            w = ((w + 1) >> 1);
            //stride = STRIDE(w, alignment);
          }
          if (inputFormat < INPUT_FORMAT_YUV422P) {
            h = ((h + 1) >> 1);
          }
          
          ENC_TB_DEBUGV_PRINT("w = %d, h = %d, stride = %d\n", w, h, chroma_stride);

          for (i = 0; i < h; i++)
          {
            if (file_read(tb->in, cb, seek, w)) return NOK;
            seek += w;
            cb += chroma_stride;
          }

          if (inputFormat != INPUT_FORMAT_YUV420_SEMIPLANAR_10BIT_P010BE) {
            /* third plane */
            ENC_TB_DEBUGV_PRINT("w = %d, h = %d, stride = %d\n", w, h, chroma_stride);

            for (i = 0; i < h; i++)
            {
              if (file_read(tb->in, cr, seek, w)) return NOK;
              seek += w;
              cr += chroma_stride;
            }
          }
        }
      }
#endif
    case INPUT_FORMAT_PP_YUV420_SEMIPLANNAR_YUV420P:
    case INPUT_FORMAT_PP_YUV420_SEMIPLANNAR:
    case INPUT_FORMAT_PP_YUV420_SEMIPLANNAR_VU:
    case INPUT_FORMAT_PP_YUV420_PLANAR_10BIT_P010:
      ENC_TB_DEBUGV_PRINT("read size = %d\n", src_img_size);
      if (file_read(tb->in, lum , seek, src_img_size)) 
        return NOK;
      break;
    default:
      break;
  }
  
  return OK;
}


/*------------------------------------------------------------------------------
    GetResolution
        Parse image resolution from file name
------------------------------------------------------------------------------*/
u32 GetResolution(char *filename, i32 *pWidth, i32 *pHeight)
{
  void * tb = NULL;
  i32 i;
  u32 w, h;
  i32 len = strlen(filename);
  i32 filenameBegin = 0;

  /* Find last '/' in the file name, it marks the beginning of file name */
  for (i = len - 1; i; --i)
    if (filename[i] == '/')
    {
      filenameBegin = i + 1;
      break;
    }

  /* If '/' found, it separates trailing path from file name */
  for (i = filenameBegin; i <= len - 3; ++i)
  {
    if ((strncmp(filename + i, "subqcif", 7) == 0) ||
        (strncmp(filename + i, "sqcif", 5) == 0))
    {
      *pWidth = 128;
      *pHeight = 96;
      ENC_TB_INFO_PRINT("Detected resolution SubQCIF (128x96) from file name.\n");
      return 0;
    }
    if (strncmp(filename + i, "qcif", 4) == 0)
    {
      *pWidth = 176;
      *pHeight = 144;
      ENC_TB_INFO_PRINT("Detected resolution QCIF (176x144) from file name.\n");
      return 0;
    }
    if (strncmp(filename + i, "4cif", 4) == 0)
    {
      *pWidth = 704;
      *pHeight = 576;
      ENC_TB_INFO_PRINT("Detected resolution 4CIF (704x576) from file name.\n");
      return 0;
    }
    if (strncmp(filename + i, "cif", 3) == 0)
    {
      *pWidth = 352;
      *pHeight = 288;
      ENC_TB_INFO_PRINT("Detected resolution CIF (352x288) from file name.\n");
      return 0;
    }
    if (strncmp(filename + i, "qqvga", 5) == 0)
    {
      *pWidth = 160;
      *pHeight = 120;
      ENC_TB_INFO_PRINT("Detected resolution QQVGA (160x120) from file name.\n");
      return 0;
    }
    if (strncmp(filename + i, "qvga", 4) == 0)
    {
      *pWidth = 320;
      *pHeight = 240;
      ENC_TB_INFO_PRINT("Detected resolution QVGA (320x240) from file name.\n");
      return 0;
    }
    if (strncmp(filename + i, "vga", 3) == 0)
    {
      *pWidth = 640;
      *pHeight = 480;
      ENC_TB_INFO_PRINT("Detected resolution VGA (640x480) from file name.\n");
      return 0;
    }
    if (strncmp(filename + i, "720p", 4) == 0)
    {
      *pWidth = 1280;
      *pHeight = 720;
      ENC_TB_INFO_PRINT("Detected resolution 720p (1280x720) from file name.\n");
      return 0;
    }
    if (strncmp(filename + i, "1080p", 5) == 0)
    {
      *pWidth = 1920;
      *pHeight = 1080;
      ENC_TB_INFO_PRINT("Detected resolution 1080p (1920x1080) from file name.\n");
      return 0;
    }
    if (filename[i] == 'x')
    {
      if (sscanf(filename + i - 4, "%ux%u", &w, &h) == 2)
      {
        *pWidth = w;
        *pHeight = h;
        ENC_TB_INFO_PRINT("Detected resolution %dx%d from file name.\n", w, h);
        return 0;
      }
      else if (sscanf(filename + i - 3, "%ux%u", &w, &h) == 2)
      {
        *pWidth = w;
        *pHeight = h;
        ENC_TB_INFO_PRINT("Detected resolution %dx%d from file name.\n", w, h);
        return 0;
      }
      else if (sscanf(filename + i - 2, "%ux%u", &w, &h) == 2)
      {
        *pWidth = w;
        *pHeight = h;
        ENC_TB_INFO_PRINT("Detected resolution %dx%d from file name.\n", w, h);
        return 0;
      }
    }
    if (filename[i] == 'w')
    {
      if (sscanf(filename + i, "w%uh%u", &w, &h) == 2)
      {
        *pWidth = w;
        *pHeight = h;
        ENC_TB_INFO_PRINT("Detected resolution %dx%d from file name.\n", w, h);
        return 0;
      }
    }
  }

  return 1;   /* Error - no resolution found */
}



static char *nextToken (char *str)
{
  char *p = strchr(str, ' ');
  if (p)
  {
    while (*p == ' ') p ++;
    if (*p == '\0') p = NULL;
  }
  return p;
}

static int ParseGopConfigString (char *line, VCEncGopConfig *gopCfg, int frame_idx, int gopSize)
{
  void * tb = NULL;
  if (!line)
    return -1;

  //format: FrameN Type POC QPoffset QPfactor  num_ref_pics ref_pics  used_by_cur
  int frameN, poc, num_ref_pics, i;
  char type;
  VCEncGopPicConfig *cfg = NULL;
  VCEncGopPicSpecialConfig *scfg = NULL;

  //frame idx
  sscanf (line, "Frame%d", &frameN);
  if ((frameN != (frame_idx + 1)) && (frameN != 0)) return -1;

  if (frameN > gopSize)
      return 0;

  if (0 == frameN)
  {
      //format: FrameN Type  QPoffset  QPfactor   TemporalId  num_ref_pics   ref_pics  used_by_cur  LTR    Offset   Interval
      scfg = &(gopCfg->pGopPicSpecialCfg[gopCfg->special_size++]);

      //frame type
      line = nextToken(line);
      if (!line) return -1;
      sscanf(line, "%c", &type);
      if (type == 'I' || type == 'i')
          scfg->codingType = VCENC_INTRA_FRAME;
      else if (type == 'P' || type == 'p')
          scfg->codingType = VCENC_PREDICTED_FRAME;
      else if (type == 'B' || type == 'b')
          scfg->codingType = VCENC_BIDIR_PREDICTED_FRAME;
      else
          scfg->codingType = FRAME_TYPE_RESERVED;

      //qp offset
      line = nextToken(line);
      if (!line) return -1;
      sscanf(line, "%d", &(scfg->QpOffset));

      //qp factor
      line = nextToken(line);
      if (!line) return -1;
      sscanf(line, "%lf", &(scfg->QpFactor));
      scfg->QpFactor = sqrt(scfg->QpFactor);

      //temporalId factor
      line = nextToken(line);
      if (!line) return -1;
      sscanf(line, "%d", &(scfg->temporalId));

      //num_ref_pics
      line = nextToken(line);
      if (!line) return -1;
      sscanf(line, "%d", &num_ref_pics);
      if (num_ref_pics > VCENC_MAX_REF_FRAMES) /* NUMREFPICS_RESERVED -1 */
      {
          ENC_TB_ERROR_PRINT("GOP Config: Error, num_ref_pic can not be more than %d \n", VCENC_MAX_REF_FRAMES);
          return -1;
      }
      scfg->numRefPics = num_ref_pics;

      if ((scfg->codingType == VCENC_INTRA_FRAME) && (0 == num_ref_pics))
          num_ref_pics = 1;
      //ref_pics
      for (i = 0; i < num_ref_pics; i++)
      {
          line = nextToken(line);
          if (!line) return -1;
          if ((strncmp(line, "L", 1) == 0) || (strncmp(line, "l", 1) == 0))
          {
              sscanf(line, "%c%d", &type, &(scfg->refPics[i].ref_pic));
              scfg->refPics[i].ref_pic = LONG_TERM_REF_ID2DELTAPOC( scfg->refPics[i].ref_pic - 1 );
          }
          else
          {
              sscanf(line, "%d", &(scfg->refPics[i].ref_pic));
          }
      }
      if (i < num_ref_pics) return -1;

      //used_by_cur
      for (i = 0; i < num_ref_pics; i++)
      {
          line = nextToken(line);
          if (!line) return -1;
          sscanf(line, "%u", &(scfg->refPics[i].used_by_cur));
      }
      if (i < num_ref_pics) return -1;

      // LTR
      line = nextToken(line);
      if (!line) return -1;
      sscanf(line, "%d", &scfg->i32Ltr);
      if(VCENC_MAX_LT_REF_FRAMES < scfg->i32Ltr)
          return -1;
      
      // Offset
      line = nextToken(line);
      if (!line) return -1;
      sscanf(line, "%d", &scfg ->i32Offset );

      // Interval
      line = nextToken(line);
      if (!line) return -1;
      sscanf(line, "%d", &scfg ->i32Interval );

      if (0 != scfg->i32Ltr)
      {
          gopCfg->u32LTR_idx[ gopCfg->ltrcnt ] = LONG_TERM_REF_ID2DELTAPOC(scfg->i32Ltr-1);
          gopCfg->ltrcnt++;
          if (VCENC_MAX_LT_REF_FRAMES < gopCfg->ltrcnt)
              return -1;
      }

      // short_change
      scfg->i32short_change = 0;
      if (0 == scfg->i32Ltr)
      {
          /* not long-term ref */
          scfg->i32short_change = 1;
          for (i = 0; i < num_ref_pics; i++)
          {
              if (IS_LONG_TERM_REF_DELTAPOC(scfg->refPics[i].ref_pic)&& (0!=scfg->refPics[i].used_by_cur))
              {
                  scfg->i32short_change = 0;
                  break;
              }
          }
      }
  }
  else
  {
      //format: FrameN Type  POC  QPoffset    QPfactor   TemporalId  num_ref_pics  ref_pics  used_by_cur
      cfg = &(gopCfg->pGopPicCfg[gopCfg->size++]);

      //frame type
      line = nextToken(line);
      if (!line) return -1;
      sscanf(line, "%c", &type);
      if (type == 'P' || type == 'p')
          cfg->codingType = VCENC_PREDICTED_FRAME;
      else if (type == 'B' || type == 'b')
          cfg->codingType = VCENC_BIDIR_PREDICTED_FRAME;
      else
          return -1;

      //poc
      line = nextToken(line);
      if (!line) return -1;
      sscanf(line, "%d", &poc);
      if (poc < 1 || poc > gopSize) return -1;
      cfg->poc = poc;

      //qp offset
      line = nextToken(line);
      if (!line) return -1;
      sscanf(line, "%d", &(cfg->QpOffset));

      //qp factor
      line = nextToken(line);
      if (!line) return -1;
      sscanf(line, "%lf", &(cfg->QpFactor));
      // sqrt(QpFactor) is used in calculating lambda
      cfg->QpFactor = sqrt(cfg->QpFactor);

      //temporalId factor
      line = nextToken(line);
      if (!line) return -1;
      sscanf(line, "%d", &(cfg->temporalId));

      //num_ref_pics
      line = nextToken(line);
      if (!line) return -1;
      sscanf(line, "%d", &num_ref_pics);
      if (num_ref_pics < 0 || num_ref_pics > VCENC_MAX_REF_FRAMES)
      {
          ENC_TB_ERROR_PRINT("GOP Config: Error, num_ref_pic can not be more than %d \n", VCENC_MAX_REF_FRAMES);
          return -1;
      }

      //ref_pics
      for (i = 0; i < num_ref_pics; i++)
      {
          line = nextToken(line);
          if (!line) return -1;
          if ((strncmp(line, "L", 1) == 0) || (strncmp(line, "l", 1) == 0))
          {
              sscanf(line, "%c%d", &type, &(cfg->refPics[i].ref_pic));
              cfg->refPics[i].ref_pic = LONG_TERM_REF_ID2DELTAPOC(cfg->refPics[i].ref_pic - 1);
          }
          else
          {
              sscanf(line, "%d", &(cfg->refPics[i].ref_pic));
          }
      }
      if (i < num_ref_pics) return -1;

      //used_by_cur
      for (i = 0; i < num_ref_pics; i++)
      {
          line = nextToken(line);
          if (!line) return -1;
          sscanf(line, "%u", &(cfg->refPics[i].used_by_cur));
      }
      if (i < num_ref_pics) return -1;

      cfg->numRefPics = num_ref_pics;
  }

  return 0;
}



static int ParseGopConfigFile (int gopSize, char *fname, VCEncGopConfig *gopCfg)
{
  void * tb = NULL;
#define MAX_LINE_LENGTH 1024
  int frame_idx = 0, line_idx = 0, addTmp;
  char achParserBuffer[MAX_LINE_LENGTH];
  FILE *fIn = fopen (fname, "r");
  if (fIn == NULL)
  {
    ENC_TB_ERROR_PRINT("GOP Config: Error, Can Not Open File %s\n", fname );
    return -1;
  }

  while ( 0 == feof(fIn))
  {
    if (feof (fIn)) break;
    line_idx ++;
    achParserBuffer[0] = '\0';
    // Read one line
    char *line = fgets ((char *) achParserBuffer, MAX_LINE_LENGTH, fIn);
    if (!line) break;
    //handle line end
    char* s = strpbrk(line, "#\n");
    if(s) *s = '\0';

    addTmp = 1;
    line = strstr(line, "Frame");
    if (line)
    {
      if( 0 == strncmp(line, "Frame0", 6))
          addTmp = 0;

      if (ParseGopConfigString(line, gopCfg, frame_idx, gopSize) < 0)
      {
          ENC_TB_ERROR_PRINT("Invalid gop configure!\n");
          return -1;
      }

      frame_idx += addTmp;
    }
  }

  fclose(fIn);
  if (frame_idx != gopSize)
  {
    ENC_TB_ERROR_PRINT("GOP Config: Error, Parsing File %s Failed at Line %d\n", fname, line_idx);
    return -1;
  }
  return 0;
}


static int ReadGopConfig (char *fname, char **config, VCEncGopConfig *gopCfg, int gopSize, u8 *gopCfgOffset)
{
  int ret = -1;

  if (gopCfg->size >= MAX_GOP_PIC_CONFIG_NUM)
    return -1;
  
  if (gopCfgOffset)
    gopCfgOffset[gopSize] = gopCfg->size;
  if(fname)
  {
    ret = ParseGopConfigFile (gopSize, fname, gopCfg);
  }
  else if(config)
  {
    int id = 0;
    while (config[id])
    {
      ParseGopConfigString (config[id], gopCfg, id, gopSize);
      id ++;
    }
    ret = 0;
  }
  return ret;
}


int InitGopConfigs (int gopSize, HANTROH26xEncOptions *options, VCEncGopConfig *gopCfg, u8 *gopCfgOffset, bool bPass2)
{
  void * tb = NULL;
  int i, pre_load_num;
  char *fname = options->gopCfg;
  char **default_configs[8] = {
              options->gopLowdelay ? RpsLowdelayDefault_GOPSize_1: (IS_H264(options->codecFormat)?RpsDefault_H264_GOPSize_1:RpsDefault_GOPSize_1),
              options->gopLowdelay ? RpsLowdelayDefault_GOPSize_2: RpsDefault_GOPSize_2,
              options->gopLowdelay ? RpsLowdelayDefault_GOPSize_3: RpsDefault_GOPSize_3,
              options->gopLowdelay ? RpsLowdelayDefault_GOPSize_4: RpsDefault_GOPSize_4,
              RpsDefault_GOPSize_5,
              RpsDefault_GOPSize_6,
              RpsDefault_GOPSize_7,
              RpsDefault_GOPSize_8 };

  if (gopSize < 0 || gopSize > MAX_GOP_SIZE)
  {
    ENC_TB_ERROR_PRINT("GOP Config: Error, Invalid GOP Size\n");
    return -1;
  }

  if (bPass2)
  {
    default_configs[1] = RpsPass2_GOPSize_2;
    default_configs[3] = RpsPass2_GOPSize_4;
    default_configs[7] = RpsPass2_GOPSize_8;
  }

  //Handle Interlace
  if (options->interlacedFrame && gopSize==1)
  {
    default_configs[0] = RpsDefault_Interlace_GOPSize_1;
  }

  // GOP size in rps array for gopSize=N
  // N<=4:      GOP1, ..., GOPN
  // 4<N<=8:   GOP1, GOP2, GOP3, GOP4, GOPN
  // N > 8:       GOP1, GOPN
  // Adaptive:  GOP1, GOP2, GOP3, GOP4, GOP6, GOP8
  if (gopSize > 8)
    pre_load_num = 1;
  else if (gopSize>=4 || gopSize==0)
    pre_load_num = 4;
  else
    pre_load_num = gopSize;

  gopCfg->special_size = 0;
  gopCfg->ltrcnt       = 0;

  for (i = 1; i <= pre_load_num; i ++)
  {    
    if (ReadGopConfig (gopSize==i ? fname : NULL, default_configs[i-1], gopCfg, i, gopCfgOffset))
      return -1;
  }

  if (gopSize == 0)
  {
    //gop6
    if (ReadGopConfig (NULL, default_configs[5], gopCfg, 6, gopCfgOffset))
      return -1;
    //gop8
    if (ReadGopConfig (NULL, default_configs[7], gopCfg, 8, gopCfgOffset))
      return -1;
  }
  else if (gopSize > 4)
  {
    //gopSize
    if (ReadGopConfig (fname, default_configs[gopSize-1], gopCfg, gopSize, gopCfgOffset))
      return -1;
  }

  if ((DEFAULT != options->ltrInterval) && (gopCfg->special_size == 0))
  {
      if (options->gopSize != 1)
      {
          ENC_TB_ERROR_PRINT("GOP Config: Error, when using --LTR configure option, the gopsize alse should be set to 1!\n");
          return -1;
      }
      gopCfg->pGopPicSpecialCfg[0].poc = 0;
      gopCfg->pGopPicSpecialCfg[0].QpOffset = options->longTermQpDelta;
      gopCfg->pGopPicSpecialCfg[0].QpFactor = QPFACTOR_RESERVED;
      gopCfg->pGopPicSpecialCfg[0].temporalId = TEMPORALID_RESERVED;
      gopCfg->pGopPicSpecialCfg[0].codingType = FRAME_TYPE_RESERVED;
      gopCfg->pGopPicSpecialCfg[0].numRefPics = NUMREFPICS_RESERVED;
      gopCfg->pGopPicSpecialCfg[0].i32Ltr = 1;
      gopCfg->pGopPicSpecialCfg[0].i32Offset = 0;
      gopCfg->pGopPicSpecialCfg[0].i32Interval = options->ltrInterval;
      gopCfg->pGopPicSpecialCfg[0].i32short_change = 0;
      gopCfg->u32LTR_idx[0]                    = LONG_TERM_REF_ID2DELTAPOC(0);

      gopCfg->pGopPicSpecialCfg[1].poc = 0;
      gopCfg->pGopPicSpecialCfg[1].QpOffset = QPOFFSET_RESERVED;
      gopCfg->pGopPicSpecialCfg[1].QpFactor = QPFACTOR_RESERVED;
      gopCfg->pGopPicSpecialCfg[1].temporalId = TEMPORALID_RESERVED;
      gopCfg->pGopPicSpecialCfg[1].codingType = FRAME_TYPE_RESERVED;
      gopCfg->pGopPicSpecialCfg[1].numRefPics = 2;
      gopCfg->pGopPicSpecialCfg[1].refPics[0].ref_pic     = -1;
      gopCfg->pGopPicSpecialCfg[1].refPics[0].used_by_cur = 1;
      gopCfg->pGopPicSpecialCfg[1].refPics[1].ref_pic     = LONG_TERM_REF_ID2DELTAPOC(0);
      gopCfg->pGopPicSpecialCfg[1].refPics[1].used_by_cur = 1;
      gopCfg->pGopPicSpecialCfg[1].i32Ltr = 0;
      gopCfg->pGopPicSpecialCfg[1].i32Offset = options->longTermGapOffset;
      gopCfg->pGopPicSpecialCfg[1].i32Interval = options->longTermGap;
      gopCfg->pGopPicSpecialCfg[1].i32short_change = 0;

      gopCfg->special_size = 2;
      gopCfg->ltrcnt = 1;
  }

  if (0)
    for(i = 0; i < (gopSize == 0 ? gopCfg->size : gopCfgOffset[gopSize]); i++)
    {
      // when use long-term, change P to B in default configs (used for last gop)
      VCEncGopPicConfig *cfg = &(gopCfg->pGopPicCfg[i]);
      if (cfg->codingType == VCENC_PREDICTED_FRAME)
        cfg->codingType = VCENC_BIDIR_PREDICTED_FRAME;
    }

  //Compatible with old bFrameQpDelta setting
  if (options->bFrameQpDelta >= 0 && fname == NULL)
  {
    for (i = 0; i < gopCfg->size; i++)
    {
      VCEncGopPicConfig *cfg = &(gopCfg->pGopPicCfg[i]);
      if (cfg->codingType == VCENC_BIDIR_PREDICTED_FRAME)
        cfg->QpOffset = options->bFrameQpDelta;
    }
  }

  // lowDelay auto detection
  VCEncGopPicConfig *cfgStart = &(gopCfg->pGopPicCfg[gopCfgOffset[gopSize]]);
  if (gopSize == 1)
  {
    options->gopLowdelay = 1;
  }
  else if ((gopSize > 1) && (options->gopLowdelay == 0))
  {
     options->gopLowdelay = 1;
     for (i = 1; i < gopSize; i++)
     {
        if (cfgStart[i].poc < cfgStart[i-1].poc)
        {
          options->gopLowdelay = 0;
          break;
        }
     }
  }

#ifdef INTERNAL_TEST
  if ((options->testId == TID_POC && gopSize == 1) && !IS_H264(options->codecFormat))
  {
    VCEncGopPicConfig *cfg = &(gopCfg->pGopPicCfg[0]);
    if (cfg->numRefPics == 2)
      cfg->refPics[1].ref_pic = -(options->intraPicRate-1);
  }
#endif

  {
      i32 i32LtrPoc[VCENC_MAX_LT_REF_FRAMES];

      for (i = 0; i < VCENC_MAX_LT_REF_FRAMES; i++)
          i32LtrPoc[i] = -1;
      for (i = 0; i < gopCfg->special_size; i++)
      {
          if (gopCfg->pGopPicSpecialCfg[i].i32Ltr > VCENC_MAX_LT_REF_FRAMES)
          {
              ENC_TB_ERROR_PRINT("GOP Config: Error, Invalid long-term index\n");
              return -1;
          }
          if (gopCfg->pGopPicSpecialCfg[i].i32Ltr > 0)
              i32LtrPoc[i] = gopCfg->pGopPicSpecialCfg[i].i32Ltr - 1;
      }

      for (i = 0; i < gopCfg->ltrcnt; i++)
      {
          if ((0 != i32LtrPoc[0]) || (-1 == i32LtrPoc[i]) || ((i>0) && i32LtrPoc[i] != (i32LtrPoc[i - 1] + 1)))
          {
              ENC_TB_ERROR_PRINT("GOP Config: Error, Invalid long-term index\n");
              return -1;
          }
      }
  }

  //For lowDelay, Handle the first few frames that miss reference frame
  if (1)
  {
    int nGop;
    int idx = 0;
    int maxErrFrame = 0;
    VCEncGopPicConfig *cfg;

    // Find the max frame number that will miss its reference frame defined in rps    
    while ((idx - maxErrFrame) < gopSize)
    {
      nGop = (idx / gopSize) * gopSize;
      cfg = &(cfgStart[idx % gopSize]);

      for (i = 0; i < cfg->numRefPics; i ++)
      {
        //POC of this reference frame
        int refPoc = cfg->refPics[i].ref_pic + cfg->poc + nGop;
        if (refPoc < 0)
        {
          maxErrFrame = idx + 1;
        }
      }
      idx ++;
    }

    // Try to config a new rps for each "error" frame by modifying its original rps 
    for (idx = 0; idx < maxErrFrame; idx ++)
    {
      int j, iRef, nRefsUsedByCur, nPoc;
      VCEncGopPicConfig *cfgCopy;

      if (gopCfg->size >= MAX_GOP_PIC_CONFIG_NUM)
        break;

      // Add to array end
      cfg = &(gopCfg->pGopPicCfg[gopCfg->size]);
      cfgCopy = &(cfgStart[idx % gopSize]);
      memcpy (cfg, cfgCopy, sizeof (VCEncGopPicConfig));
      gopCfg->size ++;

      // Copy reference pictures
      nRefsUsedByCur = iRef = 0;
      nPoc = cfgCopy->poc + ((idx / gopSize) * gopSize);
      for (i = 0; i < cfgCopy->numRefPics; i ++)
      {
        int newRef = 1;
        int used_by_cur = cfgCopy->refPics[i].used_by_cur;
        int ref_pic = cfgCopy->refPics[i].ref_pic;
        // Clip the reference POC
        if ((cfgCopy->refPics[i].ref_pic + nPoc) < 0)
          ref_pic = 0 - (nPoc);

        // Check if already have this reference
        for (j = 0; j < iRef; j ++)
        {
          if (cfg->refPics[j].ref_pic == ref_pic)
          {
             newRef = 0;
             if (used_by_cur)
               cfg->refPics[j].used_by_cur = used_by_cur;
             break;
          }
        }

        // Copy this reference        
        if (newRef)
        {          
          cfg->refPics[iRef].ref_pic = ref_pic;
          cfg->refPics[iRef].used_by_cur = used_by_cur;
          iRef ++;
        }
      }
      cfg->numRefPics = iRef;
      // If only one reference frame, set P type.
      for (i = 0; i < cfg->numRefPics; i ++)
      {
        if (cfg->refPics[i].used_by_cur)
          nRefsUsedByCur ++;
      }
      if (nRefsUsedByCur == 1)
        cfg->codingType = VCENC_PREDICTED_FRAME;
    }
  }

#if 0
      //print for debug
      int idx;
      printf ("====== REF PICTURE SETS from %s ======\n",fname ? fname : "DEFAULT");
      for (idx = 0; idx < gopCfg->size; idx ++)
      {
        int i;
        VCEncGopPicConfig *cfg = &(gopCfg->pGopPicCfg[idx]);
        char type = cfg->codingType==VCENC_PREDICTED_FRAME ? 'P' : cfg->codingType == VCENC_INTRA_FRAME ? 'I' : 'B';
        printf (" FRAME%2d:  %c %d %d %f %d", idx, type, cfg->poc, cfg->QpOffset, cfg->QpFactor, cfg->numRefPics);
        for (i = 0; i < cfg->numRefPics; i ++)
          printf (" %d", cfg->refPics[i].ref_pic);
        for (i = 0; i < cfg->numRefPics; i ++)
          printf (" %d", cfg->refPics[i].used_by_cur);
        printf("\n");
      }
      printf ("===========================================\n");
#endif
  return 0;
}

/*------------------------------------------------------------------------------

    ReadUserData
        Read user data from file and pass to encoder

    Params:
        name - name of file in which user data is located

    Returns:
        NULL - when user data reading failed
        pointer - allocated buffer containing user data

------------------------------------------------------------------------------*/
u8 *ReadUserData(VCEncInst encoder, char *name)
{
  void * tb = NULL;
  FILE *file = NULL;
  i32 byteCnt;
  u8 *data;

  if (name == NULL)
    return NULL;

  if (strcmp("0", name) == 0)
    return NULL;

  /* Get user data length from file */
  file = fopen(name, "rb");
  if (file == NULL)
  {
    ENC_TB_ERROR_PRINT("Unable to open User Data file: %s\n", name);
    return NULL;
  }
  fseeko(file, 0L, SEEK_END);
  byteCnt = ftell(file);
  rewind(file);

  /* Minimum size of user data */
  if (byteCnt < 16)
    byteCnt = 16;

  /* Maximum size of user data */
  if (byteCnt > 2048)
    byteCnt = 2048;

  /* Allocate memory for user data */
  if ((data = (u8 *) EWLmalloc(sizeof(u8) * byteCnt)) == NULL)
  {
    fclose(file);
    ENC_TB_ERROR_PRINT("Unable to alloc User Data memory\n");
    return NULL;
  }

  /* Read user data from file */
  i32 ret = fread(data, sizeof(u8), byteCnt, file);
  fclose(file);

  ENC_TB_INFO_PRINT("User data: %d bytes [%d %d %d %d ...]\n",
         byteCnt, data[0], data[1], data[2], data[3]);

  /* Pass the data buffer to encoder
   * The encoder reads the buffer during following VCEncStrmEncode() calls.
   * User data writing must be disabled (with VCEncSetSeiUserData(enc, 0, 0)) */
  VCEncSetSeiUserData(encoder, data, byteCnt);

  return data;
}

/*------------------------------------------------------------------------------
    Add new frame bits for moving average bitrate calculation
------------------------------------------------------------------------------*/
void MaAddFrame(ma_s *ma, i32 frameSizeBits)
{
    ma->frame[ma->pos++] = frameSizeBits;

    if (ma->pos == ma->length)
        ma->pos = 0;

    if (ma->count < ma->length)
        ma->count++;
}

/*------------------------------------------------------------------------------
    Calculate average bitrate of moving window
------------------------------------------------------------------------------*/
i32 Ma(ma_s *ma)
{
    i32 i;
    unsigned long long sum = 0;     /* Using 64-bits to avoid overflow */

    for (i = 0; i < ma->count; i++)
        sum += ma->frame[i];

    if (!ma->frameRateDenom)
        return 0;

    sum = sum / ma->count;

    return sum * (ma->frameRateNumer+ma->frameRateDenom-1) / ma->frameRateDenom;
}

i32 getNextGopSize(struct test_bench *tb, VCEncIn *pEncIn, VCEncInst encoder, i32 *pNextGopSize, adapGopCtr *agop)
{
  struct vcenc_instance *vcenc_instance = (struct vcenc_instance *)encoder;
  if (vcenc_instance->lookaheadDepth)
  {
    i32 updGop = getPass1UpdatedGopSize(vcenc_instance->lookahead.priv_inst);
    if (updGop)
      *pNextGopSize = updGop;
  }
  else if (pEncIn->codingType != VCENC_INTRA_FRAME)
    AdaptiveGopDecision(tb, pEncIn, encoder, pNextGopSize, agop);

  return *pNextGopSize;
}

i32 AdaptiveGopDecision(struct test_bench *tb, VCEncIn *pEncIn, VCEncInst encoder, i32 *pNextGopSize, adapGopCtr * agop)
{
    i32 nextGopSize =-1;
    
    struct vcenc_instance *vcenc_instance = (struct vcenc_instance *)encoder;
    unsigned int uiIntraCu8Num = vcenc_instance->asic.regs.intraCu8Num;
    unsigned int uiSkipCu8Num = vcenc_instance->asic.regs.skipCu8Num;
    unsigned int uiPBFrameCost = vcenc_instance->asic.regs.PBFrame4NRdCost;
    double dIntraVsInterskip = (double)uiIntraCu8Num/(double)((tb->width/8) * (tb->height/8));
    double dSkipVsInterskip = (double)uiSkipCu8Num/(double)((tb->width/8) * (tb->height/8));
    
    agop->gop_frm_num++;
    agop->sum_intra_vs_interskip += dIntraVsInterskip;
    agop->sum_skip_vs_interskip += dSkipVsInterskip;
    agop->sum_costP += (pEncIn->codingType == VCENC_PREDICTED_FRAME)? uiPBFrameCost:0;
    agop->sum_costB += (pEncIn->codingType == VCENC_BIDIR_PREDICTED_FRAME)? uiPBFrameCost:0;
    agop->sum_intra_vs_interskipP += (pEncIn->codingType == VCENC_PREDICTED_FRAME)? dIntraVsInterskip:0;
    agop->sum_intra_vs_interskipB += (pEncIn->codingType == VCENC_BIDIR_PREDICTED_FRAME)? dIntraVsInterskip:0; 
    
    if(pEncIn->gopPicIdx == pEncIn->gopSize-1)//last frame of the current gop. decide the gopsize of next gop.
    {
      dIntraVsInterskip = agop->sum_intra_vs_interskip/agop->gop_frm_num;
      dSkipVsInterskip = agop->sum_skip_vs_interskip/agop->gop_frm_num;
      agop->sum_costB = (agop->gop_frm_num>1)?(agop->sum_costB/(agop->gop_frm_num-1)):0xFFFFFFF;
      agop->sum_intra_vs_interskipB = (agop->gop_frm_num>1)?(agop->sum_intra_vs_interskipB/(agop->gop_frm_num-1)):0xFFFFFFF;
      //Enabled adaptive GOP size for large resolution
      if (((tb->width * tb->height) >= (1280 * 720)) || ((MAX_ADAPTIVE_GOP_SIZE >3)&&((tb->width * tb->height) >= (416 * 240))))
      {
          if ((((double)agop->sum_costP/(double)agop->sum_costB)<1.1)&&(dSkipVsInterskip >= 0.95))
          {
              agop->last_gopsize = nextGopSize = 1;
          }
          else if (((double)agop->sum_costP/(double)agop->sum_costB)>5)
          {
              nextGopSize = agop->last_gopsize;
          }
          else
          {
              if( ((agop->sum_intra_vs_interskipP > 0.40) && (agop->sum_intra_vs_interskipP < 0.70)&& (agop->sum_intra_vs_interskipB < 0.10)) )
              {
                  agop->last_gopsize++;
                  if(agop->last_gopsize==5 || agop->last_gopsize==7)  
                  {
                      agop->last_gopsize++;
                  }
                  agop->last_gopsize = MIN(agop->last_gopsize, MAX_ADAPTIVE_GOP_SIZE);
                  nextGopSize = agop->last_gopsize; //
              }
              else if (dIntraVsInterskip >= 0.30)
              {
                  agop->last_gopsize = nextGopSize = 1; //No B
              }
              else if (dIntraVsInterskip >= 0.20)
              {
                  agop->last_gopsize = nextGopSize = 2; //One B
              }
              else if (dIntraVsInterskip >= 0.10)
              {
                  agop->last_gopsize--;
                  if(agop->last_gopsize == 5 || agop->last_gopsize==7) 
                  {
                      agop->last_gopsize--;
                  }
                  agop->last_gopsize = MAX(agop->last_gopsize, 3);
                  nextGopSize = agop->last_gopsize; //
              }
              else
              {
                  agop->last_gopsize++;
                  if(agop->last_gopsize==5 || agop->last_gopsize==7)  
                  {
                      agop->last_gopsize++;
                  }
                  agop->last_gopsize = MIN(agop->last_gopsize, MAX_ADAPTIVE_GOP_SIZE);
                  nextGopSize = agop->last_gopsize; //
              }
          }
      }
      else
      {
        nextGopSize = 3;
      }
      agop->gop_frm_num = 0;
      agop->sum_intra_vs_interskip = 0;
      agop->sum_skip_vs_interskip = 0;
      agop->sum_costP = 0;
      agop->sum_costB = 0;
      agop->sum_intra_vs_interskipP = 0;
      agop->sum_intra_vs_interskipB = 0;
  
      nextGopSize = MIN(nextGopSize, MAX_ADAPTIVE_GOP_SIZE);

    }

    if(nextGopSize != -1)
        *pNextGopSize = nextGopSize;
    
    return nextGopSize;
}

#if defined(SUPPORT_DEC400) || defined(SUPPORT_TCACHE)
#include "fb_ips.h"
#include "dec400_f2_api.h"
#include "tcache_api.h"
#include "trans_edma_api.h"
#include "dtrc_api.h"
#include "l2cache_api.h"

#define VCE_HEIGHT_ALIGNMENT 64
#define VCE_INPUT_ALIGNMENT 32
#endif

i32 ChangeFormatForFB(struct test_bench *tb, HANTROH26xEncOptions *options,VCEncPreProcessingCfg *preProcCfg)
{
  switch (options->inputFormat)
  {
#ifdef SUPPORT_DEC400
  //for dec400
  case INPUT_FORMAT_YUV420_SEMIPLANAR_8BIT_COMPRESSED_FB:
    preProcCfg->inputType = VCENC_YUV420_SEMIPLANAR_8BIT_FB;
    preProcCfg->input_alignment = 1024;
    break;
  case INPUT_FORMAT_YUV420_SEMIPLANAR_VU_8BIT_COMPRESSED_FB:
    preProcCfg->inputType = VCENC_YUV420_SEMIPLANAR_VU_8BIT_FB;
    preProcCfg->input_alignment = 1024;
    break;
  case INPUT_FORMAT_YUV420_PLANAR_10BIT_P010_COMPRESSED_FB:
    preProcCfg->inputType = VCENC_YUV420_PLANAR_10BIT_P010_FB;
    preProcCfg->input_alignment = 1024;
    break;
#endif
#ifdef SUPPORT_TCACHE
  //for tcache
  case VCENC_YUV420_PLANAR:
  case VCENC_YUV420_SEMIPLANAR:
  case VCENC_YUV420_SEMIPLANAR_VU:
  case INPUT_FORMAT_YUV422P:
  case INPUT_FORMAT_YUV444P:
  case INPUT_FORMAT_RFC_8BIT_COMPRESSED_FB:
    preProcCfg->inputType = VCENC_YUV420_SEMIPLANAR;
    preProcCfg->input_alignment = 32;
    break;
  case VCENC_YUV420_PLANAR_10BIT_P010: /*this is semiplaner P010LE*/
  case INPUT_FORMAT_YUV420_SEMIPLANAR_10BIT_P010BE:
  case INPUT_FORMAT_YUV420_PLANAR_10BIT_P010BE:
  case INPUT_FORMAT_YUV420_PLANAR_10BIT_P010LE:
  case INPUT_FORMAT_YUV422P10LE:
  case INPUT_FORMAT_YUV422P10BE:
  case INPUT_FORMAT_RFC_10BIT_COMPRESSED_FB:
    preProcCfg->inputType = VCENC_YUV420_PLANAR_10BIT_P010;
    preProcCfg->input_alignment = 32;
    break;
  case INPUT_FORMAT_ARGB_FB:
  case INPUT_FORMAT_ABGR_FB:
  case INPUT_FORMAT_BGRA_FB:
  case INPUT_FORMAT_RGBA_FB:
  case INPUT_FORMAT_BGR24_FB:
  case INPUT_FORMAT_RGB24_FB:
    preProcCfg->inputType = (options->bitDepthLuma == 10) ? VCENC_YUV420_PLANAR_10BIT_P010 : VCENC_YUV420_SEMIPLANAR;
    preProcCfg->input_alignment = 32;
    break;
#else
  case VCENC_YUV420_SEMIPLANAR:
  case VCENC_YUV420_PLANAR_10BIT_P010:
    //don't change
    break;
#endif
  case INPUT_FORMAT_PP_YUV420_SEMIPLANNAR:
    preProcCfg->inputType = VCENC_YUV420_SEMIPLANAR;
    //preProcCfg->input_alignment = 32; //depend on the options option
    break;
  case INPUT_FORMAT_PP_YUV420_SEMIPLANNAR_VU:
    preProcCfg->inputType = VCENC_YUV420_SEMIPLANAR_VU;
    //preProcCfg->input_alignment = 32; //depend on the options option
    break;

  case INPUT_FORMAT_PP_YUV420_SEMIPLANNAR_YUV420P:
    preProcCfg->inputType = VCENC_YUV420_PLANAR;
    preProcCfg->input_alignment = 32;
    break;
    
  case INPUT_FORMAT_PP_YUV420_PLANAR_10BIT_P010:
    preProcCfg->inputType = VCENC_YUV420_PLANAR_10BIT_P010;
    preProcCfg->input_alignment = 32;
    break;
  default:
    break;
  }
  ENC_TB_DEBUGV_PRINT("::::: format %d -> %d, input alignment change to %d\n",
    options->inputFormat, preProcCfg->inputType, preProcCfg->input_alignment);
  return 0;
}

#ifdef SUPPORT_TCACHE
#if 0
TCACHE_PIX_FMT input_format_2_tcache_format(i32 input_format)
{
	switch (input_format) {
	case VCENC_YUV420_PLANAR:
		return TCACHE_PIX_FMT_YUV420P; /* 0 */
	case VCENC_YUV420_SEMIPLANAR:
    case INPUT_FORMAT_RFC_8BIT_COMPRESSED_FB:
		return TCACHE_PIX_FMT_NV12;  /* 1 */
    case VCENC_YUV420_SEMIPLANAR_VU:
        return TCACHE_PIX_FMT_NV21;  /* 2 */
	case INPUT_FORMAT_YUV420_PLANAR_10BIT_P010LE:
		return TCACHE_PIX_FMT_YUV420P10LE;  /* 3 */
	case INPUT_FORMAT_YUV420_PLANAR_10BIT_P010BE:
		return TCACHE_PIX_FMT_YUV420P10BE;  /* 4 */
	case VCENC_YUV420_PLANAR_10BIT_P010:
		return TCACHE_PIX_FMT_P010LE;  /* 5 */
	case INPUT_FORMAT_YUV420_SEMIPLANAR_10BIT_P010BE:
		return TCACHE_PIX_FMT_P010BE;  /* 6 */
    case INPUT_FORMAT_YUV422P:
        return TCACHE_PIX_FMT_YUV422P; /* 7 */
    case INPUT_FORMAT_YUV422P10LE:
        return TCACHE_PIX_FMT_YUV422P10LE; /* 8 */
    case INPUT_FORMAT_YUV422P10BE:
        return TCACHE_PIX_FMT_YUV422P10BE; /* 9 */
    case INPUT_FORMAT_YUV444P:
        return TCACHE_PIX_FMT_YUV444P; /* 10 */
    case INPUT_FORMAT_RGB24_FB:
        return TCACHE_PIX_FMT_RGB24; /* 11 */
    case INPUT_FORMAT_BGR24_FB:
        return TCACHE_PIX_FMT_BGR24; /* 12 */
    case INPUT_FORMAT_ARGB_FB:
        return TCACHE_PIX_FMT_ARGB; /* 13 */
    case INPUT_FORMAT_RGBA_FB:
        return TCACHE_PIX_FMT_RGBA; /* 14 */
    case INPUT_FORMAT_ABGR_FB:
        return TCACHE_PIX_FMT_ABGR; /* 15 */
    case INPUT_FORMAT_BGRA_FB:
        return TCACHE_PIX_FMT_BGRA; /* 16 */
    case INPUT_FORMAT_RFC_10BIT_COMPRESSED_FB:
        return TCACHE_PIX_FMT_DTRC_PACKED_10_NV12; /* 17 */
	default:
		return -1;
	}
}
#endif
#endif

#if defined(SUPPORT_DEC400) || defined(SUPPORT_TCACHE)
i32 read_table(struct test_bench *tb, u32 lum_tbl_size, u32 ch_tbl_size)
{
  i32 num;

#if 1
  num = next_picture(tb, tb->encIn.picture_cnt) + tb->firstPic;
#else
  num = tb->picture_enc_cnt;
#endif

  if (num > tb->lastPic) return NOK;

  if (file_read(tb->ints, tb->tslu, num*(lum_tbl_size+ch_tbl_size), lum_tbl_size))
    return NOK;
  if (file_read(tb->ints, tb->tsch, num*(lum_tbl_size+ch_tbl_size)+lum_tbl_size, ch_tbl_size))
    return NOK;
  
  return OK;
}

#if 0
i32 ReleaseInputHwTransformer(struct test_bench *tb, HANTROH26xEncOptions *cmdl, const void * ewl)
{
#ifdef SUPPORT_TCACHE
  if (tb->edma_handle && TRANS_EDMA_link_is_running((EDMA_HANDLE)tb->edma_handle)) {
    ENC_TB_DEBUGV_PRINT("wait read link done\n");
    if (TRANS_EDMA_RC2EP_link_finish((EDMA_HANDLE)tb->edma_handle)) {
      ENC_TB_ERROR_PRINT("wait read link done failed!!!!\n");
      return -1;
    }
  }
#endif
  return 0;
}

i32 SetupInputHwTransformer(struct test_bench *tb, HANTROH26xEncOptions *options, const void * ewl)
{
    u32 bit_depth;
    VCEncIn *pEncIn = &(tb->encIn);
    static u32 edma_link_ep_base[MAX_INPUT_PLANE+MAX_OUTPUT_PLANE] = {
    	       0x00000000, 0x02000000, 0x03000000, 0x02000000, 0x01000000
    };
#ifdef SUPPORT_L2CACHE
    L2R_GLOBAL_CFG l2rGf = {0};
    L2R_STREAM_CONFIG l2rStream = {0};
#endif

    bit_depth = 8;

    switch (options->inputFormat)
    {
#ifdef SUPPORT_DEC400
    case INPUT_FORMAT_YUV420_PLANAR_10BIT_P010_COMPRESSED_FB:
        bit_depth = 10;
        //fall into
    case INPUT_FORMAT_YUV420_SEMIPLANAR_8BIT_COMPRESSED_FB:
    case INPUT_FORMAT_YUV420_SEMIPLANAR_VU_8BIT_COMPRESSED_FB:
    {
        F2_DEC_STREAM_CFG read_streams;
        F2_BIT_DEPTH enum_bit_depth;
        F2_ALIGN_MODE align_mode;
        F2_TILE_MODE tile_mode;

        if (tb->dec400f2_handle == NULL) {
            tb->dec400f2_handle = EWLGetIpHandleByOffset(ewl, F2_DEC_OFFSET_TO_VCEA);
            if (tb->dec400f2_handle == NULL) {
                ENC_TB_ERROR_PRINT("failed get dec400 F2 handle!\n");
                return -1;
            }
        }
        
        if (tb->vce_l2r_handle == NULL) {
          tb->vce_l2r_handle = EWLGetIpHandleByOffset(ewl, VCEAL2R_OFFSET_TO_VCEA);
          if (tb->vce_l2r_handle == NULL) {
            ENC_TB_ERROR_PRINT("failed to get vce l2cache!\n");
          	return -1;
          }
        }
      
        l2rGf.sw_cache_e = 1;
        L2R_global_config(tb->vce_l2r_handle, &l2rGf);

        align_mode = F2_COMP_ALIGN_256B;
        enum_bit_depth = (bit_depth == 10) ? F2_BIT_DEPTH_10 : F2_BIT_DEPTH_8;

        ENC_TB_DEBUGV_PRINT("input: bit_depth %d, lumaSize %d, chromaSize %d\n",
                bit_depth, tb->lumaSize, tb->chromaSize);

      	//input luma
        tile_mode = (bit_depth == 10) ? F2_TILE_MODE_128x4 : F2_TILE_MODE_256x4;

        read_streams.bit_depth = enum_bit_depth;
        read_streams.compression_enable = 1;
        read_streams.compression_format = F2_COMP_FMT_YUV_ONLY;
        read_streams.stream_mode = F2_STREAM_MODE_INPUTY;
        read_streams.tile_mode = tile_mode;
        read_streams.buf_base = tb->encIn.busLuma; //tb->pictureMem->busAddress;
        read_streams.buf_end = read_streams.buf_base + tb->lumaSize - 1;
        read_streams.cache_base = tb->TSLumaMem->busAddress;

        F2_DEC_stream_config(tb->dec400f2_handle, READ_STREAM, &read_streams);

        //input chroma
        tile_mode = (bit_depth == 10) ? F2_TILE_MODE_64x4 : F2_TILE_MODE_128x4;

        read_streams.bit_depth = enum_bit_depth;
        read_streams.compression_enable = 1;
        read_streams.compression_format = F2_COMP_FMT_UV_MIX;
        read_streams.stream_mode = F2_STREAM_MODE_INPUTUV;
        read_streams.tile_mode = tile_mode;
        read_streams.buf_base = tb->encIn.busChromaU; //tb->pictureMem->busAddress + tb->lumaSize;
        read_streams.buf_end = read_streams.buf_base + tb->chromaSize - 1;
        read_streams.cache_base = tb->TSChromaMem->busAddress;

        F2_DEC_stream_config(tb->dec400f2_handle, READ_STREAM, &read_streams);

        break;
    }
#endif
#ifdef SUPPORT_TCACHE
    case INPUT_FORMAT_RFC_10BIT_COMPRESSED_FB:
        bit_depth = 10;
        //fall into
    case INPUT_FORMAT_RFC_8BIT_COMPRESSED_FB:
    {
        DTRC_GLOBAL_CONFIG dgc = {0};
        DTRC_FRAME dtrc_frame = {0};
        TCACHE_PARAM tcache_param = {0};
        TCACHE_PARAM * pParam = &tcache_param;
        int rplanes, plane, i;
        int stride, align_stride, height;
        u32 input_width, input_height, output_width, output_height;
        TCACHE_PIX_FMT input_format, output_format;
        u32 start_addr;
        u32 end_addr;
        u32 plane_size[MAX_INPUT_PLANE];
        int block_size[MAX_INPUT_PLANE];
        u32 offset[MAX_INPUT_PLANE];
        L2R_GLOBAL_CFG l2rGf = {0};
        
        //L2 config
        if (tb->tcache_dtrc_l2_handle == NULL) {
            tb->tcache_dtrc_l2_handle = EWLGetIpHandleByOffset(ewl, DTRCL2R_OFFSET_TO_VCEA);
            if (tb->tcache_dtrc_l2_handle == NULL) {
                ENC_TB_ERROR_PRINT("failed get l2 of dtrc in tcache!\n");
                return -1;
            }
        }
        l2rGf.sw_cache_e = 1;
        l2rGf.sw_reorder_e = 1;
        l2rGf.sw_cache_all_e = 1;
        L2R_global_config(tb->tcache_dtrc_l2_handle, &l2rGf);

        //DTRC config
        if (tb->tcache_dtrc_handle == NULL) {
            tb->tcache_dtrc_handle = EWLGetIpHandleByOffset(ewl, DTRC_OFFSET_TO_VCEA);
            if (tb->tcache_dtrc_handle == NULL) {
                ENC_TB_ERROR_PRINT("failed get dtrc in tcache!\n");
                return -1;
            }
        }
        dgc.max_burst_length = 0xff;
        if (!dgc.bp_byARADDR) {
            dgc.id_y = 0x1;
            dgc.id_uv = 0x0;
        }
        DTRC_global_config(tb->tcache_dtrc_handle, &dgc);

        dtrc_frame.SrcWidth = STRIDE(options->lumWidthSrc,DTRC_INPUT_WIDTH_ALIGNMENT);
        dtrc_frame.SrcHeight = STRIDE(options->lumHeightSrc,DTRC_INPUT_HEIGHT_ALIGNMENT);
        dtrc_frame.type_main8 = (bit_depth == 8);
        dtrc_frame.YDataAddr = tb->encIn.busLuma;
        dtrc_frame.UVDataAddr = tb->encIn.busChromaU;
        dtrc_frame.YTableAddr = tb->TSLumaMem->busAddress;
        dtrc_frame.UVTableAddr = tb->TSChromaMem->busAddress;
        if (dgc.bp_byARADDR) {
            dtrc_frame.YSSA = edma_link_ep_base[MAX_INPUT_PLANE+0];
            dtrc_frame.YSEA = dtrc_frame.YSSA + tb->lumaSize - 1;;
            dtrc_frame.UVSSA = edma_link_ep_base[MAX_INPUT_PLANE+1];
            dtrc_frame.UVSEA = dtrc_frame.UVSSA + tb->chromaSize - 1;
        }
        DTRC_frame_config(tb->tcache_dtrc_handle, &dtrc_frame);

        //TCache read config
        if (tb->tcache_handle == NULL) {
        	tb->tcache_handle = EWLGetIpHandleByOffset(ewl, TCACHE_OFFSET_TO_VCEA);
          	if (tb->tcache_handle == NULL) {
              ENC_TB_ERROR_PRINT("failed get tcache handle!\n");
          		return -1;
          	}
        }
        if (tb->vce_l2r_handle == NULL) {
          tb->vce_l2r_handle = EWLGetIpHandleByOffset(ewl, VCEAL2R_OFFSET_TO_VCEA);
          if (tb->vce_l2r_handle == NULL) {
            ENC_TB_ERROR_PRINT("failed to get vce l2cache!\n");
          	return -1;
          }
        }
      
        l2rGf.sw_cache_e = 1;
        l2rGf.sw_reorder_e = 0;
        L2R_global_config(tb->vce_l2r_handle, &l2rGf);

        input_width = dtrc_frame.SrcWidth;
        input_height = dtrc_frame.SrcHeight;
        input_format = input_format_2_tcache_format(options->inputFormat);
        
        output_width = input_width;
        output_height = STRIDE(input_height,VCE_HEIGHT_ALIGNMENT);
        output_format = tcache_get_output_format(input_format, bit_depth);

        pParam->dtrc_read_enable = 1;
        pParam->dtrc_bitdepth = (bit_depth == 10);
        pParam->dtrc_frame_height = input_height;
        pParam->dtrc_frame_stride = STRIDE((input_width*bit_depth+7)/8,TCACHE_RAW_INPUT_ALIGNMENT);
        pParam->dtrc_read_luma_enable = 1;
        if (dgc.bp_byARADDR)
            pParam->dtrc_read_luma_start_address = dtrc_frame.YSSA;
        else
            pParam->dtrc_read_luma_AXIID = dgc.id_y;
        pParam->dtrc_read_chroma_enable = 1;
        if (dgc.bp_byARADDR)
            pParam->dtrc_read_chroma_start_address = dtrc_frame.UVSSA;
        else
            pParam->dtrc_read_chroma_AXIID = dgc.id_uv;

        pParam->read_format = output_format;
        pParam->read_count = 0;
        pParam->read_client = 1; // VC8000E
        rplanes = tcache_get_planes(output_format);
        if (rplanes < 0)
        	return VCENC_ERROR;
        printf("read planes = %d\n", rplanes);
        for (plane = 0; plane < rplanes; plane++)
        {
        	//stride = tcache_get_stride(STRIDE(output_width*((bit_depth+7)/8),32)/((bit_depth+7)/8), output_format, plane);
        	stride = tcache_get_stride(output_width, output_format, plane, VCE_INPUT_ALIGNMENT);
        	if (stride < 0)
        		return VCENC_ERROR;
        	printf("stride = %d\n", stride);
        	align_stride = tcache_get_stride_align(stride);
        	if (align_stride < 0)
        		return VCENC_ERROR;
        	printf("align_stride = %d\n", align_stride);
        	pParam->readStride[plane] = align_stride;
            //pParam->readValidStride[plane] = input_width;
            pParam->readValidStride[plane] = align_stride;
        	
        	start_addr = edma_link_ep_base[MAX_INPUT_PLANE+plane] & 0x03FFFFFF; // for NOC look
        	printf("plane %d start_addr = 0x%08x\n", plane, start_addr);
        	pParam->readStartAddr[plane] = start_addr;
        	
        	height = tcache_get_height(output_height, output_format, plane);
        	if (height < 0)
        		return VCENC_ERROR;
        	plane_size[plane] = align_stride * height;
        	end_addr = start_addr + plane_size[plane] - 1;
        	printf("plane %d end_addr = 0x%08x\n", plane, end_addr);
        	pParam->readEndAddr[plane] = end_addr;
            
        }
        pEncIn->busLuma = edma_link_ep_base[MAX_INPUT_PLANE+0];
        pEncIn->busChromaU = edma_link_ep_base[MAX_INPUT_PLANE+1];
        pEncIn->busChromaV = 0;

        printf("config tcache\n");
        TCACHE_config(tb->tcache_handle, pParam);
        break;
    }
    case VCENC_YUV420_PLANAR:
    case VCENC_YUV420_SEMIPLANAR:
    case VCENC_YUV420_SEMIPLANAR_VU:
    case INPUT_FORMAT_YUV420_PLANAR_10BIT_P010LE:
    case INPUT_FORMAT_YUV420_PLANAR_10BIT_P010BE:
    case VCENC_YUV420_PLANAR_10BIT_P010:
    case INPUT_FORMAT_YUV420_SEMIPLANAR_10BIT_P010BE:
    case INPUT_FORMAT_YUV422P:
    case INPUT_FORMAT_YUV422P10LE:
    case INPUT_FORMAT_YUV422P10BE:
    case INPUT_FORMAT_YUV444P:
    case INPUT_FORMAT_RGB24_FB:
    case INPUT_FORMAT_BGR24_FB:
    case INPUT_FORMAT_ARGB_FB:
    case INPUT_FORMAT_RGBA_FB:
    case INPUT_FORMAT_ABGR_FB:
    case INPUT_FORMAT_BGRA_FB:
    {
        TCACHE_PARAM tcache_param = {0};
        TCACHE_PARAM * pParam = &tcache_param;
        int wplanes, rplanes, plane, i;
        int link_size, stride, align_stride, height;
        u32 input_width, input_height, output_width, output_height;
        TCACHE_PIX_FMT input_format, output_format;
        u32 start_addr;
        u32 end_addr;
        ptr_t edma_link_rc_base[MAX_INPUT_PLANE];
        u32 plane_size[MAX_INPUT_PLANE];
        int block_size[MAX_INPUT_PLANE];
        u32 offset[MAX_INPUT_PLANE];
        struct dma_link_table * edma_link;
        u32 alignment = tb->input_alignment;
        int ret;

        if (tb->tcache_handle == NULL) {
        	tb->tcache_handle = EWLGetIpHandleByOffset(ewl, TCACHE_OFFSET_TO_VCEA);
          	if (tb->tcache_handle == NULL) {
              printf("failed get tcache handle!\n");
          		return -1;
          	}
        }
        if (tb->edma_handle == NULL) {
        	tb->edma_handle = EWLGetIpHandle(ewl, PCIE_EDMA_REG_BASE-PCIE_REG_START);
          	if (tb->edma_handle == NULL) {
          		return -1;
          	}
        }
        if (tb->vce_l2r_handle == NULL) {
          tb->vce_l2r_handle = EWLGetIpHandleByOffset(ewl, VCEAL2R_OFFSET_TO_VCEA);
          if (tb->vce_l2r_handle == NULL) {
            printf("failed to get vce l2cache!\n");
          	return -1;
          }
        }
      
        l2rGf.sw_cache_e = 1;
        l2rGf.sw_reorder_e = 0;
        L2R_global_config(tb->vce_l2r_handle, &l2rGf);

        memset(pParam, 0, sizeof(TCACHE_PARAM));
      	
        pParam->RGB_COV_A = 0x4c85;
        pParam->RGB_COV_B = 0x962b;
        pParam->RGB_COV_C = 0x1d50;
        pParam->RGB_COV_E = 0x9090;
        pParam->RGB_COV_F = 0xb694;

        input_width = options->lumWidthSrc;//STRIDE(options->lumWidthSrc, alignment);
        input_height = options->lumHeightSrc;
        
        output_width = input_width;
        output_height = STRIDE(input_height, VCE_HEIGHT_ALIGNMENT);
        input_format = input_format_2_tcache_format(options->inputFormat);
        edma_link_rc_base[0] = tb->pictureMem->rc_busAddress;
        edma_link_rc_base[1] = tb->pictureMem->rc_busAddress + tb->lumaSize;
        edma_link_rc_base[2] = tb->pictureMem->rc_busAddress + tb->lumaSize + tb->chromaSize/2;

        printf("%s(%d)\n", __FUNCTION__, __LINE__);

        pEncIn->busLuma = edma_link_ep_base[MAX_INPUT_PLANE+0];
        pEncIn->busChromaU = edma_link_ep_base[MAX_INPUT_PLANE+1];
        pEncIn->busChromaV = 0;

        printf("%s(%d) edma_link_rc_base[0] = %#lx, edma_link_rc_base[1] = %#lx, edma_link_rc_base[2] = %#lx\n",
        	__FUNCTION__, __LINE__, edma_link_rc_base[0], edma_link_rc_base[1], edma_link_rc_base[2]);
        printf("%s(%d)  pEncIn->busLuma = %#lx,  pEncIn->busChromaU = %#lx\n",
        	__FUNCTION__, __LINE__,  pEncIn->busLuma,  pEncIn->busChromaU);

        // write params
        pParam->write_format = input_format;
        if (tcache_isRGB(input_format))
            pParam->write_bd = (options->bitDepthLuma == 10) ? TCACHE_COV_BD_10 : TCACHE_COV_BD_8;
        else
            pParam->write_bd = tcache_get_bitdepth(input_format);
        
        wplanes = tcache_get_planes(input_format);
        if (wplanes < 0)
        	return -1;
        printf("write planes = %d\n", wplanes);
        link_size = 0;
        for (plane = 0; plane < wplanes; plane++)
        {
        	//stride = tcache_get_stride(input_width, input_format, plane);
        	stride = tcache_get_stride(input_width, input_format, plane, alignment);
        	if (stride < 0)
        		return -1;
        	printf("stride = %d\n", stride);
        	
        	align_stride = tcache_get_stride_align(stride);
        	if (align_stride < 0)
        		return -1;
        	printf("align_stride = %d\n", align_stride);
        	pParam->writeStride[plane] = align_stride;
        	
        	start_addr = edma_link_ep_base[plane] & 0x03FFFFFF; // for NOC look
        	printf("plane %d start_addr = 0x%08x\n", plane, start_addr);
        	pParam->writeStartAddr[plane] = start_addr;
        	
        	height = tcache_get_height(input_height, input_format, plane);
        	if (height < 0)
        		return -1;
        
        	plane_size[plane] = align_stride * height;
        	end_addr = start_addr + plane_size[plane] - 1;
        	printf("plane %d end_addr = 0x%08x\n", plane, end_addr);
        	pParam->writeEndAddr[plane] = end_addr;
        	
        	block_size[plane] = tcache_get_block_size(align_stride, input_format, plane);
          	if (block_size[plane] < 0)
          		return -1;
        	link_size += (plane_size[plane] + block_size[plane] - 1)/block_size[plane];
        	printf("link_size = %d\n", link_size);
        }
        edma_link = (struct dma_link_table *)tb->edma_link_buf.rc_virtualAddress;

        ASSERT(link_size < 256 - 1);
        memset(edma_link, 0,(link_size+1)*sizeof(struct dma_link_table));
  
        //rc2ep
        offset[0] = offset[1] = offset[2] = 0;
        for (i = 0; i < link_size; i++) {
        	if (i == link_size-1)
        		//edma_link[i].control = 0x00000019; //enable interrupt
        		edma_link[i].control = 0x00000009; //disable interrupt
        	else
        		edma_link[i].control = 0x00000001;
        	
        	edma_link[i].size = MIN((u32)block_size[i%wplanes], plane_size[i%wplanes]-offset[i%wplanes]);
        	edma_link[i].sar_low = (edma_link_rc_base[i%wplanes]+offset[i%wplanes]) & 0xffffffff;
        	edma_link[i].sar_high = (edma_link_rc_base[i%wplanes]+offset[i%wplanes]) >> 32;
        	edma_link[i].dst_low = (edma_link_ep_base[i%wplanes]+offset[i%wplanes]) & 0xffffffff;
        	edma_link[i].dst_high = (edma_link_rc_base[i%wplanes]+offset[i%wplanes]) >> 32;
        
        	offset[i%wplanes] += edma_link[i].size;
        }
        for (i = 0; i < link_size+1; i++) {
         	printf(" i : %d\n", i);
         	printf("\t%#010X\n", edma_link[i].control);
         	printf("\t%#010X\n", edma_link[i].size);
         	printf("\t%#010X\n", edma_link[i].sar_low);
         	printf("\t%#010X\n", edma_link[i].sar_high);
         	printf("\t%#010X\n", edma_link[i].dst_low);
         	printf("\t%#010X\n", edma_link[i].dst_high);
        }

        // read params
        output_format = tcache_get_output_format(input_format, options->bitDepthLuma);
        pParam->read_format = output_format;
        pParam->read_count = 0;
        pParam->read_client = 1; // VC8000E
      
        rplanes = tcache_get_planes(output_format);
        if (rplanes < 0)
        	return VCENC_ERROR;
        printf("read planes = %d\n", rplanes);
        for (plane = 0; plane < rplanes; plane++)
        {
        	//stride = tcache_get_stride(STRIDE(output_width*((bit_depth+7)/8),32)/((bit_depth+7)/8), output_format, plane);
        	stride = tcache_get_stride(output_width, output_format, plane, MAX(VCE_INPUT_ALIGNMENT,alignment));
        	if (stride < 0)
        		return VCENC_ERROR;
        	printf("stride = %d\n", stride);
        	align_stride = tcache_get_stride_align(stride);
        	if (align_stride < 0)
        		return VCENC_ERROR;
        	printf("align_stride = %d\n", align_stride);
        	pParam->readStride[plane] = align_stride;
        	//pParam->readValidStride[plane] = input_width;
        	pParam->readValidStride[plane] = align_stride;

        	start_addr = edma_link_ep_base[MAX_INPUT_PLANE+plane] & 0x03FFFFFF; // for NOC look
        	printf("plane %d start_addr = 0x%08x\n", plane, start_addr);
        	pParam->readStartAddr[plane] = start_addr;
        	
        	height = tcache_get_height(output_height, output_format, plane);
        	if (height < 0)
        		return VCENC_ERROR;
        	plane_size[plane] = align_stride * height;
        	end_addr = start_addr + plane_size[plane] - 1;
        	//end_addr = start_addr + plane_size[plane];
        	printf("plane %d end_addr = 0x%08x\n", plane, end_addr);
        	pParam->readEndAddr[plane] = end_addr;
            
        }
        //pParam->readEndAddr[0] = 0x02100000;
        //pParam->readEndAddr[1] = 0x01050000;
        
        pParam->hs_image_height = input_height;
        pParam->hs_enable = 1;
        pParam->hs_dma_ch = 0;
        pParam->hs_go_toggle_count = 0xF4;
        pParam->hs_ce = wplanes;

        TCACHE_config(tb->tcache_handle, pParam);

        printf("config read link\n");
        ret = TRANS_EDMA_RC2EP_link_config(tb->edma_handle, tb->edma_link_buf.rc_busAddress, tb->edma_link_buf.rc_virtualAddress, link_size+1);
        if (ret < 0)
        	return -1;
     
        break;
    }
#endif
    default:
        break;
    }
    
    return 0;
}
#endif

static u32 TBGetBitsPerPixel(i32 input_type)
{
  switch (input_type) {
#ifdef SUPPORT_TCACHE
    case INPUT_FORMAT_ARGB_FB:
    case INPUT_FORMAT_ABGR_FB:
    case INPUT_FORMAT_RGBA_FB:
    case INPUT_FORMAT_BGRA_FB:
      return 32;
    case INPUT_FORMAT_RGB24_FB:
    case INPUT_FORMAT_BGR24_FB:
      return 24;
    case INPUT_FORMAT_YUV420_PLANAR_10BIT_P010LE:
    case INPUT_FORMAT_YUV420_PLANAR_10BIT_P010BE:
    case INPUT_FORMAT_YUV420_SEMIPLANAR_10BIT_P010BE:
      return 24;
    case INPUT_FORMAT_YUV422P:
      return 16;
    case INPUT_FORMAT_YUV422P10LE:
    case INPUT_FORMAT_YUV422P10BE:
      return 32;
    case INPUT_FORMAT_YUV444P:
      return 24;
#endif
    default:
      return 0;
  }
}
#endif

u32 SetupInputBuffer(struct test_bench *tb, HANTROH26xEncOptions *options, VCEncIn *pEncIn)
{
    u32 src_img_size;

    ENC_TB_DEBUG_PRINT("\n");

#if defined(SUPPORT_DEC400) || defined(SUPPORT_TCACHE)
    if (options->inputFormat >= INPUT_FORMAT_YUV420_SEMIPLANAR_8BIT_COMPRESSED_FB
        && options->inputFormat <= INPUT_FORMAT_RFC_10BIT_COMPRESSED_FB) {
      tb->tslu = (u8 *)tb->TSLumaMem->rc_virtualAddress;
      tb->tsch = (u8 *)tb->TSChromaMem->rc_virtualAddress;
    }
#endif
    if ((tb->input_alignment == 0 || options->formatCustomizedType != -1) && 0 != VCEncGetBitsPerPixel(options->inputFormat))
    {
      u32 size_lum = 0;
      u32 size_ch  = 0;

      getAlignedPicSizebyFormat(options->inputFormat,options->lumWidthSrc,options->lumHeightSrc,0,&size_lum,&size_ch,NULL);

      pEncIn->busLuma = tb->pictureMem->busAddress;
#ifdef USE_OLD_DRV
      tb->lum = (u8 *)tb->pictureMem->virtualAddress;
#else
      tb->lum = (u8 *)tb->pictureMem->rc_virtualAddress;
#endif
      pEncIn->busChromaU = pEncIn->busLuma + size_lum;
      tb->cb = tb->lum + (u32)size_lum;
      pEncIn->busChromaV = pEncIn->busChromaU + (u32)size_ch/2;
      tb->cr = tb->cb + (u32)size_ch/2;
      src_img_size = options->lumWidthSrc * options->lumHeightSrc *
                   VCEncGetBitsPerPixel(options->inputFormat) / 8;
    }
    else
    {
      pEncIn->busLuma = tb->pictureMem->busAddress;
#ifdef USE_OLD_DRV
      tb->lum = (u8 *)tb->pictureMem->virtualAddress;
#else
      tb->lum = (u8 *)tb->pictureMem->rc_virtualAddress;
#endif
  
      pEncIn->busChromaU = pEncIn->busLuma + tb->lumaSize;
      tb->cb = tb->lum + tb->lumaSize;
  
      pEncIn->busChromaV = pEncIn->busChromaU + tb->chromaSize/2;
      tb->cr = tb->cb + tb->chromaSize/2;
      if (0 != VCEncGetBitsPerPixel(options->inputFormat))
        src_img_size = options->lumWidthSrc * options->lumHeightSrc *
                   VCEncGetBitsPerPixel(options->inputFormat) / 8;
      else
      {
        if (options->inputFormat >= VCENC_YUV420_SEMIPLANAR_101010 && options->inputFormat <= VCENC_YUV420_VU_10BIT_TILE_96_2)
          getAlignedPicSizebyFormat(options->inputFormat,options->lumWidthSrc,options->lumHeightSrc,0,NULL,NULL,&src_img_size);
        else
#ifdef SUPPORT_TCACHE
        if (0 != TBGetBitsPerPixel(options->inputFormat))
          src_img_size = options->lumWidthSrc * options->lumHeightSrc *
                   TBGetBitsPerPixel(options->inputFormat) / 8;
        else
#endif		
          src_img_size = tb->lumaSize + tb->chromaSize;
      }
    }

    ENC_TB_DEBUG_PRINT("src_img_size = %d\n", src_img_size);
    
    //if(options->halfDsInput) {
    if(options->lookaheadDepth && options->cutree_blkratio) {
      u32 size_lum = 0;
      u32 size_ch  = 0;

      u32 alignment = (options->formatCustomizedType != -1? 0 : tb->input_alignment);
      getAlignedPicSizebyFormat(options->inputFormat_ds,options->lumWidthSrc_ds,options->lumHeightSrc_ds,alignment,&size_lum,&size_ch,NULL);

      /* save full resolution yuv for 2nd pass */
      pEncIn->busLumaOrig = pEncIn->busLuma;
      pEncIn->busChromaUOrig = pEncIn->busChromaU;
      pEncIn->busChromaVOrig = pEncIn->busChromaV;
      /* setup down-sampled yuv for 1nd pass */
      pEncIn->busLuma = tb->pictureDSMem->busAddress;
#ifdef USE_OLD_DRV
      tb->lumDS = (u8*)tb->pictureDSMem->virtualAddress;
#else
      tb->lumDS = (u8*)tb->pictureDSMem->rc_virtualAddress;
#endif
      pEncIn->busChromaU = pEncIn->busLuma + size_lum;
      tb->cbDS = tb->lumDS + (u32)size_lum;
      pEncIn->busChromaV = pEncIn->busChromaU + (u32)size_ch/2;
      tb->crDS = tb->cbDS + (u32)size_ch/2;
      //tb->src_img_size_ds = options->lumWidthSrc/2 * options->lumHeightSrc/2 * VCEncGetBitsPerPixel(options->inputFormat) / 8;
      if (0 != VCEncGetBitsPerPixel(options->inputFormat_ds))
        tb->src_img_size_ds = options->lumWidthSrc_ds * options->lumHeightSrc_ds *
                   VCEncGetBitsPerPixel(options->inputFormat_ds) / 8;
      else
      {
        if (options->inputFormat_ds >= VCENC_YUV420_SEMIPLANAR_101010 && options->inputFormat_ds <= VCENC_YUV420_VU_10BIT_TILE_96_2)
          getAlignedPicSizebyFormat(options->inputFormat_ds,options->lumWidthSrc_ds,options->lumHeightSrc_ds,0,NULL,NULL,&tb->src_img_size_ds);
        else
#ifdef SUPPORT_TCACHE
        if (0 != TBGetBitsPerPixel(options->inputFormat_ds))
          tb->src_img_size_ds = options->lumWidthSrc_ds * options->lumHeightSrc_ds *
                   TBGetBitsPerPixel(options->inputFormat_ds) / 8;
        else
#endif		
          tb->src_img_size_ds = tb->lumaSizeDs + tb->chromaSizeDs;
      }

      ENC_TB_DEBUG_PRINT("tb->src_img_size_ds = %d\n", tb->src_img_size_ds);
      
    } else {
      pEncIn->busLumaOrig = 
      pEncIn->busChromaUOrig = 
      pEncIn->busChromaVOrig = (ptr_t)NULL;
      tb->src_img_size_ds = 0;
    }
    
    return src_img_size;
}

void SetupOutputBuffer(struct test_bench *tb, VCEncIn *pEncIn)
{
#if 0
  i32 iBuf;
  for (iBuf = 0; iBuf < tb->streamBufNum; iBuf ++)
  {
    //find output buffer of multi-cores
    tb->outbufMem[iBuf] = &(tb->outbufMemFactory[tb->picture_enc_cnt % tb->parallelCoreNum][iBuf]);
      
    pEncIn->busOutBuf[iBuf] = tb->outbufMem[iBuf]->busAddress;
    pEncIn->outBufSize[iBuf] = tb->outbufMem[iBuf]->size;
#ifdef USE_OLD_DRV
    pEncIn->pOutBuf[iBuf] = tb->outbufMem[iBuf]->virtualAddress;
#else
    //pEncIn->pOutBuf[iBuf] = tb->outbufMem[iBuf]->rc_virtualAddress;
#endif
  }

#else

  i32 iBuf = tb->outMemIndex;

    //find output buffer of multi-cores
    tb->outbufMem[iBuf] = &(tb->outbufMemFactory[tb->picture_enc_cnt % tb->parallelCoreNum][iBuf]);
      
    pEncIn->busOutBuf[0] = tb->outbufMem[iBuf]->busAddress;
    pEncIn->outBufSize[0] = tb->outbufMem[iBuf]->size;
#ifdef USE_OLD_DRV
    pEncIn->pOutBuf[0] = tb->outbufMem[iBuf]->virtualAddress;
#else
    //pEncIn->pOutBuf[iBuf] = tb->outbufMem[iBuf]->rc_virtualAddress;
#endif

  
#endif
}

int vce_fifo_init(VCEncInst encoder)
{
  struct vcenc_instance *vcenc_instance = (struct vcenc_instance *)encoder;
  int ret = 0;
  int i = 0;

  av_log(NULL, AV_LOG_DEBUG, "%s enter\n", __FUNCTION__);
  
  ret = FifoInit(MAX_OUTPUT_FIFO_DEPTH, (FifoInst *)&vcenc_instance->emptyFifo);
  if (ret < 0) {
    //ENC_TB_ERROR_PRINT("FifoInit error in [%s]\n", __FUNCTION__);
    goto error;	
  }

  ret = FifoInit(MAX_OUTPUT_FIFO_DEPTH, (FifoInst *)&vcenc_instance->outputFifo);
  if (ret < 0) {
    //ENC_TB_ERROR_PRINT("FifoInit error in [%s]\n", __FUNCTION__);
    goto error;	
  }
  //ENC_TB_DEBUG_PRINT("After FifoInit: vcenc_instance->outputFifo = %p\n", vcenc_instance->outputFifo);

  for (i = 0; i < MAX_VCE_OUTPUT_FIFO_DEPTH; i++) {
    av_log(NULL, AV_LOG_DEBUG, "[%s L%d] vcenc_instance->outbufMem[%d] = %p\n", __FUNCTION__, __LINE__, i, (void *)&vcenc_instance->outbufMem[i]);
   
    if (FifoPush(vcenc_instance->emptyFifo, &vcenc_instance->outbufMem[i], FIFO_EXCEPTION_DISABLE)) {
      //ENC_TB_ERROR_PRINT("fifo push error in %s\n", __FUNCTION__); 
	  goto error;
    }
	
    av_log(NULL, AV_LOG_DEBUG, "[%s L%d] vcenc_instance->outbufMem[%d] = %p\n", __FUNCTION__, __LINE__, i, (void *)&vcenc_instance->outbufMem[i]);
 
  }

 
  return 0;
error: 
  vce_fifo_release(encoder);
  return -1;
}

int vce_fifo_release(VCEncInst encoder)
{
  struct vcenc_instance *vcenc_instance = (struct vcenc_instance *)encoder;


  if (vcenc_instance->outputFifo)
    FifoRelease(vcenc_instance->outputFifo);

  if (vcenc_instance->emptyFifo)
    FifoRelease(vcenc_instance->emptyFifo);

  return 0;
}

void getOutbufMem(VCEncInst encoder, struct test_bench *tb)
{
  struct vcenc_instance *vcenc_instance = (struct vcenc_instance *)encoder;
  i32 iBuf;

  for (iBuf = 0; iBuf < tb->streamBufNum; iBuf ++)
  {
    //find output buffer of multi-outbuf
    vcenc_instance->outbufMem[iBuf].outbufMem = &(tb->outbufMemFactory[tb->picture_enc_cnt % tb->parallelCoreNum][iBuf]);
    av_log(NULL, AV_LOG_DEBUG, "[%s L%d]vcenc_instance->outbufMem[%d].outbufMem = %p\n", __FUNCTION__, __LINE__, iBuf, vcenc_instance->outbufMem[iBuf].outbufMem);
  }

}

static void SetOutMemData(EncOutData_t *out_buffer, VCEncIn *pEncIn)
{
  pEncIn->busOutBuf[0] = out_buffer->outbufMem->busAddress; //tb->outbufMem[iBuf]->busAddress;
  pEncIn->outBufSize[0] = out_buffer->outbufMem->size; //tb->outbufMem[iBuf]->size;
#ifdef USE_OLD_DRV
  pEncIn->pOutBuf[0] = out_buffer->outbufMem->virtualAddress; //tb->outbufMem[iBuf]->virtualAddress;
#else
  //pEncIn->pOutBuf[iBuf] = tb->outbufMem[iBuf]->rc_virtualAddress;
#endif
}

int WaitEmptyFifoForEnc(VCEncInst encoder, EncOutData_t **out_buffer, const VCEncIn *pEncIn)
{
  struct vcenc_instance *vcenc_instance = (struct vcenc_instance *)encoder;

  av_log(NULL, AV_LOG_DEBUG, "%s before FifoPop\n", __FUNCTION__);
  FifoPop(vcenc_instance->emptyFifo, out_buffer, FIFO_EXCEPTION_DISABLE);
  if (*out_buffer == NULL) {
    return -1;
  }

  av_log(NULL, AV_LOG_DEBUG, "%s vcenc_instance->emptyFifo pop, out_buffer->busAddress = %p, out_buffer->size = %d, pEncIn->indexTobeEncode = %d\n", __FUNCTION__, (*out_buffer)->outbufMem->busAddress, (*out_buffer)->outbufMem->size, pEncIn->indexTobeEncode);
  av_log(NULL, AV_LOG_DEBUG, "%s after FifoPop\n", __FUNCTION__);
  
  SetOutMemData(*out_buffer, pEncIn);
  return 0;

}

void GetEncData(VCEncInst encoder, EncOutData_t *out_buffer, VCEncOut *pEncOut)
{
  struct vcenc_instance *vcenc_instance = (struct vcenc_instance *)encoder;

  int ret = 0;

  av_log(NULL, AV_LOG_DEBUG, "%s before FifoPush to vcenc_instance->outputFifo\n", __FUNCTION__);
  av_log(NULL, AV_LOG_DEBUG, "%s: pEncOut->streamSize = %d, out_buffer->outbufMem.size = %d\n", __FUNCTION__, pEncOut->streamSize, out_buffer->outbufMem->size);

  //out_buffer->streamSize = pEncOut->streamSize;
  FifoPush(vcenc_instance->outputFifo, out_buffer, FIFO_EXCEPTION_DISABLE);
  //ret = FifoPush(vcenc_instance->outputFifo, out_buffer, FIFO_EXCEPTION_ENABLE);
  av_log(NULL, AV_LOG_DEBUG, "%s after FifoPush, ret = %d\n", __FUNCTION__, ret);
}

void GetEndData(VCEncInst encoder, EncOutData_t *out_buffer, VCEncOut *pEncOut)
{
  struct vcenc_instance *vcenc_instance = (struct vcenc_instance *)encoder;

#if 0
  out_buffer->streamSize = pEncOut->streamSize;
  out_buffer->endData = HANTRO_TRUE;
#endif

  av_log(NULL, AV_LOG_DEBUG, "%s before FifoPush\n", __FUNCTION__);
  FifoPush(vcenc_instance->outputFifo, out_buffer, FIFO_EXCEPTION_DISABLE);
  av_log(NULL, AV_LOG_DEBUG, "%s after FifoPush\n", __FUNCTION__);
}

int WaitPktData(VCEncInst encoder, EncOutData_t **out_buffer)
{
  struct vcenc_instance *vcenc_instance = (struct vcenc_instance *)encoder;
  
  return FifoPop(vcenc_instance->outputFifo, out_buffer, FIFO_EXCEPTION_ENABLE);
}

void GivebackEmptyFifo(VCEncInst encoder, EncOutData_t *out_buffer)
{
  struct vcenc_instance *vcenc_instance = (struct vcenc_instance *)encoder;

  FifoPush(vcenc_instance->emptyFifo, out_buffer, FIFO_EXCEPTION_DISABLE);
  av_log(NULL, AV_LOG_DEBUG, "%s after FifoPush\n", __FUNCTION__);
  
}

void SendEosToEnc(VCEncInst encoder)
{
  struct vcenc_instance *vcenc_instance = (struct vcenc_instance *)encoder;

  FifoPush(vcenc_instance->emptyFifo, NULL, FIFO_EXCEPTION_ENABLE);
  av_log(NULL, AV_LOG_DEBUG, "%s after FifoPush\n", __FUNCTION__);
}

static i32 SetupROIMapVer3(struct test_bench *tb, HANTROH26xEncOptions *options, VCEncInst encoder)
{
  u8* memory;
  u8 u8RoiData[24];

  i32 blkSize;
  i32 num;
  i32 size;
  i32 ret = NOK;
  i32 block_num,i,j,m, n, block_width, block_height, mb_width, last_mb_height;
  i32 ctb_block_num, mb_block_num, block_cu8_rnum, block_cu8_cnum, last_block_cu8_cnum, block_cu8_num, ctb_row, ctb_column, read_size;
  u64 block_base_addr;
  u32 ctb_num, blkInCtb, blkRowInCtb, blkColumInCtb, cu8NumInCtb;

  struct vcenc_instance *vcenc_instance = (struct vcenc_instance *)encoder;

  // V3 ROI
  if ((tb->roiMapFile) && (vcenc_instance->RoiQpDelta_ver < 3))
  {
    // RoiQpDelta_ver == 0,1,2
    if (copyQPDelta2Memory(options, encoder, tb, vcenc_instance->RoiQpDelta_ver))
      return NOK;
  }
  else if((vcenc_instance->roiMapEnable) && (tb->roiMapInfoBinFile != NULL))
  {
    // RoiQpDelta_ver == 1,2,3
#ifdef USE_OLD_DRV
    memory = (u8*)tb->roiMapDeltaQpMem->virtualAddress;
#else
    memory = (u8*)tb->roiMapDeltaQpMem->rc_virtualAddress;
#endif

    // need fill into buffer of 8x8 block_size
    blkSize = 64 >> (options->roiMapDeltaQpBlockUnit & 3);
    num = next_picture(tb, tb->encIn.picture_cnt) + tb->firstPic;
    ret = NOK;

    if (num <= tb->lastPic)
    {
      switch(options->roiMapDeltaQpBlockUnit)
      {
        case 0:
          block_num=64;
          break;
        case 1:
          block_num=16;
          break;
        case 2:
          block_num=4;
          break;
        case 3:
          block_num=1;
          break;
        default:
          block_num=64;
          break;
      }

      block_width     = (((options->width + options->max_cu_size - 1)& (~(options->max_cu_size - 1))) + blkSize - 1) / blkSize;
      mb_width        = ((options->width + options->max_cu_size - 1)& (~(options->max_cu_size - 1)))/ 8;
      block_height    = (((options->height + options->max_cu_size - 1)& (~(options->max_cu_size - 1))) + blkSize - 1) / blkSize;
      size            = block_width * block_height;
      block_base_addr = ((u64)num) * ((u64)size);
      block_cu8_cnum  = blkSize / 8;
      last_block_cu8_cnum = (((options->width + options->max_cu_size - 1)& (~(options->max_cu_size - 1))) - (block_width-1)*blkSize) / 8;
      last_mb_height  = (((options->height + options->max_cu_size - 1)& (~(options->max_cu_size - 1))) - (block_height-1) * blkSize) / 16;

      if (IS_H264(options->codecFormat))
      {
          // h264
          ctb_block_num  = blkSize / options->max_cu_size;
          block_cu8_rnum = block_cu8_cnum / ctb_block_num;
          cu8NumInCtb    = block_cu8_rnum*block_cu8_cnum;
          for (i = 0; i < size; i++)
          {
              ret = file_read(tb->roiMapInfoBinFile, u8RoiData, (block_base_addr + i), 1);
              if (ret == NOK)
                  break;

              ctb_num  = i / block_width;
              blkInCtb = i % block_width;
              
              if (blkInCtb == (block_width - 1))
                  block_cu8_num = last_block_cu8_cnum;
              else
                  block_cu8_num = block_cu8_cnum;

              if (ctb_num == (block_height - 1))
                  mb_block_num = last_mb_height;
              else
                  mb_block_num = ctb_block_num;
              
              for (j = 0; j < mb_block_num; j++)
              {
                  for (m = 0; m < block_cu8_rnum; m++)
                  {
                      for (n = 0; n < block_cu8_num; n++)
                      {
                          memory[(ctb_num*ctb_block_num + j) * mb_width*block_cu8_rnum + blkInCtb * cu8NumInCtb + m*block_cu8_num + n] = u8RoiData[0];
                      }
                  }
              }
          }
      }
      else
      {
          // hevc
          ctb_block_num = options->max_cu_size / blkSize;
          cu8NumInCtb   = ctb_block_num*ctb_block_num*block_cu8_cnum*block_cu8_cnum;

          for (i = 0; i < size; i++)
          {
              ret = file_read(tb->roiMapInfoBinFile, u8RoiData, (block_base_addr + i), 1);
              if (ret == NOK)
                  break;

              ctb_num       = i / (ctb_block_num*ctb_block_num);
              blkInCtb      = i % (ctb_block_num*ctb_block_num);
              blkRowInCtb   = blkInCtb / ctb_block_num;
              blkColumInCtb = blkInCtb % ctb_block_num;
              
              for (m = 0; m < block_cu8_cnum; m++)
              {
                  for (n = 0; n < block_cu8_cnum; n++)
                  {
                      memory[ctb_num * cu8NumInCtb + (blkRowInCtb*block_cu8_cnum + m)*ctb_block_num*block_cu8_cnum + blkColumInCtb*block_cu8_cnum + n] = u8RoiData[0];
                  }
              }
          }
      }
    }

    if(ret == NOK)
    {
#ifdef USE_OLD_DRV
      memset((u8*)tb->roiMapDeltaQpMem->virtualAddress, 0, tb->roiMapDeltaQpMem->size);
#else
      memset((u8*)tb->roiMapDeltaQpMem->rc_virtualAddress, 0, tb->roiMapDeltaQpMem->size);
#endif
    }
  }

  // V3~V7 ROI index
  if((vcenc_instance->RoimapCuCtrl_index_enable) && (tb->RoimapCuCtrlIndexBinFile != NULL))
  {
#ifdef USE_OLD_DRV
    memory = (u8*)tb->RoimapCuCtrlIndexMem->virtualAddress;
#else
    memory = (u8*)tb->RoimapCuCtrlIndexMem->rc_virtualAddress;
#endif
    blkSize = IS_H264(options->codecFormat) ? 16 : 64;
    num = next_picture(tb, tb->encIn.picture_cnt) + tb->firstPic;
    size = (((options->width + blkSize - 1)/blkSize) * ((options->height + blkSize - 1)/blkSize) +7) >> 3;
    ret = NOK;
    if (num <= tb->lastPic)
    {
      for(i = 0; i < size; i += read_size)
      {
        if((size - i) > 1024)
          read_size = 1024;
        else
          read_size = size - i;
    
        ret = file_read(tb->RoimapCuCtrlIndexBinFile, (u8 *)(memory+i), (((u64)num) * ((u64)size) + i), read_size);
        if(ret == NOK)
          break;
      }
    }

    if(ret == NOK)
    {
#ifdef USE_OLD_DRV    
      memset((u8*)tb->RoimapCuCtrlIndexMem->virtualAddress, 0, tb->RoimapCuCtrlIndexMem->size);
#else
      memset((u8*)tb->RoimapCuCtrlIndexMem->rc_virtualAddress, 0, tb->RoimapCuCtrlIndexMem->size);
      //EWLTransDataRC2EP(tb->ewl, tb->RoimapCuCtrlIndexMem, tb->RoimapCuCtrlIndexMem, tb->RoimapCuCtrlIndexMem->size);
#endif
    }
  }

  // V3~V7 ROI
  if((vcenc_instance->RoimapCuCtrl_enable) && (tb->RoimapCuCtrlInfoBinFile != NULL))
  {
#ifdef USE_OLD_DRV
    memory = (u8*)tb->RoimapCuCtrlInfoMem->virtualAddress;
#else
    memory = (u8*)tb->RoimapCuCtrlInfoMem->rc_virtualAddress;
#endif

    blkSize = 8;
    num = next_picture(tb, tb->encIn.picture_cnt) + tb->firstPic;

    block_width   = (((options->width + options->max_cu_size - 1)& (~(options->max_cu_size - 1))) + blkSize - 1) / blkSize;
    block_height  = (((options->height + options->max_cu_size - 1)& (~(options->max_cu_size - 1))) + blkSize - 1) / blkSize;
    size          = block_width * block_height;
    ret = NOK;
    switch(vcenc_instance->RoimapCuCtrl_ver)
    {
      case 3:
        block_num=1;
        break;
      case 4:
        block_num=2;
        break;
      case 5:
        block_num=6;
        break;
      case 6:
        block_num=12;
        break;
      default:
        block_num=14;
        break;
    }
    
    size =  size * block_num;
    if (num <= tb->lastPic)
    {
      for(i = 0; i < size; i += read_size)
      {
        if((size - i) > 1024)
          read_size = 1024;
        else
          read_size = size - i;
    
        ret = file_read(tb->RoimapCuCtrlInfoBinFile, (u8 *)(memory+i), (((u64)num) * ((u64)size) + i), read_size);
        if(ret == NOK)
          break;
      }
    }

    if(ret == NOK)
    {
#ifdef USE_OLD_DRV
      memset((u8*)tb->RoimapCuCtrlInfoMem->virtualAddress, 0, tb->RoimapCuCtrlInfoMem->size);
#else
      memset((u8*)tb->RoimapCuCtrlInfoMem->rc_virtualAddress, 0, tb->RoimapCuCtrlInfoMem->size);
      //EWLTransDataRC2EP(tb->ewl, tb->RoimapCuCtrlInfoMem, tb->RoimapCuCtrlInfoMem, tb->RoimapCuCtrlInfoMem->size);
#endif
    }
  }

  return OK;
}

i32 SetupROIMapBuffer(struct test_bench *tb, HANTROH26xEncOptions *options, VCEncIn *pEncIn, VCEncInst encoder)
{
  struct vcenc_instance *vcenc_instance = (struct vcenc_instance *)encoder;
  pEncIn->roiMapDeltaQpAddr = tb->roiMapDeltaQpMem->busAddress;
  
  /* copy config data to memory. allocate delta qp map memory. */
  if ((options->lookaheadDepth) && tb->roiMapBinFile)
  {
#ifdef USE_OLD_DRV
    pEncIn->pRoiMapDelta = (i8 *)tb->roiMapDeltaQpMem->virtualAddress;
#else
    pEncIn->pRoiMapDelta = (i8 *)tb->roiMapDeltaQpMem->rc_virtualAddress;
#endif
    pEncIn->roiMapDeltaSize = tb->roiMapDeltaQpMem->size;
    i32 blkSize = 64 >> (options->roiMapDeltaQpBlockUnit&3);
    i32 num = next_picture(tb, tb->encIn.picture_cnt) + tb->firstPic;
    i32 size = ((options->width + blkSize - 1)/blkSize) * ((options->height + blkSize - 1)/blkSize);
    i32 ret = NOK;

    if (num <= tb->lastPic)
      ret = file_read(tb->roiMapBinFile, (u8 *)pEncIn->pRoiMapDelta, ((u64)num) * ((u64)size), size);

    if (ret != OK)
      memset(pEncIn->pRoiMapDelta, 0, size);
  }

  if(vcenc_instance->asic.regs.asicCfg.roiMapVersion == 3)
  {
      pEncIn->RoimapCuCtrlAddr      = tb->RoimapCuCtrlInfoMem->busAddress;
      pEncIn->RoimapCuCtrlIndexAddr = tb->RoimapCuCtrlIndexMem->busAddress;
      if (SetupROIMapVer3(tb, options, encoder))
        return NOK;
  }
  else if (tb->roiMapFile)
  {
    if (copyQPDelta2Memory(options, encoder, tb, vcenc_instance->asic.regs.asicCfg.roiMapVersion))
      return NOK;
  }
  
  if (tb->ipcmMapFile || tb->skipMapFile){
    if (copyFlagsMap2Memory(options, encoder, tb))
      return NOK;
  }

  return OK;
}

FILE* FormatCustomizedYUV(struct test_bench *tb, HANTROH26xEncOptions *options, i32 *ret)
{    
    *ret = OK;
    if ((options->formatCustomizedType == 1)&&
       ((options->inputFormat==VCENC_YUV420_SEMIPLANAR)||(options->inputFormat==VCENC_YUV420_SEMIPLANAR_VU)||(options->inputFormat==VCENC_YUV420_PLANAR_10BIT_P010)))
    {
      transYUVtoFBformat(tb,options, ret);
    }
    
    return NULL;
}

void GetFreeIOBuffer(struct test_bench *tb)
{
    i32 iBuf;

    //find output buffer of multi-cores
    tb->pictureMem = &(tb->pictureMemFactory[tb->picture_enc_cnt % tb->buffer_cnt]);
    tb->pictureDSMem = &(tb->pictureDSMemFactory[tb->picture_enc_cnt % tb->buffer_cnt]);

    //find output buffer of multi-cores
    for (iBuf = 0; iBuf < tb->streamBufNum; iBuf ++)
      tb->outbufMem[iBuf] = &(tb->outbufMemFactory[tb->picture_enc_cnt % tb->parallelCoreNum][iBuf]);

    //find ROI Map buffer of multi-cores
    tb->roiMapDeltaQpMem = &(tb->roiMapDeltaQpMemFactory[tb->picture_enc_cnt % tb->buffer_cnt]);

    //find transform buffer of multi-cores
    tb->transformMem = &(tb->transformMemFactory[tb->picture_enc_cnt % tb->buffer_cnt]);    
    tb->RoimapCuCtrlInfoMem  = &(tb->RoimapCuCtrlInfoMemFactory[tb->picture_enc_cnt % tb->buffer_cnt]);
    tb->RoimapCuCtrlIndexMem = &(tb->RoimapCuCtrlIndexMemFactory[tb->picture_enc_cnt % tb->buffer_cnt]);

#if defined(SUPPORT_DEC400) || defined(SUPPORT_TCACHE)
    tb->TSLumaMem = &(tb->TSLumaMemFactory[tb->picture_enc_cnt % tb->buffer_cnt]);
    tb->TSChromaMem = &(tb->TSChromaMemFactory[tb->picture_enc_cnt % tb->buffer_cnt]);
#endif
}

void InitSliceCtl(struct test_bench *tb, struct HANTROH26xEncOptions *options)
{
  int i;
  for(i = 0; i < MAX_CORE_NUM; i++) {
    tb->sliceCtlFactory[i].multislice_encoding=(options->sliceSize!=0&&(((options->height+63)/64)>options->sliceSize))?1:0;
    tb->sliceCtlFactory[i].output_byte_stream=options->byteStream?1:0;
    tb->sliceCtlFactory[i].outStreamFile=tb->out;
    tb->sliceCtlFactory[i].streamPos = 0;
  }
}

void InitStreamSegmentCrl(struct test_bench *tb, struct HANTROH26xEncOptions *options)
{
  tb->streamSegCtl.streamRDCounter = 0;
  tb->streamSegCtl.streamMultiSegEn = options->streamMultiSegmentMode != 0;
#ifdef USE_OLD_DRV
  tb->streamSegCtl.streamBase = (u8 *)tb->outbufMemFactory[0][0].virtualAddress;
#else
  tb->streamSegCtl.streamBase = (u8 *)tb->outbufMemFactory[0][0].rc_virtualAddress;
#endif

  if(tb->streamSegCtl.streamMultiSegEn)
  {
      tb->streamSegCtl.segmentSize = tb->outbufMemFactory[0][0].size / options->streamMultiSegmentAmount;
      tb->streamSegCtl.segmentSize = ((tb->streamSegCtl.segmentSize + 16 - 1) & (~(16 - 1)));//segment size must be aligned to 16byte
      tb->streamSegCtl.segmentAmount = options->streamMultiSegmentAmount;
  }
  tb->streamSegCtl.startCodeDone = 0;
  tb->streamSegCtl.output_byte_stream = tb->byteStream;
  tb->streamSegCtl.outStreamFile = tb->out;
}

void SetupSliceCtl(struct test_bench *tb)
{
    //find transform buffer of multi-cores
    tb->sliceCtl = &(tb->sliceCtlFactory[tb->picture_enc_cnt % tb->parallelCoreNum]);
    tb->sliceCtlOut = &(tb->sliceCtlFactory[(tb->picture_enc_cnt+1) % tb->parallelCoreNum]);
}

// Helper function to calculate time diffs.
unsigned int uTimeDiff(struct timeval end, struct timeval start)
{
   return (end.tv_sec - start.tv_sec)*1000000 + (end.tv_usec - start.tv_usec);
}

