#ifndef AVCODEC_HANTRO_ENC_PIC_CONFIG_H
#define AVCODEC_HANTRO_ENC_PIC_CONFIG_H

void InitPicConfig(VCEncIn *pEncIn, struct test_bench *tb, HANTROH26xEncOptions *options);

#endif /* AVCODEC_HANTRO_ENC_PIC_CONFIG_H */
