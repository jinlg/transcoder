
#include "internal.h"
#include "decode.h"
#include "avcodec.h"


#include "dwl.h"
#include "dwl_linux.h"
#include "deccfg.h"
#include "ppcfg.h"
#include "regdrv.h"
#include "hwaccel.h"
#include "libavutil/hwcontext_hantro.h"



#include "hantro_dec_common.h"
#include "hantro_vp9dec.h"

#ifndef BUILD_CMODEL

int DWLGetCoreStatistic(const void *instance, i32 * total_usage, i32 core_usage[4]);

#endif


#if 1
void TBSetDefaultCfg(struct TBCfg* tb_cfg) {
    /* TbParams */
    strcpy(tb_cfg->tb_params.packet_by_packet, "DISABLED");
    strcpy(tb_cfg->tb_params.nal_unit_stream, "DISABLED");
    tb_cfg->tb_params.seed_rnd = 1;
    strcpy(tb_cfg->tb_params.stream_bit_swap, "0");
    strcpy(tb_cfg->tb_params.stream_bit_loss, "0");
    strcpy(tb_cfg->tb_params.stream_packet_loss, "0");
    strcpy(tb_cfg->tb_params.stream_header_corrupt, "DISABLED");
    strcpy(tb_cfg->tb_params.stream_truncate, "DISABLED");
    strcpy(tb_cfg->tb_params.slice_ud_in_packet, "DISABLED");
    tb_cfg->tb_params.memory_page_size = 1;
    tb_cfg->tb_params.ref_frm_buffer_size = -1;
    tb_cfg->tb_params.first_trace_frame = 0;
    tb_cfg->tb_params.extra_cu_ctrl_eof = 0;
    tb_cfg->tb_params.unified_reg_fmt = 0;
    tb_cfg->dec_params.force_mpeg4_idct = 0;
    tb_cfg->dec_params.ref_buffer_test_mode_offset_enable = 0;
    tb_cfg->dec_params.ref_buffer_test_mode_offset_min = -256;
    tb_cfg->dec_params.ref_buffer_test_mode_offset_start = -256;
    tb_cfg->dec_params.ref_buffer_test_mode_offset_max = 255;
    tb_cfg->dec_params.ref_buffer_test_mode_offset_incr = 16;
    tb_cfg->dec_params.apf_threshold_disable = 1;
    tb_cfg->dec_params.apf_threshold_value = -1;
    tb_cfg->dec_params.apf_disable = 0;
    tb_cfg->dec_params.field_dpb_support = 0;
    tb_cfg->dec_params.service_merge_disable = 0;

    /* Enable new features by default */
    tb_cfg->dec_params.hevc_main10_support = 1;
    tb_cfg->dec_params.vp9_profile2_support = 1;
    tb_cfg->dec_params.ds_support = 1;
    tb_cfg->dec_params.rfc_support = 1;
    tb_cfg->dec_params.ring_buffer_support = 1;
    tb_cfg->dec_params.addr64_support = 1;
    tb_cfg->dec_params.service_merge_disable = 0;
    tb_cfg->dec_params.mrb_prefetch = 1;

    /* Output pixel format by default */
    tb_cfg->dec_params.format_p010_support = 1;
    tb_cfg->dec_params.format_customer1_support = 1;

    /* DecParams */
#if (DEC_X170_OUTPUT_PICTURE_ENDIAN == DEC_X170_BIG_ENDIAN)
    strcpy(tb_cfg->dec_params.output_picture_endian, "BIG_ENDIAN");
#else
    strcpy(tb_cfg->dec_params.output_picture_endian, "LITTLE_ENDIAN");
#endif

    tb_cfg->dec_params.bus_burst_length = DEC_X170_BUS_BURST_LENGTH;
    tb_cfg->dec_params.asic_service_priority = DEC_X170_ASIC_SERVICE_PRIORITY;

#if (DEC_X170_OUTPUT_FORMAT == DEC_X170_OUTPUT_FORMAT_RASTER_SCAN)
    strcpy(tb_cfg->dec_params.output_format, "RASTER_SCAN");
#else
    strcpy(tb_cfg->dec_params.output_format, "TILED");
#endif

    tb_cfg->dec_params.latency_compensation = DEC_X170_LATENCY_COMPENSATION;

    tb_cfg->dec_params.clk_gate_decoder = DEC_X170_INTERNAL_CLOCK_GATING;
    tb_cfg->dec_params.clk_gate_decoder_idle =
    DEC_X170_INTERNAL_CLOCK_GATING_RUNTIME;

#if (DEC_X170_INTERNAL_CLOCK_GATING == 0)
    strcpy(tb_cfg->dec_params.clock_gating, "DISABLED");
#else
    strcpy(tb_cfg->dec_params.clock_gating, "ENABLED");
#endif

#if (DEC_X170_DATA_DISCARD_ENABLE == 0)
    strcpy(tb_cfg->dec_params.data_discard, "DISABLED");
#else
    strcpy(tb_cfg->dec_params.data_discard, "ENABLED");
#endif

    strcpy(tb_cfg->dec_params.memory_allocation, "INTERNAL");
    strcpy(tb_cfg->dec_params.rlc_mode_forced, "DISABLED");
    strcpy(tb_cfg->dec_params.error_concealment, "PICTURE_FREEZE");
    tb_cfg->dec_params.stride_support = 0;
    tb_cfg->dec_params.jpeg_mcus_slice = 0;
    tb_cfg->dec_params.jpeg_input_buffer_size = 0;
    tb_cfg->dec_params.ch8_pix_ileav_output = 0;

    tb_cfg->dec_params.tiled_ref_support = 
    tb_cfg->pp_params.tiled_ref_support = 0;

    tb_cfg->dec_params.refbu_enable = 0;
    tb_cfg->dec_params.refbu_disable_interlaced = 1;
    tb_cfg->dec_params.refbu_disable_double = 1;
    tb_cfg->dec_params.refbu_disable_eval_mode = 1;
    tb_cfg->dec_params.refbu_disable_checkpoint = 1;
    tb_cfg->dec_params.refbu_disable_offset = 1;
    tb_cfg->dec_params.refbu_disable_top_bot_sum = 1;
#ifdef DEC_X170_REFBU_ADJUST_VALUE
    tb_cfg->dec_params.refbu_data_excess_max_pct = DEC_X170_REFBU_ADJUST_VALUE;
#else
    tb_cfg->dec_params.refbu_data_excess_max_pct = 130;
#endif

    tb_cfg->dec_params.mpeg2_support = 1;
    tb_cfg->dec_params.vc1_support = 3; /* Adv profile */
    tb_cfg->dec_params.jpeg_support = 1;
    tb_cfg->dec_params.mpeg4_support = 2; /* ASP */
    tb_cfg->dec_params.h264_support = 3; /* High */
    tb_cfg->dec_params.vp6_support = 1;
    tb_cfg->dec_params.vp7_support = 1;
    tb_cfg->dec_params.vp8_support = 1;
    tb_cfg->dec_params.prog_jpeg_support = 1;
    tb_cfg->dec_params.sorenson_support = 1;
    tb_cfg->dec_params.custom_mpeg4_support = 1; /* custom feature 1 */
    tb_cfg->dec_params.avs_support = 2; /* AVS Plus */
    tb_cfg->dec_params.rv_support = 1;
    tb_cfg->dec_params.mvc_support = 1;
    tb_cfg->dec_params.webp_support = 1;
    tb_cfg->dec_params.ec_support = 0;
    tb_cfg->dec_params.jpeg_esupport = 0;
    tb_cfg->dec_params.support_non_compliant = 1;
    tb_cfg->dec_params.max_dec_pic_width = 4096;
    tb_cfg->dec_params.max_dec_pic_height = 2304;
    tb_cfg->dec_params.hw_version = 18001;
    tb_cfg->dec_params.hw_build = 7000;
    tb_cfg->dec_params.hw_build_id = 0xFFFF;

    tb_cfg->dec_params.bus_width = DEC_X170_BUS_WIDTH;
    tb_cfg->dec_params.latency = DEC_X170_REFBU_LATENCY;
    tb_cfg->dec_params.non_seq_clk = DEC_X170_REFBU_NONSEQ;
    tb_cfg->dec_params.seq_clk = DEC_X170_REFBU_SEQ;

    tb_cfg->dec_params.strm_swap = HANTRODEC_STREAM_SWAP;
    tb_cfg->dec_params.pic_swap = HANTRODEC_STREAM_SWAP;
    tb_cfg->dec_params.dirmv_swap = HANTRODEC_STREAM_SWAP;
    tb_cfg->dec_params.tab0_swap = HANTRODEC_STREAM_SWAP;
    tb_cfg->dec_params.tab1_swap = HANTRODEC_STREAM_SWAP;
    tb_cfg->dec_params.tab2_swap = HANTRODEC_STREAM_SWAP;
    tb_cfg->dec_params.tab3_swap = HANTRODEC_STREAM_SWAP;
    tb_cfg->dec_params.rscan_swap = HANTRODEC_STREAM_SWAP;
    tb_cfg->dec_params.comp_tab_swap = HANTRODEC_STREAM_SWAP;
    tb_cfg->dec_params.max_burst = HANTRODEC_MAX_BURST;
    tb_cfg->dec_params.ref_double_buffer_enable =
    HANTRODEC_INTERNAL_DOUBLE_REF_BUFFER;
    tb_cfg->dec_params.timeout_cycles = HANTRODEC_TIMEOUT_OVERRIDE;
#ifdef DEC_X170_REFBU_SEQ
    tb_cfg->dec_params.apf_threshold_value = DEC_X170_REFBU_NONSEQ / DEC_X170_REFBU_SEQ;
#else
    tb_cfg->dec_params.apf_threshold_value = DEC_X170_REFBU_NONSEQ;
#endif
    tb_cfg->dec_params.apf_disable = DEC_X170_APF_DISABLE;
    tb_cfg->dec_params.clk_gate_decoder = DEC_X170_INTERNAL_CLOCK_GATING;
    tb_cfg->dec_params.clk_gate_decoder_idle = DEC_X170_INTERNAL_CLOCK_GATING_RUNTIME;
    tb_cfg->dec_params.axi_id_rd = DEC_X170_AXI_ID_R;
    tb_cfg->dec_params.axi_id_rd_unique_enable = DEC_X170_AXI_ID_R_E;
    tb_cfg->dec_params.axi_id_wr = DEC_X170_AXI_ID_W;
    tb_cfg->dec_params.axi_id_wr_unique_enable = DEC_X170_AXI_ID_W_E;

    /* PpParams */
    strcpy(tb_cfg->pp_params.output_picture_endian, "PP_CFG");
    strcpy(tb_cfg->pp_params.input_picture_endian, "PP_CFG");
    strcpy(tb_cfg->pp_params.word_swap, "PP_CFG");
    strcpy(tb_cfg->pp_params.word_swap16, "PP_CFG");
    tb_cfg->pp_params.bus_burst_length = PP_X170_BUS_BURST_LENGTH;

    strcpy(tb_cfg->pp_params.multi_buffer, "DISABLED");

#if (PP_X170_INTERNAL_CLOCK_GATING == 0)
    strcpy(tb_cfg->pp_params.clock_gating, "DISABLED");
#else
    strcpy(tb_cfg->pp_params.clock_gating, "ENABLED");
#endif

#if (DEC_X170_DATA_DISCARD_ENABLE == 0)
    strcpy(tb_cfg->pp_params.data_discard, "DISABLED");
#else
    strcpy(tb_cfg->pp_params.data_discard, "ENABLED");
#endif

    tb_cfg->pp_params.ppd_exists = 1;
    tb_cfg->pp_params.dithering_support = 1;
    tb_cfg->pp_params.scaling_support = 1; /* Lo/Hi performance? */
    tb_cfg->pp_params.deinterlacing_support = 1;
    tb_cfg->pp_params.alpha_blending_support = 1;
    tb_cfg->pp_params.ablend_crop_support = 0;
    tb_cfg->pp_params.pp_out_endian_support = 1;
    tb_cfg->pp_params.tiled_support = 1;
    tb_cfg->pp_params.max_pp_out_pic_width = 4096;

    tb_cfg->pp_params.fast_hor_down_scale_disable = 0;
    tb_cfg->pp_params.fast_ver_down_scale_disable = 0;
    /*    tb_cfg->pp_params.ver_downscale_stripes_disable = 0;*/

    tb_cfg->pp_params.filter_enabled = 0; /* MPEG4 deblocking filter disabled as default. */

    tb_cfg->pp_params.pix_acc_out_support = 1;
    tb_cfg->pp_params.vert_down_scale_stripe_disable_support = 0;
    tb_cfg->pp_params.pipeline_e = 1;
    tb_cfg->pp_params.pre_fetch_height = 16;
    tb_cfg->ppu_index = -1;
    memset(tb_cfg->pp_units_params, 0, sizeof(tb_cfg->pp_units_params));

    if (tb_cfg->dec_params.hw_build == 7020 || tb_cfg->dec_params.hw_version == 18001) {
        tb_cfg->dec_params.tiled_ref_support = 1;
        tb_cfg->dec_params.field_dpb_support = 1;
    }
}
#endif

#if 1

void TBSetRefbuMemModel( const struct TBCfg* tb_cfg, u32 *reg_base, struct refBuffer *p_refbu ) {
    p_refbu->bus_width_in_bits = 32 + 32*tb_cfg->dec_params.bus_width64bit_enable;
    p_refbu->curr_mem_model.latency = tb_cfg->dec_params.latency;
    p_refbu->curr_mem_model.nonseq = tb_cfg->dec_params.non_seq_clk;
    p_refbu->curr_mem_model.seq = tb_cfg->dec_params.seq_clk;
    p_refbu->data_excess_max_pct = tb_cfg->dec_params.refbu_data_excess_max_pct;
    p_refbu->mb_weight =
    p_refbu->dec_mode_mb_weights[tb_cfg->dec_params.bus_width64bit_enable];
    if( p_refbu->mem_access_stats_flag == 0 ) {
        if( tb_cfg->dec_params.bus_width64bit_enable && ! (DEC_X170_REFBU_WIDTH == 64) ) {
            p_refbu->mem_access_stats.seq >>= 1;
        } else if( !tb_cfg->dec_params.bus_width64bit_enable && (DEC_X170_REFBU_WIDTH == 64) ) {
            p_refbu->mem_access_stats.seq <<= 1;
        }
        p_refbu->mem_access_stats_flag = 1;
    }

    if( tb_cfg->dec_params.apf_threshold_value >= 0 )
        SetDecRegister( reg_base, HWIF_APF_THRESHOLD, tb_cfg->dec_params.apf_threshold_value);
}


/*------------------------------------------------------------------------------

   <++>.<++>  Function: TBGetDecRlcModeForced

        Functional description:
          Gets the integer values of decoder rlc mode forced.

        Inputs:

        Outputs:

------------------------------------------------------------------------------*/
u32 TBGetDecRlcModeForced(const struct TBCfg* tb_cfg) {
    if (strcmp(tb_cfg->dec_params.rlc_mode_forced, "ENABLED") == 0) {
        return 1;
    } else if (strcmp(tb_cfg->dec_params.rlc_mode_forced, "DISABLED") == 0) {
        return 0;
    } else {
        ASSERT(0);
        return -1;
    }
}

u32 TBGetDecClockGating(const struct TBCfg* tb_cfg) {
    return tb_cfg->dec_params.clk_gate_decoder ? 1 : 0;
}

u32 TBGetDecDataDiscard(const struct TBCfg* tb_cfg) {
    if (strcmp(tb_cfg->dec_params.data_discard, "ENABLED") == 0) {
        return 1;
    } else if (strcmp(tb_cfg->dec_params.data_discard, "DISABLED") == 0) {
        return 0;
    } else {
        ASSERT(0);
        return -1;
    }
}

u32 TBGetDecOutputPictureEndian(const struct TBCfg* tb_cfg) {
    if (strcmp(tb_cfg->dec_params.output_picture_endian, "BIG_ENDIAN") == 0) {
        return DEC_X170_BIG_ENDIAN;
    } else if (strcmp(tb_cfg->dec_params.output_picture_endian, "LITTLE_ENDIAN") == 0) {
        return DEC_X170_LITTLE_ENDIAN;
    } else {
        ASSERT(0);
        return -1;
    }
}

u32 TBGetDecOutputFormat(const struct TBCfg* tb_cfg) {

    if (strcmp(tb_cfg->dec_params.output_format, "RASTER_SCAN") == 0) {
        return DEC_X170_OUTPUT_FORMAT_RASTER_SCAN;
    } else if (strcmp(tb_cfg->dec_params.output_format, "TILED") == 0) {
        return DEC_X170_OUTPUT_FORMAT_TILED;
    } else {
        ASSERT(0);
        return -1;
    }
}

u32 TBGetDecServiceMergeDisable(const struct TBCfg* tb_cfg) {
  return tb_cfg->dec_params.service_merge_disable;
}

u32 TBGetDecBusWidth(const struct TBCfg* tb_cfg) {
    return tb_cfg->dec_params.bus_width;
}
#endif                      

void ResolvePpParamsOverlapPPU(PpUnitConfig *ppu_cfg,struct TBPpUnitParams *pp_units_params) {
    /* Override PPU1-3 parameters with tb.cfg */
    u32 i, pp_enabled;
    memset(ppu_cfg, 0,4*sizeof(PpUnitConfig));

    for (i = ppu_cfg[0].enabled ? 1 : 0; i < 4; i++) {
        ppu_cfg[i].enabled = pp_units_params[i].unit_enabled;
        ppu_cfg[i].cr_first = pp_units_params[i].cr_first;
        ppu_cfg[i].tiled_e = pp_units_params[i].tiled_e;
        ppu_cfg[i].crop.enabled = 0;//pp_units_params[i].unit_enabled;;
        ppu_cfg[i].crop.x = pp_units_params[i].crop_x;
        ppu_cfg[i].crop.y = pp_units_params[i].crop_y;
        ppu_cfg[i].crop.width = pp_units_params[i].crop_width;
        ppu_cfg[i].crop.height = pp_units_params[i].crop_height;
        ppu_cfg[i].scale.enabled = pp_units_params[i].unit_enabled;;
        ppu_cfg[i].scale.width = pp_units_params[i].scale_width;
        ppu_cfg[i].scale.height = pp_units_params[i].scale_height;
        ppu_cfg[i].shaper_enabled = pp_units_params[i].shaper_enabled;
        ppu_cfg[i].monochrome = pp_units_params[i].monochrome;
        ppu_cfg[i].planar = pp_units_params[i].planar;
        ppu_cfg[i].out_p010 = pp_units_params[i].out_p010;
        ppu_cfg[i].out_cut_8bits = pp_units_params[i].out_cut_8bits;
        ppu_cfg[i].align = DEC_ALIGN_1024B;
        ppu_cfg[i].ystride = pp_units_params[i].ystride;
        ppu_cfg[i].cstride = pp_units_params[i].cstride;
        ppu_cfg[i].out_format = 0;
        ppu_cfg[i].out_be = 0;
    }
    if (pp_units_params[0].unit_enabled) {
        /* PPU0 */
        ppu_cfg[0].align = pp_units_params[0].align;
        ppu_cfg[0].enabled |= pp_units_params[0].unit_enabled;
        ppu_cfg[0].cr_first |= pp_units_params[0].cr_first;
        //if (params->hw_format != DEC_OUT_FRM_RASTER_SCAN)
            ppu_cfg[0].tiled_e |= pp_units_params[0].tiled_e;
        ppu_cfg[0].planar |= pp_units_params[0].planar;
        ppu_cfg[0].out_p010 |= pp_units_params[0].out_p010;
        ppu_cfg[0].out_cut_8bits |= pp_units_params[0].out_cut_8bits;
        if (!ppu_cfg[0].crop.enabled && pp_units_params[0].unit_enabled) {
            ppu_cfg[0].crop.x = pp_units_params[0].crop_x;
            ppu_cfg[0].crop.y = pp_units_params[0].crop_y;
            ppu_cfg[0].crop.width = pp_units_params[0].crop_width;
            ppu_cfg[0].crop.height = pp_units_params[0].crop_height;
        }
        if (ppu_cfg[0].crop.width || ppu_cfg[0].crop.height)
        ppu_cfg[0].crop.enabled = 1;
        if (!ppu_cfg[0].scale.enabled && pp_units_params[0].unit_enabled) {
            ppu_cfg[0].scale.width = pp_units_params[0].scale_width;
            ppu_cfg[0].scale.height = pp_units_params[0].scale_height;
        }
        if (ppu_cfg[0].scale.width || ppu_cfg[0].scale.height)
            ppu_cfg[0].scale.enabled = 1;
        ppu_cfg[0].shaper_enabled = pp_units_params[0].shaper_enabled;
        ppu_cfg[0].monochrome = pp_units_params[0].monochrome;
        ppu_cfg[0].align = pp_units_params[0].align;
        if (!ppu_cfg[0].ystride)
            ppu_cfg[0].ystride = pp_units_params[0].ystride;
        if (!ppu_cfg[0].cstride)
            ppu_cfg[0].cstride = pp_units_params[0].cstride;
    }

    
    av_log(NULL, AV_LOG_DEBUG, "ppu_cfg[0].shaper_enabled = %d\n", ppu_cfg[0].shaper_enabled);
    av_log(NULL, AV_LOG_DEBUG, "ppu_cfg[1].shaper_enabled = %d\n", ppu_cfg[1].shaper_enabled);
}
                           
void printDecodeReturn(AVCodecContext *avctx,i32 retval) {

    static i32 prev_retval = 0xFFFFFF;
    if (prev_retval != retval ||
    (prev_retval != DEC_NO_DECODING_BUFFER &&
    prev_retval != DEC_PENDING_FLUSH))
        av_log(avctx, AV_LOG_DEBUG, "TB: DecDecode returned: ");
    switch (retval) {
        case DEC_OK:
            av_log(avctx, AV_LOG_DEBUG, "DEC_OK\n");
        break;
        case DEC_NONREF_PIC_SKIPPED:
            av_log(avctx, AV_LOG_DEBUG, "DEC_NONREF_PIC_SKIPPED\n");
        break;
        case DEC_STRM_PROCESSED:
            av_log(avctx, AV_LOG_DEBUG, "DEC_STRM_PROCESSED\n");
        break;
        case DEC_BUF_EMPTY:
            av_log(avctx, AV_LOG_DEBUG, "DEC_BUF_EMPTY\n");
        break;
        case DEC_NO_DECODING_BUFFER:
        /* There may be too much DEC_NO_DECODING_BUFFER.
        Only print for the 1st time. */
        if (prev_retval != DEC_NO_DECODING_BUFFER)
            av_log(avctx, AV_LOG_DEBUG, "DEC_NO_DECODING_BUFFER\n");
        break;
        case DEC_PIC_RDY:
            av_log(avctx, AV_LOG_DEBUG, "DEC_PIC_RDY\n");
        break;
        case DEC_PIC_DECODED:
            av_log(avctx, AV_LOG_DEBUG, "DEC_PIC_DECODED\n");
        break;
        case DEC_ADVANCED_TOOLS:
            av_log(avctx, AV_LOG_DEBUG, "DEC_ADVANCED_TOOLS\n");
        break;
        case DEC_HDRS_RDY:
            av_log(avctx, AV_LOG_DEBUG, "DEC_HDRS_RDY\n");
        break;
        case DEC_STREAM_NOT_SUPPORTED:
            av_log(avctx, AV_LOG_DEBUG, "DEC_STREAM_NOT_SUPPORTED\n");
        break;
        case DEC_DWL_ERROR:
            av_log(avctx, AV_LOG_DEBUG, "DEC_DWL_ERROR\n");
        break;
        case DEC_STRM_ERROR:
            av_log(avctx, AV_LOG_DEBUG, "DEC_STRM_ERROR\n");
        break;
        case DEC_HW_TIMEOUT:
            av_log(avctx, AV_LOG_DEBUG, "DEC_HW_TIMEOUT\n");
        break;
        case DEC_PENDING_FLUSH:
        if (prev_retval != DEC_PENDING_FLUSH)
            av_log(avctx, AV_LOG_DEBUG, "DEC_PENDING_FLUSH\n");
        break;
        default:
            av_log(avctx, AV_LOG_DEBUG, "Other %d\n", retval);
        break;
    }
    prev_retval = retval;
}




void fb_print_pic_coding_type(AVCodecContext *avctx,u32 *pic_type) {

    av_log(avctx, AV_LOG_DEBUG, "Coding type ");
    
    switch (pic_type[0]) {
    case DEC_PIC_TYPE_I:
        av_log(NULL, AV_LOG_DEBUG, "[I:");
    break;
    case DEC_PIC_TYPE_P:
        av_log(NULL, AV_LOG_DEBUG, "[P:");
    break;
    case DEC_PIC_TYPE_B:
        av_log(NULL, AV_LOG_DEBUG, "[B:");
    break;
    default:
        av_log(NULL, AV_LOG_DEBUG, "[Other %d:", pic_type[0]);
    break;
    }

    switch (pic_type[1]) {
        case DEC_PIC_TYPE_I:
            av_log(NULL, AV_LOG_DEBUG, "I]");
        break;
        case DEC_PIC_TYPE_P:
            av_log(NULL, AV_LOG_DEBUG, "P]");
        break;
        case DEC_PIC_TYPE_B:
            av_log(NULL, AV_LOG_DEBUG, "B]");
        break;
        default:
            av_log(NULL, AV_LOG_DEBUG, "Other %d]", pic_type[1]);
        break;
    }
}

static void dump_dec_pts_dts_delay(HantroDecContext *fb_dec_ctx, int loglevel)
{
    int i;
    av_log(fb_dec_ctx, loglevel, "*****debug pts dts\n");
    for (i = 0; i < PTS_DTS_MAX_DELAY; i++) {
        av_log(fb_dec_ctx, loglevel, "dec_pts_dts_delay[%d] %s, pts %ld, dts %ld, id %d\n", i, 
            fb_dec_ctx->dec_pts_dts_delay[i].valid ? "valid" : "not valid",
            fb_dec_ctx->dec_pts_dts_delay[i].pts_delay,
            fb_dec_ctx->dec_pts_dts_delay[i].pkt_dts_delay,
            fb_dec_ctx->dec_pts_dts_delay[i].pkt_pic_id);
    }
}

int hantro_dec_set_pts_dts(HantroDecContext *fb_dec_ctx, AVPacket *avpkt)
{
    int i;
    int empty_index;
    int pn_count;
    int frame_index;

    for (i = 0; i < PTS_DTS_MAX_DELAY; i++) {
        if (fb_dec_ctx->dec_pts_dts_delay[i].valid == 0) {
            break;
        }
    }
    if (i >= PTS_DTS_MAX_DELAY) {
        av_log(fb_dec_ctx, AV_LOG_DEBUG, "ERROR: dec_pts_dts_delay exceeds max depth %d\n", PTS_DTS_MAX_DELAY);
#if 0
        goto err_exit;
#else
        u32 min_pic_id = fb_dec_ctx->dec_pts_dts_delay[0].pkt_pic_id;
        int min_index = 0;
        for (i = 1; i < PTS_DTS_MAX_DELAY; i++) {
            if (fb_dec_ctx->dec_pts_dts_delay[i].valid 
                && fb_dec_ctx->dec_pts_dts_delay[i].pkt_pic_id < min_pic_id) {
                min_pic_id = fb_dec_ctx->dec_pts_dts_delay[i].pkt_pic_id;
                min_index = i;
            }
        }
        i = min_index;
        fb_dec_ctx->dec_pts_dts_delay[i].valid = 0;
#endif
    }
    empty_index = i;

    if (avpkt->size == 1) {
        u8 marker = avpkt->data[0];
        av_log(fb_dec_ctx, AV_LOG_DEBUG, "marker = 0x%X\n", marker);
        if (marker & 0x8) {
            /* PN frame, to find pts -1 */
            pn_count = 0;
            for (i = 0; i < PTS_DTS_MAX_DELAY; i++) {
                if (fb_dec_ctx->dec_pts_dts_delay[i].valid == 1 && fb_dec_ctx->dec_pts_dts_delay[i].pts_delay == -1) {
                    if (pn_count == 0)
                        frame_index = i;
                    pn_count++;
                }
            }
            if (pn_count == 0) {
                av_log(fb_dec_ctx, AV_LOG_DEBUG, "can't find match frame, fb_dec_ctx->pic_decode_number = %d\n", fb_dec_ctx->pic_decode_number);
                //goto err_exit;
                return 0;
            }
            if (pn_count > 1) {
                av_log(fb_dec_ctx, AV_LOG_ERROR, "can't decide match frame\n");
                goto err_exit;
            }
            av_log(fb_dec_ctx, AV_LOG_DEBUG, "frame_index = %d\n", frame_index);
            fb_dec_ctx->dec_pts_dts_delay[frame_index].pts_delay = avpkt->pts;
            dump_dec_pts_dts_delay(fb_dec_ctx, AV_LOG_DEBUG);
        } else {
            av_log(fb_dec_ctx, AV_LOG_ERROR, "unknow case\n");
            goto err_exit;
        }
    } else {
        fb_dec_ctx->dec_pts_dts_delay[empty_index].valid = 1;
        if ((avpkt->pts == fb_dec_ctx->last_pts) && (avpkt->pts != AV_NOPTS_VALUE) && fb_dec_ctx->pic_decode_number != 1) {
            /* mark before same pts as -1 wait PN frame */
            for (i = 0; i < PTS_DTS_MAX_DELAY; i++) {
                if (fb_dec_ctx->dec_pts_dts_delay[i].valid == 1 && fb_dec_ctx->dec_pts_dts_delay[i].pts_delay == avpkt->pts) {
                    frame_index = i;
                    break;
                }
            }
            if (i >= PTS_DTS_MAX_DELAY) {
                av_log(fb_dec_ctx, AV_LOG_ERROR, "can't find last same pts\n");
                goto err_exit;
            }
            fb_dec_ctx->dec_pts_dts_delay[frame_index].pts_delay = -1;
        }
        fb_dec_ctx->dec_pts_dts_delay[empty_index].pts_delay = avpkt->pts;
        fb_dec_ctx->dec_pts_dts_delay[empty_index].pkt_dts_delay = avpkt->dts;
        fb_dec_ctx->dec_pts_dts_delay[empty_index].pkt_pic_id = fb_dec_ctx->pic_decode_number - 1;
        av_log(fb_dec_ctx, AV_LOG_DEBUG, "set dec_pts_dts_delay[%d] pts %ld, dts %ld, id %d\n", empty_index,
            fb_dec_ctx->dec_pts_dts_delay[empty_index].pts_delay,
            fb_dec_ctx->dec_pts_dts_delay[empty_index].pkt_dts_delay,
            fb_dec_ctx->dec_pts_dts_delay[empty_index].pkt_pic_id);
        fb_dec_ctx->last_pts = avpkt->pts;
    }
    return 0;
    
err_exit:
    dump_dec_pts_dts_delay(fb_dec_ctx, AV_LOG_ERROR);
    return -1;

}

static int hantro_dec_get_pts_dts(HantroDecContext *fb_dec_ctx, int pid, int64_t* pts, int64_t* pkt_dts)
{
    int i;
    int need_pid = pid;
    
    dump_dec_pts_dts_delay(fb_dec_ctx, AV_LOG_DEBUG);
    
    av_log(fb_dec_ctx, AV_LOG_DEBUG, "fb_dec_ctx->sequence_info.is_interlaced = %d\n", fb_dec_ctx->sequence_info.is_interlaced);
    av_log(fb_dec_ctx, AV_LOG_DEBUG, "need_pid is %d\n", need_pid);

    for (i = 0; i < PTS_DTS_MAX_DELAY; i++) {
        if (fb_dec_ctx->dec_pts_dts_delay[i].valid
                && fb_dec_ctx->dec_pts_dts_delay[i].pkt_pic_id == need_pid) {
            av_log(fb_dec_ctx, AV_LOG_DEBUG, "get dec_pts_dts_delay[%d] %ld, %ld, %d\n", i, fb_dec_ctx->dec_pts_dts_delay[i].pts_delay,
                fb_dec_ctx->dec_pts_dts_delay[i].pkt_dts_delay, fb_dec_ctx->dec_pts_dts_delay[i].pkt_pic_id);
            fb_dec_ctx->dec_pts_dts_delay[i].valid = 0;
            *pts = fb_dec_ctx->dec_pts_dts_delay[i].pts_delay;
			*pkt_dts = fb_dec_ctx->dec_pts_dts_delay[i].pkt_dts_delay;
            return 0;
        }
    }
    av_log(fb_dec_ctx, AV_LOG_ERROR, "can't find the dec_pts_dts_delay for pic %d\n", need_pid);
    dump_dec_pts_dts_delay(fb_dec_ctx, AV_LOG_ERROR);
    return -1;
}

int hantro_dec_output_frame(AVCodecContext *avctx, AVFrame *out, struct DecPicturePpu *decoded_pic)
{
    int ret = -1;
    int i;
    HantroDecContext *fb_dec_ctx  = avctx->priv_data;
    AVHANTROFramesContext *frame_hwctx;
    AVHWFramesContext *hwframe_ctx;

    struct DecPicturePpu *pic = av_mallocz(sizeof(*pic));
    if(!pic)
        return AVERROR(ENOMEM);
    memcpy(pic,decoded_pic,sizeof(struct DecPicturePpu));
    
    av_log(avctx, AV_LOG_DEBUG, "dec output pic @: %p\n",pic);
    report_dec_pic_info(avctx,pic);

#if 0
        av_log(avctx, AV_LOG_DEBUG, "------debug pic content: %d\n");
        struct DWLLinearMem debug_bubffer;   
        u32 *p_data;

        debug_bubffer.mem_type = DWL_MEM_TYPE_CPU_FILE_SINK;
        if(DWLMallocLinear(fb_dec_ctx->dwl_inst,1*1024*1024, &debug_bubffer) != DWL_OK) {
            av_log(avctx, AV_LOG_ERROR, "UNABLE TO ALLOCATE STREAM BUFFER MEMORY\n");
            return -1;
        } else {			
            av_log(avctx, AV_LOG_DEBUG, "alloc memory for debug ,addr=0x%x, size is 0x%x OK\n",debug_bubffer.virtual_address,debug_bubffer.size);
        }
        
        av_log(avctx, AV_LOG_DEBUG, "dwl_edma_ep2rc_nolink from addr=0x%x to add=0x%x\n", pic->pictures[1].luma.bus_address, debug_bubffer.bus_address_rc);

        if(/*(len > 0) &&*/ ( fb_dec_ctx->stream_mem[fb_dec_ctx->stream_mem_index].bus_address_rc != 0))
        {       
            ret = dwl_edma_ep2rc_nolink(fb_dec_ctx->dwl_inst, pic->pictures[1].luma.bus_address, debug_bubffer.bus_address_rc, debug_bubffer.size);
        }
        p_data = (u32 *)debug_bubffer.virtual_address;
        for(i=0;i<120;i++)
        {
            if(i%16 == 0)av_log(avctx, AV_LOG_DEBUG, "\n");
            av_log(avctx, AV_LOG_DEBUG, "%08x ",p_data[i]);
            
        }
        av_log(avctx, AV_LOG_DEBUG, "\n");
        DWLFreeLinear( fb_dec_ctx->dwl_inst, &debug_bubffer);
#endif

    fb_dec_ctx->cycle_count += pic->pictures[0].picture_info.cycles_per_mb;
    //fb_dec_ctx->pic_display_number++;
    
    ret = ff_decode_frame_props(avctx, out);
    if (ret < 0) {
        av_log(avctx, AV_LOG_ERROR, "ff_decode_frame_props failed\n");
        return ret;
    }
    out->format = AV_PIX_FMT_HANTRO;//AV_PIX_FMT_YUV420P;
    out->width = pic->pictures[1].pic_width;
    out->height = pic->pictures[1].pic_height;
    out->linesize[0] = pic->pictures[1].pic_width;
    out->linesize[1] = pic->pictures[1].pic_width/2;
    out->linesize[2] = pic->pictures[1].pic_width/2;
    out->key_frame = (pic->pictures[1].picture_info.pic_coding_type == DEC_PIC_TYPE_I);
    
    av_log(avctx, AV_LOG_DEBUG, "out->width = %d, out->height = %d, out->linesize[0] = %d, out->key_frame = %d\n",
        out->width, out->height, out->linesize[0], out->key_frame);

    ret = hantro_dec_get_pts_dts(fb_dec_ctx, pic->pictures[0].picture_info.pic_id - 1, &out->pts, &out->pkt_dts);
    if (ret < 0) {
      out->pts = pic->pictures[0].picture_info.pic_id - 1;
      out->pkt_dts = pic->pictures[0].picture_info.pic_id - 1;
    }
    
    PpUnitConfig * pp0 = &fb_dec_ctx->hantro_dec_config.ppu_cfg[0];
    if(pp0->enabled == 1)
    {
        pic->pictures[0].pp_enabled = 0;
    }
    else
    {
        pic->pictures[0].pp_enabled = 1;
    }
    for (i = 1; i < 5; i++) {
        PpUnitConfig * pp = &fb_dec_ctx->hantro_dec_config.ppu_cfg[i-1];
        if (pp->enabled == 1) {
            pic->pictures[i].pp_enabled = 1;
            av_log(avctx, AV_LOG_DEBUG, "pic.pictures[%d].pp_enabled = %d,comperss_status=%d\n",i,pic->pictures[i].pp_enabled,pic->pictures[i].pic_compressed_status);
        } else {
            pic->pictures[i].pp_enabled = 0;
        }
    }
    
    for (i = 1; i < 5; i++) {
        av_log(avctx, AV_LOG_DEBUG, "pic.pictures[%d].pp_enabled = %d,comperss_status=%d,bit_depth_luma=%d\n",i,pic->pictures[i].pp_enabled,pic->pictures[i].pic_compressed_status,pic->pictures[i].sequence_info.bit_depth_luma);
    }
    av_log(avctx, AV_LOG_DEBUG, "fb_dec_ctx->picRdy = 1\n");

    av_log(avctx, AV_LOG_DEBUG, "fb_dec_ctx->hwframe = %p\n", fb_dec_ctx->hwframe);
    hwframe_ctx = fb_dec_ctx->hwframe->data;
    av_log(avctx, AV_LOG_DEBUG, "hwframe_ctx = %p\n", hwframe_ctx);
    frame_hwctx = hwframe_ctx->hwctx;
    av_log(avctx, AV_LOG_DEBUG, "frame_hwctx = %p\n", frame_hwctx);

    if (pic->pictures[1].pp_enabled) {//pic[1] means pp0, if pp0 enabled pic_info[0](rfc) should not set
        frame_hwctx->pic_info[0].enabled = 0;
    } else {

        frame_hwctx->pic_info[0].width = avctx->width;
        frame_hwctx->pic_info[0].height = avctx->height;
        frame_hwctx->pic_info[0].enabled = 1;

        frame_hwctx->pic_info[0].picdata.is_interlaced = pic->pictures[0].sequence_info.is_interlaced;
        frame_hwctx->pic_info[0].picdata.pic_stride = pic->pictures[0].pic_stride;
        frame_hwctx->pic_info[0].picdata.crop_out_width = pic->pictures[0].sequence_info.crop_params.crop_out_width;
        frame_hwctx->pic_info[0].picdata.crop_out_height = pic->pictures[0].sequence_info.crop_params.crop_out_height;
        frame_hwctx->pic_info[0].picdata.pic_format = pic->pictures[0].picture_info.format;
        frame_hwctx->pic_info[0].picdata.pic_pixformat = pic->pictures[0].picture_info.pixel_format;
        frame_hwctx->pic_info[0].picdata.bit_depth_luma = pic->pictures[0].sequence_info.bit_depth_luma;
        frame_hwctx->pic_info[0].picdata.bit_depth_chroma = pic->pictures[0].sequence_info.bit_depth_chroma;
        frame_hwctx->pic_info[0].picdata.pic_compressed_status = pic->pictures[0].pic_compressed_status;
        
        if (fb_dec_ctx->resizes[0].x || fb_dec_ctx->resizes[0].y
                || fb_dec_ctx->resizes[0].cw || fb_dec_ctx->resizes[0].ch) {
            frame_hwctx->pic_info[0].crop.enabled = 1;
            frame_hwctx->pic_info[0].crop.x = fb_dec_ctx->resizes[0].x;
            frame_hwctx->pic_info[0].crop.y = fb_dec_ctx->resizes[0].y;
            frame_hwctx->pic_info[0].crop.w = fb_dec_ctx->resizes[0].cw;
            frame_hwctx->pic_info[0].crop.h = fb_dec_ctx->resizes[0].ch;
        }
    }
    for (i = 1; i < 5; i++) {
        PpUnitConfig * pp = &fb_dec_ctx->hantro_dec_config.ppu_cfg[i-1];

        if (!pic->pictures[i].pp_enabled)
            continue;

        frame_hwctx->pic_info[i].enabled = pic->pictures[i].pp_enabled;
        frame_hwctx->pic_info[i].pic_width = pic->pictures[i].pic_width;
        frame_hwctx->pic_info[i].pic_height = pic->pictures[i].pic_height;
        if (pp->scale.enabled) {
            frame_hwctx->pic_info[i].width = pp->scale.width;
            frame_hwctx->pic_info[i].height = pp->scale.height;
        } else {
            if (pp->crop.enabled) {
                frame_hwctx->pic_info[i].width = pp->crop.width;
                frame_hwctx->pic_info[i].height = pp->crop.height;
            } else {
                //pp0 has no scale, but hevc case 12283&12315 out pic_width*pic_height is not width*height
                frame_hwctx->pic_info[i].width = MIN(pic->pictures[i].pic_width, avctx->width);
                frame_hwctx->pic_info[i].height = MIN(pic->pictures[i].pic_height, avctx->height);
            }
        }

        frame_hwctx->pic_info[i].picdata.is_interlaced = pic->pictures[i].sequence_info.is_interlaced;
        frame_hwctx->pic_info[i].picdata.pic_stride = pic->pictures[i].pic_stride;
        frame_hwctx->pic_info[i].picdata.crop_out_width = pic->pictures[i].sequence_info.crop_params.crop_out_width;
        frame_hwctx->pic_info[i].picdata.crop_out_height = pic->pictures[i].sequence_info.crop_params.crop_out_height;
        frame_hwctx->pic_info[i].picdata.pic_format = pic->pictures[i].picture_info.format;
        frame_hwctx->pic_info[i].picdata.pic_pixformat = pic->pictures[i].picture_info.pixel_format;
        frame_hwctx->pic_info[i].picdata.bit_depth_luma = pic->pictures[i].sequence_info.bit_depth_luma;
        frame_hwctx->pic_info[i].picdata.bit_depth_chroma = pic->pictures[i].sequence_info.bit_depth_chroma;
        frame_hwctx->pic_info[i].picdata.pic_compressed_status = pic->pictures[i].pic_compressed_status;
        
        av_log(avctx, AV_LOG_DEBUG, "frame_hwctx->pic_info[%d].enabled = %d\n", i, frame_hwctx->pic_info[i].enabled);
        av_log(avctx, AV_LOG_DEBUG, "frame_hwctx->pic_info[%d].width = %d\n", i, frame_hwctx->pic_info[i].width);
        av_log(avctx, AV_LOG_DEBUG, "frame_hwctx->pic_info[%d].height = %d\n", i, frame_hwctx->pic_info[i].height);
        av_log(avctx, AV_LOG_DEBUG, "frame_hwctx->pic_info[%d].pic_width = %d\n", i, frame_hwctx->pic_info[i].pic_width);
        av_log(avctx, AV_LOG_DEBUG, "frame_hwctx->pic_info[%d].pic_height = %d\n", i, frame_hwctx->pic_info[i].pic_height);
        av_log(avctx, AV_LOG_DEBUG, "frame_hwctx->pic_info[%d].picdata.is_interlaced = %d\n", i, frame_hwctx->pic_info[i].picdata.is_interlaced);
        av_log(avctx, AV_LOG_DEBUG, "frame_hwctx->pic_info[%d].picdata.pic_format = %d\n", i, frame_hwctx->pic_info[i].picdata.pic_format);
        av_log(avctx, AV_LOG_DEBUG, "frame_hwctx->pic_info[%d].picdata.pic_pixformat = %d\n", i, frame_hwctx->pic_info[i].picdata.pic_pixformat);
        av_log(avctx, AV_LOG_DEBUG, "frame_hwctx->pic_info[%d].picdata.bit_depth_luma = %d\n", i, frame_hwctx->pic_info[i].picdata.bit_depth_luma);
        av_log(avctx, AV_LOG_DEBUG, "frame_hwctx->pic_info[%d].picdata.bit_depth_chroma = %d\n", i, frame_hwctx->pic_info[i].picdata.bit_depth_chroma);
        av_log(avctx, AV_LOG_DEBUG, "frame_hwctx->pic_info[%d].picdata.pic_compressed_status = %d\n", i, frame_hwctx->pic_info[i].picdata.pic_compressed_status);
        
    }
    
    av_log(avctx, AV_LOG_DEBUG, "[%d][%d(%dx%d)][%d(%dx%d)][%d(%dx%d)][%d(%dx%d)]\n", 
        frame_hwctx->pic_info[0].enabled,
        frame_hwctx->pic_info[1].enabled, frame_hwctx->pic_info[1].width, frame_hwctx->pic_info[1].height,
        frame_hwctx->pic_info[2].enabled, frame_hwctx->pic_info[2].width, frame_hwctx->pic_info[2].height,
        frame_hwctx->pic_info[3].enabled, frame_hwctx->pic_info[3].width, frame_hwctx->pic_info[3].height,
        frame_hwctx->pic_info[4].enabled, frame_hwctx->pic_info[4].width, frame_hwctx->pic_info[4].height);

    
    if (fb_dec_ctx->vce_ds_enable) {
        if (!frame_hwctx->pic_info[1].enabled || !frame_hwctx->pic_info[2].enabled) {
            av_log(avctx, AV_LOG_ERROR, "When use 1/4 ds pass1 for vce, pp0 and pp1 should be enabled!\n");
            goto err_exit;
        }
        if (frame_hwctx->pic_info[0].enabled || frame_hwctx->pic_info[3].enabled || frame_hwctx->pic_info[4].enabled) {
            av_log(avctx, AV_LOG_ERROR, "When use 1/4 ds pass1 for vce, except pp0 and pp1 should not be enabled!\n");
            goto err_exit;
        }
        frame_hwctx->pic_info[2].flag = 1;
    }
    
    out->data[0] = pic;
    out->buf[0] = av_buffer_create((uint8_t *)pic,
        sizeof(struct DecPicturePpu), fb_dec_ctx->hantro_decode_picture_consume, fb_dec_ctx, AV_BUFFER_FLAG_READONLY);
    if (out->buf[0] == NULL) {
        goto err_exit;
    }
    //av_log(avctx, AV_LOG_DEBUG, "frame ref count %d for %p\n", av_buffer_get_ref_count(out->buf[0]), out->buf[0]->data);
    out->hw_frames_ctx = av_buffer_ref(fb_dec_ctx->hwframe);
    if (out->hw_frames_ctx == NULL) {
        goto err_exit;
    }
    
    AddDecPicWaitConsumeList(fb_dec_ctx,pic);

    return 0;
err_exit:

    return -1;
}

void hantro_dec_performance_report(AVCodecContext *avctx)
{
  HantroDecContext *fb_dec_ctx  = avctx->priv_data;
  int i;
  char info_string[2048];
  
  if (fb_dec_ctx) {

#ifndef BUILD_CMODEL
      struct statistic dec_statistic = {0};
      dec_statistic.frame_count = fb_dec_ctx->pic_display_number;
      if (fb_dec_ctx->pic_display_number) {
        dec_statistic.cycle_mb_avg = fb_dec_ctx->cycle_count/fb_dec_ctx->pic_display_number;
        DWLGetCoreStatistic(fb_dec_ctx->dwl_inst, &dec_statistic.total_usage, &dec_statistic.core_usage_counts);
#ifdef FB_PERFORMANCE_STATIC
        dec_statistic.hw_real_time_avg = DWLGetHwPerformance(fb_dec_ctx->dwl_inst) / dec_statistic.frame_count;
        dec_statistic.hw_real_time_avg_remove_overlap = DWLGetHwPerformanceRemoveOverlap(fb_dec_ctx->dwl_inst) / dec_statistic.frame_count;
#endif
      }     
#endif

    sprintf(&info_string[0], ":::DEC    : %d frames, %d Cycles/MB, %d us/frame, %.2f fps",
                  dec_statistic.frame_count,
                  dec_statistic.cycle_mb_avg,
                  dec_statistic.hw_real_time_avg,
                  (dec_statistic.hw_real_time_avg == 0) ? 0.0 : 1000000.0/((double)dec_statistic.hw_real_time_avg));

    if (dec_statistic.hw_real_time_avg - dec_statistic.hw_real_time_avg_remove_overlap > 10) {
      sprintf(&info_string[strlen(info_string)], ", remove overlap : %d us/frame, %.2f fps",
                  dec_statistic.hw_real_time_avg_remove_overlap,
                  (dec_statistic.hw_real_time_avg_remove_overlap == 0) ? 0.0 : 1000000.0/((double)dec_statistic.hw_real_time_avg_remove_overlap));
    }

    av_log(avctx, AV_LOG_INFO, "%s\n", info_string);

    av_log(avctx, AV_LOG_INFO, ":::DEC Multi-core usage statistics:\n");
    
    if (dec_statistic.total_usage == 0) dec_statistic.total_usage = 1;
    for (i = 0; i < 4; i++) {
      av_log(avctx, AV_LOG_INFO, "\tSlice[%d] Core[%d] used %6d times (%2d%%)\n", i/2, i%2, dec_statistic.core_usage_counts[i],
             (dec_statistic.core_usage_counts[i] * 100) / dec_statistic.total_usage);
    }

#ifdef FB_SYSLOG_ENABLE
      HANTRO_DEC_INFO_PRINT("%s\n", info_string);
      HANTRO_DEC_INFO_PRINT(":::DEC Multi-core usage statistics:\n");
      for (i = 0; i < 4; i++) {
        HANTRO_DEC_INFO_PRINT("\tSlice[%d] Core[%d] used %6d times (%2d%%)\n", i/2, i%2, dec_statistic.core_usage_counts[i],
               (dec_statistic.core_usage_counts[i] * 100) / dec_statistic.total_usage);
      }

#endif    

  }
}

void hantro_dec_log_header_init(AVCodecContext *avctx)
{
    HantroDecContext *fb_dec_ctx  = avctx->priv_data;


#ifdef FB_SYSLOG_ENABLE
    static char module_name[] = "DEC";
    if(strlen(fb_dec_ctx->module_name))
        fb_dec_ctx->log_header.module_name = fb_dec_ctx->module_name;
    else
        fb_dec_ctx->log_header.module_name = module_name;
#ifdef DRV_NEW_ARCH
    fb_dec_ctx->log_header.device_id = get_deviceId(fb_dec_ctx->dev_name);
#else
    fb_dec_ctx->log_header.device_id = 0;
#endif
#endif
}

void report_dec_pic_info(AVCodecContext *avctx, struct DecPicturePpu *picture)
{
    HantroDecContext *fb_dec_ctx  = avctx->priv_data;
    char info_string[2048];
    static char* pic_types[] = {"        IDR", "Non-IDR (P)", "Non-IDR (B)"};

    sprintf(&info_string[0], "PIC %2d/%2d, type %s, ", fb_dec_ctx->pic_display_number,
           picture->pictures[0].picture_info.pic_id,
           pic_types[picture->pictures[0].picture_info.pic_coding_type]);
    if (picture->pictures[0].picture_info.cycles_per_mb) {
    //client->cycle_count += picture->pictures[0].picture_info.cycles_per_mb;
    sprintf(&info_string[strlen(info_string)], " %4d cycles / mb,", picture->pictures[0].picture_info.cycles_per_mb);
    }

    sprintf(&info_string[strlen(info_string)], " %d x %d, Crop: (%d, %d), %d x %d %s",
           picture->pictures[0].sequence_info.pic_width,
           picture->pictures[0].sequence_info.pic_height,
           picture->pictures[0].sequence_info.crop_params.crop_left_offset,
           picture->pictures[0].sequence_info.crop_params.crop_top_offset,
           picture->pictures[0].sequence_info.crop_params.crop_out_width,
           picture->pictures[0].sequence_info.crop_params.crop_out_height,
           picture->pictures[0].picture_info.is_corrupted ? "CORRUPT" : "");

    av_log(avctx, AV_LOG_DEBUG, "%s\n", info_string);
    HANTRO_DEC_INFO_PRINT("%s\n", info_string);
}


void InitDecPicWaitConsumeList(HantroDecContext *fb_dec_ctx)
{
    u32 i;
    pthread_mutex_init(&fb_dec_ctx->consume_mutex, NULL);
    
    pthread_mutex_lock(&fb_dec_ctx->consume_mutex);
    for (i = 0; i < MAX_WAIT_FOR_CONSUME_BUFFERS; i++) {
        fb_dec_ctx->wait_for_consume_list[i].pic = NULL;
        fb_dec_ctx->wait_for_consume_list[i].wait_for_consume = 0;
    }
    fb_dec_ctx->wait_consume_num = 0;
    pthread_mutex_unlock(&fb_dec_ctx->consume_mutex);
}

u32 FindDecPicWaitConsumeIndex(HantroDecContext *fb_dec_ctx,u8 *data) {
    u32 i;

    pthread_mutex_lock(&fb_dec_ctx->consume_mutex);
    for (i = 0; i < MAX_WAIT_FOR_CONSUME_BUFFERS; i++) {
        if (fb_dec_ctx->wait_for_consume_list[i].pic == data)
            break;
    }

    ASSERT(i < fb_dec_ctx->wait_consume_num);
    pthread_mutex_unlock(&fb_dec_ctx->consume_mutex);
    return i;
}

u32 FindDecPicWaitConsumeEmptyIndex(HantroDecContext *fb_dec_ctx) {
    u32 i;
    
    pthread_mutex_lock(&fb_dec_ctx->consume_mutex);    
    for (i = 0; i < MAX_WAIT_FOR_CONSUME_BUFFERS; i++) {
        if (fb_dec_ctx->wait_for_consume_list[i].wait_for_consume == 0)
        break;
    }

    ASSERT(i < MAX_WAIT_FOR_CONSUME_BUFFERS);    
    pthread_mutex_unlock(&fb_dec_ctx->consume_mutex);
    
    return i;
}

u32 AddDecPicWaitConsumeList(HantroDecContext *fb_dec_ctx, void *data) {
    
    u32 i;
    u32 id;
        
    id = FindDecPicWaitConsumeEmptyIndex(fb_dec_ctx);
    
    av_log(NULL, AV_LOG_DEBUG, "AddDecPicWaitConsumeList pic(@ %p) @ %d \n", data, id);
    
    pthread_mutex_lock(&fb_dec_ctx->consume_mutex);
    fb_dec_ctx->wait_for_consume_list[id].pic = (struct DecPicturePpu *)data;
    fb_dec_ctx->wait_for_consume_list[id].wait_for_consume = 1;
    if(fb_dec_ctx->wait_consume_num < MAX_WAIT_FOR_CONSUME_BUFFERS)
        fb_dec_ctx->wait_consume_num++;
    ASSERT(i < MAX_WAIT_FOR_CONSUME_BUFFERS);
    pthread_mutex_unlock(&fb_dec_ctx->consume_mutex);
    return i;
}

u32 DelDecPicWaitConsumeList(HantroDecContext *fb_dec_ctx, u8 *data) {
    
    u32 i;
    u32 id;
    id = FindDecPicWaitConsumeIndex(fb_dec_ctx,data);
    
    pthread_mutex_lock(&fb_dec_ctx->consume_mutex);
    if(id < MAX_WAIT_FOR_CONSUME_BUFFERS)
    {
        fb_dec_ctx->wait_for_consume_list[id].pic = NULL;
        fb_dec_ctx->wait_for_consume_list[id].wait_for_consume = 0;
        if(fb_dec_ctx->wait_consume_num > 0)
            fb_dec_ctx->wait_consume_num--;
        av_log(NULL, AV_LOG_DEBUG, "DelDecPicWaitConsumeList pic(@ %p) @ %d \n", data, id);
    }
    pthread_mutex_unlock(&fb_dec_ctx->consume_mutex);
    return i;
}

void FreeDecPicWaitConsumeList(HantroDecContext *fb_dec_ctx) {
    
    u32 i;
//    pthread_mutex_lock(&fb_dec_ctx->consume_mutex);
    for (i = 0; i < MAX_WAIT_FOR_CONSUME_BUFFERS; i++) {
        if (fb_dec_ctx->wait_for_consume_list[i].wait_for_consume == 1)
        {
            av_log(NULL, AV_LOG_DEBUG, "find pic(@ %p) @ %d NO consume ! when close, force consume  \n", fb_dec_ctx->wait_for_consume_list[i].pic, i);
            if(fb_dec_ctx->hantro_decode_picture_consume)
            fb_dec_ctx->hantro_decode_picture_consume(fb_dec_ctx,(u8 *)fb_dec_ctx->wait_for_consume_list[i].pic);
            fb_dec_ctx->wait_for_consume_list[i].wait_for_consume = 0;
            fb_dec_ctx->wait_for_consume_list[i].pic = NULL;
        }
    }
    fb_dec_ctx->wait_consume_num = 0;
//    pthread_mutex_unlock(&fb_dec_ctx->consume_mutex);
    
    pthread_mutex_destroy(&fb_dec_ctx->consume_mutex);
}

enum DecRet InitHantroDecDecodeWrapper(AVCodecContext *avctx,enum DecCodec codec)
{
    HantroDecContext *fb_dec_ctx  = avctx->priv_data;
    fb_dec_ctx->codec = codec;
    switch (codec) {
        case DEC_HEVC:
            fb_dec_ctx->hantro_dec_wrapper.init = HantroDecHevcInit;
            fb_dec_ctx->hantro_dec_wrapper.GetInfo = HantroDecHevcGetInfo;
            fb_dec_ctx->hantro_dec_wrapper.SetInfo = HantroDecHevcSetInfo;
            //fb_dec_ctx->hantro_dec_wrapper.Decode = HantroDecHevcDecode;
            fb_dec_ctx->hantro_dec_wrapper.NextPicture = HantroDecHevcNextPicture;
            fb_dec_ctx->hantro_dec_wrapper.PictureConsumed = HantroDecHevcPictureConsumed;
            fb_dec_ctx->hantro_dec_wrapper.EndOfStream = HantroDecHevcEndOfStream;
            fb_dec_ctx->hantro_dec_wrapper.Release = HantroDecHevcRelease;
            fb_dec_ctx->hantro_dec_wrapper.UseExtraFrmBuffers = HevcDecUseExtraFrmBuffers;
#ifdef USE_EXTERNAL_BUFFER
            fb_dec_ctx->hantro_dec_wrapper.GetBufferInfo = HantroDecHevcGetBufferInfo;
            fb_dec_ctx->hantro_dec_wrapper.AddBuffer = HantroDecHevcAddBuffer;
#endif
        break;
        case DEC_VP9:
            fb_dec_ctx->hantro_dec_wrapper.init = HantroDecVp9Init;
            fb_dec_ctx->hantro_dec_wrapper.GetInfo = HantroDecVp9GetInfo;
            fb_dec_ctx->hantro_dec_wrapper.SetInfo = HantroDecVp9SetInfo;
            //fb_dec_ctx->hantro_dec_wrapper.Decode = HantroDecVp9Decode;
            fb_dec_ctx->hantro_dec_wrapper.NextPicture = HantroDecVp9NextPicture;
            fb_dec_ctx->hantro_dec_wrapper.PictureConsumed = HantroDecVp9PictureConsumed;
            fb_dec_ctx->hantro_dec_wrapper.EndOfStream = HantroDecVp9EndOfStream;
            fb_dec_ctx->hantro_dec_wrapper.Release = HantroDecVp9Release;
            fb_dec_ctx->hantro_dec_wrapper.UseExtraFrmBuffers = Vp9DecUseExtraFrmBuffers;
#ifdef USE_EXTERNAL_BUFFER
            fb_dec_ctx->hantro_dec_wrapper.GetBufferInfo = HantroDecVp9GetBufferInfo;
            fb_dec_ctx->hantro_dec_wrapper.AddBuffer = HantroDecVp9AddBuffer;
#endif
        break;

        case DEC_H264_H10P:
            fb_dec_ctx->hantro_dec_wrapper.init = HantroDecH264Init;
            fb_dec_ctx->hantro_dec_wrapper.GetInfo = HantroDecH264GetInfo;
            fb_dec_ctx->hantro_dec_wrapper.SetInfo = HantroDecH264SetInfo;
            //fb_dec_ctx->hantro_dec_wrapper.Decode = HantroDecH264Decode;
            fb_dec_ctx->hantro_dec_wrapper.NextPicture = HantroDecH264NextPicture;
            fb_dec_ctx->hantro_dec_wrapper.PictureConsumed = HantroDecH264PictureConsumed;
            fb_dec_ctx->hantro_dec_wrapper.EndOfStream = HantroDecH264EndOfStream;
            fb_dec_ctx->hantro_dec_wrapper.Release = HantroDecH264Release;
            fb_dec_ctx->hantro_dec_wrapper.UseExtraFrmBuffers = H264DecUseExtraFrmBuffers;
#ifdef USE_EXTERNAL_BUFFER
            fb_dec_ctx->hantro_dec_wrapper.GetBufferInfo = HantroDecH264GetBufferInfo;
            fb_dec_ctx->hantro_dec_wrapper.AddBuffer = HantroDecH264AddBuffer;
#endif
        break;

        default:
        return DEC_FORMAT_NOT_SUPPORTED;
    }
      return DEC_OK;
}

void HantroDecSetDefaultDecconfig(AVCodecContext *avctx,enum DecCodec codec)
{
    HantroDecContext *fb_dec_ctx  = avctx->priv_data;
    
    if(codec == DEC_H264_H10P)
    {
        fb_dec_ctx->hantro_dec_config.mc_cfg.mc_enable = 1;
        fb_dec_ctx->hantro_dec_config.mc_cfg.stream_consumed_callback = NULL;
        fb_dec_ctx->hantro_dec_config.use_ringbuffer = 0;
    }
    else
    {
        fb_dec_ctx->hantro_dec_config.mc_cfg.mc_enable = 0;
        fb_dec_ctx->hantro_dec_config.mc_cfg.stream_consumed_callback = NULL;
        fb_dec_ctx->hantro_dec_config.use_ringbuffer = 1;

    }
    fb_dec_ctx->hantro_dec_config.disable_picture_reordering = 0;
    fb_dec_ctx->hantro_dec_config.concealment_mode = DEC_EC_FAST_FREEZE;
    fb_dec_ctx->hantro_dec_config.align = DEC_ALIGN_1024B;
    fb_dec_ctx->hantro_dec_config.decoder_mode = DEC_NORMAL;
    fb_dec_ctx->hantro_dec_config.tile_by_tile = 0;
    fb_dec_ctx->hantro_dec_config.fscale_cfg.fixed_scale_enabled = 0;
    fb_dec_ctx->hantro_dec_config.use_video_compressor = 1;
    

    
//    memcpy(fb_dec_ctx->hantro_dec_config.ppu_cfg, client->test_params.ppu_cfg, sizeof(config.ppu_cfg));
    fb_dec_ctx->hantro_dec_config.max_num_pics_to_decode = 0;
    fb_dec_ctx->hantro_dec_config.output_format = DEC_OUT_FRM_TILED_4X4;
    fb_dec_ctx->hantro_dec_config.use_8bits_output = 0;
    fb_dec_ctx->hantro_dec_config.use_bige_output = 0;    
    fb_dec_ctx->hantro_dec_config.use_p010_output = 0;   

}

static int split_string(char ** tgt, int max, char * src, char * split)
{
  int count;
  char * currp;
  char * p;
  char c;
  int i;
  int last;

  //printf("string is %s\n", src);
  //printf("split is %s\n", split);

  currp = src;
  count = 0;
  i = 0;
  last = 0;
  while ((c = *currp++) != '\0') {
    if ((p = strchr(split, c)) == NULL) {
      if (count < max) {
        tgt[count][i++] = c;
        //printf("%d %d %c\n", count, i-1, c);
      } else {
        av_log(NULL,AV_LOG_DEBUG,"the split count exceeds max num\n");
        return -1;
      }
      last = 1; // 1 means non split char, 0 means split char
    } else {
      if (last == 1) {
        tgt[count][i] = '\0';
        //printf("split %d: %s\n", count, &tgt[count][0]);
        count++;
        i = 0;
      }
      last = 0; // 1 means non split char, 0 means split char
    }
  }
  if (last == 1) {
    tgt[count][i] = '\0';
    //printf("split %d: %s\n", count, &tgt[count][0]);
    count++;
  }

  return count;
}

int HantroDecParseResize(AVCodecContext *avctx)
{
  int i, j;
#define MAX_SEG_NUM 4
  char strs[MAX_SEG_NUM][256];
  char * pstrs[MAX_SEG_NUM];
  int seg_num = 0;
  char * p, * ep, *cp;
  int output_num = 0;
  char * resize_str;

  HantroDecContext *fb_dec_ctx  = avctx->priv_data;

  for (i = 0; i < MAX_SEG_NUM; i++) {
    pstrs[i] = &strs[i][0];
  }

  if (fb_dec_ctx->pp_setting) {
    av_log(avctx,AV_LOG_DEBUG,"fb_dec_ctx->pp_setting: %s\n", fb_dec_ctx->pp_setting);
    seg_num = split_string(&pstrs, MAX_SEG_NUM, fb_dec_ctx->pp_setting, ":");
    if (seg_num == 2) {
      output_num = atoi(pstrs[0]);
      resize_str = pstrs[1];
    } else {
      av_log(avctx, AV_LOG_ERROR, "resizes syntax error!\n");
      return -1;
    }
  }

  if (resize_str) {
    av_log(avctx,AV_LOG_DEBUG,"resize_str: %s\n", resize_str);
    seg_num = split_string(&pstrs, MAX_SEG_NUM, resize_str, "()");
    if (seg_num <= 0) {
      av_log(avctx,AV_LOG_ERROR,"can't find resize info!\n");
      return -1;
    }
  }

  fb_dec_ctx->resize_num = 0;
  while (fb_dec_ctx->resize_num < seg_num) 
  {
    cp = strs[fb_dec_ctx->resize_num];
    av_log(avctx,AV_LOG_DEBUG,"cp: %s\n", cp);
    if ((p = strchr(cp, ',')) != NULL) {
      fb_dec_ctx->resizes[fb_dec_ctx->resize_num].x = atoi(cp);
      cp = p + 1;
      av_log(avctx,AV_LOG_DEBUG,"cp: %s\n", cp);
      if ((p = strchr(cp, ',')) != NULL) {
        fb_dec_ctx->resizes[fb_dec_ctx->resize_num].y = atoi(cp);
        cp = p + 1;
        av_log(avctx,AV_LOG_DEBUG,"cp: %s\n", cp);
        if ((p = strchr(cp, ',')) != NULL) {
          fb_dec_ctx->resizes[fb_dec_ctx->resize_num].cw = atoi(cp);
          fb_dec_ctx->resizes[fb_dec_ctx->resize_num].ch = atoi(p+1);
          cp = p + 1;
          av_log(avctx,AV_LOG_DEBUG,"cp: %s\n", cp);
          if ((p = strchr(cp, ',')) != NULL) {
            cp = p + 1;
            av_log(avctx,AV_LOG_DEBUG,"cp: %s\n", cp);
          } else if (fb_dec_ctx->resize_num != 0) {
            return -1;
          }
        } else {
          return -1;
        }
      } else {
        return -1;
      }
    }
    if ((p = strchr(cp, 'x')) == NULL) {
      if (cp[0] == 'd') {
        int n = atoi(cp+1);
        if (n != 2 && n != 4 && n != 8) {
          av_log(avctx,AV_LOG_DEBUG,"only support d2/d4/d8!\n");
          return -1;
        }
        fb_dec_ctx->resizes[fb_dec_ctx->resize_num].sw = -n;
        fb_dec_ctx->resizes[fb_dec_ctx->resize_num].sh = -n;
      } else if (fb_dec_ctx->resize_num != 0) {
        av_log(avctx,AV_LOG_DEBUG,"can't find swxsh or dn!\n");
        return -1;
      }
    } else {
      fb_dec_ctx->resizes[fb_dec_ctx->resize_num].sw = atoi(cp);
      fb_dec_ctx->resizes[fb_dec_ctx->resize_num].sh = atoi(p+1);
    }
    if (fb_dec_ctx->resizes[fb_dec_ctx->resize_num].sw == -1 && fb_dec_ctx->resizes[fb_dec_ctx->resize_num].sh == -1) {
      av_log(avctx,AV_LOG_DEBUG,"resize -1x-1 error!\n");
      return -1;
    }
    av_log(avctx,AV_LOG_DEBUG,"get resize %d %d,%d,%d,%d,%dx%d\n", fb_dec_ctx->resize_num,
            fb_dec_ctx->resizes[fb_dec_ctx->resize_num].x,
            fb_dec_ctx->resizes[fb_dec_ctx->resize_num].y,
            fb_dec_ctx->resizes[fb_dec_ctx->resize_num].cw,
            fb_dec_ctx->resizes[fb_dec_ctx->resize_num].ch,
            fb_dec_ctx->resizes[fb_dec_ctx->resize_num].sw,
            fb_dec_ctx->resizes[fb_dec_ctx->resize_num].sh);
    fb_dec_ctx->resize_num++;
  }  

  if (output_num < 1 || output_num > 4) {
    av_log(avctx, AV_LOG_ERROR, "outputs number error\n");
    return -1;
  }

  if (output_num == 1 && fb_dec_ctx->resize_num == 1 
      && (fb_dec_ctx->resizes[0].x == 0 &&
          fb_dec_ctx->resizes[0].y == 0 &&
          fb_dec_ctx->resizes[0].cw == 0 &&
          fb_dec_ctx->resizes[0].ch == 0 &&
          fb_dec_ctx->resizes[0].sw == -2 &&
          fb_dec_ctx->resizes[0].sh == -2)) {

    fb_dec_ctx->vce_ds_enable = 1;
    
    fb_dec_ctx->resizes[1] = fb_dec_ctx->resizes[0];
    
    fb_dec_ctx->resizes[0].x =
    fb_dec_ctx->resizes[0].y =
    fb_dec_ctx->resizes[0].cw =
    fb_dec_ctx->resizes[0].ch = 
    fb_dec_ctx->resizes[0].sw =
    fb_dec_ctx->resizes[0].sh = 0;
    
    fb_dec_ctx->resize_num++;
    
  } else if (output_num == 1 && fb_dec_ctx->resize_num == 2) {
    
    if (!(fb_dec_ctx->resizes[0].x == fb_dec_ctx->resizes[1].x &&
          fb_dec_ctx->resizes[0].y == fb_dec_ctx->resizes[1].y &&
          fb_dec_ctx->resizes[0].cw == fb_dec_ctx->resizes[1].cw &&
          fb_dec_ctx->resizes[0].ch == fb_dec_ctx->resizes[1].ch &&
          fb_dec_ctx->resizes[1].sw == -2 &&
          fb_dec_ctx->resizes[1].sh == -2)) {
      av_log(avctx,AV_LOG_ERROR,"resize param error!\n");
      return -1;
    }
    fb_dec_ctx->vce_ds_enable = 1;
  
  } else if (output_num == fb_dec_ctx->resize_num + 1) {
    
    if (fb_dec_ctx->resize_num) {
      for (i = output_num - 1; i > 0; i--) {
        fb_dec_ctx->resizes[i] = fb_dec_ctx->resizes[i-1];
      }
    }
    fb_dec_ctx->resizes[0].x =
    fb_dec_ctx->resizes[0].y =
    fb_dec_ctx->resizes[0].cw =
    fb_dec_ctx->resizes[0].ch = 
    fb_dec_ctx->resizes[0].sw =
    fb_dec_ctx->resizes[0].sh = 0;

    fb_dec_ctx->resize_num++;
    
  } else if (output_num != fb_dec_ctx->resize_num) {
    av_log(avctx, AV_LOG_ERROR, "resize param error!\n");
    return -1;
  }

  if ((fb_dec_ctx->resizes[0].sw || fb_dec_ctx->resizes[0].sh)
    && (fb_dec_ctx->resizes[0].sw != fb_dec_ctx->resizes[0].cw
        || fb_dec_ctx->resizes[0].sh != fb_dec_ctx->resizes[0].ch)) {
    av_log(avctx, AV_LOG_ERROR, "resize channel 0 do not support scale!\n");
    return -1;
  }

  return 0;
}

int hantro_dec_init_hwctx(AVCodecContext *avctx)
{
    int ret=0;
    AVHANTRODeviceContext *device_hwctx;
    AVHANTROFramesContext *frame_hwctx;
    AVHWDeviceContext *device_ctx;
    AVHWFramesContext *hwframe_ctx;
    HantroDecContext *fb_dec_ctx = avctx->priv_data;

    if (avctx->hw_frames_ctx) {
        fb_dec_ctx->hwframe = av_buffer_ref(avctx->hw_frames_ctx);
        if (!fb_dec_ctx->hwframe) {
            ret = AVERROR(ENOMEM);
            goto error;
        }

        hwframe_ctx = (AVHWFramesContext*)fb_dec_ctx->hwframe->data;

        fb_dec_ctx->hwdevice = av_buffer_ref(hwframe_ctx->device_ref);
        if (!fb_dec_ctx->hwdevice) {
            ret = AVERROR(ENOMEM);
            goto error;
        }
    } else {
        av_log(avctx, AV_LOG_TRACE, "%s(%d) avctx->hw_device_ctx = %p\n", __FUNCTION__, __LINE__, avctx->hw_device_ctx);
        if (avctx->hw_device_ctx) {
            fb_dec_ctx->hwdevice = av_buffer_ref(avctx->hw_device_ctx);
            av_log(avctx, AV_LOG_TRACE, "%s(%d) fb_dec_ctx->hwdevice = %p\n", __FUNCTION__, __LINE__, fb_dec_ctx->hwdevice);
            if (!fb_dec_ctx->hwdevice) {
                ret = AVERROR(ENOMEM);
                goto error;
            }
        } else {
            ret = av_hwdevice_ctx_create(&fb_dec_ctx->hwdevice, AV_HWDEVICE_TYPE_HANTRO, fb_dec_ctx->dev_name, NULL, 0);
            if (ret < 0)
                return ret;
        }

        fb_dec_ctx->hwframe = av_hwframe_ctx_alloc(fb_dec_ctx->hwdevice);
        if (!fb_dec_ctx->hwframe) {
            av_log(avctx, AV_LOG_ERROR, "av_hwframe_ctx_alloc failed\n");
            ret = AVERROR(ENOMEM);
            goto error;
        }

        hwframe_ctx = (AVHWFramesContext*)fb_dec_ctx->hwframe->data;
    }

    if (!hwframe_ctx->pool) {
        if((avctx->width == 0) || (avctx->height == 0))
        {
            avctx->sw_pix_fmt = -1;
            avctx->width = 3840;
            avctx->height = 2160;
        }
        hwframe_ctx->format = AV_PIX_FMT_HANTRO;
        hwframe_ctx->sw_format = avctx->sw_pix_fmt;
        hwframe_ctx->width = avctx->width;
        hwframe_ctx->height = avctx->height;

        if ((ret = av_hwframe_ctx_init(fb_dec_ctx->hwframe)) < 0) {
            av_log(avctx, AV_LOG_ERROR, "av_hwframe_ctx_init failed\n");
            goto error;
        }
    }
    return 0;
error:
    av_log(avctx, AV_LOG_ERROR, "av_hwframe_ctx_init failed\n");
    return ret;
    
}

int hantro_send_avpkt_to_decode_buffer(AVCodecContext *avctx, AVPacket *avpkt, struct DWLLinearMem stream_buffer)
{    
    HantroDecContext *fb_dec_ctx  = avctx->priv_data;

    int ret = 0;

#ifdef	NEW_MEM_ALLOC
    if (avpkt->data) {
        ret = dwl_edma_rc2ep_nolink(fb_dec_ctx->dwl_inst, avpkt->data, stream_buffer.bus_address, avpkt->size);
    }
#endif

    return ret;
}

static int hantro_dec_find_empty_index(HantroDecContext *dec_ctx)
{
    int i;
    
    for (i = 0; i < MAX_BUFFERS; i++) {
        if (dec_ctx->ext_buffers[i].bus_address == 0)
            break;
    }

    if (i >= MAX_BUFFERS)
        return -1;
    
    return i;
}

static int hantro_dec_find_buffer_index(HantroDecContext *dec_ctx, u32 *addr)
{
    int i;
    
    for (i = 0; i < dec_ctx->num_buffers; i++) {
        if (dec_ctx->ext_buffers[i].bus_address == addr)
            break;
    }

    if (i >= dec_ctx->num_buffers)
        return -1;
    
    return i;
}

//adding extra buffer to decoder dynamically
static int hantro_add_extra_buffer_to_decoder(HantroDecContext *dec_ctx, int nb_frames, u32 buffer_size)
{
    enum DecRet rv;
    int i;
    int nb_ext_buf;
    
    if (nb_frames > dec_ctx->num_buffers) {
        
        nb_ext_buf = nb_frames - dec_ctx->num_buffers;
    
        if (buffer_size) {

            //dec_ctx->buffer_size = buffer_size;
            av_log(dec_ctx, AV_LOG_DEBUG, "buffer size %d\n", buffer_size);

            //nb_ext_buf += buf_info.buf_num;
            av_log(dec_ctx, AV_LOG_DEBUG, "nb_ext_buf = %d\n", nb_ext_buf);
        
            for (i = 0; i < nb_ext_buf; i++) {
                struct DWLLinearMem mem;
                i32 ret;
            
                mem.mem_type = DWL_MEM_TYPE_DPB;
                ret = DWLMallocLinear(dec_ctx->dwl_inst, buffer_size, &mem);
                if (ret) {
                    av_log(dec_ctx, AV_LOG_DEBUG, "DWLMallocLinear ret %d\n", ret);
                    goto err_exit;
                }
                rv = dec_ctx->hantro_dec_wrapper.AddBuffer(dec_ctx->dec_inst, &mem);
                if (rv != DEC_OK && rv != DEC_WAITING_FOR_BUFFER) {
                    DWLFreeLinear(dec_ctx->dwl_inst, &mem);
                } else {
                    int id;
                    
                    id = hantro_dec_find_empty_index(dec_ctx);
                    av_log(dec_ctx, AV_LOG_DEBUG, "find id %d\n", id);
                    if (id < 0) {
                        goto err_exit;
                    }
                    dec_ctx->ext_buffers[id] = mem;
                    //dec_ctx->buffer_consumed[id] = 1;
                    if (id >= dec_ctx->num_buffers)
                        dec_ctx->num_buffers++;
                }
            }
        }
    }

    return 0;
    
err_exit:

    return AVERROR(ENOMEM);
}


int hantro_check_buffer_number_for_trans(HantroDecContext *dec_ctx)
{
    AVHWFramesContext *hwframe_ctx;
    AVHWDeviceContext *device_ctx;
    AVHANTRODeviceContext *device_hwctx;
    int nb_frames;
    struct DecBufferInfo buf_info;
    enum DecRet rv;

    av_log(dec_ctx, AV_LOG_DEBUG, "get into %s\n", __FUNCTION__);
    
    hwframe_ctx = (AVHWFramesContext*)dec_ctx->hwframe->data;
    device_ctx = hwframe_ctx->device_ctx;
    device_hwctx = device_ctx->hwctx;
    nb_frames = device_hwctx->max_frames_delay;
    
    rv = dec_ctx->hantro_dec_wrapper.GetBufferInfo(dec_ctx->dec_inst, &buf_info);

    av_log(dec_ctx, AV_LOG_DEBUG, "GetBufferInfo ret %d\n", rv);
    av_log(dec_ctx, AV_LOG_DEBUG, "buf_to_free %p, next_buf_size %d, buf_num %d\n",
            buf_info.buf_to_free.virtual_address, buf_info.next_buf_size, buf_info.buf_num);
    
    if (rv == DEC_WAITING_FOR_BUFFER && buf_info.buf_to_free.bus_address) {
        av_log(dec_ctx, AV_LOG_DEBUG, "to free buffer\n");
        DWLFreeLinear(dec_ctx->dwl_inst, &buf_info.buf_to_free);
        int id = hantro_dec_find_buffer_index(dec_ctx, buf_info.buf_to_free.bus_address);
        if (id < 0) {
            goto err_exit;
        }
        av_log(dec_ctx, AV_LOG_DEBUG, "to clean buffer info\n");
        dec_ctx->ext_buffers[id].virtual_address = NULL;
        dec_ctx->ext_buffers[id].bus_address = 0;
        if (id == dec_ctx->num_buffers - 1)
            dec_ctx->num_buffers--;
    }
    if (buf_info.buf_num + nb_frames > dec_ctx->num_buffers) {
        return hantro_add_extra_buffer_to_decoder(dec_ctx, buf_info.buf_num + nb_frames, buf_info.next_buf_size);
    }

    return 0;

err_exit:
    return AVERROR(ENOMEM);
}

void hantro_dec_release_ext_buffers(HantroDecContext *dec_ctx)
{
    int i;
    
    //pthread_mutex_lock(&fb_dec_ctx->ext_buffer_contro);
    for (i = 0; i < dec_ctx->num_buffers; i++) {
        av_log(NULL, AV_LOG_DEBUG, "Freeing buffer %d\n", i);
        DWLFreeLinear(dec_ctx->dwl_inst, &dec_ctx->ext_buffers[i]);
        DWLmemset(&dec_ctx->ext_buffers[i], 0, sizeof(dec_ctx->ext_buffers[i]));
    }
    //pthread_mutex_unlock(&fb_dec_ctx->ext_buffer_contro);
}

int hantro_set_buffer_number_for_trans(AVCodecContext *avctx)
{    
    HantroDecContext *fb_dec_ctx  = avctx->priv_data;
    int ret = 0;

    if (fb_dec_ctx->buffer_depth > 40)
    {
        av_log(avctx, AV_LOG_ERROR, "%s %d SHOULED set buffer-depth for transcode [0,40]\n",__func__,__LINE__);
        return -1;
    }
    
    if ((fb_dec_ctx->enc_type == HANTRO_ENC_VP9) && (fb_dec_ctx->buffer_depth > 25))
    {
        av_log(avctx, AV_LOG_ERROR,"when transoode to vp9 buffer_depth(%d) should <= 25 !\n", fb_dec_ctx->buffer_depth);
        return -1;
    }
    else if (fb_dec_ctx->enc_type == HANTRO_ENC_H264)
    {
        if((fb_dec_ctx->dwl_init.priority  == 0) && (fb_dec_ctx->buffer_depth > 20))//live
        {
            av_log(avctx, AV_LOG_ERROR,"Max lookaheadDepth is %d, and it's not suitable for \"LIVE\"!\n", fb_dec_ctx->buffer_depth);
            return -1;
        }
    }

    if (fb_dec_ctx->enc_type == HANTRO_ENC_VP9) {
        if(fb_dec_ctx->buffer_depth < 2)
        {
            fb_dec_ctx->use_extra_buffers_num = 10+4;
        }
        else
        {
            fb_dec_ctx->use_extra_buffers_num = 12 + fb_dec_ctx->buffer_depth;
        }
    } else if (fb_dec_ctx->enc_type == HANTRO_ENC_NONE) {
        fb_dec_ctx->use_extra_buffers_num = 0;
    } else {
        if (fb_dec_ctx->buffer_depth == 0)
            fb_dec_ctx->use_extra_buffers_num = 8+2+8; //8+2;
        else
            fb_dec_ctx->use_extra_buffers_num = 17 + fb_dec_ctx->buffer_depth;
    }    
    
    av_log(avctx, AV_LOG_DEBUG, "%s %d fb_dec_ctx->buffer_depth=%d, fb_dec_ctx->use_extra_buffers_num=%d \n",__func__,__LINE__,fb_dec_ctx->buffer_depth,fb_dec_ctx->use_extra_buffers_num);

    return 0;
}

int hantro_check_enc_format_for_trans(AVCodecContext *avctx)
{    
    HantroDecContext *fb_dec_ctx  = avctx->priv_data;

    if (strcmp(fb_dec_ctx->enc_format, "") == 0) {
        //decoder only
        fb_dec_ctx->enc_type = HANTRO_ENC_NONE;
        //fb_dec_ctx->vce_ds_enable = 0;
        fb_dec_ctx->disable_dec400 = 1;
        fb_dec_ctx->disable_dtrc = 1;
        return 0;
    } else if (strcmp(fb_dec_ctx->enc_format, "h264") == 0) {
        fb_dec_ctx->enc_type = HANTRO_ENC_H264;
        //fb_dec_ctx->vce_ds_enable = 0;
        fb_dec_ctx->disable_dec400 = 0;
        fb_dec_ctx->disable_dtrc = 0;
        return 0;
#if 0
    } else if (strcmp(fb_dec_ctx->enc_format, "h264_ds") == 0) {
        fb_dec_ctx->enc_type = HANTRO_ENC_H264;
        fb_dec_ctx->vce_ds_enable = 1;
        fb_dec_ctx->disable_dec400 = 0;
        fb_dec_ctx->disable_dtrc = 0;
        return 0;
#endif
    } else if (strcmp(fb_dec_ctx->enc_format, "hevc") == 0) {
        fb_dec_ctx->enc_type = HANTRO_ENC_HEVC;
        //fb_dec_ctx->vce_ds_enable = 0;
        fb_dec_ctx->disable_dec400 = 0;
        fb_dec_ctx->disable_dtrc = 0;
        return 0;
#if 0
    } else if (strcmp(fb_dec_ctx->enc_format, "hevc_ds") == 0) {
        fb_dec_ctx->enc_type = HANTRO_ENC_HEVC;
        fb_dec_ctx->vce_ds_enable = 1;
        fb_dec_ctx->disable_dec400 = 0;
        fb_dec_ctx->disable_dtrc = 0;
        return 0;
#endif
    } else if (strcmp(fb_dec_ctx->enc_format, "vp9") == 0) {
        fb_dec_ctx->enc_type = HANTRO_ENC_VP9;
        //fb_dec_ctx->vce_ds_enable = 0;
        fb_dec_ctx->disable_dec400 = 0;
        fb_dec_ctx->disable_dtrc = 0;
        return 0;
    }

    av_log(avctx, AV_LOG_ERROR, "enc_format illegal: \"%s\"\n", fb_dec_ctx->enc_format);
    return -1;
}


#define OFFSET(x) offsetof(HantroDecContext, x)
#define VD AV_OPT_FLAG_VIDEO_PARAM | AV_OPT_FLAG_DECODING_PARAM
const AVOption hantro_decode_options[] = {
    { "resizes", "set output number and at most four output resizes configuration", OFFSET(pp_setting), AV_OPT_TYPE_STRING, {.str=NULL}, 0, 0, VD },
    { "dev", "set device name", OFFSET(dev_name), AV_OPT_TYPE_STRING, {.str=NULL}, 0, 0, VD },
    { "enc-format", "give the target format in encode, h264 hevc or vp9", OFFSET(enc_format), AV_OPT_TYPE_STRING, {.str=NULL}, 0, 0, VD },
    //{ "buffer-depth", "bufffer depth for transcode", OFFSET(buffer_depth), AV_OPT_TYPE_INT, {.i64 = 0}, 0, 40, VD },
#if defined(ERROR_TEST_DEC_EDMA_TRANS) || defined(ERROR_TEST_DEC_EDMA_TRANS)
    { "mem-error-test", "memory alloc error test", OFFSET(mem_err_test), AV_OPT_TYPE_INT, {.i64 = 0}, 0, INT64_MAX, VD },
#endif
    { NULL },
};

