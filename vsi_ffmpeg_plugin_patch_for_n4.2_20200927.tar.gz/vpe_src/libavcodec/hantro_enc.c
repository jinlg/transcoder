
#include "base_type.h"
#include "error.h"
#include "hevcencapi.h"
#include "encasiccontroller.h"
#include "instance.h"
#include "encinputlinebuffer.h"
#include "enccommon.h"

#ifdef SUPPORT_TCACHE
#ifdef USE_OLD_DRV
#include "edma_api.h"
#endif
#include "tcache_api.h"
#include "dtrc_api.h"
#endif
#ifndef USE_OLD_DRV
#include "fb_ips.h"
#include "trans_edma_api.h"
#ifdef DRV_NEW_ARCH
#include "transcoder.h"
#include <fcntl.h>
#include <sys/ioctl.h>
#else
#include "trans_edma.h"
#endif
#endif

#ifdef FB_SYSLOG_ENABLE
#include "syslog_sink.h"
#endif

#include "libavutil/avassert.h"
#include "libavutil/common.h"
#include "libavutil/internal.h"
#include "libavutil/opt.h"
#include "libavutil/pixfmt.h"
#include "libavutil/imgutils.h"
#include "libavcodec/avcodec.h"
#include "libavutil/hwcontext_hantro.h"

#include "hantro_enc_options.h"
#include "hantro_enc_pic_config.h"
#include "hantro_enc_utils.h"
#include "hantro_enc.h"
#include "hantro_h26xenc.h"

#include "NetSender.h"
#include "ewl.h"
#include "trans_mem_api.h"

#define MAX_GOP_LEN 300

static int IDRPocArrayInit(HANTROH26xEncContext *ctx);
static int OpenEncoder(HANTROH26xEncOptions *options, VCEncInst *pEnc, struct test_bench *tb);
static void CloseEncoder(VCEncInst encoder, struct test_bench *tb);
static int AllocRes(HANTROH26xEncOptions *cmdl, VCEncInst enc, struct test_bench *tb);
static void FreeRes(VCEncInst enc, struct test_bench *tb);
static void HEVCSliceReady(VCEncSliceReady *slice);
static i32 CheckArea(VCEncPictureArea *area, HANTROH26xEncOptions *options);
static i32 InitInputLineBuffer(inputLineBufferCfg * lineBufCfg, HANTROH26xEncOptions * options, VCEncIn * encIn, VCEncInst inst, struct test_bench *tb);
static void EncStreamSegmentReady(void *cb_data);

static int hantro_trans_pic_flush_send(AVCodecContext *avctx, int poc_need, HANTRO_ENC_IN_ADDR_t *pAddrs, int64_t *pts);
static void hantro_consume_flush(AVCodecContext *avctx);
static void HantroVCEReport(AVCodecContext *avctx);
static void hantro_rest_data_check(AVCodecContext *avctx);
static int wait_enc_thread_finish(AVCodecContext *avctx);

#ifdef VCE_MEM_ERR_TEST
int VceMemoryCheck(HANTROH26xEncOptions *opts)
{
    struct test_bench * tb = NULL;
    int ret = 0;
    if(opts->vce_memory_err_cnt++ == opts->vce_memory_err_shadow){
        ENC_TB_ERROR_PRINT("memory_err_cnt %d, vce_mem_err_test %d\n", opts->vce_memory_err_cnt, opts->vce_memory_err_shadow);
        ENC_TB_ERROR_PRINT("force malloc memory error!!!\n");
        ret = -1;
    }
    return ret;
}
#endif

#ifdef VCE_EDMA_ERR_TEST
int VceEDMAErrCheck(HANTROH26xEncOptions *opts)
{
    struct test_bench * tb = NULL;
    int ret = 0;
    if(opts->vce_edma_err_cnt++ == opts->vce_edma_err_shadow){
        ENC_TB_ERROR_PRINT("edma_err_cnt %d, vce_edma_err_test %d\n", opts->vce_edma_err_cnt, opts->vce_edma_err_shadow);
        ENC_TB_ERROR_PRINT("force edma transfer error!!!\n");
        ret = -1;
    }
    return ret;
}
#endif

static int vce_get_res_index(int w, int h)
{
  if (w * h >= 3840*2160) {
    return 6;
  } else if (w * h >= 1920*1080) {
    return 5;
  } else if (w * h >= 1280*720) {
    return 4;
  } else if (w * h >= 854*480) {
    return 3;
  } else if (w * h >= 640*360) {
    return 2;
  } else if (w * h >= 428*240) {
    return 1;
  }
  return 0;
}

i32 vce_default_bitrate[] = {
  100000,
  250000,
  500000,
  1000000,
  3000000,
  5000000,
  10000000
};
  
av_cold int hantro_encode_uninit( AVCodecContext *avctx )
{
  HANTROH26xEncContext * ctx = (HANTROH26xEncContext *)avctx->priv_data;
  struct test_bench * tb = (struct test_bench *)&ctx->tb;

  av_log(avctx, AV_LOG_DEBUG, "%s [%d]\n", __FUNCTION__, tb->enc_index);

  if ((ctx->EncProcessTerm == HANTRO_TRUE) || (ctx->flushState != HANTRO_FLUSH_ENCEND)) {
    ctx->flushState = HANTRO_FLUSH_ENCEND;
    SendEosToEnc(ctx->hantro_encoder);
  }

  wait_enc_thread_finish(avctx); //???
  
  if (ctx->hantro_encoder) {
    HantroVCEReport(avctx);
    hantro_consume_flush(avctx);
    vce_fifo_release(ctx->hantro_encoder);
    FreeRes(ctx->hantro_encoder, tb);
    CloseEncoder(ctx->hantro_encoder, tb);
  }

  av_packet_free(&ctx->outPkt);

  pthread_mutex_destroy(&ctx->rcv_packet_mutex);
  for (int i = 0; i < MAX_WAIT_DEPTH; i++) {
    av_frame_free(&ctx->PicWaitForEnc[i].trans_pic);
    pthread_mutex_destroy(&ctx->PicWaitForEnc[i].trans_mutex);
  }
  //Fifo_release(avctx);

  av_packet_free(&ctx->outPkt);

  av_buffer_unref(&ctx->hwframe);
  av_buffer_unref(&ctx->hwdevice);

#if defined(VCE_MEM_ERR_TEST) && defined(VCE_EDMA_ERR_TEST)
  ENC_TB_ERROR_PRINT("vce err_test, vce_memory_err_cnt %d, vce_edma_err_cnt %d, vce_memory_err_shadow %d, vce_edma_err_shadow %d\n",
        ctx->options.vce_memory_err_cnt, ctx->options.vce_edma_err_cnt, ctx->options.vce_memory_err_shadow, ctx->options.vce_edma_err_shadow);
#endif

  //av_packet_free((AVPacket *)&ctx->outPkt);
  return 0;
}

static av_cold int hantro_encode_get_options(AVCodecContext *avctx)
{
  HANTROH26xEncContext * ctx = (HANTROH26xEncContext *)avctx->priv_data;
  HANTROH26xEncOptions * options = &ctx->options;
  struct test_bench * tb = (struct test_bench *)&ctx->tb;

  /* set other default params */
  if (options->intraQpDelta == DEFAULT_VALUE)
    options->intraQpDelta = DEFAULT_VALUE;
  if (options->qpHdr == DEFAULT_VALUE)
    options->qpHdr = DEFAULT_VALUE;
  if (options->picRc == DEFAULT_VALUE)
    options->picRc = DEFAULT_VALUE;
  if (options->ctbRc == DEFAULT_VALUE)
    options->ctbRc = DEFAULT_VALUE;
      
  if (options->rdoLevel == DEFAULT)
    options->rdoLevel = 1;
  if (options->gopSize == DEFAULT)
    options->gopSize = 0;
  if (options->lookaheadDepth == DEFAULT)
    options->lookaheadDepth = 0;
  
  if (options->lookaheadDepth) {
    options->roiMapDeltaQpEnable = 1;
    options->roiMapDeltaQpBlockUnit = MAX(1, options->roiMapDeltaQpBlockUnit);
  }

  ENC_TB_DEBUG_PRINT("+++ hantro_encode_get_options\n");
  ENC_TB_DEBUG_PRINT("+++ options->rdoLevel = %d\n", options->rdoLevel);
  ENC_TB_DEBUG_PRINT("+++ options->bitPerSecond = %d\n", options->bitPerSecond);
  ENC_TB_DEBUG_PRINT("+++ options->inputRateNumer = %d\n", options->inputRateNumer);
  ENC_TB_DEBUG_PRINT("+++ options->inputRateDenom = %d\n", options->inputRateDenom);
  ENC_TB_DEBUG_PRINT("+++ options->outputRateNumer = %d\n", options->outputRateNumer);
  ENC_TB_DEBUG_PRINT("+++ options->outputRateDenom = %d\n", options->outputRateDenom);
  ENC_TB_DEBUG_PRINT("+++ options->intraPicRate = %d\n", options->intraPicRate);
  ENC_TB_DEBUG_PRINT("+++ options->bitrateWindow = %d\n", options->bitrateWindow);
  ENC_TB_DEBUG_PRINT("+++ options->intraQpDelta = %d\n", options->intraQpDelta);

  ENC_TB_DEBUG_PRINT("+++ options->qpHdr = %d\n", options->qpHdr);
  ENC_TB_DEBUG_PRINT("+++ options->qpMin = %d\n", options->qpMin);
  ENC_TB_DEBUG_PRINT("+++ options->qpMax = %d\n", options->qpMax);
  ENC_TB_DEBUG_PRINT("+++ options->fixedIntraQp = %d\n", options->fixedIntraQp);

  ENC_TB_DEBUG_PRINT("+++ options->tolMovingBitRate = %d\n", options->tolMovingBitRate);
  ENC_TB_DEBUG_PRINT("+++ options->bitVarRangeI = %d\n", options->bitVarRangeI);
  ENC_TB_DEBUG_PRINT("+++ options->bitVarRangeP = %d\n", options->bitVarRangeP);
  ENC_TB_DEBUG_PRINT("+++ options->bitVarRangeB = %d\n", options->bitVarRangeB);

  ENC_TB_DEBUG_PRINT("+++ options->picSkip = %d\n", options->picSkip);
  ENC_TB_DEBUG_PRINT("+++ options->profile = %d\n", options->profile);
  ENC_TB_DEBUG_PRINT("+++ options->level = %d\n", options->level);

  ENC_TB_DEBUG_PRINT("+++ options->tier = %d\n", options->tier);
  ENC_TB_DEBUG_PRINT("+++ options->exp_of_input_alignment  = %d\n", options->exp_of_input_alignment);
  ENC_TB_DEBUG_PRINT("+++ options->exp_of_ref_alignment    = %d\n", options->exp_of_ref_alignment);
  ENC_TB_DEBUG_PRINT("+++ options->exp_of_ref_ch_alignment = %d\n", options->exp_of_ref_ch_alignment);

  ENC_TB_DEBUG_PRINT("+++ options->byteStream = %d\n", options->byteStream);
  ENC_TB_DEBUG_PRINT("+++ options->videoRange = %d\n", options->videoRange);
  ENC_TB_DEBUG_PRINT("+++ options->chromaQpOffset = %d\n", options->chromaQpOffset);
  ENC_TB_DEBUG_PRINT("+++ options->gopSize = %d\n", options->gopSize);
  ENC_TB_DEBUG_PRINT("+++ options->lookaheadDepth = %d\n", options->lookaheadDepth);

  return 0;
}

static av_cold int hantro_encode_set_default_opt(AVCodecContext *avctx)
{
  HANTROH26xEncContext * ctx = (HANTROH26xEncContext *)avctx->priv_data;
  HANTROH26xEncOptions * options = &ctx->options;
  struct test_bench * tb = (struct test_bench *)&ctx->tb;

  int i;
  //memset(options, 0, sizeof(HANTROH26xEncOptions));

  options->firstPic    = 0;
  options->lastPic   = 0x7fffffff;
#if 10
  options->inputRateNumer      = avctx->framerate.num;
  options->inputRateDenom      = avctx->framerate.den;
  ENC_TB_DEBUG_PRINT("options->inputRateNumer = %d, options->inputRateDenom = %d\n", options->inputRateNumer, options->inputRateDenom);
  
  options->outputRateNumer      = DEFAULT;
  options->outputRateDenom      = DEFAULT;
#endif

  options->lumWidthSrc      = avctx->width;
  options->lumHeightSrc     = avctx->height;
  options->horOffsetSrc = DEFAULT;
  options->verOffsetSrc = DEFAULT;
  options->rotation = 0;

  switch (avctx->pix_fmt) {
    case AV_PIX_FMT_YUV420P:
        options->inputFormat = VCENC_YUV420_PLANAR;
        break;
		
    case AV_PIX_FMT_NV12:
        options->inputFormat = VCENC_YUV420_SEMIPLANAR;
        break;

    case AV_PIX_FMT_NV21:
        options->inputFormat = VCENC_YUV420_SEMIPLANAR_VU;
        break;

    case AV_PIX_FMT_YUV420P10LE:
        options->inputFormat = VCENC_YUV420_PLANAR_10BIT_P010;
        break;

    default:
        options->inputFormat = VCENC_YUV420_PLANAR;
        break;
	}
  
  options->formatCustomizedType = -1;

  options->width      = DEFAULT;
  options->height     = DEFAULT;
  options->max_cu_size  = 64;
  options->min_cu_size  = 8;
  options->max_tr_size  = 16;
  options->min_tr_size  = 4;
  options->tr_depth_intra = 2;  //mfu =>0
  options->tr_depth_inter = (options->max_cu_size == 64) ? 4 : 3;
  //options->intraPicRate   = 0;  // only first is IDR.

  if (!strcmp(avctx->codec->name, "hevcenc_hantro"))
  {
	options->codecFormat = VCENC_VIDEO_CODEC_HEVC;
  }
  else if (!strcmp(avctx->codec->name, "h264enc_hantro"))
  {
    options->codecFormat = VCENC_VIDEO_CODEC_H264;
    options->max_cu_size  = 16;
    options->min_cu_size  = 8;
    options->max_tr_size  = 16;
    options->min_tr_size  = 4;
    options->tr_depth_intra = 1;
    options->tr_depth_inter = 2;
  }

  options->bitPerSecond = DEFAULT;
#if 0
  options->bitVarRangeI = 10000;
  options->bitVarRangeP = 10000;
  options->bitVarRangeB = 10000;
  options->tolMovingBitRate = 2000;
#endif
  options->monitorFrames = DEFAULT;
#if 0
  options->tolCtbRcInter = DEFAULT;
  options->tolCtbRcIntra = DEFAULT;
#endif
  options->u32StaticSceneIbitPercent = 80;
  //options->intraQpDelta = DEFAULT;
  //options->bFrameQpDelta = -1;

  options->disableDeblocking = 0;

  options->tc_Offset = -2;
  options->beta_Offset = 5;

#if 0
  options->qpHdr = DEFAULT;
  options->qpMin = DEFAULT;
  options->qpMax = DEFAULT;
  options->qpMinI = DEFAULT;
  options->qpMaxI = DEFAULT;
  options->picRc = DEFAULT;
  options->ctbRc = DEFAULT; //CTB_RC
  options->cpbSize = 1000000;
  options->bitrateWindow = DEFAULT;
  options->fixedIntraQp = 0;
  options->hrdConformance = 0;
#endif
  options->smoothPsnrInGOP = 0;
  //options->vbr = 0;

  //options->byteStream = 1;

 // options->chromaQpOffset = 0;

  options->enableSao = 1;

  options->strong_intra_smoothing_enabled_flag = 0;
  
  options->pcm_loop_filter_disabled_flag = 0;

  options->intraAreaLeft = options->intraAreaRight = options->intraAreaTop =
                         options->intraAreaBottom = -1;  /* Disabled */
  options->ipcm1AreaLeft = options->ipcm1AreaRight = options->ipcm1AreaTop =
                         options->ipcm1AreaBottom = -1;  /* Disabled */
  options->ipcm2AreaLeft = options->ipcm2AreaRight = options->ipcm2AreaTop =
                         options->ipcm2AreaBottom = -1;  /* Disabled */
  options->gdrDuration=0;

  //options->picSkip = 0;

  //options->sliceSize = 0;

  //options->enableCabac = 1;
  options->cabacInitFlag = 0;
  options->cirStart = 0;
  options->cirInterval = 0;
  options->enableDeblockOverride = 0;
  options->deblockOverride = 0;

  options->enableScalingList = 0;

  options->compressor = 0;
  //options->sei = 0;
  //options->videoRange = 0;
  options->level = DEFAULT;
  options->profile = DEFAULT;
  //options->tier = DEFAULT;
  options->bitDepthLuma = DEFAULT;
  options->bitDepthChroma= DEFAULT;
  options->blockRCSize= DEFAULT;
  options->rcQpDeltaRange = DEFAULT;
  options->rcBaseMBComplexity = DEFAULT;
  //options->picQpDeltaMin = DEFAULT;
  options->picQpDeltaMax = DEFAULT;
  //options->ctbRcRowQpStep = DEFAULT;
  
  //options->bitrateWindow = DEFAULT;
  //options->gopSize = 0;
  //options->gopCfg = NULL;
  //options->gopLowdelay = 0;
  options->longTermGap = 0;
  options->longTermGapOffset = 0;
  options->longTermQpDelta = 0;
  options->ltrInterval = DEFAULT;

  options->outReconFrame=1;
  
  options->roiMapDeltaQpBlockUnit=0;
  options->roiMapDeltaQpEnable=0;
  options->roiMapDeltaQpFile = NULL;
  options->roiMapDeltaQpBinFile = NULL;
  options->roiMapInfoBinFile        = NULL;
  options->RoimapCuCtrlInfoBinFile  = NULL;
  options->RoimapCuCtrlIndexBinFile = NULL;
  options->RoiCuCtrlVer  = 0;
  options->RoiQpDeltaVer = 1;
  options->ipcmMapEnable = 0;
  options->ipcmMapFile = NULL;
  options->roi1Qp = DEFAULT;
  options->roi2Qp = DEFAULT;
  options->roi3Qp = DEFAULT;
  options->roi4Qp = DEFAULT;
  options->roi5Qp = DEFAULT;
  options->roi6Qp = DEFAULT;
  options->roi7Qp = DEFAULT;
  options->roi8Qp = DEFAULT;

  options->interlacedFrame = 0;
  options->noiseReductionEnable = 0;

  /* low latency */
  options->inputLineBufMode = 0;
  options->inputLineBufDepth = DEFAULT;
  options->amountPerLoopBack = 0;

  /*stride*/
  options->exp_of_input_alignment = 4;
  options->exp_of_ref_alignment = 0;
  options->exp_of_ref_ch_alignment = 0;

  options->multimode = 0;

  for(i = 0; i < MAX_STREAMS; i++)
    options->streamcfg[i] = NULL;

  options->enableOutputCuInfo = 0;
  options->P010RefEnable = 0;

  options->hashtype = 0;
  options->verbose = 0;

  /* smart */
  options->smartModeEnable = 0;
  options->smartH264LumDcTh = 5;
  options->smartH264CbDcTh = 1;
  options->smartH264CrDcTh = 1;
  options->smartHevcLumDcTh[0] = 2;
  options->smartHevcLumDcTh[1] = 2;
  options->smartHevcLumDcTh[2] = 2;
  options->smartHevcChrDcTh[0] = 2;
  options->smartHevcChrDcTh[1] = 2;
  options->smartHevcChrDcTh[2] = 2;
  options->smartHevcLumAcNumTh[0] = 12;
  options->smartHevcLumAcNumTh[1] = 51;
  options->smartHevcLumAcNumTh[2] = 204;
  options->smartHevcChrAcNumTh[0] = 3;
  options->smartHevcChrAcNumTh[1] = 12;
  options->smartHevcChrAcNumTh[2] = 51;
  options->smartH264Qp = 30;
  options->smartHevcLumQp = 30;
  options->smartHevcChrQp = 30;
  options->smartMeanTh[0] = 5;
  options->smartMeanTh[1] = 5;
  options->smartMeanTh[2] = 5;
  options->smartMeanTh[3] = 5;
  options->smartPixNumCntTh = 0;

  /* constant chroma control */
  options->constChromaEn = 0;
  options->constCb = DEFAULT;
  options->constCr = DEFAULT;

  for (i = 0; i < MAX_SCENE_CHANGE; i ++)
    options->sceneChange[i] = 0;

  options->tiles_enabled_flag = 0;
  options->num_tile_columns = 1;
  options->num_tile_rows  = 1;
  options->loop_filter_across_tiles_enabled_flag = 1;  

  options->skip_frame_enabled_flag=0;
  options->skip_frame_poc=0;

  /* HDR10 */
  options->hdr10_display_enable = 0;
  options->hdr10_dx0 = 0;
  options->hdr10_dy0 = 0;
  options->hdr10_dx1 = 0;
  options->hdr10_dy1 = 0;
  options->hdr10_dx2 = 0;
  options->hdr10_dy2 = 0;
  options->hdr10_wx  = 0;
  options->hdr10_wy  = 0;
  options->hdr10_maxluma = 0;
  options->hdr10_minluma = 0;

  options->hdr10_lightlevel_enable = 0;
  options->hdr10_maxlight          = 0;
  options->hdr10_avglight          = 0;

  options->vuiColorDescripPresentFlag    = 0;
  options->vuiColorPrimaries             = 9;
  options->vuiTransferCharacteristics    = 0; 
  options->vuiMatrixCoefficients         = 9;
  options->vuiVideoFormat                = 5;
  options->vuiVideoSignalTypePresentFlag = 0;
  options->vuiAspectRatioWidth           = 0;
  options->vuiAspectRatioHeight          = 0;

#if 0
  /* refresh vui input */
  options->vuiAspectRatioWidth          = avctx->sample_aspect_ratio.num;
  options->vuiAspectRatioHeight         = avctx->sample_aspect_ratio.den;

  if (avctx->color_primaries != AVCOL_PRI_UNSPECIFIED)
    options->vuiColorPrimaries            = avctx->color_primaries;
  if (avctx->color_trc != AVCOL_TRC_UNSPECIFIED)
    options->vuiTransferCharacteristics   = avctx->color_trc;
  if (avctx->colorspace != AVCOL_SPC_UNSPECIFIED)
    options->vuiMatrixCoefficients        = avctx->colorspace;
  options->videoRange                   = avctx->color_range;

  if (options->vuiColorPrimaries || options->vuiTransferCharacteristics || options->vuiMatrixCoefficients) {
    options->vuiColorDescripPresentFlag = 1;
  }

  if (options->vuiColorDescripPresentFlag || options->vuiVideoFormat || (options->videoRange && (options->videoRange != DEFAULT))) {
    options->vuiVideoSignalTypePresentFlag = 1;
  }
 
  /* vui info print */
  ENC_TB_DEBUG_PRINT("options->vuiAspectRatioWidth           = %d\n", options->vuiAspectRatioWidth);
  ENC_TB_DEBUG_PRINT("options->vuiAspectRatioHeight          = %d\n", options->vuiAspectRatioHeight);
  ENC_TB_DEBUG_PRINT("options->vuiColorPrimaries             = %d\n", options->vuiColorPrimaries);
  ENC_TB_DEBUG_PRINT("options->vuiTransferCharacteristics    = %d\n", options->vuiTransferCharacteristics);
  ENC_TB_DEBUG_PRINT("options->vuiMatrixCoefficients         = %d\n", options->vuiMatrixCoefficients);
  ENC_TB_DEBUG_PRINT("options->videoRange                    = %d\n", options->videoRange);
  ENC_TB_DEBUG_PRINT("options->vuiVideoFormat                = %d\n", options->vuiVideoFormat);
  ENC_TB_DEBUG_PRINT("options->vuiColorDescripPresentFlag    = %d\n", options->vuiColorDescripPresentFlag);
  ENC_TB_DEBUG_PRINT("options->vuiVideoSignalTypePresentFlag = %d\n", options->vuiVideoSignalTypePresentFlag);
#endif

  options->picOrderCntType = 0;
  options->log2MaxPicOrderCntLsb = 16;
  options->log2MaxFrameNum = 12;

  options->RpsInSliceHeader = 0;
  options->ssim = 1;
  options->vui_timing_info_enable = 1;
  options->cutree_blkratio = 0;
 
  /* skip mode */
  options->skipMapEnable = 0;
  options->skipMapFile = NULL;
  options->skipMapBlockUnit = 0;

  /* Frame level core parallel option */
  options->parallelCoreNum =1;

  //add for transcode
  options->enc_index = 0; //-1;
  options->trans_handle = NULL;

  //add for new driver
#ifdef DRV_NEW_ARCH
  options->priority = 1; //0-live, 1-vod
  options->device = "/dev/transcoder0";
  options->mem_id = -1;
#endif

  /* two stream buffer */
  options->streamBufChain = 0;

  /*multi-segment of stream buffer*/
  options->streamMultiSegmentMode = 0;
  options->streamMultiSegmentAmount = 4;

  /*dump register*/
  options->dumpRegister = 0;

  options->rasterscan = 0;

  //options->lookaheadDepth = 0;
  
  /*CRF constant*/
  //options->crf = -1;	
  return 0;
}

static int profile_check(enum AVCodecID codec, char *codecName, char *profile, HANTROH26xEncOptions *options)
{
  if (codec == AV_CODEC_ID_HEVC) {
    if (strcmp(profile, "main") == 0) {
      options->profile = VCENC_HEVC_MAIN_PROFILE;
    } else if (strcmp(profile, "still") == 0) {
      options->profile = VCENC_HEVC_MAIN_STILL_PICTURE_PROFILE;
    } else if (strcmp(profile, "main10") == 0) {
      options->profile = VCENC_HEVC_MAIN_10_PROFILE;
    } else {
      av_log(NULL, AV_LOG_ERROR, "unknow vce profile %s for %s\n", profile, codecName);
      return -1;
    }  
  } else if (codec == AV_CODEC_ID_H264) {
    if (strcmp(profile, "baseline") == 0) {
      options->profile = VCENC_H264_BASE_PROFILE;
    } else if (strcmp(profile, "main") == 0) {
      options->profile = VCENC_H264_MAIN_PROFILE;
    } else if (strcmp(profile, "high") == 0) {
      options->profile = VCENC_H264_HIGH_PROFILE;
    } else if (strcmp(profile, "high10") == 0) {
      options->profile = VCENC_H264_HIGH_10_PROFILE;
    } else {
      av_log(NULL, AV_LOG_ERROR, "unknow vce profile %s for %s\n", profile, codecName);
      return -1;
    }
  }

  return 0;
}

static int level_check(enum AVCodecID codec, char *codecName, char *level, HANTROH26xEncOptions *options)
{
  if (codec == AV_CODEC_ID_HEVC) {
    if ((strcmp(level, "1") == 0) || (strcmp(level, "1.0") == 0)) {
      options->level = VCENC_HEVC_LEVEL_1;
    } else if ((strcmp(level, "2") == 0) || (strcmp(level, "2.0") == 0)) {
      options->level = VCENC_HEVC_LEVEL_2;
    } else if (strcmp(level, "2.1") == 0) {
      options->level = VCENC_HEVC_LEVEL_2_1;
    } else if ((strcmp(level, "3") == 0) || (strcmp(level, "3.0") == 0)) {
      options->level = VCENC_HEVC_LEVEL_3;
    } else if (strcmp(level, "3.1") == 0) {
      options->level = VCENC_HEVC_LEVEL_3_1;
    } else if ((strcmp(level, "4") == 0) || (strcmp(level, "4.0") == 0)) {
      options->level = VCENC_HEVC_LEVEL_4;
    } else if (strcmp(level, "4.1") == 0) {
      options->level = VCENC_HEVC_LEVEL_4_1;
    } else if ((strcmp(level, "5") == 0) || (strcmp(level, "5.0") == 0)) {
      options->level = VCENC_HEVC_LEVEL_5;
    } else if (strcmp(level, "5.1") == 0) {
      options->level = VCENC_HEVC_LEVEL_5_1;
    } else {
      av_log(NULL, AV_LOG_ERROR, "unsupported vce level %s for %s\n", level, codecName);
      return -1;
    } 
  
  } else if (codec == AV_CODEC_ID_H264){  
    if ((strcmp(level, "1") == 0) || (strcmp(level, "1.0") == 0)) {
      options->level = VCENC_H264_LEVEL_1;
    } else if (strcmp(level, "1b") == 0) {
      options->level = VCENC_H264_LEVEL_1_b;
    } else if (strcmp(level, "1.1") == 0) {
      options->level = VCENC_H264_LEVEL_1_1;
    } else if (strcmp(level, "1.2") == 0) {
      options->level = VCENC_H264_LEVEL_1_2;
    } else if (strcmp(level, "1.3") == 0) {
      options->level = VCENC_H264_LEVEL_1_3;
    } else if ((strcmp(level, "2") == 0) || (strcmp(level, "2.0") == 0)) {
      options->level = VCENC_H264_LEVEL_2;
    } else if (strcmp(level, "2.1") == 0) {
      options->level = VCENC_H264_LEVEL_2_1;
    } else if (strcmp(level, "2.2") == 0) {
      options->level = VCENC_H264_LEVEL_2_2;
    } else if ((strcmp(level, "3") == 0) || (strcmp(level, "3.0") == 0)) {
      options->level = VCENC_H264_LEVEL_3;
    } else if (strcmp(level, "3.1") == 0) {
      options->level = VCENC_H264_LEVEL_3_1;
    } else if (strcmp(level, "3.2") == 0) {
      options->level = VCENC_H264_LEVEL_3_2;
    } else if ((strcmp(level, "4") == 0) || (strcmp(level, "4.0") == 0)) {
      options->level = VCENC_H264_LEVEL_4;
    } else if (strcmp(level, "4.1") == 0) {
      options->level = VCENC_H264_LEVEL_4_1;
    } else if (strcmp(level, "4.2") == 0) {
      options->level = VCENC_H264_LEVEL_4_2;
    } else if ((strcmp(level, "5") == 0) || (strcmp(level, "5.0") == 0)) {
      options->level = VCENC_H264_LEVEL_5;
    } else if (strcmp(level, "5.1") == 0) {
      options->level = VCENC_H264_LEVEL_5_1;
    } else if (strcmp(level, "5.2") == 0) {
      options->level = VCENC_H264_LEVEL_5_2;
    } else {
      av_log(NULL, AV_LOG_ERROR, "unsupported vce level %s for %s. \n", level, codecName);
      return -1;
    }	
  }

  return 0;
}

static int get_profile_and_level(AVCodecContext *avctx)
{
  HANTROH26xEncContext * ctx = (HANTROH26xEncContext *)avctx->priv_data;
  HANTROH26xEncOptions * options = &ctx->options;

  if (ctx->profile) {
    profile_check(avctx->codec->id, avctx->codec->name, ctx->profile, options);
  }

  if (ctx->level) {
    level_check(avctx->codec->id, avctx->codec->name, ctx->level, options);
  }

  return 0;
}

static av_cold int hantro_encode_set_vceparam(AVCodecContext *avctx, AVHANTROFramesContext *frame_hwctx)
{
  HANTROH26xEncContext * ctx = (HANTROH26xEncContext *)avctx->priv_data;
  HANTROH26xEncOptions * options = &ctx->options;
  struct test_bench * tb = (struct test_bench *)&ctx->tb;

  ENC_TB_DEBUG_PRINT("ctx->pp_index = %d\n", ctx->pp_index);
  ENC_TB_DEBUG_PRINT("pic %dx%d\n", frame_hwctx->pic_info[ctx->pp_index].width, frame_hwctx->pic_info[ctx->pp_index].height);

  /* refresh vui input */
  options->vuiAspectRatioWidth          = avctx->sample_aspect_ratio.num;
  options->vuiAspectRatioHeight         = avctx->sample_aspect_ratio.den;
  av_log(avctx, AV_LOG_DEBUG, "sar_w = %d, sar_h = %d\n", avctx->sample_aspect_ratio.num, avctx->sample_aspect_ratio.den);


  if (avctx->color_primaries != AVCOL_PRI_UNSPECIFIED)
    options->vuiColorPrimaries            = avctx->color_primaries;
  if (avctx->color_trc != AVCOL_TRC_UNSPECIFIED)
    options->vuiTransferCharacteristics   = avctx->color_trc;
  if (avctx->colorspace != AVCOL_SPC_UNSPECIFIED)
    options->vuiMatrixCoefficients        = avctx->colorspace;

  if (avctx->color_range == AVCOL_RANGE_JPEG)
    options->videoRange                   = 1; //avctx->color_range;
  else
    options->videoRange                   = 0;

  if (options->vuiColorPrimaries || options->vuiTransferCharacteristics || options->vuiMatrixCoefficients) {
    options->vuiColorDescripPresentFlag = 1;
  }

  if (options->vuiColorDescripPresentFlag || options->vuiVideoFormat || (options->videoRange && (options->videoRange != DEFAULT))) {
    options->vuiVideoSignalTypePresentFlag = 1;
  }
 
  /* vui info print */
  ENC_TB_DEBUG_PRINT("options->vuiAspectRatioWidth           = %d\n", options->vuiAspectRatioWidth);
  ENC_TB_DEBUG_PRINT("options->vuiAspectRatioHeight          = %d\n", options->vuiAspectRatioHeight);
  ENC_TB_DEBUG_PRINT("options->vuiColorPrimaries             = %d\n", options->vuiColorPrimaries);
  ENC_TB_DEBUG_PRINT("options->vuiTransferCharacteristics    = %d\n", options->vuiTransferCharacteristics);
  ENC_TB_DEBUG_PRINT("options->vuiMatrixCoefficients         = %d\n", options->vuiMatrixCoefficients);
  ENC_TB_DEBUG_PRINT("options->videoRange                    = %d\n", options->videoRange);
  ENC_TB_DEBUG_PRINT("options->vuiVideoFormat                = %d\n", options->vuiVideoFormat);
  ENC_TB_DEBUG_PRINT("options->vuiColorDescripPresentFlag    = %d\n", options->vuiColorDescripPresentFlag);
  ENC_TB_DEBUG_PRINT("options->vuiVideoSignalTypePresentFlag = %d\n", options->vuiVideoSignalTypePresentFlag);

  if (get_profile_and_level(avctx) != 0) {
    ENC_TB_ERROR_PRINT("get profile or level from cmd error, please check your input.\n");
    return -1;
  }

  if (frame_hwctx->pic_info[ctx->pp_index].picdata.is_interlaced == 0) {
    if (frame_hwctx->pic_info[ctx->pp_index].width < frame_hwctx->pic_info[ctx->pp_index].pic_width) {
      options->lumWidthSrc = frame_hwctx->pic_info[ctx->pp_index].pic_width;
    } else {
      options->lumWidthSrc = NEXT_MULTIPLE(frame_hwctx->pic_info[ctx->pp_index].width, 4);
    }
  } else {
      /*10bit may have issue, but h264 don't support 10bit*/
    options->lumWidthSrc = frame_hwctx->pic_info[ctx->pp_index].picdata.pic_stride;
  }
  if (frame_hwctx->pic_info[ctx->pp_index].height < frame_hwctx->pic_info[ctx->pp_index].pic_height) {
    options->lumHeightSrc = frame_hwctx->pic_info[ctx->pp_index].pic_height;
  } else {
    options->lumHeightSrc = NEXT_MULTIPLE(frame_hwctx->pic_info[ctx->pp_index].height, 4);
  }
  ENC_TB_DEBUG_PRINT("lumSrc %dx%d\n", options->lumWidthSrc, options->lumHeightSrc);

  if (frame_hwctx->pic_info[ctx->pp_index].width != options->lumWidthSrc) {
    options->width = frame_hwctx->pic_info[ctx->pp_index].width;
  }
  
  if (frame_hwctx->pic_info[ctx->pp_index].height != options->lumHeightSrc) {
    options->height = frame_hwctx->pic_info[ctx->pp_index].height;
  }
  ENC_TB_DEBUG_PRINT("res %dx%d\n", options->width, options->height);


  if (frame_hwctx->pic_info[ctx->pp_index].picdata.is_interlaced == 0) {
      if ((ctx->pp_index == HANTRO_DEC_OUT_RFC)
          || (ctx->pp_index == HANTRO_DEC_OUT_PP0)) {
        if (frame_hwctx->pic_info[ctx->pp_index].picdata.crop_out_width) {
          if (frame_hwctx->pic_info[ctx->pp_index].picdata.crop_out_width < frame_hwctx->pic_info[ctx->pp_index].width) {
            options->width = NEXT_MULTIPLE(frame_hwctx->pic_info[ctx->pp_index].picdata.crop_out_width, 2);
          }
        }
        if (frame_hwctx->pic_info[ctx->pp_index].picdata.crop_out_height) {
          if (frame_hwctx->pic_info[ctx->pp_index].picdata.crop_out_height < frame_hwctx->pic_info[ctx->pp_index].height) {
            options->height = NEXT_MULTIPLE(frame_hwctx->pic_info[ctx->pp_index].picdata.crop_out_height, 2);
          }
        }
      }
  } else {
      if ((ctx->pp_index == HANTRO_DEC_OUT_RFC)
          || (ctx->pp_index == HANTRO_DEC_OUT_PP0)) {
          if (frame_hwctx->pic_info[ctx->pp_index].picdata.crop_out_width < options->lumWidthSrc) {
              options->width = NEXT_MULTIPLE(frame_hwctx->pic_info[ctx->pp_index].picdata.crop_out_width, 2);
          }
          if (frame_hwctx->pic_info[ctx->pp_index].picdata.crop_out_height < options->lumHeightSrc) {
              options->height = NEXT_MULTIPLE(frame_hwctx->pic_info[ctx->pp_index].picdata.crop_out_height, 2);
          }
      }
  }
  ENC_TB_DEBUG_PRINT("+++ res %dx%d\n", options->width, options->height);

  switch (frame_hwctx->pic_info[ctx->pp_index].picdata.pic_format) {
  case DEC_OUT_FRM_TILED_4X4:
    options->inputFormat = VCENC_YUV420_SEMIPLANAR_8BIT_FB;
    break;
  case DEC_OUT_FRM_YUV420TILE_P010:
    options->inputFormat = VCENC_YUV420_PLANAR_10BIT_P010_FB;
    break;
  case DEC_OUT_FRM_YUV420TILE_PACKED:
    options->inputFormat = VCENC_YUV420_UV_8BIT_TILE_64_4;
    break;
  default:
    options->inputFormat = VCENC_YUV420_SEMIPLANAR_8BIT_FB;
    break;
  }
  
  options->bitDepthLuma   = frame_hwctx->pic_info[ctx->pp_index].picdata.bit_depth_luma;
  options->bitDepthChroma = frame_hwctx->pic_info[ctx->pp_index].picdata.bit_depth_chroma;
  options->P010RefEnable  = 1;

  switch (frame_hwctx->pic_info[ctx->pp_index].picdata.pic_pixformat) {
  case DEC_OUT_PIXEL_DEFAULT: //reference frame with no compress and pp out 8bit is this pixel format
#ifdef SUPPORT_DEC400
    if (frame_hwctx->pic_info[ctx->pp_index].picdata.bit_depth_luma > 8
         || frame_hwctx->pic_info[ctx->pp_index].picdata.bit_depth_chroma > 8) {
      if (frame_hwctx->pic_info[ctx->pp_index].picdata.pic_compressed_status > 0) {
        ENC_TB_ERROR_PRINT("should not get here!\n");
        return -1;
      } else {
        options->inputFormat = VCENC_YUV420_PLANAR_10BIT_P010_FB;
        if (options->codecFormat == VCENC_VIDEO_CODEC_H264) {
          options->profile = VCENC_H264_HIGH_10_PROFILE;
          //pCml->level = VCENC_H264_LEVEL_6_2;
        } else if (options->codecFormat == VCENC_VIDEO_CODEC_HEVC) {
          options->profile = VCENC_HEVC_MAIN_10_PROFILE;
          //pCml->level = 0;
        }
      }
    } else {
        if (frame_hwctx->pic_info[ctx->pp_index].picdata.pic_format > DEC_OUT_FRM_NV21TILE) {
          if (frame_hwctx->pic_info[ctx->pp_index].picdata.pic_compressed_status == 2) {
            options->inputFormat = INPUT_FORMAT_YUV420_SEMIPLANAR_VU_8BIT_COMPRESSED_FB;
          } else if (frame_hwctx->pic_info[ctx->pp_index].picdata.pic_compressed_status == 0) {
            options->inputFormat = VCENC_YUV420_SEMIPLANAR_VU_8BIT_FB;
          } else {
            ENC_TB_ERROR_PRINT("should not get here!\n");
            return -1;
          }
        } else if (frame_hwctx->pic_info[ctx->pp_index].picdata.pic_format == DEC_OUT_FRM_RASTER_SCAN) {
            if(frame_hwctx->pic_info[ctx->pp_index].format == AVHANTRO_FORMAT_YUV420_SEMIPLANAR_VU)
              options->inputFormat = INPUT_FORMAT_PP_YUV420_SEMIPLANNAR_VU;
            else if(frame_hwctx->pic_info[ctx->pp_index].format == AVHANTRO_FORMAT_YUV420_SEMIPLANAR_YUV420P)
              options->inputFormat = INPUT_FORMAT_PP_YUV420_SEMIPLANNAR_YUV420P;
            else
              options->inputFormat = INPUT_FORMAT_PP_YUV420_SEMIPLANNAR;
            
            av_log(ctx, AV_LOG_DEBUG, "[%s@%d], inputFormat %d, (INPUT_FORMAT_PP_YUV420_SEMIPLANNAR %d, VCENC_YUV420_PLANAR %d, INPUT_FORMAT_PP_YUV420_SEMIPLANNAR_VU %d, INPUT_FORMAT_PP_YUV420_SEMIPLANNAR_YUV420P %d)\n",
              __FUNCTION__, __LINE__, options->inputFormat, INPUT_FORMAT_PP_YUV420_SEMIPLANNAR, VCENC_YUV420_PLANAR, INPUT_FORMAT_PP_YUV420_SEMIPLANNAR_VU, INPUT_FORMAT_PP_YUV420_SEMIPLANNAR_YUV420P);

            options->b_close_dummy_regs = 1;
        } else {
          if (frame_hwctx->pic_info[ctx->pp_index].picdata.pic_compressed_status == 2) {
            options->inputFormat = INPUT_FORMAT_YUV420_SEMIPLANAR_8BIT_COMPRESSED_FB;
          } else if (frame_hwctx->pic_info[ctx->pp_index].picdata.pic_compressed_status == 0) {
            options->inputFormat = VCENC_YUV420_SEMIPLANAR_8BIT_FB;
          } else {
            ENC_TB_ERROR_PRINT("should not get here!\n");
            return -1;
          }
        }
    }
#else
    if (frame_hwctx->pic_info[ctx->pp_index].picdata.bit_depth_luma > 8
         || frame_hwctx->pic_info[ctx->pp_index].picdata.bit_depth_chroma > 8) {
        options->inputFormat = VCENC_YUV420_PLANAR_10BIT_P010_FB;
        if (options->codecFormat == VCENC_VIDEO_CODEC_H264) {
          options->profile = VCENC_H264_HIGH_10_PROFILE;
          //pCml->level = VCENC_H264_LEVEL_6_2;
        } else if (options->codecFormat == VCENC_VIDEO_CODEC_HEVC) {
          options->profile = VCENC_HEVC_MAIN_10_PROFILE;
          //pCml->level = 0;
        }
    }  else if (frame_hwctx->pic_info[ctx->pp_index].picdata.pic_format == DEC_OUT_FRM_RASTER_SCAN) {
        options->inputFormat = INPUT_FORMAT_PP_YUV420_SEMIPLANNAR;
    } else {}
#endif
    break;
  case DEC_OUT_PIXEL_CUT_8BIT:
    options->bitDepthLuma = 8;
    options->bitDepthChroma = 8;
    break;
  case DEC_OUT_PIXEL_P010: //pp out 10bit is this pixel format
#ifdef SUPPORT_DEC400
    if (frame_hwctx->pic_info[ctx->pp_index].picdata.pic_compressed_status == 2) {
      options->inputFormat = INPUT_FORMAT_YUV420_PLANAR_10BIT_P010_COMPRESSED_FB;
    } else if (frame_hwctx->pic_info[ctx->pp_index].picdata.pic_compressed_status == 0) {
       //options->inputFormat = VCENC_YUV420_PLANAR_10BIT_P010_FB;
        if(frame_hwctx->pic_info[ctx->pp_index].picdata.pic_format == DEC_OUT_FRM_RASTER_SCAN )
          options->inputFormat = INPUT_FORMAT_PP_YUV420_PLANAR_10BIT_P010;
        else
          options->inputFormat = VCENC_YUV420_PLANAR_10BIT_P010_FB;
        
        options->b_close_dummy_regs = 1;
    } else {
      ENC_TB_ERROR_PRINT("should not get here!\n");
      return -1;
    }
#else
    options->inputFormat = VCENC_YUV420_PLANAR_10BIT_P010_FB; 
#endif
    if (options->codecFormat == VCENC_VIDEO_CODEC_H264) {
      options->profile = VCENC_H264_HIGH_10_PROFILE;
      //pCml->level = VCENC_H264_LEVEL_6_2;
    } else if (options->codecFormat == VCENC_VIDEO_CODEC_HEVC) {
      options->profile = VCENC_HEVC_MAIN_10_PROFILE;
      //pCml->level = 0;
    }
    break;
  case DEC_OUT_PIXEL_RFC:
#if 0
#ifdef SUPPORT_TCACHE
    if (frame_hwctx->pic_info[ctx->pp_index].picdata.bit_depth_luma > 8
         || frame_hwctx->pic_info[ctx->pp_index].picdata.bit_depth_chroma > 8) {
      options->inputFormat = INPUT_FORMAT_RFC_10BIT_COMPRESSED_FB;
      if (options->codecFormat == VCENC_VIDEO_CODEC_H264) {
        options->profile = VCENC_H264_HIGH_10_PROFILE;
        //pCml->level = VCENC_H264_LEVEL_6_2;
      } else if (options->codecFormat == VCENC_VIDEO_CODEC_HEVC) {
        options->profile = VCENC_HEVC_MAIN_10_PROFILE;
        //pCml->level = 0;
      }
    } else {
      options->inputFormat = INPUT_FORMAT_RFC_8BIT_COMPRESSED_FB;
    }
#endif
#else
    ENC_TB_ERROR_PRINT("should not get here! RFC output disabled\n");
    return -1;
#endif
    break;
  default:
    break;
  }

  if (options->bitDepthLuma > 8 || options->bitDepthChroma > 8) {
    if (ctx->force_8bit) {
      options->bitDepthLuma = 8;
      options->bitDepthChroma = 8;
      options->profile = 0;
    } else if (ctx->bitdepth != DEFAULT_VALUE) {
      if (ctx->bitdepth == 0) {
        options->bitDepthLuma = 8;
        options->bitDepthChroma = 8;
        options->profile = 0;
      }
    }
  }
  
  options->exp_of_ref_alignment    = 10;
  options->exp_of_ref_ch_alignment = 10;
  options->compressor = 2;

  /* get default bitrate or limit bitrate */
#if 0
  {
    u32 width, height;
    width = (options->width == DEFAULT_VALUE) ? options->lumWidthSrc : options->width;
    height = (options->height == DEFAULT_VALUE) ? options->lumHeightSrc : options->height;
    ENC_TB_DEBUG_PRINT("check bitrate by width %d height %d\n", width, height);
    
    if (options->bitPerSecond == DEFAULT_VALUE) {
      int res_index = vce_get_res_index(width, height);
      options->bitPerSecond = vce_default_bitrate[res_index];
      ENC_TB_DEBUG_PRINT("get default bitrate %d\n", options->bitPerSecond);
    } else {
      u32 original_bits_perframe;
      original_bits_perframe = (width * height * 3) / 2;
      original_bits_perframe *= 8;
      if (options->bitDepthLuma > 8) {
        original_bits_perframe *= 2;
      }
      if (options->bitPerSecond > original_bits_perframe/2) {
        options->bitPerSecond = original_bits_perframe/2;
        options->bitPerSecond = ((options->bitPerSecond + 100000 - 1)/100000)*100000;
        ENC_TB_DEBUG_PRINT("limit bitrate to %d\n", options->bitPerSecond);
      }
    }
  }  
#else
  {
    u32 width, height;
    width = (options->width == DEFAULT_VALUE) ? options->lumWidthSrc : options->width;
    height = (options->height == DEFAULT_VALUE) ? options->lumHeightSrc : options->height;
    ENC_TB_DEBUG_PRINT("check bitrate by width %d height %d\n", width, height);

    /*
    if (avctx->bit_rate == 200000) {
      int res_index = vce_get_res_index(width, height);
      options->bitPerSecond = vce_default_bitrate[res_index];
      ENC_TB_DEBUG_PRINT("get default bitrate %d\n", options->bitPerSecond);
    } else */
    {
      u32 original_bits_perframe;
      options->bitPerSecond = avctx->bit_rate;
      original_bits_perframe = (width * height * 3) / 2;
      original_bits_perframe *= 8;
      if (options->bitDepthLuma > 8) {
        original_bits_perframe *= 2;
      }
      if (options->bitPerSecond > original_bits_perframe/2) {
        options->bitPerSecond = original_bits_perframe/2;
        options->bitPerSecond = ((options->bitPerSecond + 100000 - 1)/100000)*100000;
        ENC_TB_DEBUG_PRINT("limit bitrate to %d\n", options->bitPerSecond);
        av_log(avctx, AV_LOG_WARNING, "limit bitrate to %d\n", options->bitPerSecond);
      }
    }
  }
#endif

    if (options->enc_index == 0 && options->lookaheadDepth) {
        if (ctx->pp_index != 0 && ctx->pp_index != 1) {
            ENC_TB_ERROR_PRINT("enc_index not match with pp_index\n");
            return -1;
        }
        if (frame_hwctx->pic_info[2].enabled && frame_hwctx->pic_info[2].flag) {
            options->cutree_blkratio = 1;
            ENC_TB_DEBUG_PRINT("enable 1/4 resolution first pass\n");

            if (frame_hwctx->pic_info[2].picdata.is_interlaced == 0) {
              if (frame_hwctx->pic_info[2].width < frame_hwctx->pic_info[2].pic_width) {
                options->lumWidthSrc_ds = frame_hwctx->pic_info[2].pic_width;
              } else {
                options->lumWidthSrc_ds = NEXT_MULTIPLE(frame_hwctx->pic_info[2].width, 4);
              }
            } else {
                /*10bit may have issue, but h264 don't support 10bit*/
              options->lumWidthSrc_ds = frame_hwctx->pic_info[2].picdata.pic_stride;
            }
            if (frame_hwctx->pic_info[2].height < frame_hwctx->pic_info[2].pic_height) {
              options->lumHeightSrc_ds = frame_hwctx->pic_info[2].pic_height;
            } else {
              options->lumHeightSrc_ds = NEXT_MULTIPLE(frame_hwctx->pic_info[2].height, 4);
            }
            ENC_TB_DEBUG_PRINT("ds lumSrc %dx%d\n", options->lumWidthSrc_ds, options->lumHeightSrc_ds);
  
            options->width_ds = frame_hwctx->pic_info[2].width;
            options->height_ds = frame_hwctx->pic_info[2].height;


            ENC_TB_DEBUG_PRINT("ds res %dx%d\n", options->width_ds, options->height_ds);

            switch (frame_hwctx->pic_info[2].picdata.pic_format) {
            case DEC_OUT_FRM_TILED_4X4:
              options->inputFormat_ds = VCENC_YUV420_SEMIPLANAR_8BIT_FB;
              break;
            case DEC_OUT_FRM_YUV420TILE_P010:
              options->inputFormat_ds = VCENC_YUV420_PLANAR_10BIT_P010_FB;
              break;
            case DEC_OUT_FRM_YUV420TILE_PACKED:
              options->inputFormat_ds = VCENC_YUV420_UV_8BIT_TILE_64_4;
              break;
            default:
              options->inputFormat_ds = VCENC_YUV420_SEMIPLANAR_8BIT_FB;
              break;
            }
            
            switch (frame_hwctx->pic_info[2].picdata.pic_pixformat) {
              case DEC_OUT_PIXEL_DEFAULT: //reference frame with no compress and pp out 8bit is this pixel format
#ifdef SUPPORT_DEC400
                if (frame_hwctx->pic_info[2].picdata.bit_depth_luma > 8
                     || frame_hwctx->pic_info[2].picdata.bit_depth_chroma > 8) {
                  if (frame_hwctx->pic_info[2].picdata.pic_compressed_status > 0) {
                    ENC_TB_ERROR_PRINT("should not get here!\n");
                    return -1;
                  } else {
                    options->inputFormat_ds = VCENC_YUV420_PLANAR_10BIT_P010_FB;
                  }
                } else {
                    if (frame_hwctx->pic_info[2].picdata.pic_format > DEC_OUT_FRM_NV21TILE) {
                      if (frame_hwctx->pic_info[2].picdata.pic_compressed_status == 2) {
                        options->inputFormat_ds = INPUT_FORMAT_YUV420_SEMIPLANAR_VU_8BIT_COMPRESSED_FB;
                      } else if (frame_hwctx->pic_info[2].picdata.pic_compressed_status == 0) {
                        options->inputFormat_ds = VCENC_YUV420_SEMIPLANAR_VU_8BIT_FB;
                      } else {
                        ENC_TB_ERROR_PRINT("should not get here!\n");
                        return -1;
                      }
                    } else if (frame_hwctx->pic_info[2].picdata.pic_format == DEC_OUT_FRM_RASTER_SCAN) {
                        options->inputFormat_ds = INPUT_FORMAT_PP_YUV420_SEMIPLANNAR;
                    } else {
                      if (frame_hwctx->pic_info[2].picdata.pic_compressed_status == 2) {
                        options->inputFormat_ds = INPUT_FORMAT_YUV420_SEMIPLANAR_8BIT_COMPRESSED_FB;
                      } else if (frame_hwctx->pic_info[2].picdata.pic_compressed_status == 0) {
                        options->inputFormat_ds = VCENC_YUV420_SEMIPLANAR_8BIT_FB;
                      } else {
                        ENC_TB_ERROR_PRINT("should not get here!\n");
                        return -1;
                      }
                    }
                }
#else
                if (frame_hwctx->pic_info[2].picdata.bit_depth_luma > 8
                     || frame_hwctx->pic_info[2].picdata.bit_depth_chroma > 8) {
                    options->inputFormat_ds = VCENC_YUV420_PLANAR_10BIT_P010_FB;
                }  else if (frame_hwctx->pic_info[2].picdata.pic_format == DEC_OUT_FRM_RASTER_SCAN) {
                    options->inputFormat_ds = INPUT_FORMAT_PP_YUV420_SEMIPLANNAR;
                } else {}
#endif
                break;
              case DEC_OUT_PIXEL_P010: //pp out 10bit is this pixel format
#ifdef SUPPORT_DEC400
                if (frame_hwctx->pic_info[2].picdata.pic_compressed_status == 2) {
                  options->inputFormat_ds = INPUT_FORMAT_YUV420_PLANAR_10BIT_P010_COMPRESSED_FB;
                } else if (frame_hwctx->pic_info[2].picdata.pic_compressed_status == 0) {
                  options->inputFormat_ds = VCENC_YUV420_PLANAR_10BIT_P010_FB;
                } else {
                  ENC_TB_ERROR_PRINT("should not get here!\n");
                  return -1;
                }
#else
                options->inputFormat_ds = VCENC_YUV420_PLANAR_10BIT_P010_FB; 
#endif
#if 0
                if (options->codecFormat == VCENC_VIDEO_CODEC_H264) {
                  options->profile = VCENC_H264_HIGH_10_PROFILE;
                  //pCml->level = VCENC_H264_LEVEL_6_2;
                } else if (options->codecFormat == VCENC_VIDEO_CODEC_HEVC) {
                  options->profile = VCENC_HEVC_MAIN_10_PROFILE;
                  //pCml->level = 0;
                }
#endif
                break;
              case DEC_OUT_PIXEL_RFC:
                ENC_TB_ERROR_PRINT("should not get here!\n");
                return -1;
              default:
                break;
            }
 
            ENC_TB_DEBUG_PRINT("get ds config: format %d, %dx%d, %dx%d\n", options->inputFormat_ds,
                    options->lumWidthSrc_ds, options->lumHeightSrc_ds, options->width_ds, options->height_ds);
        }
    }
  
  return 0;
  
}

static int preset_check(char *inputParam, HantroPreset_t *preset)
{
  if ((inputParam == NULL) || (preset == NULL))
    return -1;

  if (strcmp(inputParam, "superfast") == 0) {
    *preset = HANTRO_PRESET_SUPERFAST;
  } else if (strcmp(inputParam, "fast") == 0) {
    *preset = HANTRO_PRESET_FAST;
  } else if (strcmp(inputParam, "medium") == 0) {
    *preset = HANTRO_PRESET_MEDIUM;
  } else if (strcmp(inputParam, "slow") == 0) {
    *preset = HANTRO_PRESET_SLOW;
  } else if (strcmp(inputParam, "superslow") == 0) {
    *preset = HANTRO_PRESET_SUPERSLOW;
  } else {
    av_log(NULL, AV_LOG_ERROR, "unknow vcepreset %s\n", inputParam);
    return -1;
  }

  return 0;
}

static int set_opt_accord_preset(enum AVCodecID codec, HANTROH26xEncOptions *options, HantroPreset_t preset)
{
  
  if (codec == AV_CODEC_ID_HEVC) {
    switch (preset) {
      case HANTRO_PRESET_SUPERFAST:
        if (options->intraQpDelta == DEFAULT)
          options->intraQpDelta = -2;
        if (options->qpHdr == DEFAULT)
          options->qpHdr = -1;
        if (options->picRc == DEFAULT)
          options->picRc = 1;
        if (options->ctbRc == DEFAULT)
          options->ctbRc = 0;
        if (options->gopSize == DEFAULT)
          options->gopSize = 1;
        if (options->rdoLevel == DEFAULT)
          options->rdoLevel = 1;
        if (options->lookaheadDepth == DEFAULT)
          options->lookaheadDepth = 0;
        break;
      case HANTRO_PRESET_FAST:
        if (options->intraQpDelta == DEFAULT)
          options->intraQpDelta = -2;
        if (options->qpHdr == DEFAULT)
          options->qpHdr = -1;
        if (options->picRc == DEFAULT)
          options->picRc = 1;
        if (options->ctbRc == DEFAULT)
          options->ctbRc = 0;
        if (options->gopSize == DEFAULT)
          options->gopSize = 4;
        if (options->rdoLevel == DEFAULT)
          options->rdoLevel = 1;
        if (options->lookaheadDepth == DEFAULT)
          options->lookaheadDepth = 0;
        break;
      case HANTRO_PRESET_MEDIUM:
        if (options->intraQpDelta == DEFAULT)
          options->intraQpDelta = -2;
        if (options->qpHdr == DEFAULT)
          options->qpHdr = -1;
        if (options->picRc == DEFAULT)
          options->picRc = 1;
        if (options->ctbRc == DEFAULT)
          options->ctbRc = 0;
        if (options->gopSize == DEFAULT)
          options->gopSize = 4;
        if (options->rdoLevel == DEFAULT)
          options->rdoLevel = 1;
        if (options->lookaheadDepth == DEFAULT)
          options->lookaheadDepth = 20;
        break;
      case HANTRO_PRESET_SLOW:
        if (options->intraQpDelta == DEFAULT)
          options->intraQpDelta = -2;
        if (options->qpHdr == DEFAULT)
          options->qpHdr = -1;
        if (options->picRc == DEFAULT)
          options->picRc = 1;
        if (options->ctbRc == DEFAULT)
          options->ctbRc = 0;
        if (options->gopSize == DEFAULT)
          options->gopSize = 0;
        if (options->rdoLevel == DEFAULT)
          options->rdoLevel = 2;
        if (options->lookaheadDepth == DEFAULT)
          options->lookaheadDepth = 30;
        break;
      case HANTRO_PRESET_SUPERSLOW:
        if (options->intraQpDelta == DEFAULT)
          options->intraQpDelta = -2;
        if (options->qpHdr == DEFAULT)
          options->qpHdr = -1;
        if (options->picRc == DEFAULT)
          options->picRc = 1;
        if (options->ctbRc == DEFAULT)
          options->ctbRc = 0;
        if (options->gopSize == DEFAULT)
          options->gopSize = 0;
        if (options->rdoLevel == DEFAULT)
          options->rdoLevel = 3;
        if (options->lookaheadDepth == DEFAULT)
          options->lookaheadDepth = 40;
        break;
      case HANTRO_PRESET_NONE:
        break;
      default:
        av_log(NULL, AV_LOG_ERROR, "unknow preset %d\n", preset);
        return -1;
    }
  
  } else if (codec == AV_CODEC_ID_H264) {
    switch (preset) {
      case HANTRO_PRESET_SUPERFAST:
        if (options->intraQpDelta == DEFAULT)
          options->intraQpDelta = -2;
        if (options->qpHdr == DEFAULT)
          options->qpHdr = -1;
        if (options->picRc == DEFAULT)
          options->picRc = 1;
        if (options->ctbRc == DEFAULT)
          options->ctbRc = 0;
        if (options->gopSize == DEFAULT)
          options->gopSize = 1;
        if (options->lookaheadDepth == DEFAULT)
          options->lookaheadDepth = 0;
        break;
      case HANTRO_PRESET_FAST:
        if (options->intraQpDelta == DEFAULT)
          options->intraQpDelta = -2;
        if (options->qpHdr == DEFAULT)
          options->qpHdr = -1;
        if (options->picRc == DEFAULT)
          options->picRc = 1;
        if (options->ctbRc == DEFAULT)
          options->ctbRc = 0;
        if (options->gopSize == DEFAULT)
          options->gopSize = 4;
        if (options->lookaheadDepth == DEFAULT)
          options->lookaheadDepth = 0;
        break;
      case HANTRO_PRESET_MEDIUM:
        if (options->intraQpDelta == DEFAULT)
          options->intraQpDelta = -2;
        if (options->qpHdr == DEFAULT)
          options->qpHdr = -1;
        if (options->picRc == DEFAULT)
          options->picRc = 1;
        if (options->ctbRc == DEFAULT)
          options->ctbRc = 0;
        if (options->gopSize == DEFAULT)
          options->gopSize = 4;
        if (options->lookaheadDepth == DEFAULT)
          options->lookaheadDepth = 20;
        break;
      case HANTRO_PRESET_SLOW:
        if (options->intraQpDelta == DEFAULT)
          options->intraQpDelta = -2;
        if (options->qpHdr == DEFAULT)
          options->qpHdr = -1;
        if (options->picRc == DEFAULT)
          options->picRc = 1;
        if (options->ctbRc == DEFAULT)
          options->ctbRc = 0;
        if (options->gopSize == DEFAULT)
          options->gopSize = 0;
        if (options->lookaheadDepth == DEFAULT)
          options->lookaheadDepth = 30;
        break;
      case HANTRO_PRESET_SUPERSLOW:
        if (options->intraQpDelta == DEFAULT)
          options->intraQpDelta = -2;
        if (options->qpHdr == DEFAULT)
          options->qpHdr = -1;
        if (options->picRc == DEFAULT)
          options->picRc = 1;
        if (options->ctbRc == DEFAULT)
          options->ctbRc = 0;
        if (options->gopSize == DEFAULT)
          options->gopSize = 0;
        if (options->lookaheadDepth == DEFAULT)
          options->lookaheadDepth = 40;
        break;
      case HANTRO_PRESET_NONE:
        break;
      default:
        av_log(NULL, AV_LOG_ERROR, "unknow preset %d\n", preset);
        return -1;
      }	
  	}
  return 0;
}

static av_cold int hantro_preset_params_set(AVCodecContext *avctx)
{
  HANTROH26xEncContext * ctx = (HANTROH26xEncContext *)avctx->priv_data;
  HANTROH26xEncOptions * options = &ctx->options;
  struct test_bench * tb = (struct test_bench *)&ctx->tb;

  HantroPreset_t preset;
  i32 ret = 0;

  ENC_TB_DEBUG_PRINT("+++ vcepreset %s\n", ctx->preset);
  
  if (ctx->preset) {
    ret = preset_check(ctx->preset, (HantroPreset_t *)&preset);
    if (ret != 0) {
      return -1;
    }
    ret = set_opt_accord_preset(avctx->codec->id, options, preset);
    
    ENC_TB_DEBUG_PRINT("options->rdoLevel = %d\n", options->rdoLevel);

  } 

  return ret;
   
}

static void hantro_params_value_print(AVCodecContext *avctx)
{
  HANTROH26xEncContext * ctx = (HANTROH26xEncContext *)avctx->priv_data;
  HANTROH26xEncOptions * options = &ctx->options;
  struct test_bench * tb = (struct test_bench *)&ctx->tb;
  
  ENC_TB_DEBUG_PRINT("^^^ ctx->force_8bit = %d\n", ctx->force_8bit);
  ENC_TB_DEBUG_PRINT("^^^ ctx->bitdepth = %d\n", ctx->bitdepth);
  ENC_TB_DEBUG_PRINT("^^^ options->intraPicRate = %d\n", options->intraPicRate);
  ENC_TB_DEBUG_PRINT("^^^ options->bitrateWindow = %d\n", options->bitrateWindow);
  ENC_TB_DEBUG_PRINT("^^^ options->intraQpDelta = %d\n", options->intraQpDelta);    
  
  ENC_TB_DEBUG_PRINT("^^^ options->tolMovingBitRate = %d\n", options->tolMovingBitRate);
  ENC_TB_DEBUG_PRINT("^^^ options->bitVarRangeI = %d\n", options->bitVarRangeI);
  ENC_TB_DEBUG_PRINT("^^^ options->bitVarRangeP = %d\n", options->bitVarRangeP);
  ENC_TB_DEBUG_PRINT("^^^ options->bitVarRangeB = %d\n", options->bitVarRangeB);    

  ENC_TB_DEBUG_PRINT("^^^ options->qpHdr = %d\n", options->qpHdr);
  ENC_TB_DEBUG_PRINT("^^^ options->qpMin = %d\n", options->qpMin);
  ENC_TB_DEBUG_PRINT("^^^ options->qpMax = %d\n", options->qpMax);    
  ENC_TB_DEBUG_PRINT("^^^ options->tier = %d\n", options->tier);
  ENC_TB_DEBUG_PRINT("^^^ options->byteStream = %d\n", options->byteStream);
  ENC_TB_DEBUG_PRINT("^^^ options->videoRange = %d\n", options->videoRange);    

  ENC_TB_DEBUG_PRINT("^^^ options->picRc = %d\n", options->picRc);
  ENC_TB_DEBUG_PRINT("^^^ options->ctbRc = %d\n", options->ctbRc);
  ENC_TB_DEBUG_PRINT("^^^ options->tolCtbRcInter = %f\n", options->tolCtbRcInter);    
  ENC_TB_DEBUG_PRINT("^^^ options->tolCtbRcIntra = %f\n", options->tolCtbRcIntra);
  ENC_TB_DEBUG_PRINT("^^^ options->ctbRcRowQpStep = %d\n", options->ctbRcRowQpStep);
  ENC_TB_DEBUG_PRINT("^^^ options->hrdConformance = %d\n", options->hrdConformance);    

  ENC_TB_DEBUG_PRINT("^^^ options->cpbSize = %d\n", options->cpbSize);
  ENC_TB_DEBUG_PRINT("^^^ options->gopSize = %d\n", options->gopSize);
  ENC_TB_DEBUG_PRINT("^^^ options->gopLowdelay = %d\n", options->gopLowdelay);    

  ENC_TB_DEBUG_PRINT("^^^ options->qpMinI = %d\n", options->qpMinI);
  ENC_TB_DEBUG_PRINT("^^^ options->qpMaxI = %d\n", options->qpMaxI);
  ENC_TB_DEBUG_PRINT("^^^ options->bFrameQpDelta = %d\n", options->bFrameQpDelta);    

  ENC_TB_DEBUG_PRINT("^^^ options->chromaQpOffset = %d\n", options->chromaQpOffset);
  ENC_TB_DEBUG_PRINT("^^^ options->vbr = %d\n", options->vbr);
  ENC_TB_DEBUG_PRINT("^^^ options->userData = %p\n", options->userData);    

  ENC_TB_DEBUG_PRINT("^^^ options->constChromaEn = %d\n", options->constChromaEn);
  ENC_TB_DEBUG_PRINT("^^^ options->constCb = %d\n", options->constCb);
  ENC_TB_DEBUG_PRINT("^^^ options->constCr = %d\n", options->constCr);    

  ENC_TB_DEBUG_PRINT("^^^ options->rdoLevel = %d\n", options->rdoLevel);
  ENC_TB_DEBUG_PRINT("^^^ options->ssim = %d\n", options->ssim);
  ENC_TB_DEBUG_PRINT("^^^ options->vui_timing_info_enable = %d\n", options->vui_timing_info_enable);    

  ENC_TB_DEBUG_PRINT("^^^ options->lookaheadDepth = %d\n", options->lookaheadDepth);
  ENC_TB_DEBUG_PRINT("^^^ options->crf = %d\n", options->crf);

}

static void *frame_enc_process(void *arg)
{
  AVCodecContext *avctx = (AVCodecContext *)arg;
  HANTROH26xEncContext * ctx = (HANTROH26xEncContext *)avctx->priv_data;
  HANTROH26xEncOptions * options = &ctx->options;
  struct test_bench * tb = (struct test_bench *)&ctx->tb;
  VCEncIn *pEncIn = (VCEncIn *)&(tb->encIn);
  VCEncOut *encOut = (VCEncOut *)&ctx->encOut;
  
  int ret = 0;
  int streamSize = 0;
  int flushRet = 0;
  int *got_packet = 0;
  int i = 0;

  EncOutData_t *out_buffer = NULL;
  
  //frame_fifo_process(avctx);

  while ((ctx->flushState != HANTRO_FLUSH_ENCEND) && (ctx->flushState != HANTRO_FLUSH_ERROR)) {

    ENC_TB_DEBUGV_PRINT("[%d]... \n", tb->enc_index);

    if (ctx->EncProcessTerm == HANTRO_TRUE) {
      goto error;
    }

    if ((ctx->injectFrameCnt < ctx->holdBufNum) && ctx->forced_idr && (avctx->internal->draining == 0)) {
      usleep(10);
      continue;
    }

    switch (ctx->flushState) {
      case HANTRO_FLUSH_IDLE:
        ctx->TransFlushPic = HANTRO_FALSE;
        flushRet = hantro_encode_encode(avctx, NULL, NULL, (int *)&streamSize);
        ENC_TB_DEBUGV_PRINT("+++ hantro_encode_encode ret = %d\n", flushRet);
        ENC_TB_DEBUGV_PRINT("+++ ctx->TransFlushPic = %d\n", ctx->TransFlushPic);
        
        if (flushRet < 0) {
          /* need error process */
          ENC_TB_ERROR_PRINT("%s error at L%d\n", __FUNCTION__, __LINE__);
          goto error;
        } 
    
        if ((ctx->TransFlushPic == HANTRO_TRUE) && (avctx->internal->draining == 1)) {
          ctx->flushState = HANTRO_FLUSH_PREPARE;
        }

        usleep(10);
        break;
    
      case HANTRO_FLUSH_PREPARE:
        hantro_trans_flush_set(avctx);
        break;
      
      case HANTRO_FLUSH_TRANSPIC: /* flush data in dec fifo */
        flushRet = hantro_encode_encode(avctx, NULL, NULL, (int *)&streamSize);
        ENC_TB_DEBUG_PRINT("hantro_encode_encode ret = %d\n", flushRet);
        
        if ((flushRet == -1) || (flushRet == VCENC_NULL_ARGUMENT)) {
          /* need error process */
          goto error;
        }
      
        break;	
      
      case HANTRO_FLUSH_ENCDATA:
      	flushRet = hantro_encode_flush(avctx, (int *)&streamSize, NULL, got_packet);
        if (flushRet < 0) {
          ENC_TB_ERROR_PRINT("hantro_encode_flush error. ret = %d\n", ret);
          goto error;
        }
        break;
      
      case HANTRO_FLUSH_FINISH:
        ret = hantro_encode_end(avctx, (int *)&streamSize, ctx->outPkt, got_packet);
        if (ret != 0) {
          ENC_TB_ERROR_PRINT("hantro_encode_end error. ret = %d\n", ret);
          goto error;
        }
        ctx->flushState = HANTRO_FLUSH_ENCEND;
        break;
      //case HANTRO_FLUSH_ENCEND:
      //  break;
    }

    //FifoPush(ctx->TranscodeFifo, flushRet, FIFO_EXCEPTION_DISABLE);
  }

#if 0
  while (HANTRO_TRUE) {
    /* add4debug */
    FifoPop(ctx->EmptyBuf, &out_buffer, FIFO_EXCEPTION_DISABLE);
    /* add end */    
  }
#endif

  return NULL;

error:
  ctx->flushState = HANTRO_FLUSH_ERROR;
  ENC_TB_ERROR_PRINT("%s got error, will return\n", __FUNCTION__);
  return NULL;
}

static int init_enc_thread(AVCodecContext *avctx)
{
  HANTROH26xEncContext * ctx = (HANTROH26xEncContext *)avctx->priv_data;
  HANTROH26xEncOptions * options = &ctx->options;
  struct test_bench * tb = (struct test_bench *)&ctx->tb;

  ENC_TB_DEBUG_PRINT("%s enter\n", __FUNCTION__);

  //Fifo_Init(avctx);
#if 0
  if (pthread_mutexattr_init(&ctx->rcv_packet_mutex_attr) < 0)
    return -1;
  if (pthread_mutex_init(&ctx->rcv_packet_mutex, &ctx->rcv_packet_mutex_attr) < 0)
    return -1;  
  pthread_mutexattr_destroy(&ctx->rcv_packet_mutex_attr);
#endif

  if (pthread_attr_init(&ctx->enc_thread_attr) < 0)
    return -1;
  if (pthread_create(&ctx->frame_enc_thread, &ctx->enc_thread_attr, &frame_enc_process, avctx) < 0)
    return -1;
  pthread_attr_destroy(&ctx->enc_thread_attr);

  return 0;
}

static int wait_enc_thread_finish(AVCodecContext *avctx)
{
  HANTROH26xEncContext * ctx = (HANTROH26xEncContext *)avctx->priv_data;
  struct test_bench * tb = (struct test_bench *)&ctx->tb;

  ENC_TB_DEBUG_PRINT("\n");

  if (ctx == NULL) {
    ENC_TB_ERROR_PRINT("ctx is NULL\n");
    return -1;
  }	

  if (ctx->frame_enc_thread) {
    pthread_join(ctx->frame_enc_thread, NULL);
  }

  return 0;
}

av_cold int hantro_encode_init(AVCodecContext *avctx)
{
    HANTROH26xEncContext * ctx = (HANTROH26xEncContext *)avctx->priv_data;
    HANTROH26xEncOptions * options = &ctx->options;
    i32 ret = OK;
    VCEncApiVersion apiVer;
    int i;
    struct test_bench * tb = (struct test_bench *)&ctx->tb;
    int pp_index = -1;

    AVHANTRODeviceContext *device_hwctx;
    AVHANTROFramesContext *frame_hwctx;
    AVHWDeviceContext *device_ctx;
    AVHWFramesContext *hwframe_ctx;	
    
    memset(tb, 0, sizeof(struct test_bench));

#ifdef FB_SYSLOG_ENABLE
    if (avctx->codec->id == AV_CODEC_ID_HEVC) {
      sprintf(&ctx->module_name[0], "%s", "HEVCENC");
    } else if (avctx->codec->id == AV_CODEC_ID_H264) {
      sprintf(&ctx->module_name[0], "%s", "H264ENC");
    }
    tb->log_header.module_name = &ctx->module_name[0];
#ifdef DRV_NEW_ARCH
    tb->log_header.device_id = get_deviceId(options->device);
#else
    tb->log_header.device_id = 0;
#endif
#endif
    

#if defined(VCE_MEM_ERR_TEST) && defined(VCE_EDMA_ERR_TEST)
    ENC_TB_ERROR_PRINT("=====%s(%d) vce do err_test, vce_memory_err_shadow %d, vce_edma_err_shadow %d, vce_memory_err_cnt %d, vce_edma_err_cnt %d\n", __FUNCTION__, __LINE__, 
        options->vce_memory_err_shadow, options->vce_edma_err_shadow, options->vce_memory_err_cnt, options->vce_edma_err_cnt);
#endif

    av_log(avctx, AV_LOG_TRACE, "%s(%d) %dx%d\n", __FUNCTION__, __LINE__, avctx->width, avctx->height);

    apiVer = VCEncGetApiVersion();

    ENC_TB_INFO_PRINT("HEVC Encoder API version %d.%d\n", apiVer.major,
          apiVer.minor);

    hantro_encode_set_default_opt(avctx);
	
    /* hw device & frame init */
    av_log(avctx, AV_LOG_TRACE, "avctx->hw_frames_ctx = %p\n", avctx->hw_frames_ctx);
    if (avctx->hw_frames_ctx) {
        ctx->hwframe = av_buffer_ref(avctx->hw_frames_ctx);
        if (!ctx->hwframe) {
            ret = AVERROR(ENOMEM);
            goto error_exit;
        }
    
        hwframe_ctx = (AVHWFramesContext*)ctx->hwframe->data;
    
        av_log(avctx, AV_LOG_TRACE, "hwframe_ctx = %p\n", hwframe_ctx);
        
        ctx->hwdevice = av_buffer_ref(hwframe_ctx->device_ref);
        if (!ctx->hwdevice) {
            ret = AVERROR(ENOMEM);
            goto error_exit;
        }
    } else {
        av_log(avctx, AV_LOG_TRACE, "%s(%d) avctx->hw_device_ctx = %p\n", __FUNCTION__, __LINE__, avctx->hw_device_ctx);
        if (avctx->hw_device_ctx) {
            ctx->hwdevice = av_buffer_ref(avctx->hw_device_ctx);
            av_log(avctx, AV_LOG_TRACE, "%s(%d) ctx->hwdevice = %p\n", __FUNCTION__, __LINE__, ctx->hwdevice);
            if (!ctx->hwdevice) {
                ret = AVERROR(ENOMEM);
                goto error_exit;
            }
        } else {
            ret = av_hwdevice_ctx_create((AVBufferRef *)&ctx->hwdevice, AV_HWDEVICE_TYPE_HANTRO, ctx->dev_name, NULL, 0);
            if (ret < 0)
                goto error_exit;
        }
    
        ctx->hwframe = av_hwframe_ctx_alloc(ctx->hwdevice);
        if (!ctx->hwframe) {
            av_log(avctx, AV_LOG_ERROR, "av_hwframe_ctx_alloc failed\n");
            ret = AVERROR(ENOMEM);
            goto error_exit;
        }
    
        hwframe_ctx = (AVHWFramesContext*)ctx->hwframe->data;
    }

    if (!hwframe_ctx->pool) {
        hwframe_ctx->format = AV_PIX_FMT_HANTRO;
        hwframe_ctx->sw_format = avctx->sw_pix_fmt;
        hwframe_ctx->width = avctx->width;
        hwframe_ctx->height = avctx->height;
    
        if ((ret = av_hwframe_ctx_init(ctx->hwframe)) < 0) {
            av_log(avctx, AV_LOG_ERROR, "av_hwframe_ctx_init failed\n");
            return 0;
        }
    }

    device_ctx   = hwframe_ctx->device_ctx;
    device_hwctx = device_ctx->hwctx;
    frame_hwctx  = hwframe_ctx->hwctx;

    options->priority = device_hwctx->priority;
    options->device   = device_hwctx->device;
    options->mem_id   = frame_hwctx->task_id;

    for (int kk = 0; kk < 5; kk ++) {
        ENC_TB_DEBUG_PRINT("[%p] frame_hwctx->pic_info[%d].enabled = %d.\n", frame_hwctx, kk, frame_hwctx->pic_info[kk].enabled);
        ENC_TB_DEBUG_PRINT("frame_hwctx->pic_info[%d].format = %d.\n", kk, frame_hwctx->pic_info[kk].format);
        ENC_TB_DEBUG_PRINT("frame_hwctx->pic_info[%d].width = %d.\n", kk, frame_hwctx->pic_info[kk].width);
        ENC_TB_DEBUG_PRINT("frame_hwctx->pic_info[%d].height = %d.\n", kk, frame_hwctx->pic_info[kk].height);
        ENC_TB_DEBUG_PRINT("frame_hwctx->pic_info[%d].crop.enabled = %d.\n", kk, frame_hwctx->pic_info[kk].crop.enabled);
        ENC_TB_DEBUG_PRINT("frame_hwctx->pic_info[%d].crop.x = %d.\n", kk, frame_hwctx->pic_info[kk].crop.x);
        ENC_TB_DEBUG_PRINT("frame_hwctx->pic_info[%d].crop.y = %d.\n", kk, frame_hwctx->pic_info[kk].crop.y);
        ENC_TB_DEBUG_PRINT("frame_hwctx->pic_info[%d].crop.w = %d.\n", kk, frame_hwctx->pic_info[kk].crop.w);
        ENC_TB_DEBUG_PRINT("frame_hwctx->pic_info[%d].crop.h = %d.\n", kk, frame_hwctx->pic_info[kk].crop.h);
        ENC_TB_DEBUG_PRINT("frame_hwctx->pic_info[%d].scale.enabled = %d.\n", kk, frame_hwctx->pic_info[kk].scale.enabled);
        ENC_TB_DEBUG_PRINT("frame_hwctx->pic_info[%d].scale.w = %d.\n", kk, frame_hwctx->pic_info[kk].scale.w);
        ENC_TB_DEBUG_PRINT("frame_hwctx->pic_info[%d].scale.h = %d.\n", kk, frame_hwctx->pic_info[kk].scale.h);

        ENC_TB_DEBUG_PRINT("frame_hwctx->pic_info[%d].picdata.is_interlaced = %d.\n", kk, frame_hwctx->pic_info[kk].picdata.is_interlaced);
        ENC_TB_DEBUG_PRINT("frame_hwctx->pic_info[%d].picdata.crop_out_width = %d.\n", kk, frame_hwctx->pic_info[kk].picdata.crop_out_width);
        ENC_TB_DEBUG_PRINT("frame_hwctx->pic_info[%d].picdata.crop_out_height = %d.\n", kk, frame_hwctx->pic_info[kk].picdata.crop_out_height);
        ENC_TB_DEBUG_PRINT("frame_hwctx->pic_info[%d].picdata.pic_format = %d.\n", kk, frame_hwctx->pic_info[kk].picdata.pic_format);
        ENC_TB_DEBUG_PRINT("frame_hwctx->pic_info[%d].picdata.pic_pixformat = %d.\n", kk, frame_hwctx->pic_info[kk].picdata.pic_pixformat);
        ENC_TB_DEBUG_PRINT("frame_hwctx->pic_info[%d].picdata.bit_depth_luma = %d.\n", kk, frame_hwctx->pic_info[kk].picdata.bit_depth_luma);
        ENC_TB_DEBUG_PRINT("frame_hwctx->pic_info[%d].picdata.bit_depth_chroma = %d.\n", kk, frame_hwctx->pic_info[kk].picdata.bit_depth_chroma);
        ENC_TB_DEBUG_PRINT("frame_hwctx->pic_info[%d].picdata.pic_compressed_status = %d.\n", kk, frame_hwctx->pic_info[kk].picdata.pic_compressed_status);

        ENC_TB_DEBUG_PRINT("avctx [%p].\n", avctx);
    }

    for (pp_index = 0; pp_index < 5; pp_index++) {
        if (frame_hwctx->pic_info[pp_index].enabled == 1) {
             break;
        }
    }

    if (pp_index == 5) {
        av_log(avctx, AV_LOG_ERROR, "can't find pp_index\n");
        return -1;
    }
    
    ENC_TB_DEBUG_PRINT("find pp_index = %d\n", pp_index);

    ctx->pp_index = pp_index;

    if ((pp_index == HANTRO_DEC_OUT_RFC)||(pp_index == HANTRO_DEC_OUT_PP0)) {
    	options->enc_index = 0;
    } else {
    	options->enc_index = pp_index - 1;
    }
    ENC_TB_DEBUG_PRINT("set options->enc_index = %d\n", options->enc_index);


    ctx->hantroParamTable = (HantroParamsDef_t *)&HantroParamTable[0];

    GetDefaultHantroParams(ctx);
    hantro_params_value_print(avctx);

    /* hantro_params get */
    if (ctx->hantro_params) {
        AVDictionary *dict    = NULL;
        AVDictionaryEntry *en = NULL;
    
        if (!av_dict_parse_string(&dict, ctx->hantro_params, "=", ":", 0)) {
            while ((en = av_dict_get(dict, "", en, AV_DICT_IGNORE_SUFFIX))) {
                if (GetHantroParamsFromCmd(ctx, en->key, en->value) < 0)
                    av_log(avctx, AV_LOG_WARNING,
                           "Error parsing option '%s = %s'. Please check if it is valid hantro-params option.\n",
                            en->key, en->value);
            }
            av_dict_free(&dict);
        }
    }

    ENC_TB_DEBUG_PRINT("after get hantro-params from cmd !\n");
    hantro_params_value_print(avctx);
	
    /* preset params set */
    ret = hantro_preset_params_set(avctx); 
    if (ret < 0) {
      av_log(avctx, AV_LOG_ERROR, "hantro_preset_params_set error, please check your cmd !\n");
    }

    hantro_encode_get_options(avctx);
  
    /* we set vce param according first decoded pic */
    ret = hantro_encode_set_vceparam(avctx, frame_hwctx);
    if (ret != 0) {
      ENC_TB_ERROR_PRINT("hantro_encode_set_vceparam error.\n");
      goto error_exit;
    }
  
    /* add for debug */
    ENC_TB_DEBUG_PRINT("+++ options->profile = %d, options->level = %d\n", options->profile, options->level);


  tb->enc_index = options->enc_index;
  
  /* the number of output stream buffers */
  //tb->streamBufNum = options->streamBufChain ? 2 : 1;
  tb->streamBufNum = MAX_OUTPUT_FIFO_DEPTH;


  /* get GOP configuration */  
  tb->gopSize = MIN(options->gopSize, MAX_GOP_SIZE);
  if (tb->gopSize==0 && options->gopLowdelay)
  {
    tb->gopSize = 4;
  }
  memset (ctx->gopPicCfg, 0, sizeof(ctx->gopPicCfg));
  tb->encIn.gopConfig.pGopPicCfg = ctx->gopPicCfg;
  memset(ctx->gopPicSpecialCfg, 0, sizeof(ctx->gopPicSpecialCfg));
  tb->encIn.gopConfig.pGopPicSpecialCfg = ctx->gopPicSpecialCfg;
  if ((ret = InitGopConfigs (tb->gopSize, options, &(tb->encIn.gopConfig), tb->encIn.gopConfig.gopCfgOffset, HANTRO_FALSE)) != 0)  {
    ENC_TB_ERROR_PRINT("InitGopConfigs failed.\n");
    goto error_exit;
  }
  if(options->lookaheadDepth) {
    memset (ctx->gopPicCfgPass2, 0, sizeof(ctx->gopPicCfgPass2));
    tb->encIn.gopConfig.pGopPicCfg = ctx->gopPicCfgPass2;
    tb->encIn.gopConfig.size = 0;
    memset(ctx->gopPicSpecialCfg, 0, sizeof(ctx->gopPicSpecialCfg));
    tb->encIn.gopConfig.pGopPicSpecialCfg = ctx->gopPicSpecialCfg;
    if ((ret = InitGopConfigs (tb->gopSize, options, &(tb->encIn.gopConfig), tb->encIn.gopConfig.gopCfgOffset, HANTRO_TRUE)) != 0)
    {
      ENC_TB_ERROR_PRINT("InitGopConfigs 2pass failed.\n"); 
      goto error_exit;
    }
    tb->encIn.gopConfig.pGopPicCfgPass1 = ctx->gopPicCfg;
    tb->encIn.gopConfig.pGopPicCfg = tb->encIn.gopConfig.pGopPicCfgPass2 = ctx->gopPicCfgPass2;
  }

    if (options->lookaheadDepth) {
        //2pass need add lookahead number
        ctx->max_frames_delay = 17 + options->lookaheadDepth;
    } else {
      if (options->gopSize == 0) {
        if (ctx->forced_idr) {
          ctx->max_frames_delay = MAX_GOP_SIZE + 2 + 1 + MAX_GOP_SIZE + 1; /* need store (GOP_size + 1) of data ahead of to calc idr */
        } else {
          ctx->max_frames_delay = MAX_GOP_SIZE + 2 + 1; /* superfast need store 1 more buf, when 3 outpus(4 outputs total) occur error need exit */
        }
      } else {
        if (ctx->forced_idr) {
          ctx->max_frames_delay = options->gopSize + 2 + 1 + options->gopSize + 1;
        } else {
          ctx->max_frames_delay = options->gopSize + 2 + 1;
        }
      }
    }
    ENC_TB_DEBUG_PRINT("ctx->max_frames_delay = %d\n", ctx->max_frames_delay);
    if (ctx->max_frames_delay > device_hwctx->max_frames_delay) {
        device_hwctx->max_frames_delay = ctx->max_frames_delay;
    }
    ENC_TB_DEBUG_PRINT("device_hwctx->max_frames_delay = %d\n", device_hwctx->max_frames_delay);

  /* add4debug */
  ctx->num_dec_max = device_hwctx->max_frames_delay;
  /* add end */
  ctx->EncoderIsOpen  = HANTRO_FALSE;
  ctx->EncoderIsStart = HANTRO_FALSE;
  ctx->EncoderIsEnd   = HANTRO_FALSE;
  //ctx->EncoderFlushPic= HANTRO_FALSE;
  ctx->TransFlushPic  = HANTRO_FALSE;
  //ctx->EncFlushFlag   = HANTRO_FALSE;
  ctx->flushState  = HANTRO_FLUSH_IDLE;

  ctx->picture_cnt_bk = 0;
  ctx->injectFrameCnt = 0;
  ctx->gopLength = (tb->gopSize == 0) ? 8 : tb->gopSize;
  ENC_TB_DEBUG_PRINT("ctx->gopLength = %d\n", ctx->gopLength);

  /*set hold buf num*/
  if (ctx->forced_idr) {
    if (options->lookaheadDepth != 0) {
      ctx->holdBufNum = ctx->max_frames_delay;
    } else {
      ctx->holdBufNum = ctx->gopLength + 1 + ctx->gopLength; //ctx->gopLength + 1;
    }
  }

  IDRPocArrayInit(ctx);

  ctx->outPkt = av_packet_alloc();
  if (!ctx->outPkt)
    goto error_exit;

  ENC_TB_DEBUG_PRINT("ctx->outPkt = %p\n", ctx->outPkt);
  
  ret = hantro_encode_open((VCEncInst *)&ctx->hantro_encoder, tb, options);
  if(ret != 0)
    goto error_exit;

  /* add4debug */
  if (ctx->EncoderIsStart == HANTRO_FALSE) {
    ctx->EncoderIsStart = HANTRO_TRUE;

    int startHeaderSize = 0; //only pass through

    ENC_TB_DEBUG_PRINT("before hantro_encode_start: ctx->outPkt->data = %p, startHeaderSize = %d\n", (void *)ctx->outPkt->data, startHeaderSize);

    ret = hantro_encode_start(avctx, ctx->outPkt, (int *)&startHeaderSize);

    if (ret != 0) {
      ENC_TB_ERROR_PRINT("hantro_encode_start error. ret = %d\n", ret);
      /* todo: close encoder ...*/
      goto error_exit;
    } else {
      ENC_TB_DEBUG_PRINT("will send start code to pkt\n");
      ctx->injectFrameCnt = 1; /* IDR need store data ahead*/
	  
      ///////////////////////////
      /* printf start header */
      #if 0
      int kk = 0;
      //uint8_t *pp = (uint8_t *)tb->outbufMem[0]->rc_virtualAddress;
      uint8_t *pp = ctx->outPkt->data;
      
      av_log(NULL, AV_LOG_INFO, "\nbefore hantro_encode_receive_packet\n");
      for (kk = 0; kk < ctx->outPkt->size; kk++) {
      	av_log(NULL, AV_LOG_INFO, "0x%x ", *(pp+kk));
      	if (kk%16==15)
      		av_log(NULL, AV_LOG_INFO, "\n");
      }
      av_log(NULL, AV_LOG_INFO, "\n");
      #endif
      
      ///////////////////////////

      //pkt->data = ctx->outPkt->data;
      //pkt->size = ctx->outPkt->size;
      if (ctx->outPkt->size) {
        avctx->extradata = av_malloc(ctx->outPkt->size);
        if (avctx->extradata == NULL) {
          ret = AVERROR(ENOMEM);
          goto error_exit;
        }

#ifdef VCE_MEM_ERR_TEST
        if(VceMemoryCheck(options) != 0){
          av_log(avctx, AV_LOG_ERROR, "[%s,%d]vce force memory error in function\n", __FUNCTION__, __LINE__);
          ret = AVERROR(ENOMEM);
          goto error_exit;
        }
#endif

        memcpy(avctx->extradata, ctx->outPkt->data, ctx->outPkt->size);
        avctx->extradata_size = ctx->outPkt->size;
        av_packet_unref(ctx->outPkt);
      }

      av_log(avctx, AV_LOG_DEBUG, "after hantro_encode_start: ctx->outPkt->data = %p, ctx->outPkt->size = %d\n", (void *)ctx->outPkt->data, ctx->outPkt->size);
      av_log(avctx, AV_LOG_DEBUG, "after hantro_encode_start: avctx->extradata = %p, avctx->extradata = %d\n", (void *)avctx->extradata, avctx->extradata_size);
      //return 0;
    }
      
  }
  
  for (i = 0; i < MAX_WAIT_DEPTH; i++) {
    pthread_mutex_init(&ctx->PicWaitForEnc[i].trans_mutex, NULL);
  }

  pthread_mutex_init(&ctx->rcv_packet_mutex, NULL);
  
  ret = init_enc_thread(avctx);
  if (ret == 0) {
    return ret;
  } else {
    for (i = 0; i < MAX_WAIT_DEPTH; i++) {
      pthread_mutex_destroy(&ctx->PicWaitForEnc[i].trans_mutex);
    }
	pthread_mutex_destroy(&ctx->rcv_packet_mutex);
  }
  /* add end */

error_exit:
  if (ctx->hantro_encoder) {
    FreeRes(ctx->hantro_encoder, tb);
    CloseEncoder(ctx->hantro_encoder, tb);
    ctx->hantro_encoder = NULL;
  }

  av_buffer_unref(&ctx->hwframe);
  av_buffer_unref(&ctx->hwdevice);
  return ret;
}

av_cold int hantro_encode_open(VCEncInst *hantro_encoder, struct test_bench *tb, HANTROH26xEncOptions *options)
{
  i32 ret = OK;
  
  /* Encoder initialization */
#ifdef DRV_NEW_ARCH
  tb->priority = options->priority;
  tb->device = options->device;
  if (tb->device == NULL)
  {
    ENC_TB_ERROR_PRINT("device node is NULL\n");
    goto error_exit;
  }
  ENC_TB_DEBUG_PRINT("device node is %s\n", tb->device);
  tb->mem_id = options->mem_id;
  ENC_TB_DEBUG_PRINT("get task id %d\n", tb->mem_id);
#endif

  if ((ret = OpenEncoder(options, hantro_encoder, tb)) != 0)
  {
    ENC_TB_ERROR_PRINT("[%d]OpenEncoder failed. ret is %d\n", tb->enc_index, ret);
    goto error_exit;
  }

  tb->firstPic  = options->firstPic;
  tb->lastPic   = options->lastPic;
  tb->inputRateNumer      = options->inputRateNumer;
  tb->inputRateDenom      = options->inputRateDenom;
  tb->outputRateNumer      = options->outputRateNumer;
  tb->outputRateDenom      = options->outputRateDenom;
  tb->width      = options->width;
  tb->height     = options->height;
  tb->input_alignment = (options->exp_of_input_alignment==0?0:(1<<options->exp_of_input_alignment));
  tb->ref_alignment = (options->exp_of_ref_alignment==0?0:(1<<options->exp_of_ref_alignment));
  tb->ref_ch_alignment = (options->exp_of_ref_ch_alignment==0?0:(1<<options->exp_of_ref_ch_alignment));
  tb->formatCustomizedType = options->formatCustomizedType;
  ENC_TB_DEBUG_PRINT("options->exp_of_input_alignment = %d\n", options->exp_of_input_alignment);
  ENC_TB_DEBUG_PRINT("tb->input_alignment = %d\n", tb->input_alignment);
  tb->idr_interval   = options->intraPicRate;
  tb->byteStream   = options->byteStream;
  tb->interlacedFrame = options->interlacedFrame;
  tb->parallelCoreNum  = options->parallelCoreNum;
  tb->buffer_cnt = tb->frame_delay = tb->parallelCoreNum;
  if(options->lookaheadDepth) {
    i32 delay = CUTREE_BUFFER_CNT(options->lookaheadDepth)-1;
#if 0
    tb->frame_delay += MIN(delay, options->lastPic-options->firstPic+1); /* lookahead depth */
#else
    tb->frame_delay += MAX(delay, 8);
#endif
    ENC_TB_DEBUG_PRINT("+++ tb->frame_delay = %d ...\n", tb->frame_delay);

    /* consider gop8->gop4 reorder: 8 4 2 1 3 6 5 7 -> 4 2 1 3 8 6 5 7
     * at least 4 more buffers are needed to avoid buffer overwrite in pass1 before consumed in pass2*/
    tb->buffer_cnt = tb->frame_delay + 4;
  }
  tb->encIn.gopConfig.idr_interval = tb->idr_interval;
  tb->encIn.gopConfig.gdrDuration = options->gdrDuration;
  tb->encIn.gopConfig.firstPic = tb->firstPic;
  tb->encIn.gopConfig.lastPic = tb->lastPic;
  tb->encIn.gopConfig.outputRateNumer = tb->outputRateNumer;      /* Output frame rate numerator */
  tb->encIn.gopConfig.outputRateDenom = tb->outputRateDenom;      /* Output frame rate denominator */
  tb->encIn.gopConfig.inputRateNumer = tb->inputRateNumer;      /* Input frame rate numerator */
  tb->encIn.gopConfig.inputRateDenom = tb->inputRateDenom;      /* Input frame rate denominator */
  tb->encIn.gopConfig.gopLowdelay = options->gopLowdelay;
  tb->encIn.gopConfig.interlacedFrame = tb->interlacedFrame;

  /* Set the test ID for internal testing,
   * the SW must be compiled with testing flags */
  VCEncSetTestId(*hantro_encoder, options->testId);

  /* Allocate input and output buffers */
  if ((ret = AllocRes(options, *hantro_encoder, tb)) != 0)
  {
    ENC_TB_ERROR_PRINT("[%d]AllocRes failed.\n", tb->enc_index);
    ret = -1;
    goto error_exit;
  }

#ifdef VCE_MEM_ERR_TEST
    if(VceMemoryCheck(options) != 0){
      ENC_TB_ERROR_PRINT("vce force memory error in function\n");
      ret = -1;
      goto error_exit;
    }
#endif

  /* add for multi out */
  if ((ret = vce_fifo_init(*hantro_encoder)) != 0)
  {
    ENC_TB_ERROR_PRINT("vce_fifo_init failed\n");
    goto error_exit;
  }

  return 0;

error_exit:
  if (ret != 0) {
    ENC_TB_ERROR_PRINT("[%d]encode init fails, ret is %d\n", tb->enc_index, ret);
  }
	
  if (*hantro_encoder) {
    FreeRes(*hantro_encoder, tb);
    CloseEncoder(*hantro_encoder, tb);
    *hantro_encoder = NULL;
  }
  
  return ret;
}

/**/
static int hantro_processFrame(AVCodecContext *avctx, AVPacket *pkt, EncOutData_t *out_buffer, int stratHeaderSize)
{
  HANTROH26xEncContext * ctx = (HANTROH26xEncContext *)avctx->priv_data;
  HANTROH26xEncOptions * options = &ctx->options;
  i32 ret = OK;
  struct test_bench * tb = (struct test_bench *)&ctx->tb;
  VCEncIn *pEncIn = (VCEncIn *)&(tb->encIn);
  VCEncOut *pEncOut = (VCEncOut *)&ctx->encOut;

  SliceCtl_s *ctl = tb->sliceCtlOut;
  int streamSize = pEncOut->streamSize;

  if (out_buffer == NULL) {
    ENC_TB_ERROR_PRINT("%s error. out_buffer is NULL.\n", __FUNCTION__);
    return -1;
  }
  
  if(options->lookaheadDepth && pEncOut->codingType == VCENC_INTRA_FRAME)
    ctx->frameCntOutput = 0;

  VCEncGetRateCtrl(ctx->hantro_encoder, (VCEncRateCtrl *)&ctx->rc);
  /* Write scaled encoder picture to file, packed yuyv 4:2:2 format */
  WriteScaled((u32 *)pEncOut->scaledPicture, ctx->hantro_encoder);

  /* write cu encoding information to file <cuInfo.txt> */
  WriteCuInformation(tb, ctx->hantro_encoder, pEncOut, options, tb->picture_enc_cnt-1, pEncIn->poc);

  pEncIn->timeIncrement = tb->outputRateDenom;

#if 0  
  if (stratHeaderSize != 0) {
    streamSize += ctx->outPkt->size;
  }
#endif

  if (streamSize != 0) {
#if 0  	
    //multi-core: output bitstream has (tb->parallelCoreNum-1) delay
    i32 coreIdx = (tb->picture_enc_cnt -1 - (tb->frame_delay-1)) % tb->parallelCoreNum;
    i32 iBuf;
    for (iBuf = 0; iBuf < tb->streamBufNum; iBuf ++)
      tb->outbufMem[iBuf] = &(tb->outbufMemFactory[coreIdx][iBuf]);

	//FifoPop(ctx->EmptyBuf, &out_buffer, FIFO_EXCEPTION_DISABLE);
    if (stratHeaderSize != 0) {
      out_buffer->headerData    = ctx->outPkt->data;
      out_buffer->headerSize    = ctx->outPkt->size;
    } else {
      out_buffer->headerData    = NULL;
      out_buffer->headerSize    = 0;;       
    }

    out_buffer->streamSize    = pEncOut->streamSize; //streamSize; //pEncOut->streamSize;
    out_buffer->outbufMem[out_buffer->buf_index]  =  tb->outbufMem[out_buffer->encOutBufIndex]; //tb->outbufMem[out_buffer->buf_index];
    out_buffer->poc_encoded   = pEncOut->indexEncoded;
    out_buffer->inTwoPassWait = HANTRO_FALSE;

    FifoPush(ctx->OutputFifo, out_buffer, FIFO_EXCEPTION_DISABLE);
#endif

    //if ((stratHeaderSize != 0) && (tb->picture_enc_cnt == 1)) {
    if (tb->picture_enc_cnt == 1) {
      ENC_TB_DEBUG_PRINT("\n");

      /* add for header data changed */
      avctx->extradata = av_realloc((void *)avctx->extradata, (size_t)pEncOut->header_size);
      memcpy(avctx->extradata, pEncOut->header_buffer, pEncOut->header_size);
      out_buffer->headerData    = avctx->extradata; //ctx->outPkt->data;
      out_buffer->headerSize    = avctx->extradata_size = pEncOut->header_size; //ctx->outPkt->size;
    } else {
      if (pEncOut->resendSPS) {
        ENC_TB_DEBUG_PRINT("has sps header: pEncOut->header_size = %d\n", pEncOut->header_size);
        out_buffer->headerData = pEncOut->header_buffer;
        out_buffer->headerSize = pEncOut->header_size;

#if 0   /* print resend header */
		int kk = 0;
		uint8_t *pp = (uint8_t *)pEncOut->header_buffer;
		
		av_log(NULL, AV_LOG_INFO, "\nin %s\n", __FUNCTION__);
        for (kk = 0; kk < pEncOut->header_size; kk++) {
			av_log(NULL, AV_LOG_INFO, "0x%x ", *(pp+kk));
			if (kk%16==15)
				av_log(NULL, AV_LOG_INFO, "\n");
        }
		av_log(NULL, AV_LOG_INFO, "\n");
#endif

      } else {
        out_buffer->headerData = NULL;
        out_buffer->headerSize = 0;      
      }
    }

    out_buffer->resendHeader  = pEncOut->resendSPS;
    out_buffer->streamSize    = pEncOut->streamSize; //streamSize; //pEncOut->streamSize;
    out_buffer->pts           = pEncOut->pts; //tb->input_pic_cnt; //pEncOut->pts;
    out_buffer->codingType    = pEncOut->codingType;


    if (tb->first_pts != AV_NOPTS_VALUE) {
        if ((pEncOut->indexEncoded == 0) || (pEncOut->codingType == VCENC_INTRA_FRAME)) {
          out_buffer->dts = pEncOut->pts - 8;
          if (pEncOut->indexEncoded && (out_buffer->dts <= tb->last_out_dts)) {
            out_buffer->dts = tb->last_out_dts + 1;
          }
        } else {
          out_buffer->dts = tb->last_out_dts + 1;
        }

        if (out_buffer->dts >= tb->first_pts) {
          if (tb->pts_offset == 0) {
            tb->pts_offset = tb->picture_enc_cnt - 1;
            ENC_TB_DEBUG_PRINT("tb->pts_offset = %d\n", tb->pts_offset);
          }
          out_buffer->dts += tb->pts_fix[ ((tb->picture_enc_cnt-1)-tb->pts_offset) % 100];
          if (out_buffer->dts > out_buffer->pts) {
            out_buffer->dts =  tb->last_out_dts + 1;
          }
        }
        if (tb->last_out_dts && out_buffer->dts <= tb->last_out_dts) {
          out_buffer->dts =  tb->last_out_dts + 1;
        }

    } else {
        if (pEncOut->indexEncoded == 0) {
            out_buffer->dts = pEncOut->pts - 8;
        } else {
            out_buffer->dts =  tb->last_out_dts + 1;
        }
    }
    tb->last_out_dts = out_buffer->dts;

    ENC_TB_DEBUG_PRINT("out_buffer->pts = %ld, out_buffer->dts = %ld, poc @%d\n", out_buffer->pts, out_buffer->dts, pEncOut->indexEncoded);
    ENC_TB_DEBUG_PRINT("pts %ld, dts %ld, poc @%d\n", (out_buffer->pts*1000)/30, (out_buffer->dts*1000)/30, pEncOut->indexEncoded);


    for (int i = 0; i < 3; i++) {
      out_buffer->ssim[i] = pEncOut->ssim[i];
    }
    out_buffer->maxSliceStreamSize = pEncOut->maxSliceStreamSize;
    out_buffer->indexEncoded = pEncOut->indexEncoded;

    GetEncData(ctx->hantro_encoder, out_buffer, pEncOut);
  }

  ENC_TB_DEBUG_PRINT("\n");
  
  return 0;
}

int hantro_packet_rcv(AVCodecContext *avctx, AVPacket *pkt) 
{
  HANTROH26xEncContext * ctx = (HANTROH26xEncContext *)avctx->priv_data;
  HANTROH26xEncOptions * options = &ctx->options;
  i32 ret = OK;
  struct test_bench * tb = (struct test_bench *)&ctx->tb;
  VCEncIn *pEncIn = (VCEncIn *)&(tb->encIn);
  VCEncOut *pEncOut = (VCEncOut *)&ctx->encOut;
  EncOutData_t *out_buffer = NULL;

  int streamSize = 0;
  int i = 0;
 
  ENC_TB_DEBUG_PRINT("\n");

  if (ctx->PktWillEnd != HANTRO_TRUE) {
    //avctx->internal->draining = 0;
  } else {
    ctx->flushState = HANTRO_FLUSH_ENCEND;
    return AVERROR_EOF;
  }

  if (ctx->flushState == HANTRO_FLUSH_ERROR) {
    ENC_TB_ERROR_PRINT("error, will return -1\n");
    return -1;
  }

  while (1) {
    ret = WaitPktData(ctx->hantro_encoder, &out_buffer);
    ENC_TB_DEBUG_PRINT("[%d] FifoPop ret = %d\n", tb->enc_index, ret);
    if (ret == FIFO_EMPTY) {
      usleep(100);
      if (avctx->internal->draining == 0) {
        return AVERROR(EAGAIN);
      }
    } else {
      break;
    }
  }

  if (out_buffer->endData == HANTRO_TRUE) {
    av_log(avctx, AV_LOG_DEBUG, "%s send vce end data...\n", __FUNCTION__);
#if 0
    if (av_new_packet(pkt, out_buffer->headerSize))
      return -1;

    memcpy(pkt->data, out_buffer->headerData, out_buffer->headerSize);
    pkt->size = out_buffer->headerSize;
    av_packet_unref(ctx->outPkt);
#else
    av_packet_unref(ctx->outPkt);
#endif
    //////////////////////
#if 0
    int kk = 0;
    //uint8_t *pp = (uint8_t *)tb->outbufMem[0]->rc_virtualAddress;
    uint8_t *pp = pkt->data;
    
    av_log(NULL, AV_LOG_INFO, "\nin hantro_encode_receive_packet\n");
    for (kk = 0; kk < pkt->size; kk++) {
    av_log(NULL, AV_LOG_INFO, "0x%x ", *(pp+kk));
    if (kk%16==15)
      av_log(NULL, AV_LOG_INFO, "\n");
    }
    av_log(NULL, AV_LOG_INFO, "\n");
#endif
    //////////////////////

    //avctx->internal->draining = 1;
    ctx->PktWillEnd = HANTRO_TRUE;

    ctx->flushState = HANTRO_FLUSH_ENCEND;
    return AVERROR_EOF;
    //return 0;    
  } else {
    //avctx->internal->draining = 0;
  }


  //av_log(avctx, AV_LOG_DEBUG, "%s %d out_buffer->streamSize = %d, out_buffer->headerSize = %d\n", __FUNCTION__, __LINE__, out_buffer->streamSize, out_buffer->headerSize);

  //streamSize = out_buffer->streamSize + out_buffer->headerSize;
  streamSize = out_buffer->resendHeader ? out_buffer->streamSize : (out_buffer->streamSize + out_buffer->headerSize);
  if (streamSize != 0)
  {
    EWLLinearMem_t packetMem;

    if (av_new_packet(pkt, streamSize)) {
      ENC_TB_ERROR_PRINT("av_new_packet error\n");
      return -1;
    }

#ifdef VCE_MEM_ERR_TEST
    if(VceMemoryCheck(options) != 0){
      av_packet_unref(pkt);
      ENC_TB_ERROR_PRINT("vce force memory error in function\n");
      return -1;
    }
#endif

#ifdef USE_OLD_DRV
    EWLLinearMem_t mem;
	mem = *out_buffer->outbufMem[0]; //*tb->outbufMem[0];
    memcpy(pkt->data, (uint8_t *)mem.virtualAddress, streamSize);
#else
	/*
    if(pEncOut->sliceHeaderSize > 0)
    {
      //memcpy(pkt->data, ctx->outPkt.data, pEncOut->sliceHeaderSize);
      ENC_TB_DEBUG_PRINT("has slice header: pEncOut->sliceHeaderSize = %d\n", pEncOut->sliceHeaderSize);
    
      packetMem.rc_busAddress = (ptr_t)pkt->data + pEncOut->sliceHeaderSize;
      packetMem.size = streamSize - pEncOut->sliceHeaderSize;

      uint8_t *data_tmp = (uint8_t *)tb->outbufMem[0]->rc_virtualAddress + packetMem.size;
      memcpy(pkt->data, data_tmp, pEncOut->sliceHeaderSize);
	  
      if (EWLTransDataEP2RC(tb->ewl, tb->outbufMem[0], (EWLLinearMem_t *)&packetMem, packetMem.size))
        return -1;
      
    } else */{
      packetMem.rc_busAddress = (ptr_t)pkt->data;
      packetMem.size = streamSize;

#if 10
      if ((out_buffer->headerSize != 0) && (out_buffer->resendHeader != HANTRO_TRUE)) {
        packetMem.rc_busAddress += out_buffer->headerSize; //ctx->outPkt->size;
        packetMem.size -= out_buffer->headerSize; //ctx->outPkt->size;
        memcpy(pkt->data, out_buffer->headerData, out_buffer->headerSize);
        //ctx->outPkt->size = 0;
        //av_packet_unref(ctx->outPkt);
        out_buffer->headerSize = 0;
      }
#endif
      //if (EWLTransDataEP2RC(tb->ewl, tb->outbufMem[0], (EWLLinearMem_t *)&packetMem, packetMem.size))
      if (EWLTransDataEP2RC(tb->ewl, out_buffer->outbufMem, (EWLLinearMem_t *)&packetMem, packetMem.size))
        return -1;

      if (out_buffer->resendHeader) {
        memcpy(pkt->data, out_buffer->headerData, out_buffer->headerSize);
      }
    }
#endif

    //if (pts) {
      pkt->pts = out_buffer->pts;
	  pkt->dts = out_buffer->dts;
      pkt->flags |= (out_buffer->codingType == VCENC_INTRA_FRAME) ? AV_PKT_FLAG_KEY : 0;
    //}
	
    ENC_TB_DEBUG_PRINT("enc pts %ld, dts %ld, cnt %d, size %d\n", pkt->pts, pkt->dts, tb->picture_enc_cnt, pkt->size);
#if 0
    if((options->streamMultiSegmentMode != 0)||(ctl->multislice_encoding==0)||(ENCH2_SLICE_READY_INTERRUPT==0)||(options->hrdConformance==1))
    {      
      VCEncStrmBufs bufs;
      getStreamBufs (&bufs, tb, options, HANTRO_TRUE);

      if (tb->streamSegCtl.streamMultiSegEn)
      {
        u8 *streamBase = tb->streamSegCtl.streamBase + (tb->streamSegCtl.streamRDCounter % tb->streamSegCtl.segmentAmount) * tb->streamSegCtl.segmentSize;
        WriteStrm(tb->streamSegCtl.outStreamFile, (u32 *)streamBase, pEncOut->streamSize - tb->streamSegCtl.streamRDCounter * tb->streamSegCtl.segmentSize, 0);
        tb->streamSegCtl.streamRDCounter = 0;
      }
      else if (options->byteStream == 0)
      {
        //WriteNalSizesToFile(nalfile, pEncOut->pNaluSizeBuf, pEncOut->numNalus);
        writeNalsBufs(tb->out, &bufs, pEncOut->pNaluSizeBuf, pEncOut->numNalus, 0, pEncOut->sliceHeaderSize, 0);
      }
      else
      {
        if(pEncOut->sliceHeaderSize > 0)
        {
          ASSERT(options->tiles_enabled_flag);
          writeStrmBufs(tb->out, &bufs, pEncOut->streamSize - pEncOut->sliceHeaderSize, pEncOut->sliceHeaderSize, 0);
          writeStrmBufs(tb->out, &bufs, 0, pEncOut->streamSize - pEncOut->sliceHeaderSize, 0);
        }
        else
          writeStrmBufs(tb->out, &bufs, 0, pEncOut->streamSize, 0);
      }
    }
#endif
	
    //pEncIn->timeIncrement = tb->outputRateDenom;

    //ctx->total_bits += pEncOut->streamSize * 8;
    ctx->total_bits += out_buffer->streamSize * 8;

    tb->validencodedframenumber++;
    //MaAddFrame(&ctx->ma, pEncOut->streamSize*8);
    MaAddFrame(&ctx->ma, out_buffer->streamSize*8);

    tb->hwcycle_acc += VCEncGetPerformance(ctx->hantro_encoder);

#if 1
    if (options->enc_index == 0) {
        AVHWDeviceContext * device_ctx;
        AVHANTRODeviceContext * hwctx;

        if (ctx->hwdevice)
            device_ctx = ctx->hwdevice->data;
        
        if (device_ctx)
            hwctx = device_ctx->hwctx;

        if (hwctx && hwctx->net_sender_handle) {
            ret = net_sender_send_fps(hwctx->net_sender_handle, get_deviceId(hwctx->device), hwctx->task_idx);
        }
    }
#endif

    ENC_TB_INFO_PRINT("=== Encoded frame%i poc=%d bits=%d TotalBits=%lu averagebitrate=%lu HWCycles=%d maxSliceBytes=%d\n",
                tb->picture_enc_cnt-1 - (tb->parallelCoreNum-1), 
                out_buffer->indexEncoded,
                out_buffer->streamSize*8,
                ctx->total_bits,
                (ctx->total_bits * tb->outputRateNumer) / ((tb->picture_enc_cnt - (tb->parallelCoreNum-1)) * tb->outputRateDenom),
                VCEncGetPerformance(ctx->hantro_encoder),
                out_buffer->maxSliceStreamSize);
#if 1
    double ssim = out_buffer->ssim[0] * 0.8 + 0.1 * (out_buffer->ssim[1] + out_buffer->ssim[2]);
    ENC_TB_INFO_PRINT("    SSIM %.4f SSIM Y %.4f U %.4f V %.4f\n", ssim, out_buffer->ssim[0], out_buffer->ssim[1], out_buffer->ssim[2]);
    tb->ssim_acc += ssim;
#endif
    
    if((options->picRc == 1)&& (tb->validencodedframenumber>=ctx->ma.length))
    {
      tb->numbersquareoferror++;
      if(tb->maxerrorovertarget<(Ma(&ctx->ma)- options->bitPerSecond))
        tb->maxerrorovertarget=(Ma(&ctx->ma)- options->bitPerSecond);
      if(tb->maxerrorundertarget<(options->bitPerSecond-Ma(&ctx->ma)))
        tb->maxerrorundertarget=(options->bitPerSecond-Ma(&ctx->ma));
      tb->sumsquareoferror+=((float)(ABS(Ma(&ctx->ma)- options->bitPerSecond))*100/options->bitPerSecond);
      tb->averagesquareoferror=(tb->sumsquareoferror/tb->numbersquareoferror);
      ENC_TB_INFO_PRINT("    RateControl(movingBitrate=%d MaxOvertarget=%d%% MaxUndertarget=%d%% AveDeviationPerframe=%f%%)\n",
                Ma(&ctx->ma),
                tb->maxerrorovertarget*100/options->bitPerSecond,
                tb->maxerrorundertarget*100/options->bitPerSecond,
                tb->averagesquareoferror);
    }

    GivebackEmptyFifo(ctx->hantro_encoder, out_buffer);

  }

//end:
  //GivebackEmptyFifo(ctx->hantro_encoder, out_buffer);

  return 0;
}

/* add for IDR */
static int IDRPocArrayInit(HANTROH26xEncContext *ctx)
{
  int i = 0;

  for (i = 0; i < MAX_IDR_ARRAY_DEPTH; i++) {
    ctx->IDRPocArray[i] = -1;
  }

  ctx->nextIDRPoc = 0;
  ctx->pocStoreIndex = ctx->nextIDRPocIndex = 0;
  ctx->updateIDRPoc = HANTRO_TRUE;

  return 0;
}

static int storeIDRPoc(HANTROH26xEncContext *ctx, int idr_poc)
{
  struct test_bench * tb = (struct test_bench *)&ctx->tb;

  if (ctx->IDRPocArray[ctx->pocStoreIndex % MAX_IDR_ARRAY_DEPTH] != -1) {
    ENC_TB_ERROR_PRINT("No mem to store IDR poc! ctx->pocStoreIndex = %d, idr_poc = %d\n", ctx->pocStoreIndex, idr_poc);
    return -1;
  }

  ctx->IDRPocArray[ctx->pocStoreIndex % MAX_IDR_ARRAY_DEPTH] = idr_poc;
  ctx->pocStoreIndex++;

  return 0;
}

static int clearIDRPoc(HANTROH26xEncContext *ctx)
{
  ctx->IDRPocArray[(ctx->nextIDRPocIndex + MAX_IDR_ARRAY_DEPTH - 1) % MAX_IDR_ARRAY_DEPTH] = -1;

  return 0;
}

static int updateNextIDRPoc(HANTROH26xEncContext *ctx, int *idr_poc)
{
  struct test_bench * tb = (struct test_bench *)&ctx->tb;
  VCEncIn *pEncIn = (VCEncIn *)&(tb->encIn);

  if (ctx->IDRPocArray[ctx->nextIDRPocIndex % MAX_IDR_ARRAY_DEPTH] == -1) {
    ENC_TB_DEBUG_PRINT("Now there is no IDR frame, wait for next!\n");
    return 1;
  }

  *idr_poc = ctx->IDRPocArray[ctx->nextIDRPocIndex % MAX_IDR_ARRAY_DEPTH];
  ctx->nextIDRPocIndex++;
  ctx->updateIDRPoc = HANTRO_FALSE;
  ENC_TB_DEBUG_PRINT("nextIDRPoc has updated to [%d], tb->input_pic_cnt = %d\n", *idr_poc, tb->input_pic_cnt);
#if 0
  ctx->nextGopStart = tb->input_pic_cnt;
  int length = *idr_poc - ctx->nextGopStart;

  if ((length > 0) && (length < ctx->nextGopSize)) {
    pEncIn->gopSize = ctx->nextGopSize = length;
  }
#endif
  return 0;
}

/* add for encode */
int hantro_receive_pic(AVCodecContext *avctx, const AVFrame *pict)
{
  HANTROH26xEncContext * ctx = (HANTROH26xEncContext *)avctx->priv_data;
  TranscoderPic_t *pTrans = NULL;
  int i = 0;
  int ret = 0;
  struct test_bench * tb = (struct test_bench *)&ctx->tb;
  VCEncIn *pEncIn = (VCEncIn *)&(tb->encIn);
  struct DecPicturePpu * picPpu = NULL;

//av_log(avctx, AV_LOG_DEBUG, "%s %d\n", __FILE__, __LINE__);

  /* should return when enc process exit abnormally */
  if (ctx->flushState == HANTRO_FLUSH_ERROR) {
    return -1;
  }

  if (pict) {
      picPpu = (struct DecPicturePpu *)pict->data[0];
	  ENC_TB_DEBUG_PRINT("picPpu->pictures[1].pp_enabled = %d\n", picPpu->pictures[1].pp_enabled); 
	  ENC_TB_DEBUG_PRINT("picPpu->pictures[2].pp_enabled = %d\n", picPpu->pictures[2].pp_enabled); 
  }

  /* add to get new vui info */
  if (pict && (tb->enc_first_frame == 0)) {
    tb->enc_first_frame = 1;
    avctx->color_range = pict->color_range;
    ENC_TB_DEBUG_PRINT("pict->color_range = %d\n", pict->color_range);
    ENC_TB_DEBUG_PRINT("pict->color_range = %d, avctx->color_range = %d\n", pict->color_range, avctx->color_range); 
  }
  /* add end */

  /* add4debug */
  hantro_rest_data_check(avctx);
  if (ctx->num_wait_consume >= ctx->num_dec_max) {
    return VCENC_OUTPUT_BUFFER_OVERFLOW;
  }
  /* add end */
  
  //store the pic.
  // find empty wait
  for (i = 0; i < MAX_WAIT_DEPTH; i++) {
    if (ctx->PicWaitForEnc[i].state == 0) {
      pTrans = (TranscoderPic_t *)&ctx->PicWaitForEnc[i];
      break;
    }
  }

//av_log(avctx, AV_LOG_DEBUG, "%s %d\n", __FILE__, __LINE__);
  
  if (pTrans) {
    pthread_mutex_lock(&pTrans->trans_mutex);

    if (pict == NULL) {
#if 0
      if (pTrans->trans_pic)
	  	av_frame_free((AVFrame *)&pTrans->trans_pic);
#endif	  
      //pTrans->trans_pic = NULL;
      av_frame_free(&pTrans->trans_pic);
      pTrans->poc = -1;
      pTrans->isInPassOneQueue = 0;
      pTrans->state = 1;
    } else {
      pTrans->poc = ctx->poc;
	  pTrans->isInPassOneQueue = 0;
	  
	  if (!pTrans->trans_pic) {
        pTrans->trans_pic = av_frame_alloc();
        if (!pTrans->trans_pic) {
          ENC_TB_ERROR_PRINT("No av frame mem alloc for enc data\n");    
	      pthread_mutex_unlock(&pTrans->trans_mutex);
          return -1;
        }
      }

      /* add for IDR */
      if (pict->key_frame && ctx->forced_idr) {
        if (ctx->poc > 0) {
          ctx->keyFrameFlag = HANTRO_TRUE;
          storeIDRPoc(ctx, ctx->poc);
#if 0
          if (ctx->updateIDRPoc == HANTRO_TRUE) {
            updateNextIDRPoc(ctx, (int *)&ctx->nextIDRPoc);
          }
#endif
          //ctx->nextIDRPoc = ctx->poc;
          ENC_TB_DEBUG_PRINT("ctx->nextIDRPoc = %d\n", ctx->nextIDRPoc);
        }
      }

      if (ctx->poc == 0) {
        tb->first_pts = pict->pts;
        tb->pts_fix[0] = 0;
      } else {
        tb->pts_fix[ctx->poc % 100] = pict->pts-(tb->last_in_pts+1);
      }
      ENC_TB_DEBUG_PRINT("last_in_pts %ld, pts %ld, tb->pts_fix[%d] = %d, poc @%d\n", tb->last_in_pts, pict->pts, ctx->poc % 100, tb->pts_fix[ctx->poc % 100], ctx->poc);
      tb->last_in_pts = pict->pts;
      

      av_frame_unref(pTrans->trans_pic);
      ret = av_frame_ref(pTrans->trans_pic, pict);
      //av_frame_move_ref(pTrans->trans_pic, pict);
      //ENC_TB_DEBUG_PRINT("[%d] pTrans->poc = %d, pTrans->trans_pic->data[0] = %p, pict->data[0] = %p\n", tb->enc_index, pTrans->poc, (void *)pTrans->trans_pic->data[0], (void *)pict->data[0]);

      //pEncIn->pts = pTrans->trans_pic->pts;

	  ENC_TB_DEBUG_PRINT("store poc = %d.\n", ctx->poc); 

	  //ENC_TB_ERROR_PRINT("store poc = %d. av_frame_ref ret = %d\n", ctx->poc, ret); 
      pTrans->state = 1;
	  ctx->poc++;
      
#ifdef VCE_MEM_ERR_TEST
      if(VceMemoryCheck(&ctx->options) != 0){
        ENC_TB_ERROR_PRINT("enc[%d] vce force memory error in function\n", tb->enc_index);
	    pthread_mutex_unlock(&pTrans->trans_mutex);
        return -1;
      }
#endif
      
    } 

    ENC_TB_DEBUG_PRINT("[%d] picPpu = %p, pTrans->poc = %d\n", tb->enc_index, (void *)picPpu, pTrans->poc);
    ENC_TB_DEBUG_PRINT("[%d] pTrans->poc = %d, pTrans->trans_pic->data[0] = %p, pict->data[0] = %p\n", tb->enc_index, pTrans->poc, (void *)pTrans->trans_pic->data[0], (void *)pict->data[0]);
    pthread_mutex_unlock(&pTrans->trans_mutex);
	
  } else {
    ENC_TB_DEBUG_PRINT("No transcode fifo for enc data\n");    
    //return -1;
    ret = VCENC_OUTPUT_BUFFER_OVERFLOW; //No fifo
  }

  ENC_TB_DEBUG_PRINT("out, ret = %d\n", ret); 	
  return ret;
}

static void hantro_consume_flush(AVCodecContext *avctx)
{
  HANTROH26xEncContext * ctx = (HANTROH26xEncContext *)avctx->priv_data;
  struct test_bench * tb = (struct test_bench *)&ctx->tb;
  
  TranscoderPic_t *pTrans = NULL;
  int i = 0;

  /* add4debug */
  struct DecPicturePpu *picPpu = NULL;

  for (i = 0; i < MAX_WAIT_DEPTH; i++) {
    if (ctx->PicWaitForEnc[i].state == 1) {
      //if ((ctx->PicWaitForEnc[i].poc != -1)&&(ctx->PicWaitForEnc[i].poc != 0)) {
      //if (ctx->PicWaitForEnc[i].poc != -1) {
        //av_log(NULL, AV_LOG_DEBUG, "[%d] wait array get EOS, pending EOS\n", ctx->pp_index);
        ENC_TB_DEBUG_PRINT("[%d] poc =%d\n",  tb->enc_index, ctx->PicWaitForEnc[i].poc);

        pTrans = &ctx->PicWaitForEnc[i];
        ENC_TB_DEBUG_PRINT("[%d]\n", tb->enc_index);
	    if (pTrans->trans_pic) {
          ENC_TB_DEBUG_PRINT("[%d]\n", tb->enc_index);
          /* add4debug */
		  picPpu = (struct DecPicturePpu *)pTrans->trans_pic->data[0];
          ENC_TB_DEBUG_PRINT("[%d] picPpu = %p\n", tb->enc_index, picPpu);
          //av_log(avctx, AV_LOG_DEBUG, "frame ref count %d for %p\n", av_buffer_get_ref_count(pTrans->trans_pic->buf[0]), pTrans->trans_pic->buf[0]->data);
	  	  av_frame_free((AVFrame *)&pTrans->trans_pic);
		  //av_frame_unref(pTrans->trans_pic);
		  //av_buffer_unref(&pTrans->trans_pic->buf[0]);
          //av_log(NULL, AV_LOG_DEBUG, "[%d] %s %d\n", ctx->pp_index, __FILE__, __LINE__);
		}
        //pTrans->poc = -1;
        pTrans->state = 0;

        //av_frame_unref(pTrans->trans_pic);
        ENC_TB_DEBUG_PRINT("[%d]\n", tb->enc_index);

        //hantro_consume_stored_pic(avctx, ctx->PicWaitForEnc[i].poc);
      //}

    }
  }
  
}

static int hantro_send_pic(AVCodecContext *avctx, int poc_need, HANTRO_ENC_IN_ADDR_t *pAddrs, int64_t *pts)
{
  HANTROH26xEncContext * ctx = (HANTROH26xEncContext *)avctx->priv_data;
  HANTROH26xEncOptions * options = &ctx->options;
  struct test_bench * tb = (struct test_bench *)&ctx->tb;
  TranscoderPic_t *pTrans = NULL;
  int i = 0, ret = 0;
  VCEncIn *pEncIn = (VCEncIn *)&(tb->encIn);
  
  struct DecPicturePpu *picPpu = NULL; //(struct DecPicturePpu *)pict_stored.data[0];
  struct DecPicture *picData = NULL; //(struct DecPicture *)&picPpu->pictures[ctx->pp_index];

  memset(pAddrs, 0, sizeof(HANTRO_ENC_IN_ADDR_t));

  //find the need_poc
  for (i = 0; i < MAX_WAIT_DEPTH; i++) {
    if (ctx->PicWaitForEnc[i].state == 1) {
      pTrans = &ctx->PicWaitForEnc[i];
      if (pTrans->poc == poc_need) {

        /* add to get new vui info */
        if (poc_need == 0) {
#if 10
          ENC_TB_DEBUG_PRINT("avctx->color_range = %d\n", avctx->color_range); 
          VCEncCodingCtrl codingCfg;
          if ((ret = VCEncGetCodingCtrl(ctx->hantro_encoder, &codingCfg)) != VCENC_OK) {
            ENC_TB_ERROR_PRINT("VCEncGetCodingCtrl failed\n");
            return -1;
          } else {
            if (avctx->color_range == AVCOL_RANGE_JPEG) {
              options->videoRange = 1;            
            } else {
              options->videoRange = 0;
            }
 
            options->vuiVideoSignalTypePresentFlag |= options->videoRange;
            //options->videoRange = 1; //avctx->color_range;
            codingCfg.vuiVideoSignalTypePresentFlag = options->vuiVideoSignalTypePresentFlag; // = 1;
            codingCfg.vuiVideoFullRange = options->videoRange;
            ENC_TB_DEBUG_PRINT("++++ encoder = %p\n", ctx->hantro_encoder);

            if ((ret = VCEncSetCodingCtrl(ctx->hantro_encoder, &codingCfg)) != VCENC_OK) {
              ENC_TB_ERROR_PRINT("VCEncSetCodingCtrl failed\n");
              return -1;
            }       
          }
#endif
          //pEncIn->resendSPS = pEncIn->resendPPS = pEncIn->resendVPS = 1;
          ENC_TB_DEBUG_PRINT("options->videoRange = %d \n", options->videoRange);  
       }
       /* add end */ 

	  	ENC_TB_DEBUG_PRINT("%s %d pTrans->trans_pic = %p\n", __FILE__, __LINE__, pTrans->trans_pic);
        picPpu = (struct DecPicturePpu *)pTrans->trans_pic->data[0];
        if (picPpu == NULL) {
          av_log(avctx, AV_LOG_ERROR, "%s enc get frame[%d] error\n", __FUNCTION__, poc_need);
          return VCENC_NULL_ARGUMENT;
        }
	    picData = (struct DecPicture *)&picPpu->pictures[ctx->pp_index];
	  	ENC_TB_DEBUG_PRINT("picPpu->pictures[1].pp_enabled = %p\n", picPpu->pictures[1].pp_enabled);
	  	ENC_TB_DEBUG_PRINT("picPpu->pictures[2].pp_enabled = %p\n", picPpu->pictures[2].pp_enabled);

        pTrans->isInPassOneQueue = 1;
        //pict = pTrans->trans_pic;
        //av_frame_copy(pict, pTrans->trans_pic);
		goto find_pic;

      }
    }
  }

  if (i == MAX_WAIT_DEPTH) {
    ENC_TB_DEBUG_PRINT("No needed pict, waitting for the next.\n");
    return -1;
  }

find_pic:
    pAddrs->busLuma = picData->luma.bus_address;
    pAddrs->busChroma = picData->chroma.bus_address;
    pAddrs->busLumaTable = picData->luma_table.bus_address;
    pAddrs->busChromaTable = picData->chroma_table.bus_address;
  
    ENC_TB_DEBUG_PRINT("[%d] busLuma[%p], busCU[%p], busLT[%p], busCT[%p]\n",
        options->enc_index, pAddrs->busLuma, pAddrs->busChroma, pAddrs->busLumaTable, pAddrs->busChromaTable);
  
    if (options->enc_index == 0 && options->lookaheadDepth && options->cutree_blkratio) {
        ENC_TB_DEBUG_PRINT("[%d] enter downSample 1pass\n", options->enc_index);
    
        picData = &picPpu->pictures[2];
        if (!picData->pp_enabled) {
            ENC_TB_ERROR_PRINT("when need 1/4 1pass input, pp1 should be enabled!\n");
            return -1;
        }
      
        pAddrs->busLumaDs = picData->luma.bus_address;
        pAddrs->busChromaDs = picData->chroma.bus_address;
        pAddrs->busLumaTableDs = picData->luma_table.bus_address;
        pAddrs->busChromaTableDs = picData->chroma_table.bus_address;
        
        ENC_TB_DEBUG_PRINT("[%d] busLumaDs[%p], busCUDs[%p], busLTDs[%p], busCTDs[%p]\n",
            options->enc_index, pAddrs->busLumaDs, pAddrs->busChromaDs, pAddrs->busLumaTableDs, pAddrs->busChromaTableDs);
    }

    if (pTrans->trans_pic->pts == AV_NOPTS_VALUE) {
        pEncIn->pts =  pTrans->poc;
    } else {
        pEncIn->pts =  pTrans->trans_pic->pts;
    }
    *pts = pEncIn->pts;
    
    ENC_TB_DEBUG_PRINT("in pts %ld poc@%d\n", pEncIn->pts, pTrans->poc);
	
    return 0;
}

static int hantro_trans_pic_flush_send(AVCodecContext *avctx, int poc_need, HANTRO_ENC_IN_ADDR_t *pAddrs, int64_t *pts)
{
  HANTROH26xEncContext * ctx = (HANTROH26xEncContext *)avctx->priv_data;
  HANTROH26xEncOptions * options = &ctx->options;
  struct test_bench * tb = (struct test_bench *)&ctx->tb;
  TranscoderPic_t *pTrans = NULL;
  int i = 0;
  VCEncIn *pEncIn = (VCEncIn *)&(tb->encIn);
  
  struct DecPicturePpu *picPpu = NULL;
  struct DecPicture *picData = NULL;

  memset(pAddrs, 0, sizeof(HANTRO_ENC_IN_ADDR_t));
  
  //find the need_poc
  for (i = 0; i < MAX_WAIT_DEPTH; i++) {
    if (ctx->PicWaitForEnc[i].state == 1) {
    //if (ctx->PicWaitForEnc[i].state == 1) {

      pTrans = &ctx->PicWaitForEnc[i];
      if (pTrans->poc == poc_need) {
	  	ENC_TB_DEBUG_PRINT("%s %d pTrans->trans_pic = %p\n", __FILE__, __LINE__, pTrans->trans_pic);
        picPpu = (struct DecPicturePpu *)pTrans->trans_pic->data[0];
	    picData = (struct DecPicture *)&picPpu->pictures[ctx->pp_index];

        
        //pict = pTrans->trans_pic;
        //av_frame_copy(pict, pTrans->trans_pic);
		goto find_pic;

      }
    }
  }

  if (i == MAX_WAIT_DEPTH) {
    ENC_TB_DEBUG_PRINT("No Pic Need Trans.\n");
    //ctx->TransFlushPic = HANTRO_TRUE; 
    ctx->flushState = HANTRO_FLUSH_ENCDATA;
    return -1;
  }

find_pic:
  pAddrs->busLuma = picData->luma.bus_address;
  pAddrs->busChroma = picData->chroma.bus_address;
  pAddrs->busLumaTable = picData->luma_table.bus_address;
  pAddrs->busChromaTable = picData->chroma_table.bus_address;

  ENC_TB_DEBUG_PRINT("[%d] busLuma[%p], busCU[%p], busLT[%p], busCT[%p]\n",
      options->enc_index, pAddrs->busLuma, pAddrs->busChroma, pAddrs->busLumaTable, pAddrs->busChromaTable);

  if (options->enc_index == 0 && options->lookaheadDepth && options->cutree_blkratio) {
      ENC_TB_DEBUG_PRINT("[%d] enter downSample 1pass\n", options->enc_index);
  
      picData = &picPpu->pictures[2];
      if (!picData->pp_enabled) {
          ENC_TB_DEBUG_PRINT("when need 1/4 1pass input, pp1 should be enabled!\n");
          return -1;
      }
    
      pAddrs->busLumaDs = picData->luma.bus_address;
      pAddrs->busChromaDs = picData->chroma.bus_address;
      pAddrs->busLumaTableDs = picData->luma_table.bus_address;
      pAddrs->busChromaTableDs = picData->chroma_table.bus_address;
      
      ENC_TB_DEBUG_PRINT("[%d] busLumaDs[%p], busCUDs[%p], busLTDs[%p], busCTDs[%p]\n",
          options->enc_index, pAddrs->busLumaDs, pAddrs->busChromaDs, pAddrs->busLumaTableDs, pAddrs->busChromaTableDs);
  }


  pTrans->isInPassOneQueue = 1;
  if (pTrans->trans_pic->pts == AV_NOPTS_VALUE) {
      pEncIn->pts =  pTrans->poc;
  } else {
      pEncIn->pts =  pTrans->trans_pic->pts;
  }
  *pts = pEncIn->pts;

  return 0;
}

static void hantro_rest_data_check(AVCodecContext *avctx)
{
  HANTROH26xEncContext * ctx = (HANTROH26xEncContext *)avctx->priv_data;
  struct test_bench * tb = (struct test_bench *)&ctx->tb;
  TranscoderPic_t *pTrans = NULL;
  int i = 0;
  int num = 0;

  for (i = 0; i < MAX_WAIT_DEPTH; i++) {
    if (ctx->PicWaitForEnc[i].state == 1) {
      pTrans = &ctx->PicWaitForEnc[i];
      num++;
	  ENC_TB_DEBUG_PRINT("poc = %d\n", pTrans->poc);
    }
  }

  ENC_TB_DEBUG_PRINT("[%d] total num = %d\n", ctx->tb.enc_index, num);
  ctx->num_wait_consume = num;
}

void hantro_consume_stored_pic(AVCodecContext *avctx, int consume_poc)
{
  HANTROH26xEncContext * ctx = (HANTROH26xEncContext *)avctx->priv_data;
  TranscoderPic_t *pTrans = NULL;
  int i;
  
  //find the need_poc
  for (i = 0; i < MAX_WAIT_DEPTH; i++) {
    if (ctx->PicWaitForEnc[i].state == 1) {
  	  pTrans = &ctx->PicWaitForEnc[i];
  	  if (pTrans->poc == consume_poc) {
        goto find_pic;
      }
    }
  }

  if (i == MAX_WAIT_DEPTH)
    return;
  
find_pic:
  pthread_mutex_lock(&pTrans->trans_mutex);

  pTrans->poc = -1;
  pTrans->state = 0;
  pTrans->isInPassOneQueue = 0;
  av_frame_unref(pTrans->trans_pic);
  pthread_mutex_unlock(&pTrans->trans_mutex);

  if (ctx->forced_idr) {
    pthread_mutex_lock(&ctx->rcv_packet_mutex);
    ctx->injectFrameCnt--;
    pthread_mutex_unlock(&ctx->rcv_packet_mutex);
  }
}

static void tb_init_pic(struct test_bench *tb, HANTROH26xEncOptions *options, ma_s *ma, adapGopCtr *agop)
{
  tb->validencodedframenumber=0;

  //Adaptive Gop variables
  agop->last_gopsize = MAX_ADAPTIVE_GOP_SIZE;
  agop->gop_frm_num = 0;
  agop->sum_intra_vs_interskip = 0;
  agop->sum_skip_vs_interskip = 0;
  agop->sum_intra_vs_interskipP = 0;
  agop->sum_intra_vs_interskipB = 0;
  agop->sum_costP = 0;
  agop->sum_costB = 0;
  
  ma->pos = ma->count = 0;
  ma->frameRateNumer = options->outputRateNumer;
  ma->frameRateDenom = options->outputRateDenom;
  if (options->outputRateDenom)
      ma->length = MAX(LEAST_MONITOR_FRAME, MIN(options->monitorFrames,
                              MOVING_AVERAGE_FRAMES));
  else
      ma->length = MOVING_AVERAGE_FRAMES;
}

av_cold int hantro_encode_start(AVCodecContext *avctx, AVPacket *pkt, int *streamSize)
{
  HANTROH26xEncContext * ctx = (HANTROH26xEncContext *)avctx->priv_data;
  HANTROH26xEncOptions * options = &ctx->options;
  i32 ret = OK;
  struct test_bench * tb = (struct test_bench *)&ctx->tb;
  VCEncIn *pEncIn = (VCEncIn *)&(tb->encIn);
  VCEncOut *encOut = (VCEncOut *)&ctx->encOut;

  ENC_TB_DEBUG_PRINT("&ctx->tb[%p]\n", (void*)&ctx->tb);

  i32 p = 0;
  u32 i = 0;
  int cnt = 1;

  u32 gopSize = tb->gopSize;
  ctx->adaptiveGop = (gopSize == 0);

  memset(&ctx->agop, 0, sizeof(ctx->agop));

  /* av packet malloc */
  if (av_new_packet(pkt, tb->packetBufSize))
    goto error;
  
#ifdef VCE_MEM_ERR_TEST
  if(VceMemoryCheck(options) != 0){
     ENC_TB_ERROR_PRINT("vce force memory error in function\n");
     goto error;
   }
#endif

  tb->outMemIndex = 0;

  SetupOutputBuffer(tb, pEncIn);
  pEncIn->pOutBuf[0] = (u32 *)pkt->data;
  ENC_TB_DEBUG_PRINT("pEncIn->pOutBuf[0] = %p\n", (void *)pEncIn->pOutBuf[0]);

  InitSliceCtl(tb, options);
  InitStreamSegmentCrl(tb, options);

  if (options->inputLineBufMode)
  {
    if (InitInputLineBuffer(&(tb->inputCtbLineBuf), options, pEncIn, ctx->hantro_encoder, tb))
    {
      ENC_TB_ERROR_PRINT("Fail to Init Input Line Buffer: virt_addr=%p, bus_addr=%08x\n",
              tb->inputCtbLineBuf.sram, (u32)(tb->inputCtbLineBuf.sramBusAddr));
      goto error;
    }

#ifdef VCE_MEM_ERR_TEST
    if(VceMemoryCheck(options) != 0){
       ENC_TB_ERROR_PRINT("vce force memory error in function\n");
       goto error;
    }
#endif

  }

  /* before VCEncStrmStart called */
  tb_init_pic(tb, options, (ma_s *)&ctx->ma, (adapGopCtr *)&ctx->agop);
  InitPicConfig(pEncIn, tb, options);
  ctx->nextGopSize = pEncIn->gopSize;

  /* Video, sequence and picture parameter sets */
  for (p = 0; p < cnt; p++)
  {
    if (VCEncStrmStart(ctx->hantro_encoder, pEncIn, encOut))
    {
      ENC_TB_ERROR_PRINT("VCEncStrmStart failed\n");
      goto error;
    }


    //ctx->total_bits += encOut->streamSize * 8;
    *streamSize = encOut->streamSize;
    ENC_TB_DEBUG_PRINT("*streamSize = %d\n", *streamSize);

		///////////////////////////
		/* printf start header */
		#if 0
		int kk = 0;
		//uint8_t *pp = (uint8_t *)tb->outbufMem[0]->rc_virtualAddress;
		uint8_t *pp = pkt->data;
		
		av_log(NULL, AV_LOG_INFO, "\nbefore EP2RC\n");
        for (kk = 0; kk < encOut->streamSize; kk++) {
			av_log(NULL, AV_LOG_INFO, "0x%x ", *(pp+kk));
			if (kk%16==15)
				av_log(NULL, AV_LOG_INFO, "\n");
        }
		av_log(NULL, AV_LOG_INFO, "\n");
  		#endif

		///////////////////////////
		

		///////////////////////////
		/* check start header */
		#if 0
		int kkk = 0;
		uint8_t *p = (uint8_t *)tb->outbufMem[0]->rc_virtualAddress;
        for (kkk = 0; kkk < encOut->streamSize; kkk++) {
			av_log(NULL, AV_LOG_INFO, "0x%x ", *(p+kkk));
			if (kkk%16==15)
				av_log(NULL, AV_LOG_INFO, "\n");
        }
		av_log(NULL, AV_LOG_INFO, "\n");
  		#endif

		///////////////////////////

  }

#ifdef VCE_MEM_ERR_TEST
    if(VceMemoryCheck(options) != 0){
       ENC_TB_ERROR_PRINT("vce force VCEncStrmStart get streamSize 0.\n");
       *streamSize = 0;
       pkt->size = *streamSize;
     }
#endif

  /* send start data */
  if (*streamSize != 0) {
/*
    //multi-core: output bitstream has (tb->parallelCoreNum-1) delay
    i32 coreIdx = (tb->picture_enc_cnt -1 - (tb->frame_delay-1)) % tb->parallelCoreNum;
    i32 iBuf;
    for (iBuf = 0; iBuf < tb->streamBufNum; iBuf ++)
      tb->outbufMem[iBuf] = &(tb->outbufMemFactory[coreIdx][iBuf]);

    EWLLinearMem_t mem;
	mem = *tb->outbufMem[0];

    if (av_new_packet(pkt, *streamSize))
      goto error;

#ifdef VCE_MEM_ERR_TEST
    if(VceMemoryCheck(options) != 0){
       av_log(avctx, AV_LOG_ERROR, "[%s,%d]vce force memory error in function\n", __FUNCTION__, __LINE__);
       goto error;
     }
#endif
#ifdef USE_OLD_DRV
      memcpy(pkt->data, (uint8_t *)mem.virtualAddress, *streamSize);
#else
      memcpy(pkt->data, (uint8_t *)mem.rc_virtualAddress, *streamSize);
#endif	
*/
      pkt->size = *streamSize;
  } else {
      pkt->size = 0;
  }

  ret = VCEncGetRateCtrl(ctx->hantro_encoder, (VCEncRateCtrl *)&ctx->rc);
  if(ret) goto error;

  /* Allocate a buffer for user data and read data from file */
  ctx->pUserData = ReadUserData(ctx->hantro_encoder, options->userData);

  /* Read configuration files for ROI/CuTree/IPCM/GMV ... */
  if (readConfigFiles(tb, options)) goto error;

  ENC_TB_DEBUG_PRINT("pkt->size = %d\n", pkt->size);
  
  return 0;

error:
  ENC_TB_ERROR_PRINT("%s error\n", __FUNCTION__);
  //hantro_consume_flush(avctx);
  return -1;
}

static int calcFlushDataCodingType(HANTROH26xEncContext *ctx)
{
  HANTROH26xEncOptions * options = &ctx->options;

  struct test_bench * tb = (struct test_bench *)&ctx->tb;
  VCEncIn *pEncIn = (VCEncIn *)&(tb->encIn);

  ENC_TB_DEBUG_PRINT("tb->encIn.indexTobeEncode[%d] tb->encIn.forceIDR = %d\n", tb->encIn.indexTobeEncode, tb->encIn.forceIDR);
  
  if (ctx->keyFrameFlag == HANTRO_TRUE) {

    if (pEncIn->gopPicIdx == pEncIn->gopSize - 1) {
      ENC_TB_DEBUG_PRINT("\n");
      ctx->nextGopStart = tb->input_pic_cnt; //tb->picture_enc_cnt; //tb->picture_enc_cnt + 1;
      int length = ctx->nextIDRPoc - ctx->nextGopStart;
      ENC_TB_DEBUG_PRINT("length = %d, ctx->nextGopStart = %d\n", length, ctx->nextGopStart);

      if (length == 0) {
        //ctx->nextGopSize = 4;
        ctx->idrFlag = FRAME_IDR;
      }
    }
  }

  ctx->nextGopSize = 1;

  ENC_TB_DEBUG_PRINT("+++ before VCEncFindNextPic: ctx->nextGopSize = %d\n", ctx->nextGopSize);

  tb->encIn.forceIDR = ((ctx->idrFlag == FRAME_IDR) ? HANTRO_TRUE : HANTRO_FALSE); //ctx->idrFlag; 
  pEncIn->resendPPS = pEncIn->resendSPS = pEncIn->resendVPS = ((ctx->idrFlag == FRAME_IDR) ? 1 : 0);

  ENC_TB_DEBUG_PRINT("tb->encIn.indexTobeEncode[%d] tb->encIn.forceIDR = %d\n", tb->encIn.indexTobeEncode, tb->encIn.forceIDR);

  if (ctx->idrFlag == FRAME_IDR) {
    ctx->nextCodingType = VCEncFindNextPic(ctx->hantro_encoder, pEncIn, ctx->nextGopSize, tb->encIn.gopConfig.gopCfgOffset, true);
    ENC_TB_DEBUG_PRINT("+++ idr flag is true: ctx->nextGopSize = %d, ctx->nextCodingType = %d\n", ctx->nextGopSize, ctx->nextCodingType);

    clearIDRPoc(ctx);
    ctx->updateIDRPoc = HANTRO_TRUE;

  } else {
    ctx->nextCodingType = VCEncFindNextPic(ctx->hantro_encoder, pEncIn, ctx->nextGopSize, tb->encIn.gopConfig.gopCfgOffset, false);
    ENC_TB_DEBUG_PRINT("+++ idr flag is false: ctx->nextGopSize = %d, ctx->nextCodingType = %d\n", ctx->nextGopSize, ctx->nextCodingType);
  }

  if (pEncIn->bIsIDR == HANTRO_TRUE) {
    ctx->idrFlag = ctx->forced_idr ? FRAME_IDR2NORMAL : FRAME_NORMAL;
  } else {
    ctx->idrFlag = FRAME_NORMAL;
  }

  return 0;
}

static int calcNextCodingType(HANTROH26xEncContext *ctx)
{
  HANTROH26xEncOptions * options = &ctx->options;

  struct test_bench * tb = (struct test_bench *)&ctx->tb;
  VCEncIn *pEncIn = (VCEncIn *)&(tb->encIn);

  if (ctx->keyFrameFlag == HANTRO_TRUE) {
    if (ctx->next_poc == 0) {
      pEncIn->gopSize = 1;
    }
 
    if (pEncIn->gopPicIdx == pEncIn->gopSize - 1) {
      ENC_TB_DEBUG_PRINT("\n");
      ctx->nextGopStart = tb->input_pic_cnt; //tb->picture_enc_cnt; //tb->picture_enc_cnt + 1;
      int length = ctx->nextIDRPoc - ctx->nextGopStart;
      ENC_TB_DEBUG_PRINT("length = %d, ctx->nextGopStart = %d\n", length, ctx->nextGopStart);

      if (length > ctx->gopLength) {
        //ctx->nextGopSize = 4;
        ENC_TB_DEBUG_PRINT("pass through\n");
      } else {
        if ((length >= 1) && (length <= ctx->gopLength)) {
          if (length > 4)
            ctx->nextGopSize = 4;
          else
            ctx->nextGopSize = length; // - 1;
          ENC_TB_DEBUG_PRINT("+++ ctx->nextGopSize = %d\n", ctx->nextGopSize);
        } else if (length == 0) {
          ENC_TB_DEBUG_PRINT("+++ next frame will encode IDR, ctx->nextGopStart = %d.\n", ctx->nextGopStart);
          ctx->nextGopSize = 1;
          ctx->idrFlag = FRAME_IDR; //HANTRO_TRUE;
        }
      }
    }
  }

  ENC_TB_DEBUG_PRINT("+++ before VCEncFindNextPic: ctx->nextGopSize = %d\n", ctx->nextGopSize);

  tb->encIn.forceIDR = ((ctx->idrFlag == FRAME_IDR) ? HANTRO_TRUE : HANTRO_FALSE); //ctx->idrFlag; 
  pEncIn->resendPPS = pEncIn->resendSPS = pEncIn->resendVPS = ((ctx->idrFlag == FRAME_IDR) ? 1 : 0);

  if (ctx->idrFlag == FRAME_IDR) {
    ctx->nextCodingType = VCEncFindNextPic(ctx->hantro_encoder, pEncIn, ctx->nextGopSize, tb->encIn.gopConfig.gopCfgOffset, true);
    ENC_TB_DEBUG_PRINT("+++ idr flag is true: ctx->nextGopSize = %d, ctx->nextCodingType = %d\n", ctx->nextGopSize, ctx->nextCodingType);

    clearIDRPoc(ctx);
    ctx->updateIDRPoc = HANTRO_TRUE;

  } else if (ctx->idrFlag == FRAME_IDR2NORMAL) {
    pEncIn->gopSize = ctx->nextGopSize = (ctx->adaptiveGop ? (options->lookaheadDepth ? 4 : 1) : tb->gopSize); 

    ctx->nextGopStart = tb->input_pic_cnt;
    int length_predict = ctx->nextIDRPoc - ctx->nextGopStart;
  
    if ((length_predict > 0) && (length_predict < ctx->nextGopSize)) {
      pEncIn->gopSize = ctx->nextGopSize = length_predict;
    }
	
    ctx->nextCodingType = VCEncFindNextPic(ctx->hantro_encoder, pEncIn, ctx->nextGopSize, tb->encIn.gopConfig.gopCfgOffset, false);
  }	else {
    ctx->nextCodingType = VCEncFindNextPic(ctx->hantro_encoder, pEncIn, ctx->nextGopSize, tb->encIn.gopConfig.gopCfgOffset, false);
    ENC_TB_DEBUG_PRINT("+++ idr flag is false: ctx->nextGopSize = %d, ctx->nextCodingType = %d\n", ctx->nextGopSize, ctx->nextCodingType);

  }

  if (pEncIn->bIsIDR == HANTRO_TRUE) {
    ctx->idrFlag = ctx->forced_idr ? FRAME_IDR2NORMAL : FRAME_NORMAL;
  } else {
    ctx->idrFlag = FRAME_NORMAL;
  }

  return 0;
}

av_cold int hantro_encode_encode(AVCodecContext *avctx, AVPacket *pkt,
                                    const AVFrame *pict, int *streamSize)
{
  HANTROH26xEncContext * ctx = (HANTROH26xEncContext *)avctx->priv_data;
  HANTROH26xEncOptions * options = &ctx->options;
  i32 ret = OK;
  struct test_bench * tb = (struct test_bench *)&ctx->tb;
  VCEncIn *pEncIn = (VCEncIn *)&(tb->encIn);
  VCEncOut *encOut = (VCEncOut *)&ctx->encOut;

  //AVFrame pict_stored = {0};
  HANTRO_ENC_IN_ADDR_t addrs;
  int64_t pict_pts = 0;
  u32 src_img_size;

  u32 i, tmp;
  int retValue = 0;
  int widthChromaValign32 = 0;
  //EncOutData_t out_buffer;
  int out_buf_index = -1;
  int startHeaderSize = 0;

  //ctx->EncInbk = *pEncIn;

  ENC_TB_DEBUG_PRINT("%s(%d)\n", __FUNCTION__, __LINE__);
  
  /* IO buffer */
  GetFreeIOBuffer(tb);
  SetupSliceCtl(tb);

  /* Setup encoder input */
  ENC_TB_DEBUG_PRINT("%s(%d)\n", __FUNCTION__, __LINE__);
  src_img_size = SetupInputBuffer(tb, options, pEncIn);

#if 0 /*do in api*/

  SetupOutputBuffer(tb, pEncIn);  

#endif

#ifdef SUPPORT_TCACHE
  if ((options->inputFormat >= INPUT_FORMAT_ARGB_FB && options->inputFormat <= INPUT_FORMAT_YUV444P)
      || options->inputFormat == VCENC_YUV420_PLANAR
      || options->inputFormat == VCENC_YUV420_SEMIPLANAR
      || options->inputFormat == VCENC_YUV420_SEMIPLANAR_VU
      || options->inputFormat == VCENC_YUV420_PLANAR_10BIT_P010)
  {
    ENC_TB_DEBUG_PRINT("raw input through TCache\n");
  }
  else
#endif
  {
#ifdef USE_OLD_DRV
    ENC_TB_DEBUG_PRINT("old drv not need edma\n");
#endif
  }

  ENC_TB_DEBUG_PRINT("%s %d, tb->encIn.picture_cnt = %d. \n", __FILE__, __LINE__, tb->encIn.picture_cnt);

  if (ctx->updateIDRPoc == HANTRO_TRUE) {
    updateNextIDRPoc(ctx, (int *)&ctx->nextIDRPoc);
  }

  ctx->next_poc = next_picture(tb, tb->encIn.picture_cnt) + tb->firstPic;

  pEncIn->indexTobeEncode = ctx->next_poc;
  //pEncIn->indexForOutbufMem = tb->outMemIndex;
  ENC_TB_DEBUG_PRINT("ctx->next_poc = %d\n", ctx->next_poc);
  //ENC_TB_DEBUG_PRINT("pict_stored = %p\n", &pict_stored);

  if (ctx->flushState == HANTRO_FLUSH_IDLE) {
    //if (hantro_send_pic(avctx, ctx->next_poc, &addrs, &pict_pts) < 0) {
    ret = hantro_send_pic(avctx, ctx->next_poc, &addrs, &pict_pts);
    if (ret < 0) {
      if (ret == VCENC_NULL_ARGUMENT) {
        ENC_TB_ERROR_PRINT("There is some error internal.\n"); 
        return -1;
      }

      ENC_TB_DEBUG_PRINT("[%d] ctx->next_poc = %d. wait next pict\n", tb->enc_index, ctx->next_poc);  	

      ctx->TransFlushPic = HANTRO_TRUE;
  
      return 0;
    } else {
      //out_buffer->needEagain = HANTRO_FALSE;
    }
  } else if (ctx->flushState == HANTRO_FLUSH_TRANSPIC) {
    ENC_TB_DEBUG_PRINT("Begin to flush trans DATA\n");  	

    if(hantro_trans_pic_flush_send(avctx, ctx->next_poc, &addrs, &pict_pts) < 0) {
      ENC_TB_DEBUG_PRINT("No Data Trans, begin to enter VCE Flush\n");  	
      return 0;
      //return HANTRO_FLUSH_TRANSPIC;
    }
  } else {
    /* not should be here */
    ENC_TB_ERROR_PRINT("There is some error internal.\n");  	
    return -1;
  }
  //pEncIn->pts = pict_pts; //??? need or not 

  if (tb->lastPic > 0 && ctx->next_poc > tb->lastPic) {
    ENC_TB_DEBUG_PRINT("next_poc = %d, exceed lastPic %d\n", ctx->next_poc, tb->lastPic);
    return -1;
  }
#if 10
  if (addrs.busLuma == NULL || addrs.busChroma == NULL) {
    ENC_TB_DEBUG_PRINT("get EOS\n");
    return 0;
  }

  if (pEncIn->poc == 0) {
    pEncIn->resendSPS = pEncIn->resendPPS = pEncIn->resendVPS = 1;
  }  
  
  if (tb->enc_index == 0 && options->lookaheadDepth && options->cutree_blkratio) {
    ENC_TB_DEBUG_PRINT("set 1pass ds addr\n");

    if (addrs.busLumaDs == 0 || addrs.busChromaDs == 0) {
      ENC_TB_ERROR_PRINT("1pass ds addr should not be zero!\n");
      return -1;
    }
  
    pEncIn->busLuma = addrs.busLumaDs;
    pEncIn->busChromaU = addrs.busChromaDs;
    pEncIn->busChromaV = 0;
#if defined(SUPPORT_DEC400) || defined(SUPPORT_TCACHE)
    tb->TSLumaMem->busAddress = addrs.busLumaTableDs;
    tb->TSChromaMem->busAddress = addrs.busChromaTableDs;
#endif

    pEncIn->busLumaOrig = addrs.busLuma;
    pEncIn->busChromaUOrig = addrs.busChroma;
    if(INPUT_FORMAT_PP_YUV420_SEMIPLANNAR_YUV420P == options->inputFormat){
      widthChromaValign32 = ((options->width/2+31)/32)*32;
      pEncIn->busChromaVOrig = addrs.busChroma + widthChromaValign32 * options->height/2;
    }
    else{
      pEncIn->busChromaVOrig = 0;
    }
  } else {
    pEncIn->busLuma = addrs.busLuma;
    pEncIn->busChromaU = addrs.busChroma;
    if(INPUT_FORMAT_PP_YUV420_SEMIPLANNAR_YUV420P == options->inputFormat){
      widthChromaValign32 = ((options->width/2+31)/32)*32;
      pEncIn->busChromaV = addrs.busChroma + widthChromaValign32 * options->height/2;
    }
    else{
      pEncIn->busChromaV = 0;
    }
#if defined(SUPPORT_DEC400) || defined(SUPPORT_TCACHE)
    tb->TSLumaMem->busAddress = addrs.busLumaTable;
    tb->TSChromaMem->busAddress = addrs.busChromaTable;
#endif
  }
#endif

  ENC_TB_DEBUG_PRINT("pEncIn->busLuma    = %p\n", pEncIn->busLuma);
  ENC_TB_DEBUG_PRINT("pEncIn->busChromaU = %p\n", pEncIn->busChromaU);
  ENC_TB_DEBUG_PRINT("pEncIn->resendSPS = %d\n",  pEncIn->resendSPS);

#if defined(SUPPORT_DEC400) || defined(SUPPORT_TCACHE)
  ENC_TB_DEBUG_PRINT("TSLumaMem->busAddr = %p\n", tb->TSLumaMem->busAddress);
  ENC_TB_DEBUG_PRINT("TSChromaMem->busAd = %p\n", tb->TSChromaMem->busAddress);
#endif  

  ctx->frameCntTotal++;

  FormatCustomizedYUV(tb, options, &ret);
    if(ret){
      ENC_TB_ERROR_PRINT("Format customized yuv failed\n"); 
      goto error;
    }

  /* 
    * per-frame test functions
    */ 
        
  /* 1. scene changed frames from usr*/
  pEncIn->sceneChange = 0;
  tmp = next_picture(tb, tb->encIn.picture_cnt) + tb->firstPic;
  for (i = 0; i < MAX_SCENE_CHANGE; i ++)
  {
    if (options->sceneChange[i] == 0)
    {
      break;
    }
    if (options->sceneChange[i] == tmp)
    {
      pEncIn->sceneChange = 1;
      break;
    }
  }

  /* 2. GMV setting from user*/
  readGmv(tb, pEncIn, options);

  pEncIn->codingType = (pEncIn->poc == 0) ? VCENC_INTRA_FRAME : ctx->nextCodingType;
#ifdef TEST_ENCODER_ONLY
  ENC_TB_INFO_PRINT("=== Encoding frame%i %s codeType=%d with poc %d...\n", tb->input_pic_cnt, tb->input, pEncIn->codingType, ctx->next_poc);
#else
  ENC_TB_INFO_PRINT("=== Encoding frame%i codeType=%d with poc %d...\n", tb->input_pic_cnt, pEncIn->codingType, ctx->next_poc);
#endif
  tb->input_pic_cnt ++;

  if (pEncIn->sceneChange) {
    ENC_TB_INFO_PRINT("    Input a Scene Changed Frame! \n");
  }

  if (pEncIn->codingType == VCENC_INTRA_FRAME&&options->gdrDuration == 0 && ((pEncIn->poc == 0)|| (pEncIn->bIsIDR)))
  {
    if(!options->lookaheadDepth)
      ctx->frameCntOutput = 0;
  }

  /* 3. On-fly bitrate setting */
  for (i = 0; i < MAX_BPS_ADJUST; i++)
    if (options->bpsAdjustFrame[i] &&
        (tb->encIn.picture_cnt == options->bpsAdjustFrame[i]))
    {
      ctx->rc.bitPerSecond = options->bpsAdjustBitrate[i];
      ENC_TB_INFO_PRINT("Adjusting bitrate target: %d\n", ctx->rc.bitPerSecond);
      if ((ret = VCEncSetRateCtrl(ctx->hantro_encoder, (VCEncRateCtrl *)&ctx->rc)) != VCENC_OK)
      {
        ENC_TB_ERROR_PRINT("VCEncSetRateCtrl() failed. ret is %d\n", ret);
      }
    }

  /* 4. SetupROI-Map */
  if (SetupROIMapBuffer(tb, options, pEncIn, ctx->hantro_encoder)) {
      ENC_TB_ERROR_PRINT("Failed to setup ROI map buffer\n");
      goto error;
    }

  /* 5. encoding specific frame from user: all CU/MB are SKIP*/
  pEncIn->bSkipFrame = options->skip_frame_enabled_flag && (pEncIn->poc == options->skip_frame_poc);

  /* 6. low latency */
  if (options->inputLineBufMode)
  {
    pEncIn->lineBufWrCnt = VCEncStartInputLineBuffer(&(tb->inputCtbLineBuf));
  }
    
#if defined(SUPPORT_DEC400) || defined(SUPPORT_TCACHE)
    pEncIn->PrivData.PicMemRcBusAddr = tb->pictureMem->rc_busAddress;

    pEncIn->PrivData.bitDepthLuma = options->bitDepthLuma;
    pEncIn->PrivData.input_alignment = tb->input_alignment;
    
    if (addrs.busLumaDs) {
  
      pEncIn->PrivData.lumaSize = tb->lumaSizeDs;
      pEncIn->PrivData.chromaSize = tb->chromaSizeDs;
      pEncIn->PrivData.lumWidthSrc = options->lumWidthSrc/2;
      pEncIn->PrivData.lumHeightSrc = options->lumHeightSrc/2;
      pEncIn->PrivData.inputFormat = options->inputFormat_ds;

      pEncIn->PrivData.TSLumaMemBusAddress = addrs.busLumaTableDs;
      pEncIn->PrivData.TSChromaMemBusAddress = addrs.busChromaTableDs;
      pEncIn->PrivData.busLuma = addrs.busLumaDs;
      pEncIn->PrivData.busChromaU = addrs.busChromaDs;
    } else {

      pEncIn->PrivData.lumaSize = tb->lumaSize;
      pEncIn->PrivData.chromaSize = tb->chromaSize;
      pEncIn->PrivData.lumWidthSrc = options->lumWidthSrc;
      pEncIn->PrivData.lumHeightSrc = options->lumHeightSrc;
      pEncIn->PrivData.inputFormat = options->inputFormat;
		
      pEncIn->PrivData.TSLumaMemBusAddress = addrs.busLumaTable; //picData->luma_table.bus_address; //
      pEncIn->PrivData.TSChromaMemBusAddress = addrs.busChromaTable; //picData->chroma_table.bus_address; //tb->TSChromaMem->busAddress;
      pEncIn->PrivData.busLuma = addrs.busLuma; //picData->luma.bus_address; //pEncIn->busLuma;
      pEncIn->PrivData.busChromaU = addrs.busChroma; //picData->chroma.bus_address; //pEncIn->busChromaU;
      if(INPUT_FORMAT_PP_YUV420_SEMIPLANNAR_YUV420P == options->inputFormat){
        widthChromaValign32 = ((options->width/2+31)/32)*32;
        pEncIn->PrivData.busChromaV = addrs.busChroma + widthChromaValign32 * options->height/2;
      }
      av_log(NULL, AV_LOG_DEBUG, "[%s@%d],Priv busLuma %p, busChromaU %p, busChromaV %p \n", __FUNCTION__, __LINE__,pEncIn->PrivData.busLuma, pEncIn->PrivData.busChromaU, pEncIn->PrivData.busChromaV);
      
    }
    /* for pass two encoder hardware set */  
    pEncIn->PassTwoHWData.bitDepthLuma = options->bitDepthLuma;
    pEncIn->PassTwoHWData.inputFormat = options->inputFormat;
    pEncIn->PassTwoHWData.lumaSize = tb->lumaSize;
    pEncIn->PassTwoHWData.chromaSize = tb->chromaSize;
    pEncIn->PassTwoHWData.lumWidthSrc = options->lumWidthSrc;
    pEncIn->PassTwoHWData.lumHeightSrc = options->lumHeightSrc;
    pEncIn->PassTwoHWData.input_alignment = tb->input_alignment;
    pEncIn->PassTwoHWData.TSLumaMemBusAddress = addrs.busLumaTable;//picData->luma_table.bus_address; //tb->TSLumaMem->busAddress;
    pEncIn->PassTwoHWData.TSChromaMemBusAddress = addrs.busChromaTable; //picData->chroma_table.bus_address; //tb->TSChromaMem->busAddress;
    pEncIn->PassTwoHWData.PicMemRcBusAddr = tb->pictureMem->rc_busAddress;
    pEncIn->PassTwoHWData.busLuma = addrs.busLuma; //picData->luma.bus_address; //pEncIn->busLuma;
    pEncIn->PassTwoHWData.busChromaU = addrs.busChroma; //picData->chroma.bus_address; //pEncIn->busChromaU;
    if(INPUT_FORMAT_PP_YUV420_SEMIPLANNAR_YUV420P == options->inputFormat){
      widthChromaValign32 = ((options->width/2+31)/32)*32;
      pEncIn->PassTwoHWData.busChromaV = addrs.busChroma + widthChromaValign32 * options->height/2;
    }
    av_log(NULL, AV_LOG_DEBUG, "[%s@%d],Pass2 busLuma %p, busChromaU %p, busChromaV %p \n", __FUNCTION__, __LINE__,pEncIn->PassTwoHWData.busLuma, pEncIn->PassTwoHWData.busChromaU, pEncIn->PassTwoHWData.busChromaV);

    if (options->inputFormat == INPUT_FORMAT_RFC_8BIT_COMPRESSED_FB
        || options->inputFormat == INPUT_FORMAT_RFC_10BIT_COMPRESSED_FB) {
      i32 x = (options->horOffsetSrc == DEFAULT) ? 0 : options->horOffsetSrc;
      i32 y = (options->verOffsetSrc == DEFAULT) ? 0 : options->verOffsetSrc;
      i32 w = (options->width == DEFAULT) ? 0 : options->width;
      i32 h = (options->height == DEFAULT) ? 0 : options->height;
      i32 b = (options->inputFormat == INPUT_FORMAT_RFC_10BIT_COMPRESSED_FB) ? 2 : 1;
      i32 aw = (((w*b+31)/32)*32)/b;
      i32 ah = (((y+h)+7)/8)*8-y;
      ENC_TB_DEBUG_PRINT("options->lumWidthSrc = %d, x = %d, w = %d, b = %d, aw = %d\n", options->lumWidthSrc, x, w, b, aw);
      if (w) {
        pEncIn->PassTwoHWData.crop_x = x;
        pEncIn->PassTwoHWData.crop_w = MIN(aw, options->lumWidthSrc-x);
      }
      ENC_TB_DEBUG_PRINT("pEncIn->PassTwoHWData.crop_x = %d, pEncIn->PassTwoHWData.crop_w = %d\n",
          pEncIn->PassTwoHWData.crop_x, pEncIn->PassTwoHWData.crop_w);
      if (ah) {
        pEncIn->PassTwoHWData.crop_y = y;
        pEncIn->PassTwoHWData.crop_h = ah;
      }
      ENC_TB_DEBUG_PRINT("pEncIn->PassTwoHWData.crop_y = %d, pEncIn->PassTwoHWData.crop_h = %d\n",
          pEncIn->PassTwoHWData.crop_y, pEncIn->PassTwoHWData.crop_h);
      
      if ((pEncIn->PassTwoHWData.crop_x || pEncIn->PassTwoHWData.crop_w)
        && pEncIn->PassTwoHWData.crop_y == 0 && pEncIn->PassTwoHWData.crop_h == 0) {
        pEncIn->PassTwoHWData.crop_h = pEncIn->PassTwoHWData.lumHeightSrc;
      }
        if ((pEncIn->PassTwoHWData.crop_y || pEncIn->PassTwoHWData.crop_h)
        && pEncIn->PassTwoHWData.crop_x == 0 && pEncIn->PassTwoHWData.crop_w == 0) {
        pEncIn->PassTwoHWData.crop_w = pEncIn->PassTwoHWData.lumWidthSrc;
      }
      if (pEncIn->PassTwoHWData.crop_x == 0 && pEncIn->PassTwoHWData.crop_w == options->lumWidthSrc
        && pEncIn->PassTwoHWData.crop_y == 0 && pEncIn->PassTwoHWData.crop_h == options->lumHeightSrc) {
        pEncIn->PassTwoHWData.crop_w = 0;
        pEncIn->PassTwoHWData.crop_h = 0;
      }
      pEncIn->PrivData.crop_x = pEncIn->PassTwoHWData.crop_x;
      pEncIn->PrivData.crop_y = pEncIn->PassTwoHWData.crop_y;
      pEncIn->PrivData.crop_w = pEncIn->PassTwoHWData.crop_w;
      pEncIn->PrivData.crop_h = pEncIn->PassTwoHWData.crop_h;
      ENC_TB_DEBUG_PRINT("need set dtrc crop (%d, %d, %d x %d)\n", pEncIn->PassTwoHWData.crop_x,
          pEncIn->PassTwoHWData.crop_y, pEncIn->PassTwoHWData.crop_w, pEncIn->PassTwoHWData.crop_h);
    }
#endif

  gettimeofday(&tb->timeFrameStart, 0);
  ret = VCEncStrmEncode(ctx->hantro_encoder, pEncIn, encOut, &HEVCSliceReady, tb->sliceCtl);
  gettimeofday(&tb->timeFrameEnd, 0);

  if (ret != VCENC_FRAME_ENQUEUE) {
    ENC_TB_DEBUG_PRINT("hantro_consume_stored_pic[%d] \n", encOut->indexEncoded);
 
    hantro_consume_stored_pic(avctx, encOut->indexEncoded);
  }
  
  switch (ret)
  {
    case VCENC_FRAME_ENQUEUE:
      //tb->picture_enc_cnt++;

      ENC_TB_DEBUG_PRINT("VCENC_FRAME_ENQUEUE\n");
      //if (ctx->EncFlushFlag == HANTRO_FALSE) {
        //Adaptive GOP size decision
        if (ctx->adaptiveGop && options->lookaheadDepth) {
            ENC_TB_DEBUG_PRINT("got nextGopSize[%d] before from func getNextGopSize\n", ctx->nextGopSize);
            getNextGopSize(tb, pEncIn, ctx->hantro_encoder, &ctx->nextGopSize, &ctx->agop);
            ENC_TB_DEBUG_PRINT("got nextGopSize[%d] from func getNextGopSize\n", ctx->nextGopSize);
        } else if(options->lookaheadDepth) { // for sync only, not update gopSize
          getPass1UpdatedGopSize(((struct vcenc_instance *)ctx->hantro_encoder)->lookahead.priv_inst);
        }
      //} else {
      if (ctx->flushState == HANTRO_FLUSH_TRANSPIC) {
        ctx->nextGopSize = 1;
      }

      ctx->EncInbk = *pEncIn;
      ctx->picture_cnt_bk = tb->encIn.picture_cnt;

      calcNextCodingType(ctx);
 
      //ctx->nextCodingType = VCEncFindNextPic (ctx->hantro_encoder, pEncIn, ctx->nextGopSize, tb->encIn.gopConfig.gopCfgOffset, false);
      pEncIn->timeIncrement = tb->outputRateDenom;
      break;        
    case VCENC_FRAME_READY:
#if defined(SUPPORT_DEC400) || defined(SUPPORT_TCACHE)
      if (ReleasePass2InputHwTransformer(ctx->hantro_encoder, &pEncIn->PassTwoHWData) < 0) {
        ENC_TB_ERROR_PRINT("ReleasePass2InputHwTransformer failed\n");
        goto error;
      }
#endif
      ENC_TB_DEBUG_PRINT("encOut->indexEncoded = %d\n", encOut->indexEncoded);
      ENC_TB_DEBUG_PRINT("encOut->codingType = %d\n", encOut->codingType);
	  ENC_TB_DEBUG_PRINT("encOut->streamSize = %d\n", encOut->streamSize);

      if(encOut->codingType != VCENC_NOTCODED_FRAME)
        tb->picture_enc_cnt++;
      if (encOut->streamSize == 0)
      {
        tb->encIn.picture_cnt ++;
        break;
      }

      ENC_TB_DEBUG_PRINT("\n");
	  
      //*streamSize += encOut->streamSize;

      //ENC_TB_DEBUG_PRINT("*streamSize = %d\n", *streamSize);
#if 0 //ndef USE_OLD_DRV
      //EWLTransDataEP2RC(tb->ewl, tb->outbufMem[0], tb->outbufMem[0], encOut->streamSize);
      if (EWLTransDataEP2RC(tb->ewl, tb->outbufMem[0], tb->outbufMem[0], *streamSize))
          goto error;

#ifdef VCE_EDMA_ERR_TEST
      if(VceEDMAErrCheck(options) != 0){
          av_log(avctx, AV_LOG_ERROR, "[%s,%d]vce force edma error in function\n", __FUNCTION__, __LINE__);
          goto error;
      }
#endif

#endif

#if 0
      if (pict) {
        pict_pts = pict->pts;
      }
#endif

      //retValue = hantro_processFrame(avctx, pkt, &out_buffer, startHeaderSize);
      retValue = hantro_processFrame(avctx, pkt, encOut->p_out_buffer, ctx->outPkt->size);
      if(retValue < 0)
        goto error;

      ENC_TB_DEBUG_PRINT("hantro_processFrame over\n");

      //if (ctx->EncFlushFlag == HANTRO_FALSE) {
        //Adaptive GOP size decision
        if (ctx->adaptiveGop) {
          getNextGopSize(tb, pEncIn, ctx->hantro_encoder, &ctx->nextGopSize, &ctx->agop);
        }
        else if(options->lookaheadDepth) { // for sync only, not update gopSize
           getPass1UpdatedGopSize(((struct vcenc_instance *)ctx->hantro_encoder)->lookahead.priv_inst);
        }
		//} else {
     
      if (ctx->flushState == HANTRO_FLUSH_TRANSPIC) {
        ctx->nextGopSize = 1;
      }

      ctx->EncInbk = *pEncIn;
      ctx->picture_cnt_bk = tb->encIn.picture_cnt;

      /* add for IDR */
      ENC_TB_DEBUG_PRINT("+++ ctx->nextIDRPoc = %d, ctx->poc = %d, ctx->next_poc = %d, tb->picture_enc_cnt = %d, tb->encIn.picture_cnt = %d\n", ctx->nextIDRPoc, ctx->poc, ctx->next_poc, tb->picture_enc_cnt, tb->encIn.picture_cnt);
      ENC_TB_DEBUG_PRINT("+++ pEncIn->gopPicIdx = %d, pEncIn->gopSize = %d, ctx->nextGopSize = %d\n", pEncIn->gopPicIdx, pEncIn->gopSize, ctx->nextGopSize);

      calcNextCodingType(ctx);

      //ctx->nextCodingType = VCEncFindNextPic (ctx->hantro_encoder, pEncIn, ctx->nextGopSize, tb->encIn.gopConfig.gopCfgOffset, false);

      ENC_TB_DEBUG_PRINT("pEncIn->gopSize = %d, tb->nextGopSize = %d\n", pEncIn->gopSize, tb->nextGopSize);

      if (ctx->pUserData)
      {
        /* We want the user data to be written only once so
         * we disable the user data and free the memory after
         * first frame has been encoded. */
        VCEncSetSeiUserData(ctx->hantro_encoder, NULL, 0);
        EWLfree(ctx->pUserData);
        ctx->pUserData = NULL;
      }
      break;
    case VCENC_OUTPUT_BUFFER_OVERFLOW:
      tb->encIn.picture_cnt ++;
      break;
    default:
      ENC_TB_ERROR_PRINT("VCEncStrmEncode ret is %d\n", ret);
      goto error;
      break;
    }

#if 0
    if (ctx->updateIDRPoc == HANTRO_TRUE) {
      updateNextIDRPoc(ctx, (int *)&ctx->nextIDRPoc);
    }
#endif

    ENC_TB_DEBUG_PRINT("ctx->frameCntTotal[%d] \n", ctx->frameCntTotal);

#if 0
    if (ret != VCENC_FRAME_ENQUEUE) {
      //hantro_consume_stored_pic(avctx, ctx->next_poc);
      ENC_TB_DEBUG_PRINT("hantro_consume_stored_pic[%d] \n", encOut->indexEncoded);

      hantro_consume_stored_pic(avctx, encOut->indexEncoded);
    }
#endif

#if 10
    if(options->profile==VCENC_HEVC_MAIN_STILL_PICTURE_PROFILE)
      return ret;
#endif

	return ret;
error:

  ret = -1;
  if (ret != OK) {
    ENC_TB_ERROR_PRINT("encode() fails\n");
    VCEncSetError(ctx->hantro_encoder);
    av_log(ctx, AV_LOG_ERROR, "encode() fails %p\n", ctx->hantro_encoder);
	//hantro_consume_flush(avctx);
  }

  return -1;
}

int hantro_trans_flush_set(AVCodecContext *avctx)
{
  HANTROH26xEncContext * ctx = (HANTROH26xEncContext *)avctx->priv_data;
  struct test_bench * tb = (struct test_bench *)&ctx->tb;
  VCEncIn *pEncIn = (VCEncIn *)&(tb->encIn);
  
  //if (ctx->flushState == HANTRO_FLUSH_PREPARE) {
    ENC_TB_DEBUG_PRINT("get EOS, begin to flush trans pic\n");
    ctx->flushState = HANTRO_FLUSH_TRANSPIC;

    hantro_rest_data_check(avctx); //to check for debug
  
    *pEncIn = ctx->EncInbk;
    tb->encIn.picture_cnt = ctx->picture_cnt_bk;
    //ctx->nextCodingType = VCEncFindNextPic(ctx->hantro_encoder, pEncIn, 1, tb->encIn.gopConfig.gopCfgOffset, false);
    calcFlushDataCodingType(ctx);
    pEncIn->gopSize = 1;
    pEncIn->timeIncrement = tb->outputRateDenom;
  //}

  return 0;
}

av_cold int hantro_encode_flush(AVCodecContext *avctx, int *streamSize, 
                                 AVPacket *pkt,int *got_packet)
{
  HANTROH26xEncContext * ctx = (HANTROH26xEncContext *)avctx->priv_data;
  HANTROH26xEncOptions * options = &ctx->options;
  i32 ret = OK;
  struct test_bench * tb = (struct test_bench *)&ctx->tb;
  VCEncIn *pEncIn = (VCEncIn *)&(tb->encIn);
  VCEncOut *encOut = (VCEncOut *)&ctx->encOut;
  int retValue = 0;

  //*got_packet = 0;

  //while((ret = VCEncFlush(ctx->hantro_encoder, pEncIn, encOut, &HEVCSliceReady)) != VCENC_OK)
  ret = VCEncFlush(ctx->hantro_encoder, pEncIn, encOut, &HEVCSliceReady);	
  
  {
    switch (ret)
    {
      case VCENC_FRAME_READY:
        //SetupOutputBuffer(tb, pEncIn); /*do in api*/
        SetupSliceCtl(tb);
        tb->picture_enc_cnt++;
        if (encOut->streamSize == 0)
        {
          tb->encIn.picture_cnt ++;
          ENC_TB_DEBUG_PRINT("VCENC_FRAME_READY streamSize is 0\n");
          break;
        }
#if 0 //ndef USE_OLD_DRV
        if (EWLTransDataEP2RC(tb->ewl, tb->outbufMem[0], tb->outbufMem[0], encOut->streamSize))
          goto error;

#ifdef VCE_EDMA_ERR_TEST
        if(VceEDMAErrCheck(options) != 0){
          av_log(avctx, AV_LOG_ERROR, "[%s,%d]vce force edma error in function\n", __FUNCTION__, __LINE__);
          ret = -1;
        }
#endif
 
#endif
        //retValue = hantro_processFrame(avctx, pkt, &out_buffer, out_buffer.headerSize); //???
        retValue = hantro_processFrame(avctx, pkt, encOut->p_out_buffer, ctx->outPkt->size);
        if (retValue < 0) {
          goto error;
        }
		//hantro_packet_rcv(avctx, pkt);
        //*got_packet = 1;
        hantro_consume_stored_pic(avctx, encOut->indexEncoded);
        break;
      case VCENC_FRAME_ENQUEUE:
	  	//*got_packet = 1;
        //ASSERT(0);
        //continue;
        ENC_TB_DEBUG_PRINT("VCENC_FRAME_ENQUEUE\n");
        break;
      case VCENC_OUTPUT_BUFFER_OVERFLOW:
        tb->encIn.picture_cnt ++;
        break;
      case VCENC_OK:
        //ctx->EncoderFlushPic = HANTRO_TRUE;
        ctx->flushState = HANTRO_FLUSH_FINISH;
        ENC_TB_DEBUG_PRINT("VCENC_OK\n");
        break;
      default:
        ENC_TB_ERROR_PRINT("VCEncMultiCoreFlush ret = %d\n", ret);
        goto error;
        //break;
    }
  }
  
  return 0;
error:
  //ctx->EncoderFlushPic == HANTRO_TRUE;
  ctx->flushState = HANTRO_FLUSH_FINISH;
  return -1;	
}

av_cold int hantro_encode_end(AVCodecContext *avctx, int *streamSize, 
                                 AVPacket *pkt,int *got_packet)
{
  HANTROH26xEncContext * ctx = (HANTROH26xEncContext *)avctx->priv_data;
  HANTROH26xEncOptions * options = &ctx->options;
  i32 ret = OK;
  struct test_bench * tb = (struct test_bench *)&ctx->tb;
  VCEncIn *pEncIn = (VCEncIn *)&(tb->encIn);
  VCEncOut *encOut = (VCEncOut *)&ctx->encOut;

  EncOutData_t *out_buffer = NULL;

  if (ctx->EncoderIsEnd == HANTRO_TRUE) return 0;

  if (av_new_packet(pkt, tb->packetBufSize))
    return -1;
  
#ifdef VCE_MEM_ERR_TEST
  if(VceMemoryCheck(options) != 0){
    ENC_TB_ERROR_PRINT("[%s,%d]vce force memory error in function\n");
    goto error;
  }
#endif
  tb->outMemIndex = (tb->outMemIndex + 1) % (MAX_OUTPUT_FIFO_DEPTH);

  //SetupOutputBuffer(tb, pEncIn); /*do in api*/
  pEncIn->pOutBuf[0] = (u32 *)pkt->data;

  ret = VCEncStrmEnd(ctx->hantro_encoder, pEncIn, encOut);

#ifdef VCE_MEM_ERR_TEST
    if(VceMemoryCheck(options) != 0){
       ENC_TB_ERROR_PRINT("vce force VCEncStrmEnd return error\n");
       ret = VCENC_ERROR;
     }
#endif

  if (ret == VCENC_OK)
  {  
/*
    i32 coreIdx = (tb->picture_enc_cnt -1 - (tb->frame_delay-1)) % tb->parallelCoreNum;
    i32 iBuf;
    for (iBuf = 0; iBuf < tb->streamBufNum; iBuf ++)
      tb->outbufMem[iBuf] = &(tb->outbufMemFactory[coreIdx][iBuf]);

    EWLLinearMem_t mem;
	mem = *tb->outbufMem[0];

    //av_log(NULL, AV_LOG_DEBUG, "%s %d encOut->streamSize = %d\n", __FILE__, __LINE__, encOut->streamSize);

    if (av_new_packet(pkt, encOut->streamSize))
      goto error;

#ifdef USE_OLD_DRV
    EWLLinearMem_t mem;
	mem = *tb->outbufMem[0];
    memcpy(pkt->data, (uint8_t *)mem.virtualAddress, encOut->streamSize);
#else
    memcpy(pkt->data, (uint8_t *)mem.rc_virtualAddress, encOut->streamSize);
#endif
*/

#if 0    
    /* add4debug */
    FifoPop(ctx->EmptyBuf, &out_buffer, FIFO_EXCEPTION_DISABLE);
    /* add end */

    out_buffer->headerSize = encOut->streamSize;
    out_buffer->headerData = pkt->data;
    out_buffer->endData    = HANTRO_TRUE;
    out_buffer->inTwoPassWait = HANTRO_FALSE;
    av_log(avctx, AV_LOG_DEBUG, "[%s] out_buffer->headerSize = %d\n", __FUNCTION__, out_buffer->headerSize);
    FifoPush(ctx->OutputFifo, out_buffer, FIFO_EXCEPTION_DISABLE);

    pkt->size = encOut->streamSize;

	//*got_packet = 1;
#endif
    out_buffer = encOut->p_out_buffer;

    out_buffer->headerSize = encOut->streamSize;
    out_buffer->headerData = pkt->data;
    out_buffer->endData = HANTRO_TRUE;
    GetEndData(ctx->hantro_encoder, out_buffer, encOut);

  } else {
    ENC_TB_ERROR_PRINT("VCEncStrmEnd ret is %d\n", ret);
    av_packet_unref(pkt);
    goto error;
  }

  ctx->EncoderIsEnd = HANTRO_TRUE;
  //hantro_consume_flush(avctx);

  return 0;
error:
  //hantro_consume_flush(avctx);
  return -1;
}
	
/*------------------------------------------------------------------------------

    OpenEncoder
        Create and configure an encoder instance.

    Params:
        options     - processed comand line options
        pEnc    - place where to save the new encoder instance
    Return:
        0   - for success
        -1  - error

------------------------------------------------------------------------------*/
int OpenEncoder(HANTROH26xEncOptions *options, VCEncInst *pEnc, struct test_bench *tb)
{
  VCEncRet ret = -1;
  VCEncConfig cfg;
  VCEncCodingCtrl codingCfg;
  VCEncRateCtrl rcCfg;
  VCEncPreProcessingCfg preProcCfg;
  VCEncInst encoder = NULL;
  i32 i;
  EWLInitParam_t param = {0};

#if 0
  /* Default resolution, try parsing input file name */
  if (options->lumWidthSrc == DEFAULT || options->lumHeightSrc == DEFAULT)
  {
    if (GetResolution(options->input, &options->lumWidthSrc, &options->lumHeightSrc))
    {
      /* No dimensions found in filename, using default QCIF */
      options->lumWidthSrc = 176;
      options->lumHeightSrc = 144;
    }
  }
#endif
  /* Encoder initialization */
  if (options->width == DEFAULT)
    options->width = options->lumWidthSrc;

  if (options->height == DEFAULT)
    options->height = options->lumHeightSrc;

  ChangeCmlCustomizedFormat(options);
  
  /* outputRateNumer */
  if (options->outputRateNumer == DEFAULT)
  {
    options->outputRateNumer = options->inputRateNumer;
  }

  /* outputRateDenom */
  if (options->outputRateDenom == DEFAULT)
  {
    options->outputRateDenom = options->inputRateDenom;
  }
  /*cfg.ctb_size = options->max_cu_size;*/
  if (options->rotation&&options->rotation!=3)
  {
    cfg.width = options->height;
    cfg.height = options->width;
  }
  else
  {
    cfg.width = options->width;
    cfg.height = options->height;
  }


  cfg.frameRateDenom = options->outputRateDenom;
  cfg.frameRateNum = options->outputRateNumer;

  /* intra tools in sps and pps */
  cfg.strongIntraSmoothing = options->strong_intra_smoothing_enabled_flag;

  cfg.streamType = (options->byteStream) ? VCENC_BYTE_STREAM : VCENC_NAL_UNIT_STREAM;

  cfg.level = (IS_H264(options->codecFormat) ? VCENC_H264_LEVEL_5_2 : VCENC_HEVC_LEVEL_5_1);

  /* hard coded level for H.264 */
  if (options->level != DEFAULT && options->level != 0)
    cfg.level = (VCEncLevel)options->level;

  cfg.tier = VCENC_HEVC_MAIN_TIER;
  if (options->tier != DEFAULT)
    cfg.tier = (VCEncTier)options->tier;

  //cfg.profile = (IS_H264(options->codecFormat) ? VCENC_H264_HIGH_PROFILE : VCENC_HEVC_MAIN_PROFILE);
  cfg.profile = (IS_H264(options->codecFormat) ? VCENC_H264_MAIN_PROFILE : VCENC_HEVC_MAIN_PROFILE);

  cfg.codecFormat = options->codecFormat;

  if (options->profile != DEFAULT && options->profile != 0)
    cfg.profile = (VCEncProfile)options->profile;    

  /* convert between H.264/HEVC profiles for testing purpose */
  if(IS_H264(options->codecFormat)) {
    if((int)cfg.profile >= VCENC_HEVC_MAIN_PROFILE && cfg.profile < VCENC_HEVC_MAIN_10_PROFILE)
      cfg.profile = VCENC_H264_HIGH_PROFILE;
  } else {
    if(cfg.profile >= VCENC_H264_BASE_PROFILE && cfg.profile <= VCENC_H264_HIGH_PROFILE)
      cfg.profile = VCENC_HEVC_MAIN_PROFILE;
  }

  cfg.bitDepthLuma = 8;
  if (options->bitDepthLuma != DEFAULT && options->bitDepthLuma != 8)
    cfg.bitDepthLuma = options->bitDepthLuma;    

  cfg.bitDepthChroma= 8;
  if (options->bitDepthChroma != DEFAULT && options->bitDepthChroma != 8)
    cfg.bitDepthChroma = options->bitDepthChroma;

  //for fbtrans bitdepth = 9 is not supported, and bitdepth luma != chroma is not supported too -kwu
  if ((cfg.bitDepthLuma != 8 && cfg.bitDepthLuma != 10)
        || (cfg.bitDepthChroma != 8 && cfg.bitDepthChroma != 10)
        || cfg.bitDepthLuma != cfg.bitDepthChroma) {
    ENC_TB_ERROR_PRINT("UNSUPPORT bitdepth!\n");
    goto error_exit;
  }

  if ((options->interlacedFrame && options->gopSize != 1) || IS_H264(options->codecFormat))
  {
    ENC_TB_INFO_PRINT("OpenEncoder: treat interlace to progressive for gopSize!=1 case\n");
    options->interlacedFrame = 0;
  }

#ifndef BUILD_CMODEL
  if (options->inputFormat == VCENC_YUV420_SEMIPLANAR_8BIT_FB
    || options->inputFormat == VCENC_YUV420_SEMIPLANAR_VU_8BIT_FB
    || options->inputFormat == VCENC_YUV420_PLANAR_10BIT_P010_FB
#ifdef SUPPORT_DEC400
    || options->inputFormat == INPUT_FORMAT_YUV420_SEMIPLANAR_8BIT_COMPRESSED_FB
    || options->inputFormat == INPUT_FORMAT_YUV420_SEMIPLANAR_VU_8BIT_COMPRESSED_FB
    || options->inputFormat == INPUT_FORMAT_YUV420_PLANAR_10BIT_P010_COMPRESSED_FB
#endif
    ) {
    if (options->exp_of_input_alignment < 10)
      options->exp_of_input_alignment = 10;
  }
  options->exp_of_ref_alignment = 10;
  options->exp_of_ref_ch_alignment = 10;
#endif

  //default maxTLayer
  cfg.maxTLayers = 1;

  /* Find the max number of reference frame */
  if (options->intraPicRate == 1)
  {
    cfg.refFrameAmount = 0;
  }
  else
  {
    u32 maxRefPics = 0;
    u32 maxTemporalId = 0;
    int idx;
    for (idx = 0; idx < tb->encIn.gopConfig.size; idx ++)
    {
      VCEncGopPicConfig *cfg = &(tb->encIn.gopConfig.pGopPicCfg[idx]);
      if (cfg->codingType != VCENC_INTRA_FRAME)
      {
        if (maxRefPics < cfg->numRefPics)
          maxRefPics = cfg->numRefPics;

        if (maxTemporalId < cfg->temporalId)
          maxTemporalId = cfg->temporalId;
      }
    }
    cfg.refFrameAmount = maxRefPics + options->interlacedFrame + tb->encIn.gopConfig.ltrcnt;
    cfg.maxTLayers = maxTemporalId +1;
  }
  cfg.compressor = options->compressor;
  ENC_TB_DEBUG_PRINT("cfg.compressor = %d\n", cfg.compressor); 

  cfg.interlacedFrame = options->interlacedFrame;
  cfg.enableOutputCuInfo = (options->enableOutputCuInfo > 0) ? 1 : 0;
  cfg.rdoLevel = CLIP3(1, 3, options->rdoLevel) - 1;
  ENC_TB_DEBUG_PRINT("cfg.rdoLevel = %d\n", cfg.rdoLevel);
  cfg.verbose = options->verbose;
  cfg.exp_of_input_alignment = options->exp_of_input_alignment;
  cfg.exp_of_ref_alignment = options->exp_of_ref_alignment;
  cfg.exp_of_ref_ch_alignment = options->exp_of_ref_ch_alignment;
  cfg.exteralReconAlloc = 0;
  cfg.P010RefEnable = options->P010RefEnable;
  cfg.enableSsim = options->ssim;
  cfg.ctbRcMode = (options->ctbRc != DEFAULT) ? options->ctbRc : 0;
  cfg.parallelCoreNum = options->parallelCoreNum;
  cfg.pass = (options->lookaheadDepth?2:0);
  cfg.bPass1AdaptiveGop = (options->gopSize == 0);
  cfg.picOrderCntType = options->picOrderCntType;
  cfg.dumpRegister = options->dumpRegister;
  cfg.rasterscan = options->rasterscan;
  cfg.log2MaxPicOrderCntLsb = options->log2MaxPicOrderCntLsb;
  cfg.log2MaxFrameNum = options->log2MaxFrameNum;
  cfg.lookaheadDepth = options->lookaheadDepth;
  cfg.extDSRatio = ((options->lookaheadDepth && options->cutree_blkratio) ? 1 : 0);
  if (cfg.extDSRatio) {
    cfg.width_ds = options->width_ds;
    if (options->width_ds == DEFAULT) {
      cfg.width_ds = options->lumWidthSrc_ds;
    }
    cfg.height_ds = options->height_ds;
    if (options->height_ds == DEFAULT) {
      cfg.height_ds = options->lumHeightSrc_ds;
    }
  }
  ENC_TB_DEBUG_PRINT("[%d] cfg.extDSRatio = %d, and ds res %dx%d\n", tb->enc_index, cfg.extDSRatio, cfg.width_ds, cfg.height_ds);
  if (options->parallelCoreNum > 1 && cfg.width * cfg.height < 256*256) {
    ENC_TB_INFO_PRINT("Disable multicore for small resolution (< 255*255)\n");
    cfg.parallelCoreNum = options->parallelCoreNum = 1;
  }

#ifdef FB_SYSLOG_ENABLE
  cfg.enc_index = tb->enc_index;
#ifdef DRV_NEW_ARCH
  cfg.device_id = tb->log_header.device_id;
#endif
#endif

  ENC_TB_DEBUG_PRINT("\n+++ cfg.w = %d, cfg.h = %d\n", cfg.width, cfg.height);


  cfg.perf = EWLcalloc(1, sizeof(ENCPERF));
  if (cfg.perf) {
    ENCPERF * perf = cfg.perf;
    tb->perf = perf;
    ENC_TB_DEBUG_PRINT("calloc perf = %p\n", perf);
    pthread_mutex_init(&perf->hwcycle_acc_mutex, NULL);
#ifdef FB_PERFORMANCE_STATIC
    PERFORMANCE_STATIC_INIT(tb, perf, vcehw);
    PERFORMANCE_STATIC_INIT(tb, perf, vcehwp1);
    PERFORMANCE_STATIC_INIT(tb, perf, vce_dummy_0);
    PERFORMANCE_STATIC_INIT(tb, perf, vce_dummy_1);
    PERFORMANCE_STATIC_INIT(tb, perf, CU_ANAL);
    PERFORMANCE_STATIC_INIT(tb, perf, vcehw_total);
    PERFORMANCE_STATIC_INIT(tb, perf, vce_total);
#endif
  }

  param.clientType = IS_H264(options->codecFormat) ? EWL_CLIENT_TYPE_H264_ENC : EWL_CLIENT_TYPE_HEVC_ENC;
  
#ifdef DRV_NEW_ARCH
  param.device = tb->device;
  param.priority = tb->priority;
  param.mem_id = tb->mem_id;
  param.pass = 0;
#endif
  param.perf = cfg.perf;
  param.ewl_index = tb->enc_index;

#ifdef VCE_MEM_ERR_TEST
  param.vce_memory_err_shadow = (i32 *)&options->vce_memory_err_shadow;
  param.vce_memory_err_cnt    = (i32 *)&options->vce_memory_err_cnt;
#endif
  
#ifdef VCE_EDMA_ERR_TEST
  param.vce_edma_err_shadow   = (i32 *)&options->vce_edma_err_shadow;
  param.vce_edma_err_cnt      = (i32 *)&options->vce_edma_err_cnt;
#endif

  if ((tb->ewl = EWLInit(&param)) == NULL)
  {
    ENC_TB_ERROR_PRINT("OpenEncoder: EWL Initialization failed!\n");
    goto error_exit;
  }
  ENC_TB_DEBUG_PRINT("ewl is outside initialized.\n");

  /* this is for 2 pass */
  if (options->lookaheadDepth != 0) {
    param.pass = 1;
    if ((tb->twoPassEwl = EWLInit(&param)) == NULL)
    {
      ENC_TB_ERROR_PRINT("OpenEncoder: EWL for 2 pass Initialization failed!\n");
      goto error_exit;
    }
    ENC_TB_DEBUG_PRINT("2 pass ewl is outside initialized.\n");
  }

  if ((ret = VCEncInit(&cfg, pEnc, tb->ewl, tb->twoPassEwl)) != VCENC_OK)
  {
    ENC_TB_ERROR_PRINT("VCEncInit failed\n");
    *pEnc = NULL; //*pEnc;
    goto error_exit;
  }

  encoder = *pEnc;

  /* Encoder setup: coding control */
  if ((ret = VCEncGetCodingCtrl(encoder, &codingCfg)) != VCENC_OK)
  {
    ENC_TB_ERROR_PRINT("VCEncGetCodingCtrl failed\n");
    goto error_exit;
  }
  else
  {

    if (options->sliceSize != DEFAULT)
      codingCfg.sliceSize = options->sliceSize;
    if (options->enableCabac != DEFAULT)
      codingCfg.enableCabac = options->enableCabac;
    if (options->cabacInitFlag != DEFAULT)
      codingCfg.cabacInitFlag = options->cabacInitFlag;
    codingCfg.vuiVideoFullRange = 0;
    if (options->videoRange != DEFAULT)
      codingCfg.vuiVideoFullRange = options->videoRange;

    codingCfg.disableDeblockingFilter = (options->disableDeblocking != 0);
    codingCfg.tc_Offset = options->tc_Offset;
    codingCfg.beta_Offset = options->beta_Offset;
    codingCfg.enableSao = options->enableSao;
    codingCfg.enableDeblockOverride = options->enableDeblockOverride;
    codingCfg.deblockOverride = options->deblockOverride;
    
    if (options->sei)
      codingCfg.seiMessages = 1;
    else
      codingCfg.seiMessages = 0;

    codingCfg.gdrDuration = options->gdrDuration;
    codingCfg.fieldOrder = options->fieldOrder;

    codingCfg.cirStart = options->cirStart;
    codingCfg.cirInterval = options->cirInterval;
    
    if(codingCfg.gdrDuration == 0)
    {
      codingCfg.intraArea.top = options->intraAreaTop;
      codingCfg.intraArea.left = options->intraAreaLeft;
      codingCfg.intraArea.bottom = options->intraAreaBottom;
      codingCfg.intraArea.right = options->intraAreaRight;
      codingCfg.intraArea.enable = CheckArea(&codingCfg.intraArea, options);
    }
    else
    {
      //intraArea will be used by GDR, customer can not use intraArea when GDR is enabled. 
      codingCfg.intraArea.enable = 0;
    }

    codingCfg.pcm_loop_filter_disabled_flag = options->pcm_loop_filter_disabled_flag;
    
    codingCfg.ipcm1Area.top = options->ipcm1AreaTop;
    codingCfg.ipcm1Area.left = options->ipcm1AreaLeft;
    codingCfg.ipcm1Area.bottom = options->ipcm1AreaBottom;
    codingCfg.ipcm1Area.right = options->ipcm1AreaRight;
    codingCfg.ipcm1Area.enable = CheckArea(&codingCfg.ipcm1Area, options);

    codingCfg.ipcm2Area.top = options->ipcm2AreaTop;
    codingCfg.ipcm2Area.left = options->ipcm2AreaLeft;
    codingCfg.ipcm2Area.bottom = options->ipcm2AreaBottom;
    codingCfg.ipcm2Area.right = options->ipcm2AreaRight;
    codingCfg.ipcm2Area.enable = CheckArea(&codingCfg.ipcm2Area, options);
    codingCfg.ipcmMapEnable = options->ipcmMapEnable;
    codingCfg.pcm_enabled_flag = (codingCfg.ipcm1Area.enable || codingCfg.ipcm2Area.enable || codingCfg.ipcmMapEnable);

    if(codingCfg.gdrDuration == 0)
    {
      codingCfg.roi1Area.top = options->roi1AreaTop;
      codingCfg.roi1Area.left = options->roi1AreaLeft;
      codingCfg.roi1Area.bottom = options->roi1AreaBottom;
      codingCfg.roi1Area.right = options->roi1AreaRight;
      if (CheckArea(&codingCfg.roi1Area, options) && (options->roi1DeltaQp || (options->roi1Qp >= 0)))
        codingCfg.roi1Area.enable = 1;
      else
        codingCfg.roi1Area.enable = 0;
    }
    else
    {
      codingCfg.roi1Area.enable = 0;
    }
    
    codingCfg.roi2Area.top = options->roi2AreaTop;
    codingCfg.roi2Area.left = options->roi2AreaLeft;
    codingCfg.roi2Area.bottom = options->roi2AreaBottom;
    codingCfg.roi2Area.right = options->roi2AreaRight;
    if (CheckArea(&codingCfg.roi2Area, options) && (options->roi2DeltaQp || (options->roi2Qp >= 0)))
      codingCfg.roi2Area.enable = 1;
    else
      codingCfg.roi2Area.enable = 0;

    codingCfg.roi3Area.top = options->roi3AreaTop;
    codingCfg.roi3Area.left = options->roi3AreaLeft;
    codingCfg.roi3Area.bottom = options->roi3AreaBottom;
    codingCfg.roi3Area.right = options->roi3AreaRight;
    if (CheckArea(&codingCfg.roi3Area, options) && (options->roi3DeltaQp || (options->roi3Qp >= 0)))
      codingCfg.roi3Area.enable = 1;
    else
      codingCfg.roi3Area.enable = 0;

    codingCfg.roi4Area.top = options->roi4AreaTop;
    codingCfg.roi4Area.left = options->roi4AreaLeft;
    codingCfg.roi4Area.bottom = options->roi4AreaBottom;
    codingCfg.roi4Area.right = options->roi4AreaRight;
    if (CheckArea(&codingCfg.roi4Area, options) && (options->roi4DeltaQp || (options->roi4Qp >= 0)))
      codingCfg.roi4Area.enable = 1;
    else
      codingCfg.roi4Area.enable = 0;

    codingCfg.roi5Area.top = options->roi5AreaTop;
    codingCfg.roi5Area.left = options->roi5AreaLeft;
    codingCfg.roi5Area.bottom = options->roi5AreaBottom;
    codingCfg.roi5Area.right = options->roi5AreaRight;
    if (CheckArea(&codingCfg.roi5Area, options) && (options->roi5DeltaQp || (options->roi5Qp >= 0)))
      codingCfg.roi5Area.enable = 1;
    else
      codingCfg.roi5Area.enable = 0;

    codingCfg.roi6Area.top = options->roi6AreaTop;
    codingCfg.roi6Area.left = options->roi6AreaLeft;
    codingCfg.roi6Area.bottom = options->roi6AreaBottom;
    codingCfg.roi6Area.right = options->roi6AreaRight;
    if (CheckArea(&codingCfg.roi6Area, options) && (options->roi6DeltaQp || (options->roi6Qp >= 0)))
      codingCfg.roi6Area.enable = 1;
    else
      codingCfg.roi6Area.enable = 0;

    codingCfg.roi7Area.top = options->roi7AreaTop;
    codingCfg.roi7Area.left = options->roi7AreaLeft;
    codingCfg.roi7Area.bottom = options->roi7AreaBottom;
    codingCfg.roi7Area.right = options->roi7AreaRight;
    if (CheckArea(&codingCfg.roi7Area, options) && (options->roi7DeltaQp || (options->roi7Qp >= 0)))
      codingCfg.roi7Area.enable = 1;
    else
      codingCfg.roi7Area.enable = 0;

    codingCfg.roi8Area.top = options->roi8AreaTop;
    codingCfg.roi8Area.left = options->roi8AreaLeft;
    codingCfg.roi8Area.bottom = options->roi8AreaBottom;
    codingCfg.roi8Area.right = options->roi8AreaRight;
    if (CheckArea(&codingCfg.roi8Area, options) && (options->roi8DeltaQp || (options->roi8Qp >= 0)))
      codingCfg.roi8Area.enable = 1;
    else
      codingCfg.roi8Area.enable = 0;
    
    codingCfg.roi1DeltaQp = options->roi1DeltaQp;
    codingCfg.roi2DeltaQp = options->roi2DeltaQp;
    codingCfg.roi3DeltaQp = options->roi3DeltaQp;
    codingCfg.roi4DeltaQp = options->roi4DeltaQp;
    codingCfg.roi5DeltaQp = options->roi5DeltaQp;
    codingCfg.roi6DeltaQp = options->roi6DeltaQp;
    codingCfg.roi7DeltaQp = options->roi7DeltaQp;
    codingCfg.roi8DeltaQp = options->roi8DeltaQp;
    codingCfg.roi1Qp = options->roi1Qp;
    codingCfg.roi2Qp = options->roi2Qp;
    codingCfg.roi3Qp = options->roi3Qp;
    codingCfg.roi4Qp = options->roi4Qp;
    codingCfg.roi5Qp = options->roi5Qp;
    codingCfg.roi6Qp = options->roi6Qp;
    codingCfg.roi7Qp = options->roi7Qp;
    codingCfg.roi8Qp = options->roi8Qp;

    if (codingCfg.cirInterval)
      ENC_TB_INFO_PRINT("  CIR: %d %d\n",
             codingCfg.cirStart, codingCfg.cirInterval);

    if (codingCfg.intraArea.enable)
      ENC_TB_INFO_PRINT("  IntraArea: %dx%d-%dx%d\n",
             codingCfg.intraArea.left, codingCfg.intraArea.top,
             codingCfg.intraArea.right, codingCfg.intraArea.bottom);

    if (codingCfg.ipcm1Area.enable)
      ENC_TB_INFO_PRINT("  IPCM1Area: %dx%d-%dx%d\n",
             codingCfg.ipcm1Area.left, codingCfg.ipcm1Area.top,
             codingCfg.ipcm1Area.right, codingCfg.ipcm1Area.bottom);

    if (codingCfg.ipcm2Area.enable)
      ENC_TB_INFO_PRINT("  IPCM2Area: %dx%d-%dx%d\n",
             codingCfg.ipcm2Area.left, codingCfg.ipcm2Area.top,
             codingCfg.ipcm2Area.right, codingCfg.ipcm2Area.bottom);

    if (codingCfg.roi1Area.enable)
      ENC_TB_INFO_PRINT("  ROI 1: %s %d  %dx%d-%dx%d\n",
             codingCfg.roi1Qp >= 0 ? "QP" : "QP Delta",
             codingCfg.roi1Qp >= 0 ? codingCfg.roi1Qp : codingCfg.roi1DeltaQp,
             codingCfg.roi1Area.left, codingCfg.roi1Area.top,
             codingCfg.roi1Area.right, codingCfg.roi1Area.bottom);

    if (codingCfg.roi2Area.enable)
      ENC_TB_INFO_PRINT("  ROI 2: %s %d  %dx%d-%dx%d\n",
             codingCfg.roi2Qp >= 0 ? "QP" : "QP Delta",
             codingCfg.roi2Qp >= 0 ? codingCfg.roi2Qp : codingCfg.roi2DeltaQp,
             codingCfg.roi2Area.left, codingCfg.roi2Area.top,
             codingCfg.roi2Area.right, codingCfg.roi2Area.bottom);

    if (codingCfg.roi3Area.enable)
      ENC_TB_INFO_PRINT("  ROI 3: %s %d  %dx%d-%dx%d\n",
             codingCfg.roi3Qp >= 0 ? "QP" : "QP Delta",
             codingCfg.roi3Qp >= 0 ? codingCfg.roi3Qp : codingCfg.roi3DeltaQp,
             codingCfg.roi3Area.left, codingCfg.roi3Area.top,
             codingCfg.roi3Area.right, codingCfg.roi3Area.bottom);
    
    if (codingCfg.roi4Area.enable)
      ENC_TB_INFO_PRINT("  ROI 4: %s %d  %dx%d-%dx%d\n",
             codingCfg.roi4Qp >= 0 ? "QP" : "QP Delta",
             codingCfg.roi4Qp >= 0 ? codingCfg.roi4Qp : codingCfg.roi4DeltaQp,
             codingCfg.roi4Area.left, codingCfg.roi4Area.top,
             codingCfg.roi4Area.right, codingCfg.roi4Area.bottom);
    
    if (codingCfg.roi5Area.enable)
      ENC_TB_INFO_PRINT("  ROI 5: %s %d  %dx%d-%dx%d\n",
             codingCfg.roi5Qp >= 0 ? "QP" : "QP Delta",
             codingCfg.roi5Qp >= 0 ? codingCfg.roi5Qp : codingCfg.roi5DeltaQp,
             codingCfg.roi5Area.left, codingCfg.roi5Area.top,
             codingCfg.roi5Area.right, codingCfg.roi5Area.bottom);
    
    if (codingCfg.roi6Area.enable)
      ENC_TB_INFO_PRINT("  ROI 6: %s %d  %dx%d-%dx%d\n",
             codingCfg.roi6Qp >= 0 ? "QP" : "QP Delta",
             codingCfg.roi6Qp >= 0 ? codingCfg.roi6Qp : codingCfg.roi6DeltaQp,
             codingCfg.roi6Area.left, codingCfg.roi6Area.top,
             codingCfg.roi6Area.right, codingCfg.roi6Area.bottom);
    
    if (codingCfg.roi7Area.enable)
      ENC_TB_INFO_PRINT("  ROI 7: %s %d  %dx%d-%dx%d\n",
             codingCfg.roi7Qp >= 0 ? "QP" : "QP Delta",
             codingCfg.roi7Qp >= 0 ? codingCfg.roi7Qp : codingCfg.roi7DeltaQp,
             codingCfg.roi7Area.left, codingCfg.roi7Area.top,
             codingCfg.roi7Area.right, codingCfg.roi7Area.bottom);
    
    if (codingCfg.roi8Area.enable)
      ENC_TB_INFO_PRINT("  ROI 8: %s %d  %dx%d-%dx%d\n",
             codingCfg.roi8Qp >= 0 ? "QP" : "QP Delta",
             codingCfg.roi8Qp >= 0 ? codingCfg.roi8Qp : codingCfg.roi8DeltaQp,
             codingCfg.roi8Area.left, codingCfg.roi8Area.top,
             codingCfg.roi8Area.right, codingCfg.roi8Area.bottom);
             
    codingCfg.roiMapDeltaQpEnable = options->roiMapDeltaQpEnable;
    codingCfg.roiMapDeltaQpBlockUnit=options->roiMapDeltaQpBlockUnit;

    codingCfg.RoimapCuCtrl_index_enable = (options->RoimapCuCtrlIndexBinFile != NULL);
    codingCfg.RoimapCuCtrl_enable       = (options->RoimapCuCtrlInfoBinFile != NULL);
    codingCfg.roiMapDeltaQpBinEnable    = (options->roiMapInfoBinFile != NULL);
    codingCfg.RoimapCuCtrl_ver          = options->RoiCuCtrlVer;
    codingCfg.RoiQpDelta_ver            = options->RoiQpDeltaVer;

    /* SKIP map */
    codingCfg.skipMapEnable = options->skipMapEnable;

    codingCfg.enableScalingList = options->enableScalingList;
    codingCfg.chroma_qp_offset= options->chromaQpOffset;

    /* low latency */
    codingCfg.inputLineBufEn = (options->inputLineBufMode>0) ? 1 : 0;
    codingCfg.inputLineBufLoopBackEn = (options->inputLineBufMode==1||options->inputLineBufMode==2) ? 1 : 0;
    if (options->inputLineBufDepth != DEFAULT) codingCfg.inputLineBufDepth = options->inputLineBufDepth;
    codingCfg.amountPerLoopBack = options->amountPerLoopBack;
    codingCfg.inputLineBufHwModeEn = (options->inputLineBufMode==2||options->inputLineBufMode==4) ? 1 : 0;
    codingCfg.inputLineBufCbFunc = VCEncInputLineBufDone;
    codingCfg.inputLineBufCbData = &(tb->inputCtbLineBuf);

    /*stream multi-segment*/
    codingCfg.streamMultiSegmentMode = options->streamMultiSegmentMode;
    codingCfg.streamMultiSegmentAmount = options->streamMultiSegmentAmount;
    codingCfg.streamMultiSegCbFunc = &EncStreamSegmentReady;
    codingCfg.streamMultiSegCbData = &(tb->streamSegCtl);

    /* denoise */
    codingCfg.noiseReductionEnable = options->noiseReductionEnable;//0: disable noise reduction; 1: enable noise reduction
    if(options->noiseLow == 0)
    {
        codingCfg.noiseLow = 10;        
    }
    else
    {
        codingCfg.noiseLow = CLIP3(1, 30, options->noiseLow);//0: use default value; valid value range: [1, 30]
    }
    
    if(options->firstFrameSigma == 0)
    {
        codingCfg.firstFrameSigma = 11;
    }
    else
    {
        codingCfg.firstFrameSigma = CLIP3(1, 30, options->firstFrameSigma);
    }

    /* smart */
    codingCfg.smartModeEnable = options->smartModeEnable;
    codingCfg.smartH264LumDcTh = options->smartH264LumDcTh;
    codingCfg.smartH264CbDcTh = options->smartH264CbDcTh;
    codingCfg.smartH264CrDcTh = options->smartH264CrDcTh;
    for(i = 0; i < 3; i++) {
      codingCfg.smartHevcLumDcTh[i] = options->smartHevcLumDcTh[i];
      codingCfg.smartHevcChrDcTh[i] = options->smartHevcChrDcTh[i];
      codingCfg.smartHevcLumAcNumTh[i] = options->smartHevcLumAcNumTh[i];
      codingCfg.smartHevcChrAcNumTh[i] = options->smartHevcChrAcNumTh[i];
    }
    codingCfg.smartH264Qp = options->smartH264Qp;
    codingCfg.smartHevcLumQp = options->smartHevcLumQp;
    codingCfg.smartHevcChrQp = options->smartHevcChrQp;
    for(i = 0; i < 4; i++)
      codingCfg.smartMeanTh[i] = options->smartMeanTh[i];
    codingCfg.smartPixNumCntTh = options->smartPixNumCntTh;

    /* tile */
    codingCfg.tiles_enabled_flag = options->tiles_enabled_flag && !IS_H264(options->codecFormat);
    codingCfg.num_tile_columns = options->num_tile_columns;
    codingCfg.num_tile_rows       = options->num_tile_rows;
    codingCfg.loop_filter_across_tiles_enabled_flag = options->loop_filter_across_tiles_enabled_flag;

    /* HDR10 */
    codingCfg.Hdr10Display.hdr10_display_enable = options->hdr10_display_enable;
    if (options->hdr10_display_enable)
    {
    	codingCfg.Hdr10Display.hdr10_dx0 = options->hdr10_dx0;
    	codingCfg.Hdr10Display.hdr10_dy0 = options->hdr10_dy0;
    	codingCfg.Hdr10Display.hdr10_dx1 = options->hdr10_dx1;
    	codingCfg.Hdr10Display.hdr10_dy1 = options->hdr10_dy1;
    	codingCfg.Hdr10Display.hdr10_dx2 = options->hdr10_dx2;
    	codingCfg.Hdr10Display.hdr10_dy2 = options->hdr10_dy2;
    	codingCfg.Hdr10Display.hdr10_wx  = options->hdr10_wx;
    	codingCfg.Hdr10Display.hdr10_wy  = options->hdr10_wy;
    	codingCfg.Hdr10Display.hdr10_maxluma = options->hdr10_maxluma;
    	codingCfg.Hdr10Display.hdr10_minluma = options->hdr10_minluma;
    }
    
    codingCfg.Hdr10LightLevel.hdr10_lightlevel_enable = options->hdr10_lightlevel_enable;
    if (options->hdr10_lightlevel_enable)
    {
    	codingCfg.Hdr10LightLevel.hdr10_maxlight = options->hdr10_maxlight;
    	codingCfg.Hdr10LightLevel.hdr10_avglight = options->hdr10_avglight;
    }
    
    codingCfg.vuiColorDescription.vuiColorDescripPresentFlag = options->vuiColorDescripPresentFlag;
    if (options->vuiColorDescripPresentFlag)
    {
    	codingCfg.vuiColorDescription.vuiMatrixCoefficients      = options->vuiMatrixCoefficients;
    	codingCfg.vuiColorDescription.vuiColorPrimaries          = options->vuiColorPrimaries;
    	codingCfg.vuiColorDescription.vuiTransferCharacteristics = options->vuiTransferCharacteristics;
    }

    codingCfg.vuiVideoFormat                = options->vuiVideoFormat;
    codingCfg.vuiVideoSignalTypePresentFlag = options->vuiVideoSignalTypePresentFlag;
    codingCfg.sampleAspectRatioHeight       = options->vuiAspectRatioHeight;
    codingCfg.sampleAspectRatioWidth        = options->vuiAspectRatioWidth;

    codingCfg.RpsInSliceHeader = options->RpsInSliceHeader;

    if ((ret = VCEncSetCodingCtrl(encoder, &codingCfg)) != VCENC_OK)
    {
      ENC_TB_ERROR_PRINT("VCEncSetCodingCtrl failed\n");
      goto error_exit;
    }

  }

  /* Encoder setup: rate control */
  if ((ret = VCEncGetRateCtrl(encoder, &rcCfg)) != VCENC_OK)
  {
    ENC_TB_ERROR_PRINT("VCEncGetRateCtrl failed\n");
    goto error_exit;
  }
  else
  {
    ENC_TB_INFO_PRINT("Get rate control: qp %2d qpRange I[%2d, %2d] PB[%2d, %2d] %8d bps  "
           "pic %d skip %d  hrd %d  cpbSize %d bitrateWindow %d "
           "intraQpDelta %2d\n",
           rcCfg.qpHdr, rcCfg.qpMinI, rcCfg.qpMaxI, rcCfg.qpMinPB, rcCfg.qpMaxPB, rcCfg.bitPerSecond,
           rcCfg.pictureRc, rcCfg.pictureSkip, rcCfg.hrd,
           rcCfg.hrdCpbSize, rcCfg.bitrateWindow, rcCfg.intraQpDelta);

    if (options->qpHdr != DEFAULT)
      rcCfg.qpHdr = options->qpHdr;
    else
      rcCfg.qpHdr = -1;
    if (options->qpMin != DEFAULT)
      rcCfg.qpMinI = rcCfg.qpMinPB = options->qpMin;
    if (options->qpMax != DEFAULT)
      rcCfg.qpMaxI = rcCfg.qpMaxPB = options->qpMax;
    if (options->qpMinI != DEFAULT)
      rcCfg.qpMinI = options->qpMinI;
    if (options->qpMaxI != DEFAULT)
      rcCfg.qpMaxI = options->qpMaxI;
    if (options->picSkip != DEFAULT)
      rcCfg.pictureSkip = options->picSkip;
    if (options->picRc != DEFAULT)
      rcCfg.pictureRc = options->picRc;
    if (options->ctbRc != DEFAULT)
      rcCfg.ctbRc = options->ctbRc;

    rcCfg.blockRCSize = 0;
    if (options->blockRCSize != DEFAULT)
      rcCfg.blockRCSize = options->blockRCSize;
    
    rcCfg.rcQpDeltaRange = 10;
    if (options->rcQpDeltaRange != DEFAULT)
      rcCfg.rcQpDeltaRange = options->rcQpDeltaRange;

    rcCfg.rcBaseMBComplexity = 15;
    if (options->rcBaseMBComplexity != DEFAULT)
      rcCfg.rcBaseMBComplexity = options->rcBaseMBComplexity;
    
    if (options->picQpDeltaMax != DEFAULT)
      rcCfg.picQpDeltaMax = options->picQpDeltaMax;
    if (options->picQpDeltaMin != DEFAULT)
      rcCfg.picQpDeltaMin = options->picQpDeltaMin;
    if (options->bitPerSecond != DEFAULT)
      rcCfg.bitPerSecond = options->bitPerSecond;
    if (options->bitVarRangeI != DEFAULT)
      rcCfg.bitVarRangeI = options->bitVarRangeI;
    if (options->bitVarRangeP != DEFAULT)
      rcCfg.bitVarRangeP = options->bitVarRangeP;
    if (options->bitVarRangeB != DEFAULT)
      rcCfg.bitVarRangeB = options->bitVarRangeB;

    if (options->tolMovingBitRate != DEFAULT)
      rcCfg.tolMovingBitRate = options->tolMovingBitRate;

    if (options->tolCtbRcInter != DEFAULT)
      rcCfg.tolCtbRcInter = options->tolCtbRcInter;

    if (options->tolCtbRcIntra != DEFAULT)
      rcCfg.tolCtbRcIntra = options->tolCtbRcIntra;

    if (options->ctbRcRowQpStep != DEFAULT)
      rcCfg.ctbRcRowQpStep = options->ctbRcRowQpStep;

    rcCfg.longTermQpDelta = options->longTermQpDelta;
    
    if (options->monitorFrames != DEFAULT)
      rcCfg.monitorFrames = options->monitorFrames;
    else 
    {
      rcCfg.monitorFrames =(options->outputRateNumer+options->outputRateDenom-1) / options->outputRateDenom;
      options->monitorFrames = (options->outputRateNumer+options->outputRateDenom-1) / options->outputRateDenom;
    }
      
    if(rcCfg.monitorFrames>MOVING_AVERAGE_FRAMES)
      rcCfg.monitorFrames=MOVING_AVERAGE_FRAMES;

    if (rcCfg.monitorFrames < 10)
    {
      rcCfg.monitorFrames = (options->outputRateNumer > options->outputRateDenom)? 10:LEAST_MONITOR_FRAME;
    }

    if (options->hrdConformance != DEFAULT)
      rcCfg.hrd = options->hrdConformance;

    if (options->cpbSize != DEFAULT)
      rcCfg.hrdCpbSize = options->cpbSize;

    if (options->intraPicRate != 0)
      rcCfg.bitrateWindow = MIN(options->intraPicRate, MAX_GOP_LEN);

    if (options->bitrateWindow != DEFAULT)
      rcCfg.bitrateWindow = options->bitrateWindow;

    if (options->intraQpDelta != DEFAULT)
      rcCfg.intraQpDelta = options->intraQpDelta;

    if (options->vbr != DEFAULT)
      rcCfg.vbr = options->vbr;

    if (options->crf != DEFAULT)
      rcCfg.crf = options->crf;

    rcCfg.fixedIntraQp = options->fixedIntraQp;
    rcCfg.smoothPsnrInGOP = options->smoothPsnrInGOP;
    rcCfg.u32StaticSceneIbitPercent = options->u32StaticSceneIbitPercent;

    ENC_TB_INFO_PRINT("Set rate control: qp %2d qpRange I[%2d, %2d] PB[%2d, %2d] %9d bps  "
           "pic %d skip %d  hrd %d"
           "  cpbSize %d bitrateWindow %d intraQpDelta %2d "
           "fixedIntraQp %2d\n",
           rcCfg.qpHdr, rcCfg.qpMinI, rcCfg.qpMaxI, rcCfg.qpMinPB, rcCfg.qpMaxPB, rcCfg.bitPerSecond,
           rcCfg.pictureRc, rcCfg.pictureSkip, rcCfg.hrd,
           rcCfg.hrdCpbSize, rcCfg.bitrateWindow, rcCfg.intraQpDelta,
           rcCfg.fixedIntraQp);

    if ((ret = VCEncSetRateCtrl(encoder, &rcCfg)) != VCENC_OK)
    {
      ENC_TB_ERROR_PRINT("VCEncSetRateCtrl failed\n");
      goto error_exit;
    }
  }

  /* Optional scaled image output */
  if (options->scaledWidth * options->scaledHeight > 0)
  {
    i32 dsFrmSize = options->scaledWidth * options->scaledHeight * 2;
    /* the scaled image size changes frame by frame when testing down-scaling */
    if (options->testId == 34)
    {
      dsFrmSize = options->width * options->height * 2;
    }
    if((options->bitDepthLuma!=8) || (options->bitDepthChroma!=8))
      dsFrmSize <<= 1;

    if (options->scaledOutputFormat == 1)
      dsFrmSize = dsFrmSize *3 /4;

    if (EWLMallocRefFrm(tb->ewl, dsFrmSize, 0, &tb->scaledPictureMem) != EWL_OK)
    {
#ifdef USE_OLD_DRV
      tb->scaledPictureMem.virtualAddress = NULL;
      tb->scaledPictureMem.busAddress = 0;
#else
      memset(&tb->scaledPictureMem, 0, sizeof(EWLLinearMem_t));
#endif
    }
  }

  /* PreP setup */
  if ((ret = VCEncGetPreProcessing(encoder, &preProcCfg)) != VCENC_OK)
  {
    ENC_TB_ERROR_PRINT("VCEncGetPreProcessing failed\n");
    goto error_exit;
  }
  
  ENC_TB_INFO_PRINT("Get PreP: input %4dx%d : offset %4dx%d : format %d : rotation %d"
   "cc %d : scaling %d\n",
  preProcCfg.origWidth, preProcCfg.origHeight, preProcCfg.xOffset,
  preProcCfg.yOffset, preProcCfg.inputType, preProcCfg.rotation,
  preProcCfg.colorConversion.type,
  preProcCfg.scaledOutput);

  preProcCfg.inputType = (VCEncPictureType)options->inputFormat;
  preProcCfg.rotation = (VCEncPictureRotation)options->rotation;
  preProcCfg.mirror = (VCEncPictureMirror)options->mirror;

  preProcCfg.origWidth = options->lumWidthSrc;
  preProcCfg.origHeight = options->lumHeightSrc;

  if (options->horOffsetSrc != DEFAULT)
    preProcCfg.xOffset = options->horOffsetSrc;
  if (options->verOffsetSrc != DEFAULT)
    preProcCfg.yOffset = options->verOffsetSrc;

#ifdef SUPPORT_TCACHE
  if (options->inputFormat == INPUT_FORMAT_RFC_8BIT_COMPRESSED_FB
        || options->inputFormat == INPUT_FORMAT_RFC_10BIT_COMPRESSED_FB) {
    i32 x = (options->horOffsetSrc == DEFAULT) ? 0 : options->horOffsetSrc;
    i32 y = (options->verOffsetSrc == DEFAULT) ? 0 : options->verOffsetSrc;
    i32 w = (options->width == DEFAULT) ? 0 : options->width;
    i32 h = (options->height == DEFAULT) ? 0 : options->height;
    i32 b = (options->inputFormat == INPUT_FORMAT_RFC_10BIT_COMPRESSED_FB) ? 2 : 1;
    i32 aw = (((w*b+31)/32)*32)/b;
    i32 ah = (((y+h)+7)/8)*8-y;
    ENC_TB_DEBUG_PRINT("options->lumWidthSrc = %d, x = %d, w = %d, b = %d, aw = %d\n", options->lumWidthSrc, x, w, b, aw);
    if (w) {
      preProcCfg.xOffset = 0;
      preProcCfg.origWidth = MIN(aw, options->lumWidthSrc - x);
    }
    ENC_TB_DEBUG_PRINT("preProcCfg.xOffset = %d, preProcCfg.origWidth = %d\n", preProcCfg.xOffset, preProcCfg.origWidth);
    if (ah) {
      preProcCfg.yOffset = 0;
      preProcCfg.origHeight = ah;
    }
    ENC_TB_DEBUG_PRINT("preProcCfg.yOffset = %d, preProcCfg.origHeight = %d\n", preProcCfg.yOffset, preProcCfg.origHeight);
  }
#endif
  if (options->inputFormat == INPUT_FORMAT_PP_YUV420_SEMIPLANNAR
      || options->inputFormat == INPUT_FORMAT_PP_YUV420_SEMIPLANNAR_VU
      || options->inputFormat == INPUT_FORMAT_PP_YUV420_PLANAR_10BIT_P010
      || options->inputFormat == INPUT_FORMAT_PP_YUV420_SEMIPLANNAR_YUV420P ) {
    i32 x = (options->horOffsetSrc == DEFAULT) ? 0 : options->horOffsetSrc;
    i32 y = (options->verOffsetSrc == DEFAULT) ? 0 : options->verOffsetSrc;
    i32 w = (options->width == DEFAULT) ? 0 : options->width;
    i32 h = (options->height == DEFAULT) ? 0 : options->height;
    i32 b = (options->inputFormat == INPUT_FORMAT_PP_YUV420_PLANAR_10BIT_P010) ? 2 : 1;
    i32 aw = (((w*b+31)/32)*32)/b;
    ENC_TB_DEBUG_PRINT("options->lumWidthSrc = %d, x = %d, w = %d, b = %d, aw = %d\n", options->lumWidthSrc, x, w, b, aw);
    if (x) {
      preProcCfg.xOffset = x;
    }
    ENC_TB_DEBUG_PRINT("preProcCfg.xOffset = %d, preProcCfg.origWidth = %d\n", preProcCfg.xOffset, preProcCfg.origWidth);
    if (y) {
      preProcCfg.yOffset = y;
    }
    ENC_TB_DEBUG_PRINT("preProcCfg.yOffset = %d, preProcCfg.origHeight = %d\n", preProcCfg.yOffset, preProcCfg.origHeight);
  }
  // add for crop end
        
  if (options->interlacedFrame) preProcCfg.origHeight /= 2;

  if (options->colorConversion != DEFAULT)
    preProcCfg.colorConversion.type =
      (VCEncColorConversionType)options->colorConversion;
  if (preProcCfg.colorConversion.type == VCENC_RGBTOYUV_USER_DEFINED)
  {
    preProcCfg.colorConversion.coeffA = 20000;
    preProcCfg.colorConversion.coeffB = 44000;
    preProcCfg.colorConversion.coeffC = 5000;
    preProcCfg.colorConversion.coeffE = 35000;
    preProcCfg.colorConversion.coeffF = 38000;
    preProcCfg.colorConversion.coeffG = 35000;
    preProcCfg.colorConversion.coeffH = 38000;
    preProcCfg.colorConversion.LumaOffset = 0;
  }

  if (options->rotation&&options->rotation!=3)
  {
    preProcCfg.scaledWidth = options->scaledHeight;
    preProcCfg.scaledHeight = options->scaledWidth;
  }
  else
  {
    preProcCfg.scaledWidth = options->scaledWidth;
    preProcCfg.scaledHeight = options->scaledHeight;
  }
  preProcCfg.busAddressScaledBuff = tb->scaledPictureMem.busAddress;
#ifdef USE_OLD_DRV
  preProcCfg.virtualAddressScaledBuff = tb->scaledPictureMem.virtualAddress;
#else
  preProcCfg.virtualAddressScaledBuff = tb->scaledPictureMem.rc_virtualAddress;
#endif
  preProcCfg.sizeScaledBuff = tb->scaledPictureMem.size;
  preProcCfg.input_alignment = 1<<options->exp_of_input_alignment;
  preProcCfg.scaledOutputFormat = options->scaledOutputFormat;

  ENC_TB_INFO_PRINT("Set PreP: input %4dx%d : offset %4dx%d : format %d : rotation %d"
   "cc %d : scaling %d\n",
   preProcCfg.origWidth, preProcCfg.origHeight, preProcCfg.xOffset,
   preProcCfg.yOffset, preProcCfg.inputType, preProcCfg.rotation,
   preProcCfg.colorConversion.type,
   preProcCfg.scaledOutput, preProcCfg.scaledOutputFormat);

  if(options->scaledWidth*options->scaledHeight > 0)
    preProcCfg.scaledOutput=1;

   /* constant chroma control */
   preProcCfg.constChromaEn = options->constChromaEn;
   if (options->constCb != DEFAULT)
     preProcCfg.constCb = options->constCb;
   if (options->constCr != DEFAULT)
     preProcCfg.constCr = options->constCr;

  ChangeToCustomizedFormat(options,&preProcCfg);

  ChangeFormatForFB(tb, options, &preProcCfg);
  
  if (cfg.extDSRatio) {
    preProcCfg.origWidth_ds = options->lumWidthSrc_ds;
    preProcCfg.origHeight_ds = options->lumHeightSrc_ds;
  }

  /* for edma trans raw from rc to ep, it need to close the dummy regisiter.*/
  preProcCfg.b_close_dummy_regs = options->b_close_dummy_regs;

  if ((ret = VCEncSetPreProcessing(encoder, &preProcCfg)) != VCENC_OK)
  {
    ENC_TB_ERROR_PRINT("VCEncSetPreProcessing failed\n");
    goto error_exit;
  }
  ret = 0;

error_exit:
  return ret;
}
/*------------------------------------------------------------------------------

    CloseEncoder
       Release an encoder insatnce.

   Params:
        encoder - the instance to be released
------------------------------------------------------------------------------*/
void CloseEncoder(VCEncInst encoder, struct test_bench *tb)
{
  VCEncRet ret;

#ifdef USE_OLD_DRV
  if (tb->scaledPictureMem.virtualAddress != NULL)
#endif
    EWLFreeLinear(tb->ewl, &tb->scaledPictureMem);

  if (encoder) {
    if ((ret = VCEncRelease(encoder)) != VCENC_OK)
    {
      ENC_TB_ERROR_PRINT("VCEncRelease failed\n");
    }
  }

  if (tb->ewl)
  {
    EWLRelease(tb->ewl);
    tb->ewl = NULL;
  }

  if (tb->twoPassEwl)
  {
    EWLRelease(tb->twoPassEwl);
    tb->twoPassEwl = NULL;
  }
  
  if (tb->perf) {
    ENCPERF * perf = tb->perf;
    pthread_mutex_destroy(&perf->hwcycle_acc_mutex);
#ifdef FB_PERFORMANCE_STATIC
    PERFORMANCE_STATIC_REPORT(tb, perf, vcehwp1);
    PERFORMANCE_STATIC_VERBOSE(tb, perf, vcehwp1);
    PERFORMANCE_STATIC_REPORT(tb, perf, vcehw);
    PERFORMANCE_STATIC_VERBOSE(tb, perf, vcehw);
    PERFORMANCE_STATIC_REPORT(tb, perf, CU_ANAL);
    PERFORMANCE_STATIC_VERBOSE(tb, perf, CU_ANAL);
    PERFORMANCE_STATIC_REPORT(tb, perf, vcehw_total);
    PERFORMANCE_STATIC_VERBOSE(tb, perf, vcehw_total);
    PERFORMANCE_STATIC_REPORT(tb, perf, vce_total);
    PERFORMANCE_STATIC_VERBOSE(tb, perf, vce_total);
#endif
    EWLfree(tb->perf);
    tb->perf = NULL;
  }
}
/*------------------------------------------------------------------------------

    AllocRes

    Allocation of the physical memories used by both SW and HW:
    the input pictures and the output stream buffer.

    NOTE! The implementation uses the EWL instance from the encoder
          for OS independence. This is not recommended in final environment
          because the encoder will release the EWL instance in case of error.
          Instead, the memories should be allocated from the OS the same way
          as inside EWLMallocLinear().

------------------------------------------------------------------------------*/
int AllocRes(HANTROH26xEncOptions *cmdl, VCEncInst enc, struct test_bench *tb)
{
  i32 ret;
  u32 pictureSize = 0;
  u32 pictureDSSize = 0;
  u32 streamBufTotalSize;
  u32 outbufSize[2] = {0, 0};
  u32 block_size;
  u32 transform_size=0;
  u32 lumaSize = 0,chromaSize = 0;
  u32 lumaSizeDs = 0,chromaSizeDs = 0;
  u32 coreIdx=0;
  i32 iBuf;
  u32 alignment = 0;

  
  ENC_TB_DEBUG_PRINT("cmdl->inputFormat = %d\n", cmdl->inputFormat);
  ENC_TB_DEBUG_PRINT("tb->input_alignment = %d\n", tb->input_alignment);
  
  alignment = (cmdl->formatCustomizedType != -1? 0 : tb->input_alignment);
  getAlignedPicSizebyFormat(cmdl->inputFormat,cmdl->lumWidthSrc,cmdl->lumHeightSrc,alignment,&lumaSize,&chromaSize,&pictureSize);


  tb->lumaSize = lumaSize;
  tb->chromaSize = chromaSize;
  ENC_TB_DEBUG_PRINT("lumaSize = %d, chromaSize = %d\n", lumaSize, chromaSize);
  
  if (cmdl->lookaheadDepth && cmdl->cutree_blkratio) {
    getAlignedPicSizebyFormat(cmdl->inputFormat_ds,cmdl->lumWidthSrc_ds,cmdl->lumHeightSrc_ds,alignment,&lumaSizeDs,&chromaSizeDs,&pictureDSSize);
    tb->lumaSizeDs = lumaSizeDs;
    tb->chromaSizeDs = chromaSizeDs;
    ENC_TB_DEBUG_PRINT("lumaSizeDs = %d, chromaSizeDs = %d\n", lumaSizeDs, chromaSizeDs);
  }

#if defined(SUPPORT_DEC400) || defined(SUPPORT_TCACHE)
  if (cmdl->inputFormat == INPUT_FORMAT_YUV420_SEMIPLANAR_8BIT_COMPRESSED_FB
        || cmdl->inputFormat == INPUT_FORMAT_YUV420_SEMIPLANAR_VU_8BIT_COMPRESSED_FB
        || cmdl->inputFormat == INPUT_FORMAT_YUV420_PLANAR_10BIT_P010_COMPRESSED_FB
        || cmdl->inputFormat == INPUT_FORMAT_RFC_8BIT_COMPRESSED_FB
        || cmdl->inputFormat == INPUT_FORMAT_RFC_10BIT_COMPRESSED_FB)
  {
    u32 tbl_luma_size, tbl_chroma_size;
    
    if (cmdl->inputFormat == INPUT_FORMAT_RFC_8BIT_COMPRESSED_FB
        || cmdl->inputFormat == INPUT_FORMAT_RFC_10BIT_COMPRESSED_FB)
    {
      int nCBSG = (cmdl->lumWidthSrc+127)/8/16;
      int nCBSR = (cmdl->lumHeightSrc+7)/8;
      tbl_luma_size = 16 * nCBSG * nCBSR;

      nCBSG = (cmdl->lumWidthSrc+255)/16/16;
      nCBSR = (cmdl->lumHeightSrc+7)/2/4;
      tbl_chroma_size = 16 * nCBSG * nCBSR;
    }
    else
    {
      tbl_luma_size = (((lumaSize/tb->input_alignment)*2+7)/8+15)&(~15);
      tbl_chroma_size = (((chromaSize/tb->input_alignment)*2+7)/8+15)&(~15);
    }
    ENC_TB_DEBUG_PRINT("tbl_luma_size = %d, tbl_chroma_size = %d\n", tbl_luma_size, tbl_chroma_size);
#if 0
    for(coreIdx =0; coreIdx < tb->parallelCoreNum; coreIdx++)
    {
#ifdef USE_OLD_DRV
      ret = EWLMallocLinear(((struct vcenc_instance *)enc)->asic.ewl, tbl_luma_size, tb->input_alignment,
                            &tb->TSLumaMemFactory[coreIdx]);
      if (ret != EWL_OK)
      {
        tb->TSLumaMemFactory[coreIdx].virtualAddress = NULL;
        return 1;
      }
      ret = EWLMallocLinear(((struct vcenc_instance *)enc)->asic.ewl, tbl_chroma_size, tb->input_alignment,
                            &tb->TSChromaMemFactory[coreIdx]);
      if (ret != EWL_OK)
      {
        tb->TSChromaMemFactory[coreIdx].virtualAddress = NULL;
        return 1;
      }
#else
      ret = EWLMallocInoutLinear(((struct vcenc_instance *)enc)->asic.ewl, tbl_luma_size, tb->input_alignment,
                            &tb->TSLumaMemFactory[coreIdx]);
      if (ret != EWL_OK)
      {
        //memset(&tb->TSLumaMemFactory[coreIdx], 0, sizeof(EWLLinearMem_t));
        return 1;
      }
      ret = EWLMallocInoutLinear(((struct vcenc_instance *)enc)->asic.ewl, tbl_chroma_size, tb->input_alignment,
                            &tb->TSChromaMemFactory[coreIdx]);
      if (ret != EWL_OK)
      {
        //memset(&tb->TSChromaMemFactory[coreIdx], 0, sizeof(EWLLinearMem_t));
        return 1;
      }
#endif
    }
#endif
    tb->tbl_luma_size = tbl_luma_size;
    tb->tbl_chroma_size = tbl_chroma_size;
  }
#endif

#ifdef SUPPORT_TCACHE
#ifdef USE_OLD_DRV
  ret = EWLMallocLinear(((struct vcenc_instance *)enc)->asic.ewl, 256*sizeof(struct dma_link_table), tb->input_alignment,
                        &tb->edma_link_buf);
  if (ret != EWL_OK) {
    tb->edma_link_buf.virtualAddress = NULL;
    return 1;
  }
#else
#if 0
  ret = EWLMallocHostLinear(((struct vcenc_instance *)enc)->asic.ewl, 256*sizeof(struct dma_link_table), tb->input_alignment,
                        &tb->edma_link_buf);
  if (ret != EWL_OK) {
    //memset(&tb->edma_link_buf, 0, sizeof(EWLLinearMem_t));
    return 1;
  }
#else
  ret = EWLMallocHostLinear(((struct vcenc_instance *)enc)->asic.ewl, 256*sizeof(struct dma_link_table), tb->input_alignment,
                        &tb->encIn.PrivData.edma_link_buf);
  if (ret != EWL_OK) {
    //memset(&tb->edma_link_buf, 0, sizeof(EWLLinearMem_t));
    return 1;
  }

#ifdef VCE_MEM_ERR_TEST
  if(VceMemoryCheck(cmdl) != 0){
    ENC_TB_ERROR_PRINT("vce force memory error in function\n");
    return 1;
  }
#endif

  ret = EWLMallocHostLinear(((struct vcenc_instance *)enc)->asic.ewl, 256*sizeof(struct dma_link_table), tb->input_alignment,
                        &tb->encIn.PassTwoHWData.edma_link_buf);
  if (ret != EWL_OK) {
    //memset(&tb->edma_link_buf, 0, sizeof(EWLLinearMem_t));
    return 1;
  }

#ifdef VCE_MEM_ERR_TEST
  if(VceMemoryCheck(cmdl) != 0){
     ENC_TB_ERROR_PRINT("vce force memory error in function\n");
     return 1;
  }
#endif

#endif  
#endif
#endif

  if (cmdl->formatCustomizedType != -1)
  {
    u32 trans_format = VCENC_FORMAT_MAX;
    u32 input_alignment = 0;
    switch(cmdl->formatCustomizedType)
    {
      case 0: 
        if (cmdl->inputFormat==VCENC_YUV420_PLANAR)
        {
          if (IS_HEVC(cmdl->codecFormat))//Dahua hevc
            trans_format = VCENC_YUV420_PLANAR_8BIT_DAHUA_HEVC;
          else//Dahua h264
            trans_format = VCENC_YUV420_PLANAR_8BIT_DAHUA_H264;
        }
        break;
      case 1:
        {
          if (cmdl->inputFormat==VCENC_YUV420_SEMIPLANAR || cmdl->inputFormat==VCENC_YUV420_SEMIPLANAR_VU)
            trans_format = VCENC_YUV420_SEMIPLANAR_8BIT_FB;
          else if (cmdl->inputFormat==VCENC_YUV420_PLANAR_10BIT_P010)
            trans_format = VCENC_YUV420_PLANAR_10BIT_P010_FB;
          input_alignment = tb->input_alignment;
          break;
        }
      case 2:
        trans_format = VCENC_YUV420_SEMIPLANAR_101010;
        break;
      case 3:
      case 4:
        trans_format = VCENC_YUV420_8BIT_TILE_64_4;
        break;
      case 5:
        trans_format = VCENC_YUV420_10BIT_TILE_32_4;
        break;
      case 6:
      case 7:
        trans_format = VCENC_YUV420_10BIT_TILE_48_4;
        break;
      case 8:
      case 9:
        trans_format = VCENC_YUV420_8BIT_TILE_128_2;
        break;
      case 10:
      case 11:
        trans_format = VCENC_YUV420_10BIT_TILE_96_2;
        break;
      default:
        break;
    }
    
    getAlignedPicSizebyFormat(trans_format,cmdl->lumWidthSrc,cmdl->lumHeightSrc,input_alignment,NULL,NULL,&transform_size);
    tb->transformedSize = transform_size;
    
  }
  /* Here we use the EWL instance directly from the encoder
   * because it is the easiest way to allocate the linear memories */
   
#if 0  //fb transcode not need alloc pictureMem, transformMem
  for(coreIdx =0; coreIdx < tb->buffer_cnt; coreIdx++)
  {
#ifdef SUPPORT_TCACHE
    if ((cmdl->inputFormat >= INPUT_FORMAT_ARGB_FB && cmdl->inputFormat <= INPUT_FORMAT_YUV444P)
      || cmdl->inputFormat == VCENC_YUV420_PLANAR
      || cmdl->inputFormat == VCENC_YUV420_SEMIPLANAR
      || cmdl->inputFormat == VCENC_YUV420_SEMIPLANAR_VU
      || cmdl->inputFormat == VCENC_YUV420_PLANAR_10BIT_P010)
    {
      ret = EWLMallocHostLinear(((struct vcenc_instance *)enc)->asic.ewl, pictureSize,tb->input_alignment,
                        &tb->pictureMemFactory[coreIdx]);
      if (ret != EWL_OK)
      {
        //memset(&tb->pictureMemFactory[coreIdx], 0, sizeof(EWLLinearMem_t));
        return 1;
      }
    }
    else
#endif
    {
#ifdef USE_OLD_DRV
      ret = EWLMallocLinear(((struct vcenc_instance *)enc)->asic.ewl, pictureSize,alignment,
                            &tb->pictureMemFactory[coreIdx]);
      if (ret != EWL_OK)
      {
        tb->pictureMemFactory[coreIdx].virtualAddress = NULL;
        return 1;
      }
#else
      ret = EWLMallocInoutLinear(((struct vcenc_instance *)enc)->asic.ewl, pictureSize, alignment,
                            &tb->pictureMemFactory[coreIdx]);
      if (ret != EWL_OK)
      {
        //memset(&tb->pictureMemFactory[coreIdx], 0, sizeof(EWLLinearMem_t));
        return 1;
      }
#endif
	}

    if (cmdl->formatCustomizedType != -1 && transform_size!=0)
    {
#ifdef USE_OLD_DRV
      ret = EWLMallocLinear(((struct vcenc_instance *)enc)->asic.ewl, transform_size,tb->input_alignment,
                            &tb->transformMemFactory[coreIdx]);
      if (ret != EWL_OK)
      {
        tb->transformMemFactory[coreIdx].virtualAddress = NULL;
        return 1;
      }
#else
      ret = EWLMallocInoutLinear(((struct vcenc_instance *)enc)->asic.ewl, transform_size,tb->input_alignment,
                            &tb->transformMemFactory[coreIdx]);
      if (ret != EWL_OK)
      {
        //memset(&tb->transformMemFactory[coreIdx], 0, sizeof(EWLLinearMem_t));
        return 1;
      }      
#endif    
	}

#ifdef USE_OLD_DRV
    tb->pictureDSMemFactory[coreIdx].virtualAddress = NULL;
    if(cmdl->halfDsInput) {
      getAlignedPicSizebyFormat(cmdl->inputFormat,cmdl->lumWidthSrc/2,cmdl->lumHeightSrc/2,alignment,NULL,NULL,&pictureDSSize);
      ret = EWLMallocLinear(((struct vcenc_instance *)enc)->asic.ewl, pictureDSSize,alignment,
          &tb->pictureDSMemFactory[coreIdx]);
      if (ret != EWL_OK)
      {
        tb->pictureDSMemFactory[coreIdx].virtualAddress = NULL;
        return 1;
      }
    }
#else
    if(cmdl->halfDsInput) {
      getAlignedPicSizebyFormat(cmdl->inputFormat,cmdl->lumWidthSrc/2,cmdl->lumHeightSrc/2,alignment,NULL,NULL,&pictureDSSize);
      ret = EWLMallocInoutLinear(((struct vcenc_instance *)enc)->asic.ewl, pictureDSSize,alignment,
          &tb->pictureDSMemFactory[coreIdx]);
      if (ret != EWL_OK)
      {
        //memset(&tb->pictureDSMemFactory[coreIdx], 0, sizeof(EWLLinearMem_t));
        return 1;
      }
    }
#endif
  }
#endif

  /* set tb->pictureMemFactory[coreIdx].size */
  for(coreIdx =0; coreIdx < tb->buffer_cnt; coreIdx++) {
#ifdef USE_OLD_DRV
    tb->pictureMemFactory[coreIdx].size = getEWLMallocSize(pictureSize);
#else
    tb->pictureMemFactory[coreIdx].size = getEWLMallocInoutSize(tb->input_alignment, pictureSize);
    ENC_TB_DEBUG_PRINT("tb->pictureMemFactory[%d].size = %x\n", coreIdx, tb->pictureMemFactory[coreIdx].size);
#endif

  }

  /* Limited amount of memory on some test environment */
  if (cmdl->outBufSizeMax == 0) cmdl->outBufSizeMax = 12;
  streamBufTotalSize = 4 * tb->pictureMemFactory[0].size;
  streamBufTotalSize = CLIP3(VCENC_STREAM_MIN_BUF0_SIZE, (u32)cmdl->outBufSizeMax * 1024 * 1024, streamBufTotalSize);
  streamBufTotalSize = (cmdl->streamMultiSegmentMode != 0? tb->pictureMemFactory[0].size/16 : streamBufTotalSize);
  outbufSize[0] = streamBufTotalSize;
  tb->packetBufSize = streamBufTotalSize; /* packet buf size need alloc */
#if 0
  if (tb->streamBufNum > 1)
  {
    /* set small stream buffer0 to test two stream buffers */
    outbufSize[0] = MAX(tb->pictureMemFactory[0].size >> 10, VCENC_STREAM_MIN_BUF0_SIZE);
    outbufSize[1] = (streamBufTotalSize - outbufSize[0]) / (tb->streamBufNum-1);
  }
#endif
  for(coreIdx = 0; coreIdx < tb->parallelCoreNum; coreIdx++)
  {
    for (iBuf = 0; iBuf < tb->streamBufNum; iBuf ++)
    {
      //i32 size = outbufSize[iBuf ? 1 : 0];
      i32 size = outbufSize[0];
	  
#ifdef USE_OLD_DRV
      ret = EWLMallocLinear(((struct vcenc_instance *)enc)->asic.ewl, size, tb->input_alignment,
                             &tb->outbufMemFactory[coreIdx][iBuf]);
      if (ret != EWL_OK)
      {
        tb->outbufMemFactory[coreIdx][iBuf].virtualAddress = NULL;
        return 1;
      }
#else
      //ret = EWLMallocInoutLinear(((struct vcenc_instance *)enc)->asic.ewl, size, tb->input_alignment,
      //                       &tb->outbufMemFactory[coreIdx][iBuf]);
      ret = EWLMallocLinear(((struct vcenc_instance *)enc)->asic.ewl, size, tb->input_alignment,
                              &tb->outbufMemFactory[coreIdx][iBuf]);
      if (ret != EWL_OK)
      {
        //memset(&tb->outbufMemFactory[coreIdx][iBuf], 0, sizeof(EWLLinearMem_t));
        return 1;
      }

#ifdef VCE_MEM_ERR_TEST
      if(VceMemoryCheck(cmdl) != 0){
         ENC_TB_ERROR_PRINT("vce force memory error in function\n");
         return 1;
      }
#endif

#endif

    }

    /* add for multi out, vce inst outmem get EP addr */
    getOutbufMem(enc, tb);
  }

  //allocate delta qp map memory.
  // 4 bits per block.
  block_size=((cmdl->width+cmdl->max_cu_size-1)& (~(cmdl->max_cu_size - 1)))*((cmdl->height+cmdl->max_cu_size-1)& (~(cmdl->max_cu_size - 1)))/(8*8*2);
  // 8 bits per block if ipcm map/absolute roi qp is supported
  if (((struct vcenc_instance *)enc)->asic.regs.asicCfg.roiMapVersion >= 1)
    block_size *= 2;
  block_size = ((block_size+15)&(~15));
#ifdef USE_OLD_DRV
  if (EWLMallocLinear(((struct vcenc_instance *)enc)->asic.ewl, block_size*tb->buffer_cnt,0,&tb->roiMapDeltaQpMemFactory[0]) != EWL_OK)
  {
    tb->roiMapDeltaQpMemFactory[0].virtualAddress = NULL;
    return 1;
  }
#else
  if (EWLMallocInoutLinear(((struct vcenc_instance *)enc)->asic.ewl, block_size*tb->buffer_cnt,0,&tb->roiMapDeltaQpMemFactory[0]) != EWL_OK)
  {
    //memset(&tb->roiMapDeltaQpMemFactory[0], 0, sizeof(EWLLinearMem_t));
    return 1;
  }

#ifdef VCE_MEM_ERR_TEST
      if(VceMemoryCheck(cmdl) != 0){
        ENC_TB_ERROR_PRINT("vce force memory error in function\n");
        return 1;
      }
#endif

#endif  

  i32 total_size = tb->roiMapDeltaQpMemFactory[0].size;
  for(coreIdx = 0; coreIdx < tb->buffer_cnt; coreIdx++)
  {
#ifdef USE_OLD_DRV
    tb->roiMapDeltaQpMemFactory[coreIdx].virtualAddress = (u32*)((ptr_t)tb->roiMapDeltaQpMemFactory[0].virtualAddress + coreIdx * block_size);
#else
    tb->roiMapDeltaQpMemFactory[coreIdx].rc_virtualAddress = (u32*)((ptr_t)tb->roiMapDeltaQpMemFactory[0].rc_virtualAddress + coreIdx * block_size);
#endif
    tb->roiMapDeltaQpMemFactory[coreIdx].busAddress = tb->roiMapDeltaQpMemFactory[0].busAddress + coreIdx * block_size;
    tb->roiMapDeltaQpMemFactory[coreIdx].size = (coreIdx < tb->buffer_cnt-1 ? block_size : total_size - (tb->buffer_cnt-1)*block_size);
#ifdef USE_OLD_DRV
    memset(tb->roiMapDeltaQpMemFactory[coreIdx].virtualAddress, 0, block_size);
#else
    memset(tb->roiMapDeltaQpMemFactory[coreIdx].rc_virtualAddress, 0, block_size);
#endif
    if(((struct vcenc_instance *)enc)->asic.regs.asicCfg.roiMapVersion == 3)
    {
        if(cmdl->RoimapCuCtrlInfoBinFile != NULL)
        {
            u8 u8CuInfoSize;
            if(cmdl->RoiCuCtrlVer == 3)
              u8CuInfoSize = 1;
            else if(cmdl->RoiCuCtrlVer == 4)
              u8CuInfoSize = 2;
            else if(cmdl->RoiCuCtrlVer == 5)
              u8CuInfoSize = 6;
            else if(cmdl->RoiCuCtrlVer == 6)
              u8CuInfoSize = 12;
            else // if((cmdl->RoiCuCtrlVer == 7)
              u8CuInfoSize = 14;
			  
#ifdef USE_OLD_DRV			  
            if (EWLMallocLinear(((struct vcenc_instance *)enc)->asic.ewl, (block_size*u8CuInfoSize),0,&tb->RoimapCuCtrlInfoMemFactory[coreIdx]) != EWL_OK)
            {
                tb->RoimapCuCtrlInfoMemFactory[coreIdx].virtualAddress = NULL;
                return 1;
            }
            memset(tb->RoimapCuCtrlInfoMemFactory[coreIdx].virtualAddress, 0, block_size);
#else
            if (EWLMallocInoutLinear(((struct vcenc_instance *)enc)->asic.ewl, (block_size*u8CuInfoSize),0,&tb->RoimapCuCtrlInfoMemFactory[coreIdx]) != EWL_OK)
            {
              //memset(&tb->RoimapCuCtrlInfoMemFactory[coreIdx], 0, sizeof(EWLLinearMem_t));
              return 1;
            }
            memset(tb->RoimapCuCtrlInfoMemFactory[coreIdx].rc_virtualAddress, 0, block_size);

#ifdef VCE_MEM_ERR_TEST
          if(VceMemoryCheck(cmdl) != 0){
             ENC_TB_ERROR_PRINT("vce force memory error in function\n");
             return 1;
          }
#endif

#endif			
        }

        if(cmdl->RoimapCuCtrlIndexBinFile != NULL)
        {
            block_size = 1 << (IS_H264(cmdl->codecFormat) ? 4 : 6);
            block_size=((cmdl->width+block_size-1)& (~(block_size - 1)))*((cmdl->height+block_size-1)& (~(block_size - 1)))/(block_size*block_size);
#ifdef USE_OLD_DRV
            if (EWLMallocLinear(((struct vcenc_instance *)enc)->asic.ewl, block_size,0,&tb->RoimapCuCtrlIndexMemFactory[coreIdx]) != EWL_OK)
            {
                tb->RoimapCuCtrlIndexMemFactory[coreIdx].virtualAddress = NULL;
                return 1;
            }
            memset(tb->RoimapCuCtrlIndexMemFactory[coreIdx].virtualAddress, 0, block_size);
#else
            if (EWLMallocInoutLinear(((struct vcenc_instance *)enc)->asic.ewl, block_size,0,&tb->RoimapCuCtrlIndexMemFactory[coreIdx]) != EWL_OK)
            {
                //memset(&tb->RoimapCuCtrlIndexMemFactory[coreIdx], 0, sizeof(EWLLinearMem_t));
                return 1;
            }
            memset(tb->RoimapCuCtrlIndexMemFactory[coreIdx].rc_virtualAddress, 0, block_size);

#ifdef VCE_MEM_ERR_TEST
            if(VceMemoryCheck(cmdl) != 0){
               ENC_TB_ERROR_PRINT("vce force memory error in function\n");
               return 1;
            }
#endif

#endif
        }
    }
 
  }

  for(coreIdx =0; coreIdx < tb->buffer_cnt; coreIdx++)
  {
#ifdef USE_OLD_DRV
    ENC_TB_DEBUG_PRINT("Input buffer[%d] size:          %d bytes\n", coreIdx, tb->pictureMemFactory[coreIdx].size);
    ENC_TB_DEBUG_PRINT("Input buffer[%d] bus address:   %p\n", coreIdx, (void *)tb->pictureMemFactory[coreIdx].busAddress);
    ENC_TB_DEBUG_PRINT("Input buffer[%d] user address:  %p\n", coreIdx, tb->pictureMemFactory[coreIdx].virtualAddress);

#else
    ENC_TB_DEBUG_PRINT("Input buffer[%d] Addr EP(%p) RC(%p) VIRT(%p) size(%d)\n", coreIdx,
                            (void *)tb->pictureMemFactory[coreIdx].busAddress,
                            (void *)tb->pictureMemFactory[coreIdx].rc_busAddress,
                            tb->pictureMemFactory[coreIdx].rc_virtualAddress,
                            tb->pictureMemFactory[coreIdx].size);
#endif
  }

  for(coreIdx =0; coreIdx < tb->parallelCoreNum; coreIdx++)
  {
    for (iBuf = 0; iBuf < tb->streamBufNum; iBuf ++)
    {
#ifdef USE_OLD_DRV
      ENC_TB_DEBUG_PRINT("Output buffer[%d] size:         %d bytes\n", coreIdx, tb->outbufMemFactory[coreIdx][iBuf].size);
      ENC_TB_DEBUG_PRINT("Output buffer[%d] bus address:  %p\n", coreIdx, (void *)tb->outbufMemFactory[coreIdx][iBuf].busAddress);
      ENC_TB_DEBUG_PRINT("Output buffer[%d] user address: %p\n",  coreIdx, tb->outbufMemFactory[coreIdx][iBuf].virtualAddress);
#else
      ENC_TB_DEBUG_PRINT("Output buffer[%d] Addr EP(%p) RC(%p) VIRT(%p) size(%d)\n", coreIdx,
                            (void *)tb->outbufMemFactory[coreIdx][iBuf].busAddress,
                            (void *)tb->outbufMemFactory[coreIdx][iBuf].rc_busAddress,
                            tb->outbufMemFactory[coreIdx][iBuf].rc_virtualAddress,
                            tb->outbufMemFactory[coreIdx][iBuf].size);
#endif
    }
  }
  return 0;
}

/*------------------------------------------------------------------------------

    FreeRes

    Release all resources allcoated byt AllocRes()

------------------------------------------------------------------------------*/
void FreeRes(VCEncInst enc, struct test_bench *tb)
{
  u32 coreIdx=0;
  i32 iBuf;
    
#ifdef USE_OLD_DRV
  if (tb->roiMapDeltaQpMemFactory[0].virtualAddress != NULL)
  {
    for(coreIdx = 1; coreIdx < tb->buffer_cnt; coreIdx++)
      tb->roiMapDeltaQpMemFactory[0].size += tb->roiMapDeltaQpMemFactory[coreIdx].size;
    EWLFreeLinear(((struct vcenc_instance *)enc)->asic.ewl, &tb->roiMapDeltaQpMemFactory[0]);
  }
  for(coreIdx =0; coreIdx < tb->buffer_cnt; coreIdx++)
  {
    if (tb->pictureMemFactory[coreIdx].virtualAddress != NULL) {
#ifdef SUPPORT_TCACHE
      if (tb->pictureMemFactory[coreIdx].in_host)
      {
        EWLFreeHostLinear(((struct vcenc_instance *)enc)->asic.ewl, &tb->pictureMemFactory[coreIdx]);
      }
      else
#endif
      {
        EWLFreeLinear(((struct vcenc_instance *)enc)->asic.ewl, &tb->pictureMemFactory[coreIdx]);
      }
    }
	    
	if (tb->pictureDSMemFactory[coreIdx].virtualAddress != NULL)
      EWLFreeLinear(((struct vcenc_instance *)enc)->asic.ewl, &tb->pictureDSMemFactory[coreIdx]);

    if (tb->transformMemFactory[coreIdx].virtualAddress != NULL)
      EWLFreeLinear(((struct vcenc_instance *)enc)->asic.ewl, &tb->transformMemFactory[coreIdx]);

#if 0//def SUPPORT_DEC400
    if (tb->TSLumaMemFactory[coreIdx].virtualAddress != NULL)
      EWLFreeLinear(((struct vcenc_instance *)enc)->asic.ewl, &tb->TSLumaMemFactory[coreIdx]);
    if (tb->TSChromaMemFactory[coreIdx].virtualAddress != NULL)
      EWLFreeLinear(((struct vcenc_instance *)enc)->asic.ewl, &tb->TSChromaMemFactory[coreIdx]);
#endif
#ifdef SUPPORT_TCACHE
    if (tb->edma_link_buf.virtualAddress != NULL)
      EWLFreeLinear(((struct vcenc_instance *)enc)->asic.ewl, &tb->edma_link_buf);
#endif

    if (tb->RoimapCuCtrlInfoMemFactory[coreIdx].virtualAddress != NULL)
      EWLFreeLinear(((struct vcenc_instance *)enc)->asic.ewl, &tb->RoimapCuCtrlInfoMemFactory[coreIdx]);
    if (tb->RoimapCuCtrlIndexMemFactory[coreIdx].virtualAddress != NULL)
      EWLFreeLinear(((struct vcenc_instance *)enc)->asic.ewl, &tb->RoimapCuCtrlIndexMemFactory[coreIdx]);
  }
  for(coreIdx =0; coreIdx < tb->parallelCoreNum; coreIdx++)
  {
    for (iBuf = 0; iBuf < tb->streamBufNum; iBuf ++)
    {
      if (tb->outbufMemFactory[coreIdx][iBuf].virtualAddress != NULL)
        EWLFreeLinear(((struct vcenc_instance *)enc)->asic.ewl, &tb->outbufMemFactory[coreIdx][iBuf]);
    }
  }
#else /*USE_OLD_DRV*/
  for(coreIdx = 1; coreIdx < tb->buffer_cnt; coreIdx++)
    tb->roiMapDeltaQpMemFactory[0].size += tb->roiMapDeltaQpMemFactory[coreIdx].size;
  EWLFreeLinear(((struct vcenc_instance *)enc)->asic.ewl, &tb->roiMapDeltaQpMemFactory[0]);

  for(coreIdx =0; coreIdx < tb->buffer_cnt; coreIdx++)
  {
#if 0
    EWLFreeLinear(((struct vcenc_instance *)enc)->asic.ewl, &tb->pictureMemFactory[coreIdx]);
    EWLFreeLinear(((struct vcenc_instance *)enc)->asic.ewl, &tb->pictureDSMemFactory[coreIdx]);
    EWLFreeLinear(((struct vcenc_instance *)enc)->asic.ewl, &tb->transformMemFactory[coreIdx]);
#endif
    EWLFreeLinear(((struct vcenc_instance *)enc)->asic.ewl, &tb->RoimapCuCtrlInfoMemFactory[coreIdx]);
    EWLFreeLinear(((struct vcenc_instance *)enc)->asic.ewl, &tb->RoimapCuCtrlIndexMemFactory[coreIdx]);  
  }

  for(coreIdx =0; coreIdx < tb->parallelCoreNum; coreIdx++)
  {
    for (iBuf = 0; iBuf < tb->streamBufNum; iBuf ++)
    {
      EWLFreeLinear(((struct vcenc_instance *)enc)->asic.ewl, &tb->outbufMemFactory[coreIdx][iBuf]);
    }

#if 0//def SUPPORT_DEC400
    EWLFreeLinear(((struct vcenc_instance *)enc)->asic.ewl, &tb->TSLumaMemFactory[coreIdx]);
    EWLFreeLinear(((struct vcenc_instance *)enc)->asic.ewl, &tb->TSChromaMemFactory[coreIdx]);
#endif
  }
     
#ifdef SUPPORT_TCACHE
#if 0
    EWLFreeLinear(((struct vcenc_instance *)enc)->asic.ewl, &tb->edma_link_buf);
#else
    EWLFreeLinear(((struct vcenc_instance *)enc)->asic.ewl, &tb->encIn.PrivData.edma_link_buf);
    EWLFreeLinear(((struct vcenc_instance *)enc)->asic.ewl, &tb->encIn.PassTwoHWData.edma_link_buf);
#endif
#endif

#endif  
}

/*------------------------------------------------------------------------------

    CheckArea

------------------------------------------------------------------------------*/
i32 CheckArea(VCEncPictureArea *area, HANTROH26xEncOptions *options)
{
  i32 w = (options->width + options->max_cu_size - 1) / options->max_cu_size;
  i32 h = (options->height + options->max_cu_size - 1) / options->max_cu_size;

  if ((area->left < (u32)w) && (area->right < (u32)w) &&
      (area->top < (u32)h) && (area->bottom < (u32)h)) return 1;

  return 0;
}

/*    Callback function called by the encoder SW after "slice ready"
    interrupt from HW. Note that this function is not necessarily called
    after every slice i.e. it is possible that two or more slices are
    completed between callbacks. 
------------------------------------------------------------------------------*/
void HEVCSliceReady(VCEncSliceReady *slice)
{
  u32 i;
  u32 streamSize;
  u32 pos;
  SliceCtl_s *ctl = (SliceCtl_s*)slice->pAppData;
  /* Here is possible to implement low-latency streaming by
   * sending the complete slices before the whole frame is completed. */
  if(ctl->multislice_encoding && (ENCH2_SLICE_READY_INTERRUPT))
  {
    pos = slice->slicesReadyPrev ? ctl->streamPos:  /* Here we store the slice pointer */
                                   0;               /* Pointer to beginning of frame */
    streamSize=0;
    for(i = slice->nalUnitInfoNumPrev; i < slice->nalUnitInfoNum; i++)
    {
      streamSize += *(slice->sliceSizes+i);
    }

#if 10	
    AVPacket *outPkt;
    
    outPkt = av_packet_alloc();
    if (outPkt == NULL)
      return;
    av_init_packet(outPkt);
	
	if (av_packet_from_data(outPkt, (uint8_t *)&slice->streamBufs, streamSize))
		return;
	
#endif

    pos += streamSize;
    /* Store the slice pointer for next callback */
    ctl->streamPos = pos;
  }
}

/*------------------------------------------------------------------------------

    InitInputLineBuffer
    -get line buffer params for IRQ handle
    -get address of input line buffer
------------------------------------------------------------------------------*/
i32 InitInputLineBuffer(inputLineBufferCfg * lineBufCfg,
                           HANTROH26xEncOptions * options,
                           VCEncIn * encIn,
                           VCEncInst inst,
                           struct test_bench *tb)
{
    VCEncCodingCtrl codingCfg;
    u32 stride,chroma_stride;
    VCEncGetAlignedStride(options->lumWidthSrc,options->inputFormat,&stride,&chroma_stride,tb->input_alignment);
    VCEncGetCodingCtrl(inst, &codingCfg);

    memset(lineBufCfg, 0, sizeof(inputLineBufferCfg));
    lineBufCfg->depth  =  codingCfg.inputLineBufDepth;
    lineBufCfg->hwHandShake = codingCfg.inputLineBufHwModeEn;
    lineBufCfg->loopBackEn = codingCfg.inputLineBufLoopBackEn;
    lineBufCfg->inst   = (void *)inst;
    lineBufCfg->asic   = &(((struct vcenc_instance *)inst)->asic);
    lineBufCfg->wrCnt  = 0;
    lineBufCfg->inputFormat = options->inputFormat;
    lineBufCfg->pixOnRow = stride;
    lineBufCfg->encWidth  = options->width;
    lineBufCfg->encHeight = options->height;
    lineBufCfg->srcHeight = options->lumHeightSrc;
    lineBufCfg->srcVerOffset = options->verOffsetSrc;
    lineBufCfg->getMbLines = &VCEncGetEncodedMbLines;
    lineBufCfg->setMbLines = &VCEncSetInputMBLines;
    lineBufCfg->ctbSize = IS_H264(options->codecFormat) ? 16 : 64;
    lineBufCfg->lumSrc = tb->lum;
    lineBufCfg->cbSrc  = tb->cb;
    lineBufCfg->crSrc  = tb->cr;

    if (VCEncInitInputLineBuffer(lineBufCfg))
      return -1;

    /* loopback mode */
    if (lineBufCfg->loopBackEn && lineBufCfg->lumBuf.buf)
    {
        VCEncPreProcessingCfg preProcCfg;
        encIn->busLuma = lineBufCfg->lumBuf.busAddress;
        encIn->busChromaU = lineBufCfg->cbBuf.busAddress;
        encIn->busChromaV = lineBufCfg->crBuf.busAddress;

        /* In loop back mode, data in line buffer start from the line to be encoded*/
        VCEncGetPreProcessing(inst, &preProcCfg);
        preProcCfg.yOffset = 0;
        VCEncSetPreProcessing(inst, &preProcCfg);
    }

    return 0;
}

/* Callback function called by the encoder SW after "segment ready"
    interrupt from HW. Note that this function is called after every segment is ready.
------------------------------------------------------------------------------*/
void EncStreamSegmentReady(void *cb_data)
{
  u8 *streamBase;
  SegmentCtl_s *ctl = (SegmentCtl_s*)cb_data;

  if(ctl->streamMultiSegEn)
  {
    streamBase = ctl->streamBase + (ctl->streamRDCounter % ctl->segmentAmount) * ctl->segmentSize;

    if (ctl->output_byte_stream == 0 && ctl->startCodeDone == 0)
    {
      const u8 start_code_prefix[4] = {0x0, 0x0, 0x0, 0x1};
      fwrite(start_code_prefix, 1, 4, ctl->outStreamFile);
      ctl->startCodeDone = 1;
    }
    printf("<----receive segment irq %d\n",ctl->streamRDCounter);
    WriteStrm(ctl->outStreamFile, (u32 *)streamBase, ctl->segmentSize, 0);

    ctl->streamRDCounter++;
  }
}

/* add for ssim statistic */
void HantroVCEReport(AVCodecContext *avctx)
{
#ifndef BUILD_CMODEL
  //Transcoder_t * trans = (Transcoder_t *)trans_handle;
  HANTROH26xEncContext * ctx = (HANTROH26xEncContext *)avctx->priv_data;
  struct test_bench * tb = (struct test_bench *)&ctx->tb;
  
  if (ctx) {

    struct statistic enc_statistic = {0};
    ENCPERF  *perf = tb->perf;
    int j = 0;
	
    enc_statistic.frame_count = tb->picture_enc_cnt - (tb->parallelCoreNum-1);
    if (enc_statistic.frame_count && tb->picture_enc_cnt) {
        if (((tb->width+15)/16)*((tb->height+15)/16)) {
            enc_statistic.cycle_mb_avg = tb->hwcycle_acc / enc_statistic.frame_count / (((tb->width+15)/16)*((tb->height+15)/16));
            enc_statistic.cycle_mb_avg_p1 = perf->hwcycle_accp1 / enc_statistic.frame_count / (((tb->width+15)/16)*((tb->height+15)/16));
            enc_statistic.cycle_mb_avg_total = perf->hwcycle_acc_total / enc_statistic.frame_count / (((tb->width+15)/16)*((tb->height+15)/16));
        }
      enc_statistic.ssim_avg = tb->ssim_acc / enc_statistic.frame_count;
      if (tb->outputRateDenom) {
          enc_statistic.bitrate_avg = (ctx->total_bits * tb->outputRateNumer) / (enc_statistic.frame_count * tb->outputRateDenom);
      }
      enc_statistic.core_usage_counts[0] = perf->core_usage_counts[0];
      enc_statistic.core_usage_counts[1] = perf->core_usage_counts[1];
      enc_statistic.core_usage_counts[2] = perf->core_usage_counts_p1[0];
      enc_statistic.core_usage_counts[3] = perf->core_usage_counts_p1[1];
      enc_statistic.total_usage = enc_statistic.core_usage_counts[0]
                                + enc_statistic.core_usage_counts[1]
                                + enc_statistic.core_usage_counts[2]
                                + enc_statistic.core_usage_counts[3];
#ifdef FB_PERFORMANCE_STATIC
      enc_statistic.hw_real_time_avg = (PERFORMANCE_STATIC_GET_TOTAL(tb, perf, vcehw)
                                      + PERFORMANCE_STATIC_GET_TOTAL(tb, perf, vcehwp1)) / enc_statistic.frame_count;
      enc_statistic.hw_real_time_avg_remove_overlap = PERFORMANCE_STATIC_GET_TOTAL(tb, perf, vcehw_total) / enc_statistic.frame_count;
#endif
      enc_statistic.last_frame_encoded_timestamp = perf->last_frame_encoded_timestamp;
    }
    

    av_log(avctx, AV_LOG_INFO, ":::ENC[%d] : %d frames, SSIM %.4f, %d Cycles/MB, %d us/frame, %.2f fps, %u bps\n",
           tb->enc_index, enc_statistic.frame_count,
           enc_statistic.ssim_avg,
           enc_statistic.cycle_mb_avg_total,
           enc_statistic.hw_real_time_avg,
           (enc_statistic.hw_real_time_avg == 0) ? 0.0 : 1000000.0/((double)enc_statistic.hw_real_time_avg),
           enc_statistic.bitrate_avg);

    if (enc_statistic.cycle_mb_avg_p1) {
      av_log(avctx, AV_LOG_INFO, "\tPass 1 : %d Cycles/MB\n", enc_statistic.cycle_mb_avg_p1);
      av_log(avctx, AV_LOG_INFO, "\tPass 2 : %d Cycles/MB\n", enc_statistic.cycle_mb_avg);
    } 

#if 0
{
    av_log(avctx, AV_LOG_INFO, "\tremove overlap : %d us/frame, enc_statistic.hw_real_time_avg = %d\n",
           enc_statistic.hw_real_time_avg_remove_overlap,
           enc_statistic.hw_real_time_avg);
}
#endif

    if (enc_statistic.hw_real_time_avg > enc_statistic.hw_real_time_avg_remove_overlap + 10) {
      av_log(avctx, AV_LOG_INFO, "\tremove overlap : %d us/frame, %.2f fps\n",
             enc_statistic.hw_real_time_avg_remove_overlap,
             (enc_statistic.hw_real_time_avg_remove_overlap == 0) ? 0.0 : 1000000.0/((double)enc_statistic.hw_real_time_avg_remove_overlap));
    }

    av_log(avctx, AV_LOG_INFO, ":::ENC[%d] Multi-core usage statistics:\n", tb->enc_index);

    if (enc_statistic.total_usage == 0) enc_statistic.total_usage = 1;

    for (j = 0; j < 2; j++) {
      if (enc_statistic.core_usage_counts[2] || enc_statistic.core_usage_counts[3])
        av_log(avctx, AV_LOG_INFO, "\tPass 1 Slice[%d] used %6d times (%2d%%)\n", j, enc_statistic.core_usage_counts[2+j],
               (enc_statistic.core_usage_counts[2+j] * 100) / enc_statistic.total_usage);
    }
    for (j = 0; j < 2; j++) {
      av_log(avctx, AV_LOG_INFO, "\tSlice[%d] used %6d times (%2d%%)\n", j, enc_statistic.core_usage_counts[j],
             (enc_statistic.core_usage_counts[j] * 100) / enc_statistic.total_usage);
    }

    ENC_TB_STAT_PRINT(":::ENC[%d] : %d frames, SSIM %.4f, %d Cycles/MB, %d us/frame, %.2f fps, %u bps\n",
                      tb->enc_index, enc_statistic.frame_count,
                      enc_statistic.ssim_avg,
                      enc_statistic.cycle_mb_avg_total,
                      enc_statistic.hw_real_time_avg,
                      (enc_statistic.hw_real_time_avg == 0) ? 0.0 : 1000000.0/((double)enc_statistic.hw_real_time_avg),
                      enc_statistic.bitrate_avg);

    if (enc_statistic.cycle_mb_avg_p1) {
      ENC_TB_STAT_PRINT("\tPass 1 : %d Cycles/MB\n", enc_statistic.cycle_mb_avg_p1);
      ENC_TB_STAT_PRINT("\tPass 2 : %d Cycles/MB\n", enc_statistic.cycle_mb_avg);
    }

    if (enc_statistic.hw_real_time_avg > enc_statistic.hw_real_time_avg_remove_overlap + 10) {
      ENC_TB_STAT_PRINT("\tremove overlap : %d us/frame, %.2f fps\n",
                        enc_statistic.hw_real_time_avg_remove_overlap,
                        (enc_statistic.hw_real_time_avg_remove_overlap == 0) ? 0.0 : 1000000.0/((double)enc_statistic.hw_real_time_avg_remove_overlap));
    }

    ENC_TB_STAT_PRINT(":::ENC[%d] Multi-core usage statistics:\n", tb->enc_index);

    if (enc_statistic.total_usage == 0) enc_statistic.total_usage = 1;

    for (j = 0; j < 2; j++) {
      if (enc_statistic.core_usage_counts[2] || enc_statistic.core_usage_counts[3])
        ENC_TB_STAT_PRINT("\tPass 1 Slice[%d] used %6d times (%2d%%)\n", j, enc_statistic.core_usage_counts[2+j],
                          (enc_statistic.core_usage_counts[2+j] * 100) / enc_statistic.total_usage);
    }
    for (j = 0; j < 2; j++) {
      ENC_TB_STAT_PRINT("\tSlice[%d] used %6d times (%2d%%)\n", j, enc_statistic.core_usage_counts[j],
             (enc_statistic.core_usage_counts[j] * 100) / enc_statistic.total_usage);
    }
  
#if 0  
    av_log(NULL, AV_LOG_INFO, ":::TRANS  : %d frames, %d us/frame, %.2f fps\n",
                      enc_statistic.frame_count,
                      enc_statistic.frame_count ? PERFORMANCE_STATIC_GET_TOTAL(trans, trans) / enc_statistic.frame_count : 0,
                      enc_statistic.frame_count ? 1000000.0/((double)(PERFORMANCE_STATIC_GET_TOTAL(trans, trans) / trans->enc_stat[0].frame_count)) : 0.0);
#endif
  }
#endif
}

