
#ifndef AVCODEC_HANTRO_VP9DEC_H
#define AVCODEC_HANTRO_VP9DEC_H

#include "libavutil/buffer.h"
#include "libavutil/intreadwrite.h"
#include "libavutil/thread.h"

#include "cabac.h"
#include "error_resilience.h"
#include "internal.h"
#include "mpegutils.h"
#include "parser.h"
#include "qpeldsp.h"
#include "rectangle.h"
#include "videodsp.h"

#include "vp9decapi.h"
#include "dwl.h"
#include "dwlthread.h"

#include "vp9hwd_container.h"
#include "regdrv.h"
#include "deccfg.h"
#include "hantro_dec_tb_defs.h"
#include "hantro_dec_common.h"


//static void ReleaseExtBuffers(AVCodecContext *avctx);

u32 FindExtBufferIndex(AVCodecContext *avctx,u32 *addr) ;
u32 FindEmptyIndex(AVCodecContext *avctx);
enum DecRet Vp9DecAddBuffer(Vp9DecInst dec_inst,
                            struct DWLLinearMem *info);

static void ParseSuperframeIndex(const u8* data, size_t data_sz,
                                 const u8* buf, size_t buf_sz,
                                 u32 sizes[8], i32* count);

enum DecRet Vp9Decode(void* inst, struct DWLLinearMem input, struct DecOutput* output,
                             u8* stream, u32 strm_len, u32 pic_id);

static enum DecRet Vp9Init(HantroDecContext *fb_dec_ctx, struct DecConfig config,
                      const void *dwl);

#endif /* AVCODEC_H264DEC_H */
