/*------------------------------------------------------------------------------
--                                                                                                                               --
--       This software is confidential and proprietary and may be used                                   --
--        only as expressly authorized by a licensing agreement from                                     --
--                                                                                                                               --
--                            Verisilicon.                                                                                    --
--                                                                                                                               --
--                   (C) COPYRIGHT 2014 VERISILICON                                                            --
--                            ALL RIGHTS RESERVED                                                                    --
--                                                                                                                               --
--                 The entire notice above must be reproduced                                                 --
--                  on all copies and should not be removed.                                                    --
--                                                                                                                               --
--------------------------------------------------------------------------------*/

#ifndef AVCODEC_HANTRO_H26XENC_H
#define AVCODEC_HANTRO_H26XENC_H

#include "libavutil/avassert.h"
#include "libavutil/opt.h"
#include "libavutil/imgutils.h"
#include "libavutil/pixdesc.h"
#include "libavutil/timer.h"
#include "libavutil/fifo.h"
#include "avcodec.h"
#include "internal.h"

#include "base_type.h"

#include "hevcencapi.h"
#include "encinputlinebuffer.h"
#include <sys/time.h>
#include "hantro_enc_options.h"

#include "pthread.h"
#include "fifo.h"

#ifdef FB_SYSLOG_ENABLE
#include "syslog_sink.h"
#define ENC_TB_PRINT_FLUSH() FB_SYSLOG_FLUSH()
#define ENC_TB_STAT_PRINT(fmt, ...) FB_SYSLOG(tb,SYSLOG_SINK_LEV_STAT,fmt, ## __VA_ARGS__)
#define ENC_TB_INFO_PRINT(fmt, ...) FB_SYSLOG(tb,SYSLOG_SINK_LEV_INFO,fmt, ## __VA_ARGS__)
#define ENC_TB_ERROR_PRINT(fmt, ...) FB_SYSLOG(tb,SYSLOG_SINK_LEV_ERROR,"%s([%d]): " fmt,\
                                    __FUNCTION__, __LINE__, ## __VA_ARGS__)
#define ENC_TB_DEBUG_PRINT(fmt, ...) FB_SYSLOG(tb,SYSLOG_SINK_LEV_DEBUG_SW,"%s([%d]): " fmt,\
                                    __FUNCTION__, __LINE__, ## __VA_ARGS__)
#define ENC_TB_DEBUGV_PRINT(fmt, ...) FB_SYSLOG(tb,SYSLOG_SINK_LEV_DEBUG_SW_VERBOSE,"%s([%d]): " fmt,\
                                    __FUNCTION__, __LINE__, ## __VA_ARGS__)
#endif

#define MAX_FIFO_DEPTH 16
#define MAX_WAIT_DEPTH 78 //34
#define MAX_ENC_NUM    4
#define MAX_OUTPUT_FIFO_DEPTH 2 //1

#define USE_SELF_DEFINE

#define DEFAULT_VALUE -255

#define DEFAULT -255
#define MAX_CUTREE_DEPTH 64
#define MAX_DELAY_NUM (MAX_CORE_NUM+MAX_CUTREE_DEPTH)

#define MAX_IDR_ARRAY_DEPTH MAX_WAIT_DEPTH

typedef struct {
  u32 streamPos;
  u32 multislice_encoding;
  u32 output_byte_stream;
  FILE *outStreamFile;
} SliceCtl_s;

typedef struct {
  u32 streamRDCounter;
  u32 streamMultiSegEn;
  u8 *streamBase;
  u32 segmentSize;
  u32 segmentAmount;
  FILE *outStreamFile;
  u8 startCodeDone; 
  i32 output_byte_stream;
} SegmentCtl_s;

struct test_bench
{
#ifdef FB_SYSLOG_ENABLE
  LOG_INFO_HEADER log_header;
#endif
  ENCPERF * perf;
  char *input;
  char *halfDsInput;
  char *output;
  char *test_data_files;
  FILE *in;
  FILE *inDS;
  FILE *out;
  FILE *fmv;
  i32 width;
  i32 height;
  i32 outputRateNumer;      /* Output frame rate numerator */
  i32 outputRateDenom;      /* Output frame rate denominator */
  i32 inputRateNumer;      /* Input frame rate numerator */
  i32 inputRateDenom;      /* Input frame rate denominator */
  i32 firstPic;
  i32 lastPic;
  i32 input_pic_cnt;
  i32 picture_enc_cnt;
  i32 enc_first_frame;
  i32 idr_interval;
  i32 byteStream;
  u8 *lum;
  u8 *cb;
  u8 *cr;
  u8 *lumDS;
  u8 *cbDS;
  u8 *crDS;
  u32 src_img_size_ds;
  i32 interlacedFrame;
  u32 validencodedframenumber;
  u32 input_alignment;
  u32 ref_alignment;
  u32 ref_ch_alignment;
  i32 formatCustomizedType;
  u32 lumaSize;
  u32 chromaSize;
  u32 lumaSizeDs;
  u32 chromaSizeDs;
  u32 transformedSize;

  char **argv;      /* Command line parameter... */
  i32 argc;
  /* Moved from global space */
  FILE *yuvFile;
  FILE *roiMapFile;
  FILE *roiMapBinFile;
  FILE *ipcmMapFile;
  FILE *skipMapFile;
  FILE *roiMapInfoBinFile;
  FILE *RoimapCuCtrlInfoBinFile;
  FILE *RoimapCuCtrlIndexBinFile;

  /* SW/HW shared memories for input/output buffers */
  EWLLinearMem_t * pictureMem;
  EWLLinearMem_t * pictureDSMem;
  EWLLinearMem_t * outbufMem[MAX_STRM_BUF_NUM];
  EWLLinearMem_t * roiMapDeltaQpMem;
  EWLLinearMem_t * transformMem;
  EWLLinearMem_t * RoimapCuCtrlInfoMem;
  EWLLinearMem_t * RoimapCuCtrlIndexMem;

  EWLLinearMem_t pictureMemFactory[MAX_DELAY_NUM];
  EWLLinearMem_t pictureDSMemFactory[MAX_DELAY_NUM];
  EWLLinearMem_t outbufMemFactory[MAX_CORE_NUM][MAX_STRM_BUF_NUM]; /* [coreIdx][bufIdx] */
  EWLLinearMem_t roiMapDeltaQpMemFactory[MAX_DELAY_NUM];
  EWLLinearMem_t transformMemFactory[MAX_DELAY_NUM];
  EWLLinearMem_t RoimapCuCtrlInfoMemFactory[MAX_DELAY_NUM];
  EWLLinearMem_t RoimapCuCtrlIndexMemFactory[MAX_DELAY_NUM];

  EWLLinearMem_t scaledPictureMem;
  float sumsquareoferror;
  float averagesquareoferror;
  i32 maxerrorovertarget;
  i32 maxerrorundertarget;
  long numbersquareoferror;

  u32 gopSize;
  i32 nextGopSize;
  VCEncIn encIn;

  inputLineBufferCfg inputCtbLineBuf;

  FILE *gmvFile[2];
  
  u32 parallelCoreNum;
  SliceCtl_s sliceCtlFactory[MAX_DELAY_NUM];
  SliceCtl_s *sliceCtl;
  SliceCtl_s *sliceCtlOut;

  const void *ewl;
  const void *twoPassEwl;

  int enc_index;
  double ssim_acc;
  i64 hwcycle_acc;
  
#if defined(SUPPORT_DEC400) || defined(SUPPORT_TCACHE)
  char *inputts;
  FILE *ints;
  u8 *tslu;
  u8 *tsch;
  u32 tbl_luma_size;
  u32 tbl_chroma_size;
  u32 tbl_luma_size_ds;
  u32 tbl_chroma_size_ds;
  EWLLinearMem_t * TSLumaMem;
  EWLLinearMem_t * TSChromaMem;
  EWLLinearMem_t TSLumaMemFactory[MAX_DELAY_NUM];
  EWLLinearMem_t TSChromaMemFactory[MAX_DELAY_NUM];
  void * dec400f2_handle;
#endif

#ifdef DRV_NEW_ARCH
  int priority;
  char * device;
  int mem_id;
#endif
  i32 streamBufNum;
  u32 frame_delay;
  u32 buffer_cnt;
  SegmentCtl_s streamSegCtl;

  struct timeval timeFrameStart;
  struct timeval timeFrameEnd;

  u32 packetBufSize;
  u32 outMemIndex;


  int64_t first_pts;
  int64_t last_in_pts;
  int64_t pts_fix[100];
  int     pts_offset;
  int64_t last_out_dts;

};

#define MOVING_AVERAGE_FRAMES    120

typedef struct {
    i32 frame[MOVING_AVERAGE_FRAMES];
    i32 length;
    i32 count;
    i32 pos;
    i32 frameRateNumer;
    i32 frameRateDenom;
} ma_s;

typedef struct {
    int gop_frm_num;
    double sum_intra_vs_interskip;
    double sum_skip_vs_interskip;
    double sum_intra_vs_interskipP;
    double sum_intra_vs_interskipB;
    int sum_costP;
    int sum_costB;
    int last_gopsize;
} adapGopCtr;

typedef struct HANTRO_ENC_IN_ADDR_s {
    ptr_t busLuma;
    ptr_t busChroma;
    ptr_t busLumaTable;
    ptr_t busChromaTable;
  
    ptr_t busLumaDs;
    ptr_t busChromaDs;
    ptr_t busLumaTableDs;
    ptr_t busChromaTableDs;
} HANTRO_ENC_IN_ADDR_t;

typedef struct TranscoderPic_s {
  int state;
  int isInPassOneQueue;
  int poc;
  pthread_mutex_t trans_mutex;
  AVFrame * trans_pic;
} TranscoderPic_t;

typedef enum HantroPreset_e {
  HANTRO_PRESET_NONE,
  HANTRO_PRESET_SUPERFAST,
  HANTRO_PRESET_FAST,
  HANTRO_PRESET_MEDIUM,
  HANTRO_PRESET_SLOW,
  HANTRO_PRESET_SUPERSLOW,
  HANTRO_PRESET_NUM
} HantroPreset_t;

enum {
  HANTRO_DEC_OUT_RFC,
  HANTRO_DEC_OUT_PP0,
  HANTRO_DEC_OUT_PP1,
  HANTRO_DEC_OUT_PP2,
  HANTRO_DEC_OUT_PP3,
};

typedef enum HantroFlushState_e {
  HANTRO_FLUSH_IDLE,
  HANTRO_FLUSH_PREPARE = 5,
  HANTRO_FLUSH_TRANSPIC,
  HANTRO_FLUSH_ENCDATA,
  HANTRO_FLUSH_FINISH,
  HANTRO_FLUSH_ENCEND,
  HANTRO_FLUSH_ERROR = -1,
} HantroFlushState_t;

typedef enum IDRCalcState_e {
  FRAME_NORMAL,
  FRAME_IDR,
  FRAME_IDR2NORMAL,
} IDRCalcState_t;

typedef struct HANTROH26xEncContext {
    AVClass *class;
    HANTROH26xEncOptions options;
    AVCodecContext *avctx;
    struct test_bench tb;
    char module_name[20];
    int pp_index;
    int max_frames_delay;

    /**/
    VCEncInst hantro_encoder;
    VCEncOut encOut;
	
    VCEncGopPicConfig gopPicCfg[MAX_GOP_PIC_CONFIG_NUM];
    VCEncGopPicConfig gopPicCfgPass2[MAX_GOP_PIC_CONFIG_NUM];
    VCEncGopPicSpecialConfig gopPicSpecialCfg[MAX_GOP_SPIC_CONFIG_NUM];

    VCEncRateCtrl rc;

    bool EncoderIsOpen;
    bool EncoderIsStart;
    bool EncoderIsEnd;
    //PktState_t rcvPktFlag;
    //PktRcvRet_t rcvPktRet;
    bool EncProcessTerm;
    bool EncoderFlushPic;
    //bool inTwoPassWait;
    bool PktWillEnd;

    /* param for enc tail flush */
    bool TransFlushPic;
    //bool EncFlushFlag;
    HantroFlushState_t flushState;
    VCEncIn EncInbk;
    int picture_cnt_bk;

    adapGopCtr agop;
    bool adaptiveGop;
    u8 *pUserData;
    int next_poc;
    VCEncPictureCodingType nextCodingType;
    i32 nextGopSize;

    AVPacket *outPkt;
    AVFrame  *inputFrame;

    AVBufferRef *hwframe;
    AVBufferRef *hwdevice;
    u8 *dev_name;

    TranscoderPic_t PicWaitForEnc[MAX_WAIT_DEPTH];
    i32 poc;

    /* param for performance */
    ma_s ma;
    u64 total_bits;
    u32 frameCntTotal;
    u32 frameCntOutput;

    /* param pass from ffmpeg */
    char *preset;
    int force_8bit;
    int bitdepth;
    char *profile;
    char *level;

    char *hantro_params;
    HantroParamsDef_t *hantroParamTable;

    /* thread params */
    //pthread_t frame_fifo_thread;
    pthread_t frame_enc_thread;
    //pthread_attr_t fifo_thread_attr;
    pthread_attr_t enc_thread_attr;
    pthread_mutex_t rcv_packet_mutex;
    pthread_mutexattr_t rcv_packet_mutex_attr;

    FifoInst TranscodeFifo;
    FifoInst TransEmptyFifo;
    FifoInst OutputFifo;
    FifoInst EmptyBuf;
    //EncOutData_t OutBuf[MAX_OUTPUT_FIFO_DEPTH];
    //EncOutData_t out_buffer[MAX_OUTPUT_FIFO_DEPTH];
	
    //int output_rdy_cnt;
    //int frame_rdy_cnt;
    int num_wait_consume;
    int num_dec_max;

    //unsigned int in_width;
    //unsigned int in_height;

    /* add for idr debug */
    int nextIDRPoc;
    i32 IDRPocArray[MAX_IDR_ARRAY_DEPTH];
    int forced_idr;
    //int predict_poc;
    bool keyFrameFlag;
    IDRCalcState_t idrFlag;
    int nextGopStart;
    int injectFrameCnt;
    int gopLength; /* used to calc max gopSize for IDR */
    int pocStoreIndex;
    int nextIDRPocIndex;
    bool updateIDRPoc;
    int holdBufNum;

} HANTROH26xEncContext;


/* add for ssim statistic */
struct statistic {
  u32 frame_count;
  u32 cycle_mb_avg;
  u32 cycle_mb_avg_p1;
  u32 cycle_mb_avg_total;
  double ssim_avg;
  u32 bitrate_avg;
  u32 hw_real_time_avg;
  u32 hw_real_time_avg_remove_overlap;
  i32 total_usage;
  i32 core_usage_counts[4];
  struct timeval last_frame_encoded_timestamp;
};

extern HantroParamsDef_t HantroParamTable[];
extern int GetDefaultHantroParams(HANTROH26xEncContext *ctx);
extern int GetHantroParamsFromCmd(HANTROH26xEncContext *ctx, const char *name, const char *inputValue);
extern void SendEosToEnc(VCEncInst encoder);

#ifdef USE_OLD_DRV
extern u32 getEWLMallocSize(u32 size);
#else
extern u32 getEWLMallocInoutSize(u32 alignment, u32 inSize);
#endif

#ifdef FB_PERFORMANCE_STATIC
extern i64 EWLGetHwPerformance(const void *instance);
#endif
#endif


