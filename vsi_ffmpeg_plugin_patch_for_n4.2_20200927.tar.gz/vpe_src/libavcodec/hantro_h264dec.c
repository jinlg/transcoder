#include "libavutil/avassert.h"
#include "libavutil/display.h"
#include "libavutil/imgutils.h"
#include "libavutil/opt.h"
#include "libavutil/stereo3d.h"
#include "libavutil/timer.h"
#include "internal.h"
#include "bytestream.h"
#include "cabac.h"
#include "cabac_functions.h"
#include "error_resilience.h"
#include "avcodec.h"
#include "h264.h"
#include "hantro_h264dec.h"
#include "h264dec.h"
#include "h2645_parse.h"
#include "h264data.h"
#include "h264chroma.h"
#include "h264_mvpred.h"
#include "h264_ps.h"
#include "golomb.h"
#include "hwaccel.h"
#include "mathops.h"
#include "me_cmp.h"
#include "mpegutils.h"
#include "profiles.h"
#include "rectangle.h"
#include "thread.h"
#include "h264decapi.h"
#include "dwl.h"

#include "decode.h"
#include "avcodec.h"
#include "libavutil/hwcontext_hantro.h"
#include "libavutil/mem.h"


#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <dectypes.h>
#include <stdio.h>

#include "libavformat/avc.h"
#include "hantro_h264dec_utils.h"
#include "hantro_dec_common.h"
#include "transcoder.h"


static av_cold int hantro_decode_h264_close(AVCodecContext *avctx);

static void hantro_decode_h264_picture_consume(void *opaque, uint8_t *data)
{
    HantroDecContext *fb_dec_ctx = opaque;
    struct DecPicturePpu pic = *((struct DecPicturePpu *)data);
    if(fb_dec_ctx->initialized)
    {
        av_log(fb_dec_ctx, AV_LOG_DEBUG, "%s(%d) pic @ %p\n",__FUNCTION__,__LINE__,data);
        DelDecPicWaitConsumeList(fb_dec_ctx,data);
        H264PictureConsumedNoDWL(fb_dec_ctx->dec_inst, pic);        
    }
    else
        av_log(NULL, AV_LOG_DEBUG, "in %s  after close @ %p ..... \n",__FUNCTION__, data);
    if (data) av_free(data);
}

static av_cold int hantro_decode_h264_init(AVCodecContext *avctx)
{
    int ret;
    HantroDecContext *fb_dec_ctx = avctx->priv_data;
    AVHANTRODeviceContext *device_hwctx;
    AVHANTROFramesContext *frame_hwctx;
    AVHWDeviceContext *device_ctx;
    AVHWFramesContext *hwframe_ctx;

    H264DecApiVersion dec_api;
    H264DecBuild dec_build;
    u32 n_cores;
    FILE *f_tbcfg;
    u32 major_version, minor_version, prod_id;


    H264DecMCConfig mc_init_cfg = {0};
    enum DecDpbFlags flags = 0;
    u32 size, i;

    
    if(fb_dec_ctx->initialized == 1)
    {
        av_log(avctx, AV_LOG_DEBUG, "%s %d has initialized !!\n",__func__,__LINE__);
        return 0;
    }

    if (hantro_check_enc_format_for_trans(avctx))
        goto error;
    
    av_log(avctx, AV_LOG_TRACE, "%s(%d) avctx->hw_frames_ctx = %p\n", __FUNCTION__, __LINE__, avctx->hw_frames_ctx);

    
    ret = hantro_dec_init_hwctx(avctx);
    if(ret) goto error;

    hwframe_ctx = (AVHWFramesContext*)fb_dec_ctx->hwframe->data;
    device_ctx = hwframe_ctx->device_ctx;
    device_hwctx = device_ctx->hwctx;
    frame_hwctx = hwframe_ctx->hwctx;

    av_log(avctx, AV_LOG_DEBUG, "device_ctx = %p, hwframe_ctx = %p\n", device_ctx, hwframe_ctx);
    av_log(avctx, AV_LOG_DEBUG, "device_hwctx = %p\n", device_hwctx);
    av_log(avctx, AV_LOG_DEBUG, "device_hwctx->internal = %p\n", device_hwctx->internal);
    av_log(avctx, AV_LOG_DEBUG, "device_hwctx->device = %s\n", device_hwctx->device);
    av_log(avctx, AV_LOG_DEBUG, "device_hwctx->priority = %d\n", device_hwctx->priority);
    
    InitHantroDecDecodeWrapper(avctx,DEC_H264_H10P);
    HantroDecSetDefaultDecconfig(avctx,DEC_H264_H10P);
    
    fb_dec_ctx->hantro_decode_picture_consume = hantro_decode_h264_picture_consume;



    if(fb_dec_ctx->pp_setting && strlen(fb_dec_ctx->pp_setting) > 0)
    av_log(avctx, AV_LOG_DEBUG, "\t\t--------------in fb_h264_decode_init option pp_settting is %s\n",fb_dec_ctx->pp_setting);
    if(fb_dec_ctx->dev_name)
    av_log(avctx, AV_LOG_DEBUG, "\t\t--------------in fb_h264_decode_init option dev_name is %s\n",fb_dec_ctx->dev_name);
    
    av_log(avctx, AV_LOG_DEBUG, "\t\t--------------in fb_h264_decode_init option disable_dec400 = %d\n",fb_dec_ctx->disable_dec400);

    fb_dec_ctx->dev_name = av_strdup(device_hwctx->device);
    sprintf(fb_dec_ctx->module_name,"H264DEC");
	fb_dec_ctx->avctx = avctx;
    hantro_dec_log_header_init(avctx);
    
	fb_dec_ctx->stream_stop = NULL;
	fb_dec_ctx->align = DEC_ALIGN_1024B;
	fb_dec_ctx->clock_gating = DEC_X170_INTERNAL_CLOCK_GATING;
	fb_dec_ctx->data_discard = DEC_X170_DATA_DISCARD_ENABLE;
	fb_dec_ctx->latency_comp = DEC_X170_LATENCY_COMPENSATION;
	fb_dec_ctx->output_picture_endian = DEC_X170_OUTPUT_PICTURE_ENDIAN;
	fb_dec_ctx->bus_burst_length = DEC_X170_BUS_BURST_LENGTH;
	fb_dec_ctx->asic_service_priority = DEC_X170_ASIC_SERVICE_PRIORITY;
	fb_dec_ctx->output_format = DEC_X170_OUTPUT_FORMAT;
	fb_dec_ctx->service_merge_disable = DEC_X170_SERVICE_MERGE_DISABLE;
	fb_dec_ctx->tiled_output = DEC_REF_FRM_RASTER_SCAN;
	fb_dec_ctx->dpb_mode = DEC_DPB_FRAME;
	fb_dec_ctx->pp_units_params_from_cmd_valid = 0;
	fb_dec_ctx->dwl_init.client_type = DWL_CLIENT_TYPE_H264_DEC;
    if(fb_dec_ctx->dev_name)
        fb_dec_ctx->dwl_init.dec_dev_name = fb_dec_ctx->dev_name;
    else
        fb_dec_ctx->dwl_init.dec_dev_name = device_hwctx->device;
    fb_dec_ctx->dwl_init.priority = device_hwctx->priority;
    avctx->pix_fmt = AV_PIX_FMT_YUV420P;//AV_PIX_FMT_HANTRO;

    //pthread_mutex_init(&fb_dec_ctx->ext_buffer_contro, NULL);


    memset(fb_dec_ctx->ext_buffers, 0, sizeof(fb_dec_ctx->ext_buffers));

    //fb_dec_ctx->buffer_release_flag = 1;
    fb_dec_ctx->cycle_count = 0;

    /* set test bench configuration */
    TBSetDefaultCfg(&fb_dec_ctx->tb_cfg);


#ifdef HANTRO_CMODEL
    av_log(avctx, AV_LOG_DEBUG, "\t\ttb_cfg.dec_params.hw_build = %d\n",tb_cfg.dec_params.hw_build);
#endif

    av_log(avctx, AV_LOG_DEBUG, "\t\t fb_dec_ctx->tb_cfg.dec_params.hw_build = %d\n",fb_dec_ctx->tb_cfg.dec_params.hw_build);
    ResolvePpParamsOverlapPPU(fb_dec_ctx->hantro_dec_config.ppu_cfg,fb_dec_ctx->tb_cfg.pp_units_params);

    if(fb_dec_ctx->pp_setting && strlen(fb_dec_ctx->pp_setting) > 0)
    {
        ret = HantroDecParseResize(avctx);
        if(ret) goto error;   
    }
    //ret = hantro_set_buffer_number_for_trans(avctx);
    //if(ret)goto error;
    HantroDecParsePPUCfg(avctx,fb_dec_ctx->hantro_dec_config.ppu_cfg);

    if (prod_id == 0x6731)
        fb_dec_ctx->max_strm_len = DEC_X170_MAX_STREAM;
    else
        fb_dec_ctx->max_strm_len = DEC_X170_MAX_STREAM_VC8000D;


    fb_dec_ctx->tb_cfg.pp_params.pipeline_e = 1;

    fb_dec_ctx->mb_error_concealment = 0; 
    fb_dec_ctx->rlc_mode = TBGetDecRlcModeForced(&fb_dec_ctx->tb_cfg);
    fb_dec_ctx->clock_gating = TBGetDecClockGating(&fb_dec_ctx->tb_cfg);
    fb_dec_ctx->data_discard = TBGetDecDataDiscard(&fb_dec_ctx->tb_cfg);
    fb_dec_ctx->latency_comp = fb_dec_ctx->tb_cfg.dec_params.latency_compensation;
    fb_dec_ctx->output_picture_endian = TBGetDecOutputPictureEndian(&fb_dec_ctx->tb_cfg);
    fb_dec_ctx->bus_burst_length = fb_dec_ctx->tb_cfg.dec_params.bus_burst_length;
    fb_dec_ctx->asic_service_priority = fb_dec_ctx->tb_cfg.dec_params.asic_service_priority;
    fb_dec_ctx->output_format = TBGetDecOutputFormat(&fb_dec_ctx->tb_cfg);
    fb_dec_ctx->service_merge_disable = TBGetDecServiceMergeDisable(&fb_dec_ctx->tb_cfg);

    fb_dec_ctx->enable_mc = 1;

    fb_dec_ctx->seed_rnd = fb_dec_ctx->tb_cfg.tb_params.seed_rnd;

    fb_dec_ctx->dwl_init.mem_id = frame_hwctx->task_id;

    av_log(avctx, AV_LOG_DEBUG, "device = %s\n", fb_dec_ctx->dwl_init.dec_dev_name);
    av_log(avctx, AV_LOG_DEBUG, "priority = %d\n", fb_dec_ctx->dwl_init.priority);
    av_log(avctx, AV_LOG_DEBUG, "mem_id = %d\n", fb_dec_ctx->dwl_init.mem_id);
    av_log(avctx, AV_LOG_DEBUG, "client_type = %d\n", fb_dec_ctx->dwl_init.client_type);

#if defined(ERROR_TEST_DEC_EDMA_TRANS) || defined(ERROR_TEST_DEC_EDMA_TRANS)
    if(fb_dec_ctx->mem_err_test > 0)
    {
        av_log(avctx, AV_LOG_DEBUG, "fb_dec_ctx->mem_err_test = %d\n", fb_dec_ctx->mem_err_test);
        fb_dec_ctx->dwl_init.mem_err_test = fb_dec_ctx->mem_err_test;
    }
    else
        fb_dec_ctx->dwl_init.mem_err_test = 0;
#else
    fb_dec_ctx->dwl_init.mem_err_test = 0;
#endif

    fb_dec_ctx->dwl_inst = DWLInit(&fb_dec_ctx->dwl_init);
    if(fb_dec_ctx->dwl_inst == NULL) {
        av_log(avctx, AV_LOG_ERROR, "DWLInit# ERROR: DWL Init failed\n");
        goto error;
    } else {
        av_log(avctx, AV_LOG_DEBUG, "DWLInit#: DWL Init OK\n");
    }	

    /* Print API version number */
    dec_api = H264DecGetAPIVersion();
    dec_build = H264DecGetBuild(fb_dec_ctx->dwl_inst);
    n_cores = H264DecMCGetCoreCount(fb_dec_ctx->dwl_inst);
    av_log(avctx, AV_LOG_DEBUG, "\nX170 H.264 Decoder API v%d.%d - SW build: %d.%d - HW build: %x, %d cores\n\n",
    dec_api.major, dec_api.minor, dec_build.sw_build >>16,
    dec_build.sw_build & 0xFFFF, dec_build.hw_build, n_cores);
    prod_id = dec_build.hw_build >> 16;
    major_version = (dec_build.hw_build & 0xF000) >> 12;
    minor_version = (dec_build.hw_build & 0x0FF0) >> 4;

    /* number of stream buffers to allocate */
    fb_dec_ctx->allocated_buffers = n_cores + 1;


    if(fb_dec_ctx->tiled_output)   flags |= DEC_REF_FRM_TILED_DEFAULT;
    if(fb_dec_ctx->dpb_mode == DEC_DPB_INTERLACED_FIELD)
    flags |= DEC_DPB_ALLOW_FIELD_ORDERING;

    if (fb_dec_ctx->enable_mc) {
    mc_init_cfg.mc_enable = 1;
    //???  mc_init_cfg.stream_consumed_callback = StreamBufferConsumed;
    }
    ret = H264DecInit(&fb_dec_ctx->dec_inst,
    fb_dec_ctx->dwl_inst,
    DEC_NORMAL,
    0,
    DEC_EC_FAST_FREEZE,
    0, flags, 0, 
    0, 0, &mc_init_cfg);
    if(ret != DEC_OK) {
        av_log(avctx, AV_LOG_ERROR, "DECODER INITIALIZATION FAILED\n");
        goto error;
    } else {
        av_log(avctx, AV_LOG_DEBUG, "DECODER H264DecInit Init OK\n");
    } 	
    /* configure decoder to decode both views of MVC stereo high streams  */
    if (fb_dec_ctx->enable_mvc)
    H264DecSetMvc(fb_dec_ctx->dec_inst);
#if 0
    SetDecRegister(((decContainer_t *) fb_dec_ctx->dec_inst)->h264_regs, HWIF_DEC_LATENCY,
    fb_dec_ctx->latency_comp);
    SetDecRegister(((decContainer_t *) fb_dec_ctx->dec_inst)->h264_regs, HWIF_DEC_CLK_GATE_E,
    fb_dec_ctx->clock_gating);
    SetDecRegister(((decContainer_t *) fb_dec_ctx->dec_inst)->h264_regs, HWIF_DEC_OUT_ENDIAN,
    fb_dec_ctx->output_picture_endian);
    SetDecRegister(((decContainer_t *) fb_dec_ctx->dec_inst)->h264_regs, HWIF_DEC_MAX_BURST,
    fb_dec_ctx->bus_burst_length);
    SetDecRegister(((decContainer_t *) fb_dec_ctx->dec_inst)->h264_regs, HWIF_DEC_DATA_DISC_E,
    fb_dec_ctx->data_discard);
    SetDecRegister(((decContainer_t *) fb_dec_ctx->dec_inst)->h264_regs, HWIF_SERV_MERGE_DIS,
    fb_dec_ctx->service_merge_disable);
#endif
    if(fb_dec_ctx->rlc_mode) {
        /*Force the decoder into RLC mode */
        ((decContainer_t *) fb_dec_ctx->dec_inst)->force_rlc_mode = 1;
        ((decContainer_t *) fb_dec_ctx->dec_inst)->rlc_mode = 1;
        ((decContainer_t *) fb_dec_ctx->dec_inst)->try_vlc = 0;
    }

    if (fb_dec_ctx->enable_mc) 
    size = 4096*1165;
    else
    //size = fb_dec_ctx->max_strm_len;
    size = 1*1024*1024;

    for(i = 0; i < fb_dec_ctx->allocated_buffers; i++) {
        fb_dec_ctx->stream_mem[i].mem_type = DWL_MEM_TYPE_DPB;
        if(DWLMallocLinear(fb_dec_ctx->dwl_inst,
        size, fb_dec_ctx->stream_mem + i) != DWL_OK) {
            av_log(avctx, AV_LOG_ERROR, "UNABLE TO ALLOCATE STREAM BUFFER MEMORY\n");
            goto error;
        } else {			
            av_log(avctx, AV_LOG_DEBUG, "alloc memory for %d stream ,addr=0x%x, size is 0x%x OK\n",i,fb_dec_ctx->stream_mem[i].virtual_address,fb_dec_ctx->stream_mem[i].size);
        }
    }

#if 0
	av_log(avctx, AV_LOG_ERROR, "%s(%d), force error\n", __FUNCTION__, __LINE__);
	goto error;
#endif

    fb_dec_ctx->stream_mem_index = 0;
    fb_dec_ctx->pic_decode_number = 1;
    fb_dec_ctx->pic_display_number = 0;
    fb_dec_ctx->got_package_number = 0;
    fb_dec_ctx->prev_width = 0;
    fb_dec_ctx->prev_height = 0;

    struct HANTRODWL *dwl = (struct HANTRODWL *)fb_dec_ctx->dwl_inst;

    fb_dec_ctx->closed = 0;
    fb_dec_ctx->initialized = 1;

    av_log(avctx, AV_LOG_DEBUG, "fb_h264_decode_init OK !!\n");
    return 0;
error:
    
    hantro_decode_h264_close(avctx);
    return AVERROR_UNKNOWN;
}

static int hantro_decode_h264_decode_frame(AVCodecContext *avctx, void *data,
                             int *got_frame, AVPacket *avpkt)
{
    const uint8_t *buf = avpkt->data;
    int buf_size       = avpkt->size;
    HantroDecContext *fb_dec_ctx  = avctx->priv_data;
    AVFrame *out = ( AVFrame *)data;
    enum DecRet ret;
    int i,j;
    int nal_length;
    int total_nal_length = 0;


    fb_dec_ctx->picRdy = 0;
    
    if(avpkt == NULL)
    {

        av_log(avctx, AV_LOG_ERROR, "in hantro_decode_h264_encode_frame avpkt == NULL...\n");
        return 0;
        
    }
    av_log(avctx, AV_LOG_DEBUG, " begin fb_h264_decode_frame...  avpkt->size = %d,avpkt->side_data_elems=%d\n", avpkt->size,avpkt->side_data_elems);
    *got_frame = 0;
	if(avpkt->size > fb_dec_ctx->stream_mem[fb_dec_ctx->stream_mem_index].size)
	{
		av_log(avctx, AV_LOG_DEBUG, "avpkt->size is too large(%d > %d @%d), re-allocing... \n",avpkt->size,fb_dec_ctx->stream_mem[fb_dec_ctx->stream_mem_index].size,fb_dec_ctx->stream_mem_index);
		fb_dec_ctx->stream_mem[fb_dec_ctx->stream_mem_index].virtual_address = NULL;
		DWLFreeLinear(fb_dec_ctx->dwl_inst, &fb_dec_ctx->stream_mem[fb_dec_ctx->stream_mem_index]);
		//alloc again
		av_log(avctx, AV_LOG_DEBUG, "alloc again(%d), re-allocing... \n",avpkt->size);
		fb_dec_ctx->stream_mem[fb_dec_ctx->stream_mem_index].mem_type = DWL_MEM_TYPE_DPB;
        if(DWLMallocLinear(fb_dec_ctx->dwl_inst, avpkt->size, fb_dec_ctx->stream_mem + fb_dec_ctx->stream_mem_index) != DWL_OK) {
            av_log(avctx, AV_LOG_ERROR, "UNABLE TO ALLOCATE STREAM BUFFER MEMORY\n");
            H264DecEndOfStream(fb_dec_ctx->dec_inst,1);
            goto err_exit;
        }
		else
			av_log(avctx, AV_LOG_DEBUG, "after alloc size=%d @%d, re-allocing... \n",fb_dec_ctx->stream_mem[fb_dec_ctx->stream_mem_index].size,fb_dec_ctx->stream_mem_index);
	}
    if((avpkt->size == 0) ||(fb_dec_ctx->eos_flush == 1))
    {
        av_log(avctx, AV_LOG_DEBUG, " befor H264DecEndOfStream  EOS... \n");
        H264DecEndOfStream(fb_dec_ctx->dec_inst,1);
        av_log(avctx, AV_LOG_DEBUG, " after H264DecEndOfStream  EOS... \n");

        ret = H264NextPicture(fb_dec_ctx->dec_inst,&fb_dec_ctx->pic);
        av_log(avctx, AV_LOG_DEBUG, "Vp9NextPicture ret %d\n",ret);
        if(ret == DEC_PIC_RDY) {
    
            for (i = 0; i < DEC_MAX_OUT_COUNT; i++) {
                av_log(avctx, AV_LOG_DEBUG, "DEC_PIC_RDY pic %d -> %d x %d\n",i,fb_dec_ctx->pic.pictures[i].pic_width,fb_dec_ctx->pic.pictures[i].pic_height);
            }
            fb_dec_ctx->picRdy = 1;
            if(hantro_dec_output_frame(avctx,out,&fb_dec_ctx->pic)) goto err_exit;
            *got_frame = fb_dec_ctx->picRdy;

            if(*got_frame == 1)
            {
                fb_dec_ctx->picRdy = 0;
                fb_dec_ctx->pic_display_number++;
                av_log(avctx, AV_LOG_DEBUG, "******** %d got frame :data[0]=%p,data[1]=%p buf[0]=%p,buf[1]=%p \n",fb_dec_ctx->pic_display_number,out->data[0],out->data[1],out->buf[0],out->buf[1]);

            }

            return 1;
        } else if(ret == DEC_END_OF_STREAM) {
            //fb_dec_ctx->last_pic_flag = 1;
            av_log(avctx, AV_LOG_DEBUG, "END-OF-STREAM received in output thread\n");
            //fb_dec_ctx->add_buffer_thread_run = 0;
            return 0;
        } else if(ret < 0) {
            goto err_exit;
        }
        return 0;
    }

    fb_dec_ctx->got_package_number++;


    if(hantro_send_avpkt_to_decode_buffer(avctx,avpkt,fb_dec_ctx->stream_mem[fb_dec_ctx->stream_mem_index])) goto err_exit;
    fb_dec_ctx->stream_mem[fb_dec_ctx->stream_mem_index].virtual_address = avpkt->data;
    fb_dec_ctx->h264_dec_input.stream = fb_dec_ctx->stream_mem[fb_dec_ctx->stream_mem_index].virtual_address;
  	fb_dec_ctx->h264_dec_input.stream_bus_address = fb_dec_ctx->stream_mem[fb_dec_ctx->stream_mem_index].bus_address;
    fb_dec_ctx->h264_dec_input.data_len = avpkt->size;
//    fb_dec_ctx->h264_dec_input.buffer_len = avpkt->size;

	if (hantro_dec_set_pts_dts(fb_dec_ctx, avpkt) < 0) {
        av_log(avctx, AV_LOG_ERROR, "ERROR: hantro_dec_set_pts_dts!\n");
        goto err_exit;
	}

    if (fb_dec_ctx->enc_type != HANTRO_ENC_NONE) {
        if (hantro_check_buffer_number_for_trans(fb_dec_ctx) < 0)
            goto err_exit;
    }

    do{
        fb_dec_ctx->h264_dec_input.pic_id = fb_dec_ctx->pic_decode_number;

        //av_log(avctx, AV_LOG_TRACE, "fb_dec_ctx->h264_dec_input.data_len = %d\n", fb_dec_ctx->h264_dec_input.data_len);
        ret = H264DecDecode(fb_dec_ctx->dec_inst, &fb_dec_ctx->h264_dec_input, &fb_dec_ctx->h264_dec_output);

        printDecodeReturn(avctx,ret);
        switch (ret) {
        case DEC_STREAM_NOT_SUPPORTED: {
            av_log(avctx, AV_LOG_ERROR, "ERROR: UNSUPPORTED STREAM!\n");
            goto err_exit;
        }
        case DEC_HDRS_RDY: {
            //struct H264DecConfig fb_dec_ctx->h264_dec_cfg;
            //H264DecInfo fb_dec_ctx->h264_dec_info;
#ifdef DPB_REALLOC_DISABLE
            if(fb_dec_ctx->hdrs_rdy) {
                av_log(avctx, AV_LOG_DEBUG, "Decoding ended, flush the DPB\n");
                /* the err_exit of stream is not reached yet */
                H264DecEndOfStream(fb_dec_ctx->dec_inst, 0);
            }
#endif
            //save_flag = 0;
            /* Set a flag to indicate that headers are ready */
            fb_dec_ctx->hdrs_rdy = 1;
/*
            TBSetRefbuMemModel( &fb_dec_ctx->tb_cfg,
                  ((decContainer_t *) fb_dec_ctx->dec_inst)->h264_regs,
                  &((decContainer_t *) fb_dec_ctx->dec_inst)->ref_buffer_ctrl );
*/
            /* Stream headers were successfully decoded
            * -> stream information is available for query now */

            START_SW_PERFORMANCE;
            //fb_dec_ctx->rv = H264DecGetInfo(fb_dec_ctx->dec_inst, &fb_dec_ctx->h264_dec_info);
            fb_dec_ctx->rv = fb_dec_ctx->hantro_dec_wrapper.GetInfo(fb_dec_ctx->dec_inst,&fb_dec_ctx->sequence_info);
            
            END_SW_PERFORMANCE;
            if(fb_dec_ctx->rv != DEC_OK) {
                av_log(avctx, AV_LOG_ERROR, "ERROR in getting stream info!\n");
                goto err_exit;
            }
#if 1
            av_log(avctx, AV_LOG_DEBUG, "Width %d Height %d\n",
            fb_dec_ctx->sequence_info.pic_width, fb_dec_ctx->sequence_info.pic_height);

            av_log(avctx, AV_LOG_DEBUG, "Cropping params: (%d, %d) %dx%d\n",
            fb_dec_ctx->sequence_info.crop_params.crop_left_offset,
            fb_dec_ctx->sequence_info.crop_params.crop_top_offset,
            fb_dec_ctx->sequence_info.crop_params.crop_out_width,
            fb_dec_ctx->sequence_info.crop_params.crop_out_height);

            av_log(avctx, AV_LOG_DEBUG, "MonoChrome = %d\n", fb_dec_ctx->sequence_info.is_mono_chrome);
            av_log(avctx, AV_LOG_DEBUG, "Interlaced = %d\n", fb_dec_ctx->sequence_info.is_interlaced);
            av_log(avctx, AV_LOG_DEBUG, "num_of_ref_frames = %d\n", fb_dec_ctx->sequence_info.num_of_ref_frames);
            if((fb_dec_ctx->sequence_info.bit_depth_chroma > 8) ||(fb_dec_ctx->sequence_info.bit_depth_luma > 8)) {
            av_log(avctx, AV_LOG_ERROR, "NOT support bit depth is 10bit for H.264!!!\n");
            goto err_exit;
      }
            
            if(fb_dec_ctx->sequence_info.is_mono_chrome == 1) {
                av_log(avctx, AV_LOG_ERROR, "NOT support mono chrome handle as error!!!\n");
                goto err_exit;
            }
           // if (fb_dec_ctx->h264_dec_info.interlaced_sequence)
           // fb_dec_ctx->force_to_single_core = 1;
#endif
#ifdef ALWAYS_OUTPUT_REF
            H264DecUseExtraFrmBuffers(fb_dec_ctx->dec_inst, fb_dec_ctx->use_extra_buffers_num);
#endif

            
#if 0
            fb_dec_ctx->h264_dec_cfg.error_conceal = fb_dec_ctx->error_conceal;
            fb_dec_ctx->h264_dec_cfg.decoder_mode = fb_dec_ctx->low_latency ? DEC_LOW_LATENCY :
                       fb_dec_ctx->low_latency_sim ? DEC_LOW_LATENCY_RTL : DEC_NORMAL;
            fb_dec_ctx->h264_dec_cfg.align = fb_dec_ctx->align;
            /*
            if (fb_dec_ctx->align == DEC_ALIGN_1B)
            fb_dec_ctx->h264_dec_cfg.align = DEC_ALIGN_64B;
            */
            fb_dec_ctx->h264_dec_cfg.align = DEC_ALIGN_1024B;
            //fb_dec_ctx->rv = H264DecSetInfo(fb_dec_ctx->dec_inst, &fb_dec_ctx->h264_dec_cfg);
#endif            
            if(HantroDecModifyConfigBySeqeuenceInfo(avctx)) goto err_exit;
            fb_dec_ctx->rv = fb_dec_ctx->hantro_dec_wrapper.SetInfo(fb_dec_ctx->dec_inst,fb_dec_ctx->hantro_dec_config,&fb_dec_ctx->sequence_info);
            
            if (fb_dec_ctx->rv != DEC_OK) {
                av_log(avctx, AV_LOG_ERROR, "Invalid pp parameters\n");
                goto err_exit;
            }
#if 0
            if(fb_dec_ctx->h264_dec_info.output_format == DEC_OUT_FRM_TILED_4X4)
            av_log(avctx, AV_LOG_DEBUG, "Output format = DEC_OUT_FRM_TILED_4X4\n");
            else if(fb_dec_ctx->h264_dec_info.output_format == DEC_OUT_FRM_MONOCHROME)
            av_log(avctx, AV_LOG_DEBUG, "Output format = DEC_OUT_FRM_MONOCHROME\n");
            else
            av_log(avctx, AV_LOG_DEBUG, "Output format = DEC_OUT_FRM_RASTER_SCAN\n");
#endif  
#if 0
            if((fb_dec_ctx->h264_dec_info.pic_buff_size != fb_dec_ctx->min_buffer_num) ||
            (fb_dec_ctx->h264_dec_info.pic_width * fb_dec_ctx->h264_dec_info.pic_height != fb_dec_ctx->prev_width * fb_dec_ctx->prev_height)) {
                /* Reset buffers added and stop adding extra buffers when a new header comes. */
                if(fb_dec_ctx->pp_enabled)
                    fb_dec_ctx->res_changed = 1;
                else {
                    fb_dec_ctx->add_extra_flag = 0;
                    fb_h264_release_ext_buffers(fb_dec_ctx);
                    fb_dec_ctx->buffer_release_flag = 1;
                    fb_dec_ctx->num_buffers = 0;
                }
            }
            fb_dec_ctx->prev_width = fb_dec_ctx->h264_dec_info.pic_width;
            fb_dec_ctx->prev_height = fb_dec_ctx->h264_dec_info.pic_height;
            fb_dec_ctx->min_buffer_num = fb_dec_ctx->h264_dec_info.pic_buff_size;
            fb_dec_ctx->dpb_mode = fb_dec_ctx->h264_dec_info.dpb_mode;

            /* release the old temp image buffer if exists */
            if(fb_dec_ctx->tmp_image)
                free(fb_dec_ctx->tmp_image);

            /* check if we do need to crop */
            if(fb_dec_ctx->h264_dec_info.crop_params.crop_left_offset == 0 &&
            fb_dec_ctx->h264_dec_info.crop_params.crop_top_offset == 0 &&
            fb_dec_ctx->h264_dec_info.crop_params.crop_out_width == fb_dec_ctx->h264_dec_info.pic_width &&
            fb_dec_ctx->h264_dec_info.crop_params.crop_out_height == fb_dec_ctx->h264_dec_info.pic_height ) {
                fb_dec_ctx->crop_display = 0;
            }

            if(fb_dec_ctx->crop_display) {
                /* Cropped frame size in planar YUV 4:2:0 */
                fb_dec_ctx->pic_size = fb_dec_ctx->h264_dec_info.crop_params.crop_out_width *
                fb_dec_ctx->h264_dec_info.crop_params.crop_out_height;
                if(!fb_dec_ctx->h264_dec_info.mono_chrome)
                    fb_dec_ctx->pic_size = (3 * fb_dec_ctx->pic_size) / 2;
                fb_dec_ctx->tmp_image = malloc(fb_dec_ctx->pic_size);
                if(fb_dec_ctx->tmp_image == NULL) {
                    av_log(avctx, AV_LOG_ERROR, "ERROR in allocating cropped image!\n");
                    return -1;
                }
            } else {
                /* Decoder output frame size in planar YUV 4:2:0 */
                if (fb_dec_ctx->scale_enabled && fb_dec_ctx->scale_mode == FLEXIBLE_SCALE) {
                    fb_dec_ctx->pic_size = ((fb_dec_ctx->scaled_w + 15) & ~15) * fb_dec_ctx->scaled_h;
                } else {
                    fb_dec_ctx->pic_size = fb_dec_ctx->h264_dec_info.pic_width * fb_dec_ctx->h264_dec_info.pic_height;
                }
                if(!fb_dec_ctx->h264_dec_info.mono_chrome)
                    fb_dec_ctx->pic_size = (3 * fb_dec_ctx->pic_size) / 2;
                if (fb_dec_ctx->use_peek_output)
                    fb_dec_ctx->tmp_image = malloc(fb_dec_ctx->pic_size);
            }

            av_log(avctx, AV_LOG_DEBUG, "video_range %d, matrix_coefficients %d\n",
            fb_dec_ctx->h264_dec_info.video_range, fb_dec_ctx->h264_dec_info.matrix_coefficients);
#endif

            break;
        }
        case DEC_ADVANCED_TOOLS: {

            if (fb_dec_ctx->enable_mc) {
                /* ASO/FMO detected and not supported in multicore mode */
                av_log(avctx, AV_LOG_DEBUG, "ASO/FMO detected in multicore, decoding will stop\n");
                return -1;
            }
            /* ASO/STREAM ERROR was noticed in the stream. The decoder has to
            * reallocate resources */
            assert(fb_dec_ctx->h264_dec_output.data_left); /* we should have some data left *//* Used to indicate that picture decoding needs to finalized prior to corrupting next picture */

            /* Used to indicate that picture decoding needs to finalized prior to corrupting next picture
            * pic_rdy = 0; */
#ifdef LOW_LATENCY_FRAME_MODE
            if(fb_dec_ctx->low_latency) {
                fb_dec_ctx->process_end_flag = 1;
                //pic_decoded = 1;
                // sem_post(&next_frame_start_sem);
                // wait_for_task_completion(task);
                fb_dec_ctx->h264_dec_input.data_len = 0;
                //task_has_freed = 1;
            }
#endif
            break;
        }
        case DEC_PENDING_FLUSH:
        //eos = 1;
        
		av_log(avctx, AV_LOG_ERROR, "case DEC_PENDING_FLUSH fb_dec_ctx->h264_dec_output.data_left=%d\n",fb_dec_ctx->h264_dec_output.data_left );
		H264DecEndOfStream(fb_dec_ctx->dec_inst,1);
		fb_dec_ctx->eos_flush = 1;
		goto h264nextpic;
		case DEC_PIC_DECODED:
            /* case DEC_FREEZED_PIC_RDY: */
            /* Picture is now ready */
            fb_dec_ctx->pic_rdy = 1;
            fb_dec_ctx->h264_dec_output.data_left = 0;

            /*lint -esym(644,tmp_image,pic_size) variable initialized at
            * DEC_HDRS_RDY_BUFF_NOT_EMPTY case */

            if (ret == DEC_PIC_DECODED) {
                /* If enough pictures decoded -> force decoding to err_exit
                * by setting that no more stream is available */
                if(fb_dec_ctx->pic_decode_number == fb_dec_ctx->max_num_pics) {
                    fb_dec_ctx->process_end_flag = 1;
                    fb_dec_ctx->h264_dec_input.data_len = 0;
                }

                av_log(avctx, AV_LOG_DEBUG, "DECODED PICTURE %d\n", fb_dec_ctx->pic_decode_number);
                /* Increment decoding number for every decoded picture */
                fb_dec_ctx->pic_decode_number++;
            }

        break;

        case DEC_STRM_PROCESSED:
        case DEC_BUF_EMPTY:
        case DEC_NONREF_PIC_SKIPPED:
        case DEC_NO_DECODING_BUFFER:
        case DEC_STRM_ERROR: {
        /* Used to indicate that picture decoding needs to finalized prior to corrupting next picture
        * pic_rdy = 0; */
usleep(10);
        break;
        }

        case DEC_WAITING_FOR_BUFFER: {
            av_log(avctx, AV_LOG_DEBUG, "Waiting for frame buffers\n");
#if 0
            struct DWLLinearMem mem,mem_ext;
            int alloc_buffer_num;

            fb_dec_ctx->rv = H264DecGetBufferInfo(fb_dec_ctx->dec_inst, &fb_dec_ctx->h264_hbuf);
            av_log(avctx, AV_LOG_DEBUG, "H264DecGetBufferInfo ret %d\n", fb_dec_ctx->rv);
            av_log(avctx, AV_LOG_DEBUG, "buf_to_free %p, next_buf_size %d, buf_num %d\n",
            (void *)fb_dec_ctx->h264_hbuf.buf_to_free.virtual_address, fb_dec_ctx->h264_hbuf.next_buf_size, fb_dec_ctx->h264_hbuf.buf_num);

            if (fb_dec_ctx->h264_hbuf.buf_to_free.virtual_address != NULL && fb_dec_ctx->res_changed) {
                fb_dec_ctx->add_extra_flag = 0;
                fb_h264_release_ext_buffers(fb_dec_ctx);
                fb_dec_ctx->buffer_release_flag = 1;
                fb_dec_ctx->num_buffers = 0;
                fb_dec_ctx->res_changed = 0;
            }

            fb_dec_ctx->buffer_size = fb_dec_ctx->h264_hbuf.next_buf_size;
            if(fb_dec_ctx->buffer_release_flag && fb_dec_ctx->h264_hbuf.next_buf_size) {
            /* Only add minimum required buffers at first. */
            //extra_buffer_num = fb_dec_ctx->h264_hbuf.buf_num - min_buffer_num;
#ifdef ALWAYS_OUTPUT_REF
            alloc_buffer_num = fb_dec_ctx->h264_hbuf.buf_num;
#else
            alloc_buffer_num = fb_dec_ctx->h264_hbuf.buf_num + fb_dec_ctx->use_extra_buffers_num;
#endif

            for(i=0; i<alloc_buffer_num; i++) {
                mem.mem_type = DWL_MEM_TYPE_DPB;
                if (fb_dec_ctx->pp_enabled)
                    ret = DWLMallocLinear(fb_dec_ctx->dwl_inst, fb_dec_ctx->h264_hbuf.next_buf_size, &mem);
                else
                    ret = DWLMallocRefFrm(fb_dec_ctx->dwl_inst, fb_dec_ctx->h264_hbuf.next_buf_size, &mem);
                if(ret) 
                {
                    fb_dec_ctx->num_buffers = i;
                    goto err_exit;
                }
                mem_ext = mem;
                //memset(mem.virtual_address, 0x00,mem.size);
                fb_dec_ctx->rv = H264DecAddBuffer(fb_dec_ctx->dec_inst, &mem);
                if(fb_dec_ctx->rv != DEC_OK && fb_dec_ctx->rv != DEC_WAITING_FOR_BUFFER) {
                    if (fb_dec_ctx->pp_enabled)
                    DWLFreeLinear(fb_dec_ctx->dwl_inst, &mem);
                    else
                    DWLFreeRefFrm(fb_dec_ctx->dwl_inst, &mem);
                } else {
                    fb_dec_ctx->ext_buffers[i] = mem_ext;
                }
            }
                /* Extra buffers are allowed when minimum required buffers have been added.*/
                fb_dec_ctx->num_buffers = alloc_buffer_num;
                fb_dec_ctx->add_extra_flag = 1;
            }
#else
            if (hantro_check_buffer_number_for_trans(fb_dec_ctx) < 0)
                goto err_exit;
#endif
            break;
        }
        case DEC_OK:
        /* nothing to do, just call again */
        break;
        case DEC_HW_TIMEOUT:
            av_log(avctx, AV_LOG_ERROR, "Timeout\n");
            goto err_exit;
        case DEC_ABORTED:
            av_log(avctx, AV_LOG_ERROR, "H264 decoder is aborted: %d\n", ret);
            H264DecAbortAfter(fb_dec_ctx->dec_inst);
            goto err_exit;
        case DEC_MEMFAIL:
        case DEC_SYSTEM_ERROR:
        case DEC_FATAL_SYSTEM_ERROR:
            fb_h264_handle_fatal_error();
            H264DecEndOfStream(fb_dec_ctx->dec_inst,1);
            goto err_exit;
        default:
            av_log(avctx, AV_LOG_ERROR, "FATAL ERROR: %d\n", ret);
            goto err_exit;
        }

        fb_dec_ctx->h264_dec_input.stream = fb_dec_ctx->h264_dec_output.strm_curr_pos;
        fb_dec_ctx->h264_dec_input.stream_bus_address = fb_dec_ctx->h264_dec_output.strm_curr_bus_address;
        fb_dec_ctx->h264_dec_input.data_len = fb_dec_ctx->h264_dec_output.data_left;

    }while(fb_dec_ctx->h264_dec_output.data_left);
h264nextpic:
    ret = H264NextPicture(fb_dec_ctx->dec_inst,&fb_dec_ctx->pic);
    av_log(avctx, AV_LOG_DEBUG, "H264NextPicture ret = %d\n", ret);
    if(ret)
    {
        av_log(avctx, AV_LOG_DEBUG, "H264NextPicture: %d\n", ret);
        printDecodeReturn(avctx,ret);
    }
    if(ret == DEC_PIC_RDY) {
        fb_dec_ctx->picRdy = 1;
        fb_dec_ctx->pts = avpkt->pts;
        fb_dec_ctx->pkt_dts = avpkt->dts;
        if(hantro_dec_output_frame(avctx,out,&fb_dec_ctx->pic)) goto err_exit;
        
    } else if(ret == DEC_END_OF_STREAM) {
        //fb_dec_ctx->last_pic_flag = 1;
        av_log(avctx, AV_LOG_DEBUG, "END-OF-STREAM received\n");
        //fb_dec_ctx->add_buffer_thread_run = 0;
        return 0;
    } else if(ret < 0) {
        goto err_exit;
    }

    *got_frame = fb_dec_ctx->picRdy;

    if(*got_frame == 1)
    {
        fb_dec_ctx->picRdy = 0;
        fb_dec_ctx->pic_display_number++;
        av_log(avctx, AV_LOG_DEBUG, "******** %d got frame :data[0]=%p,data[1]=%p buf[0]=%p,buf[1]=%p \n",
            fb_dec_ctx->pic_display_number,out->data[0],out->data[1],out->buf[0],out->buf[1]);
    }

end:
    fb_dec_ctx->stream_mem_index++;
    if(fb_dec_ctx->stream_mem_index == fb_dec_ctx->allocated_buffers)
        fb_dec_ctx->stream_mem_index = 0;

    av_log(avctx, AV_LOG_DEBUG, "in h264_decode_frame return:avpkt->size = %d.........\n",avpkt->size);

	return avpkt->size;
err_exit:		
    av_log(avctx, AV_LOG_ERROR, "error !!! err_exit of h264_decode_frame...  \n");
    return AVERROR_EOF;
}

static av_cold int hantro_decode_h264_close(AVCodecContext *avctx)
{    
    HantroDecContext *fb_dec_ctx  = avctx->priv_data;
    int i;
    
    av_log(avctx, AV_LOG_DEBUG, "%s(%d)\n", __FUNCTION__, __LINE__);
#if 0
    if(fb_dec_ctx->initialized == 0)
    {
        av_log(avctx, AV_LOG_DEBUG, "fb_dec_ctx->initialized=%d, no inited... \n",fb_dec_ctx->initialized);
        return 0;
    }
#endif
	if(fb_dec_ctx->closed == 1)
		return 0;
    fb_dec_ctx->closed = 1;
    av_log(avctx, AV_LOG_DEBUG, "fb_h264_decode_end..... \n");
//   FreeDecPicWaitConsumeList(fb_dec_ctx);
    
    for(i = 0; i < fb_dec_ctx->allocated_buffers; i++) {
        if(fb_dec_ctx->stream_mem[i].mem_type == DWL_MEM_TYPE_DPB)
            fb_dec_ctx->stream_mem[i].virtual_address = NULL;
        if( fb_dec_ctx->dec_inst)
            DWLFreeLinear(fb_dec_ctx->dwl_inst, & fb_dec_ctx->stream_mem[i]);
    }

    
    if(fb_dec_ctx->pic_display_number > 0)
        hantro_dec_performance_report(avctx);
    if(fb_dec_ctx->dec_inst)
        H264DecRelease(fb_dec_ctx->dec_inst);
    //ReleaseExtBuffers(avctx);
    hantro_dec_release_ext_buffers(fb_dec_ctx);
    if(fb_dec_ctx->dwl_inst)
        DWLRelease(fb_dec_ctx->dwl_inst);
    
    av_buffer_unref(&fb_dec_ctx->hwframe);
    av_buffer_unref(&fb_dec_ctx->hwdevice);
    fb_dec_ctx->initialized = 0;
    return 0;
}

#if 0
#define OFFSET(x) offsetof(HantroDecContext, x)
#define VD AV_OPT_FLAG_VIDEO_PARAM | AV_OPT_FLAG_DECODING_PARAM
static const AVOption hantro_decode_options[] = {
    { "pp_set", "set pp configure", OFFSET(pp_setting), AV_OPT_TYPE_STRING, {.str=""}, 0, 0, VD },
    { "dev_name", "set device name", OFFSET(dev_name), AV_OPT_TYPE_STRING, {.str="/dev/transcoder0"}, 0, 0, VD },
//    { "disable-dec400", "disable DEC400 compress function", OFFSET(disable_dec400), AV_OPT_TYPE_INT, {.i64 = 0}, 0, 1, VD },
    { "enc-format", "give the target format in encode, h264 hevc or vp9", OFFSET(enc_format), AV_OPT_TYPE_STRING, {.str=""}, 0, 0, VD },
    { "buffer-depth", "bufffer depth for transcode", OFFSET(buffer_depth), AV_OPT_TYPE_INT, {.i64 = 0}, 0, 40, VD },
    { NULL },
};
#endif

static const AVClass hantro_decode_h264_class = {
    .class_name = "h264d_hantro",
    .item_name  = av_default_item_name,
    .option     = hantro_decode_options,
    .version    = LIBAVUTIL_VERSION_INT,
};

static const AVCodecDefault hantro_decode_h264_defaults[] = {
    { NULL },
};

static const AVCodecHWConfigInternal *hantro_hw_configs[] = {
    &(const AVCodecHWConfigInternal) {
        .public = {
            .pix_fmt     = AV_PIX_FMT_HANTRO,
            .methods     = AV_CODEC_HW_CONFIG_METHOD_HW_DEVICE_CTX |
                           AV_CODEC_HW_CONFIG_METHOD_HW_FRAMES_CTX |
                           AV_CODEC_HW_CONFIG_METHOD_INTERNAL,
            .device_type = AV_HWDEVICE_TYPE_HANTRO,
        },
        .hwaccel = NULL,
    },
    NULL
};

AVCodec ff_h264_hantro_decoder = {
    .name           = "h264dec_hantro",
    .long_name      = NULL_IF_CONFIG_SMALL("H264 (HANTRO VC8000D)"),
    .type           = AVMEDIA_TYPE_VIDEO,
    .id             = AV_CODEC_ID_H264,
    .priv_data_size = sizeof(HantroDecContext),
    .init           = &hantro_decode_h264_init,
    .decode        = &hantro_decode_h264_decode_frame,
    .close          = &hantro_decode_h264_close,
    .priv_class     = &hantro_decode_h264_class,
    .capabilities   = AV_CODEC_CAP_DELAY | AV_CODEC_CAP_HARDWARE | AV_CODEC_CAP_AVOID_PROBING,
    .defaults       = hantro_decode_h264_defaults,
    .pix_fmts       = (const enum AVPixelFormat[]) {
        AV_PIX_FMT_HANTRO,
        AV_PIX_FMT_YUV420P,
        AV_PIX_FMT_NONE
  	},
  	.hw_configs         = &hantro_hw_configs,
    .wrapper_name   = "hantro",
    .bsfs           = "h264_mp4toannexb",
};

