/*------------------------------------------------------------------------------
--                                                                                                                               --
--       This software is confidential and proprietary and may be used                                   --
--        only as expressly authorized by a licensing agreement from                                     --
--                                                                                                                               --
--                            Verisilicon.                                                                                    --
--                                                                                                                               --
--                   (C) COPYRIGHT 2014 VERISILICON                                                            --
--                            ALL RIGHTS RESERVED                                                                    --
--                                                                                                                               --
--                 The entire notice above must be reproduced                                                 --
--                  on all copies and should not be removed.                                                    --
--                                                                                                                               --
--------------------------------------------------------------------------------*/


#ifndef AVCODEC_HANTRO_ENC_OPTIONS_H
#define AVCODEC_HANTRO_ENC_OPTIONS_H

#define MAX_BPS_ADJUST 20
#define MAX_STREAMS 16
#define MAX_SCENE_CHANGE 20

typedef struct HANTROH26xEncOptions {
  i32 outputRateNumer;      /* Output frame rate numerator */
  i32 outputRateDenom;      /* Output frame rate denominator */
  i32 inputRateNumer;      /* Input frame rate numerator */
  i32 inputRateDenom;      /* Input frame rate denominator */
  i32 firstPic;
  i32 lastPic;

  i32 width;
  i32 height;
  i32 lumWidthSrc;
  i32 lumHeightSrc;

  // for 1/4 resolution first pass, for disable rfc datapath, horOffsetSrc and verOffsetSrc should be 0, so not need ds params
  i32 width_ds;
  i32 height_ds;
  i32 lumWidthSrc_ds;
  i32 lumHeightSrc_ds;
  i32 inputFormat_ds;

  i32 inputFormat;
  i32 formatCustomizedType;     /*change general format to customized one*/

  i32 picture_cnt;
  i32 byteStream;


  i32 max_cu_size;    /* Max coding unit size in pixels */
  i32 min_cu_size;    /* Min coding unit size in pixels */
  i32 max_tr_size;    /* Max transform size in pixels */
  i32 min_tr_size;    /* Min transform size in pixels */
  i32 tr_depth_intra;   /* Max transform hierarchy depth */
  i32 tr_depth_inter;   /* Max transform hierarchy depth */
  VCEncVideoCodecFormat codecFormat;     /* Video Codec Format: HEVC/H264/AV1 */

  i32 min_qp_size;

  i32 enableCabac;      /* [0,1] H.264 entropy coding mode, 0 for CAVLC, 1 for CABAC */
  i32 cabacInitFlag;

  // intra setup
  u32 strong_intra_smoothing_enabled_flag;

  i32 cirStart;
  i32 cirInterval;

  i32 intraAreaEnable;
  i32 intraAreaLeft;
  i32 intraAreaTop;
  i32 intraAreaRight;
  i32 intraAreaBottom;

  i32 pcm_loop_filter_disabled_flag;  
  
  i32 ipcm1AreaLeft;
  i32 ipcm1AreaTop;
  i32 ipcm1AreaRight;
  i32 ipcm1AreaBottom;

  i32 ipcm2AreaLeft;
  i32 ipcm2AreaTop;
  i32 ipcm2AreaRight;
  i32 ipcm2AreaBottom;
  i32 ipcmMapEnable;
  char *ipcmMapFile;

  char *skipMapFile;
  i32 skipMapEnable;
  i32 skipMapBlockUnit;

  i32 roi1AreaEnable;
  i32 roi2AreaEnable;
  i32 roi3AreaEnable;
  i32 roi4AreaEnable;
  i32 roi5AreaEnable;
  i32 roi6AreaEnable;
  i32 roi7AreaEnable;
  i32 roi8AreaEnable;

  i32 roi1AreaTop;
  i32 roi1AreaLeft;
  i32 roi1AreaBottom;
  i32 roi1AreaRight;

  i32 roi2AreaTop;
  i32 roi2AreaLeft;
  i32 roi2AreaBottom;
  i32 roi2AreaRight;

  i32 roi1DeltaQp;
  i32 roi2DeltaQp;
  i32 roi1Qp;
  i32 roi2Qp;

  i32 roi3AreaTop;
  i32 roi3AreaLeft;
  i32 roi3AreaBottom;
  i32 roi3AreaRight;
  i32 roi3DeltaQp;
  i32 roi3Qp;

  i32 roi4AreaTop;
  i32 roi4AreaLeft;
  i32 roi4AreaBottom;
  i32 roi4AreaRight;
  i32 roi4DeltaQp;
  i32 roi4Qp;

  i32 roi5AreaTop;
  i32 roi5AreaLeft;
  i32 roi5AreaBottom;
  i32 roi5AreaRight;
  i32 roi5DeltaQp;
  i32 roi5Qp;

  i32 roi6AreaTop;
  i32 roi6AreaLeft;
  i32 roi6AreaBottom;
  i32 roi6AreaRight;
  i32 roi6DeltaQp;
  i32 roi6Qp;

  i32 roi7AreaTop;
  i32 roi7AreaLeft;
  i32 roi7AreaBottom;
  i32 roi7AreaRight;
  i32 roi7DeltaQp;
  i32 roi7Qp;

  i32 roi8AreaTop;
  i32 roi8AreaLeft;
  i32 roi8AreaBottom;
  i32 roi8AreaRight;
  i32 roi8DeltaQp;
  i32 roi8Qp;

  /* Rate control parameters */
  i32 hrdConformance;
  i32 cpbSize;
  i32 intraPicRate;   /* IDR interval */

  i32 vbr; /* Variable Bit Rate Control by qpMin */
  i32 qpHdr;
  i32 qpMin;
  i32 qpMax;
  i32 qpMinI;
  i32 qpMaxI;
  i32 bitPerSecond;
  i32 crf; /*CRF constant*/
  
  i32 bitVarRangeI;

  i32 bitVarRangeP;

  i32 bitVarRangeB;
  u32 u32StaticSceneIbitPercent;

  i32 tolMovingBitRate;/*tolerance of max Moving bit rate */
  i32 monitorFrames;/*monitor frame length for moving bit rate*/
  i32 picRc;
  i32 ctbRc;
  i32 blockRCSize;
  u32 rcQpDeltaRange;
  u32 rcBaseMBComplexity;
  i32 picSkip;
  i32 picQpDeltaMin;
  i32 picQpDeltaMax;
  i32 ctbRcRowQpStep;

  float tolCtbRcInter;
  float tolCtbRcIntra;

  i32 bitrateWindow;
  i32 intraQpDelta;
  i32 fixedIntraQp;
  i32 bFrameQpDelta;

  i32 disableDeblocking;

  i32 enableSao;


  i32 tc_Offset;
  i32 beta_Offset;


  i32 chromaQpOffset;

  i32 profile;              /*main profile or main still picture profile*/
  i32 tier;               /*main tier or high tier*/
  i32 level;              /*main profile level*/

  i32 bpsAdjustFrame[MAX_BPS_ADJUST];
  i32 bpsAdjustBitrate[MAX_BPS_ADJUST];
  i32 smoothPsnrInGOP;

  i32 sliceSize;

  i32 testId;

  i32 rotation;
  i32 mirror;
  i32 horOffsetSrc;
  i32 verOffsetSrc;
  i32 colorConversion;
  i32 scaledWidth;
  i32 scaledHeight;
  i32 scaledOutputFormat;

  i32 enableDeblockOverride;
  i32 deblockOverride;

  i32 enableScalingList;

  u32 compressor;

  i32 interlacedFrame;
  i32 fieldOrder;
  i32 videoRange;
  i32 ssim;
  i32 sei;
  char *userData;
  u32 gopSize;
  char *gopCfg;
  u32 gopLowdelay;
  i32 outReconFrame;
  u32 longTermGap;
  u32 longTermGapOffset;
  u32 ltrInterval;
  i32 longTermQpDelta;
  
  i32 gdrDuration;
  u32 roiMapDeltaQpBlockUnit;
  u32 roiMapDeltaQpEnable;
  char *roiMapDeltaQpFile;
  char *roiMapDeltaQpBinFile;
  char *roiMapInfoBinFile;
  char *RoimapCuCtrlInfoBinFile;
  char *RoimapCuCtrlIndexBinFile;
  u32 RoiCuCtrlVer;
  u32 RoiQpDeltaVer;
  i32 outBufSizeMax;
  i32 multimode;  // Multi-stream mode, 0--disable, 1--mult-thread, 2--multi-process
  char *streamcfg[MAX_STREAMS];
  i32 outfile_format; //0->hevc, 1->h264, 2->vp9

  //WIENER_DENOISE
  i32 noiseReductionEnable;
  i32 noiseLow;
  i32 firstFrameSigma;

  i32 bitDepthLuma;
  i32 bitDepthChroma;

  u32 enableOutputCuInfo;

  u32 rdoLevel;
  /* low latency */
  i32 inputLineBufMode;
  i32 inputLineBufDepth;
  i32 amountPerLoopBack;

  u32 hashtype;
  u32 verbose;

  /* for smart */
  i32 smartModeEnable;
  i32 smartH264Qp;
  i32 smartHevcLumQp;
  i32 smartHevcChrQp;
  i32 smartH264LumDcTh;
  i32 smartH264CbDcTh;
  i32 smartH264CrDcTh;
  /* threshold for hevc cu8x8/16x16/32x32 */
  i32 smartHevcLumDcTh[3];
  i32 smartHevcChrDcTh[3];
  i32 smartHevcLumAcNumTh[3];
  i32 smartHevcChrAcNumTh[3];
  /* back ground */
  i32 smartMeanTh[4];
  /* foreground/background threashold: maximum foreground pixels in background block */
  i32 smartPixNumCntTh;

  /* constant chroma control */
  i32 constChromaEn;
  u32 constCb;
  u32 constCr;

  i32 sceneChange[MAX_SCENE_CHANGE];

  /* for tile*/
  i32 tiles_enabled_flag;
  i32 num_tile_columns;
  i32 num_tile_rows;
  i32 loop_filter_across_tiles_enabled_flag;  

  /*for skip frame encoding ctr*/
  i32 skip_frame_enabled_flag;
  i32 skip_frame_poc;
  
  /*stride*/
  u32 exp_of_input_alignment;
  u32 exp_of_ref_alignment;
  u32 exp_of_ref_ch_alignment;

  /* HDR10 */
  u32 hdr10_display_enable;
  u32 hdr10_dx0;
  u32 hdr10_dy0;
  u32 hdr10_dx1;
  u32 hdr10_dy1;
  u32 hdr10_dx2;
  u32 hdr10_dy2;
  u32 hdr10_wx;
  u32 hdr10_wy;
  u32 hdr10_maxluma;
  u32 hdr10_minluma;

  u32 hdr10_lightlevel_enable;
  u32 hdr10_maxlight;
  u32 hdr10_avglight;

  u32 vuiColorDescripPresentFlag;
  u32 vuiColorPrimaries;
  u32 vuiTransferCharacteristics;
  u32 vuiMatrixCoefficients;
  u32 vuiVideoFormat;
  u32 vuiVideoSignalTypePresentFlag;
  u32 vuiAspectRatioWidth;
  u32 vuiAspectRatioHeight;

  u32 RpsInSliceHeader;
  u32 P010RefEnable;
  u32 vui_timing_info_enable;

  u32 picOrderCntType;
  u32 log2MaxPicOrderCntLsb;
  u32 log2MaxFrameNum;

  u32 cutree_blkratio;
  i16 gmv[2][2];
  char *gmvFileName[2];
  char *halfDsInput;

  u32 parallelCoreNum;

  u32 dumpRegister;
  u32 rasterscan;

  u32 streamBufChain;
  u32 lookaheadDepth;
  u32 streamMultiSegmentMode;
  u32 streamMultiSegmentAmount;
   
  //add for transcode
  i32 enc_index;
  void * trans_handle;

  //add for new driver
#ifdef DRV_NEW_ARCH
  int priority;
  char * device;
  int mem_id;
#endif

#ifdef VCE_MEM_ERR_TEST
  int vce_memory_err_shadow;
  int vce_memory_err_cnt;
#endif

#ifdef VCE_EDMA_ERR_TEST
  int vce_edma_err_shadow;
  int vce_edma_err_cnt;
#endif

  u32 b_close_dummy_regs; /* for edma upload filter trans raw from rc to ep, no tcache, */
} HANTROH26xEncOptions;

#define NOCARE (-255)
#define COM_SHORT '0'

#define ARRAY_COUNT(a) (sizeof(a)/sizeof(a[0]))

typedef enum {
  TYPE_NOARG,
  TYPE_INT,
  TYPE_FLOAT,
  TYPE_STRING,
  TYPE_COLON2,
  TYPE_COLON4,
} ENUM_OPTION_TYPE;

typedef struct {
  char * name;
  char short_name;
  ENUM_OPTION_TYPE type;
  int min;
  int max;
  int offset;
  //int offset1;
  
  union {
    int64_t i64;
    float dbl;
    const char *str;
    struct {
        int32_t min;
        int32_t max;
    } colon2;
  } default_val;
  
  u32 flag;
  char * help;
} HantroParamsDef_t;


#endif /* AVCODEC_HANTRO_ENC_OPTIONS_H */

