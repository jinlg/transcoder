
#ifndef AVCODEC_HANTRO_H264DEC_H
#define AVCODEC_HANTRO_H264DEC_H

#include "libavutil/avassert.h"
#include "libavutil/opt.h"
#include "libavutil/imgutils.h"
#include "libavutil/pixdesc.h"
#include "libavutil/timer.h"
#include "libavutil/buffer.h"
#include "libavutil/intreadwrite.h"
#include "libavutil/thread.h"
#include "avcodec.h"
#include "cabac.h"
#include "error_resilience.h"
#include "h264_parse.h"
#include "h264_ps.h"
#include "h264_sei.h"
#include "h2645_parse.h"
#include "h264chroma.h"
#include "h264dsp.h"
#include "h264pred.h"
#include "h264qpel.h"
#include "internal.h"
#include "mpegutils.h"
#include "parser.h"
#include "qpeldsp.h"
#include "rectangle.h"
#include "videodsp.h"
#include "h264dec.h"

#include "h264decapi.h"
#include "h264decapi_e.h"
#include "dwl.h"
#include "dwlthread.h"

#include "h264hwd_container.h"
#include "hantro_dec_tb_defs.h"
#include "regdrv.h"
#include "deccfg.h"

#endif /* AVCODEC_HANTRO_H264DEC_H */


