#ifndef AVCODEC_HANTRO_ENC_H
#define AVCODEC_HANTRO_ENC_H

#include "dectypes.h"
#include "libavutil/hwcontext_hantro.h"

#ifndef NEXT_MULTIPLE
#define NEXT_MULTIPLE(value, n) (((value) + (n) - 1) & ~((n) - 1))
#endif

int hantro_receive_pic(AVCodecContext *avctx, const AVFrame *pict);
//int hantro_send_pic(AVCodecContext *avctx, AVFrame *pict, int poc_need, HANTRO_ENC_IN_ADDR_t *pAddrs);
void hantro_consume_stored_pic(AVCodecContext *avctx, int consume_poc);
void hantro_enc_close(HANTROH26xEncContext *ctx);

av_cold int hantro_encode_init(AVCodecContext *avctx);
av_cold int hantro_encode_uninit(AVCodecContext *avctx);

av_cold int hantro_encode_open(VCEncInst *hantro_encoder, struct test_bench *tb, HANTROH26xEncOptions *options);
av_cold int hantro_encode_start(AVCodecContext *avctx, AVPacket *pkt, int *streamSize);
av_cold int hantro_encode_encode(AVCodecContext *avctx, AVPacket *pkt,
                                    const AVFrame *pict, int *streamSize);
av_cold int hantro_encode_flush(AVCodecContext *avctx, int *streamSize, 
                                 AVPacket *pkt,int *got_packet);
av_cold int hantro_encode_end(AVCodecContext *avctx, int *streamSize, 
                                 AVPacket *pkt,int *got_packet);

int hantro_trans_flush_set(AVCodecContext *avctx);
int hantro_packet_rcv(AVCodecContext *avctx, AVPacket *pkt);

//int Transcode_Rcv_Pic(AVCodecContext *avctx, const AVFrame *pict);
//int Transcode_Send_Pic(AVCodecContext *avctx, int poc_need, HANTRO_ENC_IN_ADDR_t *pAddrs, int64_t *pts);

#ifdef VCE_MEM_ERR_TEST
int VceMemoryCheck(HANTROH26xEncOptions *opts);
#endif

#ifdef VCE_EDMA_ERR_TEST
int VceEDMAErrCheck(HANTROH26xEncOptions *opts);
#endif

#endif /* AVCODEC_HANTRO_ENC_H */

