/*------------------------------------------------------------------------------
--                                                                                                                               --
--       This software is confidential and proprietary and may be used                                   --
--        only as expressly authorized by a licensing agreement from                                     --
--                                                                                                                               --
--                            Verisilicon.                                                                                    --
--                                                                                                                               --
--                   (C) COPYRIGHT 2014 VERISILICON                                                            --
--                            ALL RIGHTS RESERVED                                                                    --
--                                                                                                                               --
--                 The entire notice above must be reproduced                                                 --
--                  on all copies and should not be removed.                                                    --
--                                                                                                                               --
--------------------------------------------------------------------------------
--
--  Abstract : Cache Wrapper Layer for OS services
--
------------------------------------------------------------------------------*/

#ifndef __CWL_H__
#define __CWL_H__

#ifdef __cplusplus
extern "C"
{
#endif
#include "dwl_l2_base_type.h"
#include <linux/ioctl.h>    /* needed for the _IOW etc stuff used later */
#include "dwl.h"



/* ASSERT */
#ifndef NDEBUG
#define ASSERT(x) assert(x)
#else
#define ASSERT(x)
#endif

/*---Abstract : Cache Wrapper Layer for OS services----*/

extern FILE *fCwl;

/* Macro for debug printing */
#undef PTRACE
#ifdef FB_SYSLOG_ENABLE
#include "syslog_sink.h"
#define DWL_L2_DEBUG(fmt, ...) FB_SYSLOG(dec_dwl,SYSLOG_SINK_LEV_DEBUG_SW,"%s(%d): " fmt,\
                                    __FUNCTION__, __LINE__, ## __VA_ARGS__)
//#define DWL_L2_DEBUG(fmt, ...) FB_SYSLOG(dec_dwl,SYSLOG_SINK_LEV_ERROR,"%s(%d): " fmt,\
//                                                                        __FUNCTION__, __LINE__, ## __VA_ARGS__)
#define DWL_L2_ERRPRINT(fmt, ...) FB_SYSLOG(dec_dwl,SYSLOG_SINK_LEV_ERROR,"%s(%d): " fmt,\
                                    __FUNCTION__, __LINE__, ## __VA_ARGS__)
#define DWL_L2_REG_DEBUG(fmt, ...) FB_SYSLOG(dec_dwl,SYSLOG_SINK_LEV_DEBUG_S_IP,"%s(%d): " fmt,\
                                    __FUNCTION__, __LINE__, ## __VA_ARGS__)
#else
#ifdef _DWL_DEBUG
#   include <stdio.h>
#   define PTRACE printf
#else
#   define PTRACE(...)  /* no trace */
#endif
#endif

/* the cache device driver node */
#ifndef CACHE_MODULE_PATH
#define CACHE_MODULE_PATH             "/tmp/dev/hantro_cache"
#endif

enum reg_amount
{
 CACHE_RD_SWREG_AMOUNT = 6+4*8,
 CACHE_WR_SWREG_AMOUNT = 5+5*13,
 CACHE_SWREG_MAX = 200,
 L2_SWREG_TOTAL = 0x400
};

/* Flags for read-only, write-only and read-write */
#define RO 1
#define WO 2
#define RW 3


/* HW Register field names */
typedef enum
{

#include "dwl_l2_registernum.h"

  CacheRegisterAmount

} regName;



/* HW Register field descriptions */
typedef struct
{
  u32 name;               /* Register name and index  */
  i32 base;               /* Register base address  */
  u32 mask;               /* Bitmask for this field */
  i32 lsb;                /* LSB for this field [31..0] */
  i32 trace;              /* Enable/disable writing in swreg_params.trc */
  i32 rw;                 /* 1=Read-only 2=Write-only 3=Read-Write */
  char *description;      /* Field description */
} regField_s;

#define H2REG(name, base, mask, lsb, trace, rw, desc) \
        {name, base, mask, lsb, trace, rw, desc}
/*-----------------------*/


#define CACHE_OK  0
#define CACHE_TIMEOUT 1
#define CACHE_ERROR -1
#define CACHE_HW_FETAL_RECOVERY -2
#define CACHE_HW_FETAL_UNRECOVERY -3

typedef enum
{
 CACHE_RD,
 CACHE_WR,
 CACHE_BI
}cache_dir;

typedef enum
{
 ENCODER_VC8000E,
 DECODER_VC8000D_0,
 DECODER_VC8000D_1,
 DECODER_G1_0,
 DECODER_G1_1,
 DECODER_G2_0,
 DECODER_G2_1
}client_type;

enum addr_type
{
 BaseInLum,
 BaseInCb,
 BaseRefLum1,
 BaseRefChr1,
 BaseRefLum0,
 BaseRefChr0,
 BaseRef4nLum1,
 BaseRef4nLum0,
 BottomBaseRefLum1,
 BottomBaseRefChr1,
 BaseRefLum2,
 BottomBaseRefLum2,
 BaseRefChr2,
 BottomBaseRefChr2,
 BaseRefLum3,
 BottomBaseRefLum3,
 BaseRefChr3,
 BottomBaseRefChr3,
 BaseRef4nLum2,
 BaseRef4nLum3,
 BottomBaseRef4nLum1,
 BottomBaseRef4nLum2,
 BottomBaseRef4nLum3,
 BaseStream
};


typedef struct
{
 /*both for cache read and write*/
 u32 start_addr;//equal to physical addr>>4 and the start_addr<<4 must be aligned to 1<< LOG2_ALIGNMENT which is fixed in HW
 u32 trace_start_addr;//start addr for simulation trace file
 u32 base_offset;
 /*only for cache read*/
 u32 no_chroma;
 u32 cache_bypass;
 u32 shaper_bypass;
 u32 cache_enable;
 u32 shaper_enable;
 u32 first_tile;
 u32 prefetch_enable;
 u32 prefetch_threshold;
 u32 shift_h;
 u32 range_h;
 u32 cache_all;
 u32 end_addr;
 u32 trace_end_addr;//end addr for simulation trace file
 /*only for cache write*/
 u32 line_size;//the valid width of the input frame/reference frame
 u32 line_stride;//equal to line_size aligment to 1<< LOG2_ALIGNMENT then >>4
 u32 line_cnt;//the valid height of the input frame/reference frame
 u32 stripe_e;
 u32 pad_e;
 u32 block_e;
 u32 rfc_e;
 u32 max_h;
 u32 ln_cnt_start;
 u32 ln_cnt_mid;
 u32 ln_cnt_end;
 u32 ln_cnt_step;
 u32 tile_id;
 u32 tile_num;
 u32 tile_by_tile;
 u32 width;
 u32 height;
 u32 num_tile_cols;
 u32 num_tile_rows;
 u32 tile_size[2048];
 FILE* file_fid;
 u32 hw_dec_pic_count;
 u32 stream_buffer_id;
 u32 hw_id;
 u32 pp_buffer;
 u32 trace_start_pic;
} CWLChannelConf_t;


i32 DWLL2EnableCacheChannel(const void *instance, u32 core_id, void **dev, u32 *channel, CWLChannelConf_t *cfg,client_type client,cache_dir dir);
i32 DWLL2EnableCacheWork(const void *instance, u32 core_id, void *dev);
i32 DWLL2DisableCacheChannel(const void *instance, u32 core_id, void *dev,u32 channel,cache_dir dir);
i32 DWLL2SetCacheExpAddr(const void *instance, u32 core_id, void *dev,u32 start_addr,u32 end_addr);
i32 DWLL2VC8000DL2GetCacheTimeoutSt(const void *instance, u32 core_id, void *dev);
i32 DWLL2DisableCacheChannelALL(const void *instance, u32 core_id, void **dev,cache_dir dir);
i32 DWLL2printInfo(const void *instance, u32 core_id, void *dev, CWLChannelConf_t *cfg);




/* Return values */

#define DWL_HW_WAIT_OK              DWL_OK
#define DWL_HW_WAIT_ERROR           DWL_ERROR
#define DWL_HW_WAIT_TIMEOUT         1

#define CACHE_ABORTED               2
#define CACHE_ERROR_RE              4
#define CACHE_ERROR_UNRE            8

 typedef struct
{
 i32 core_id;
    u32 RegBaseOffset;  /* IO mem base */
 u32 l2regMirror[CACHE_SWREG_MAX];
} dwl_l2_regMapping;


/* DWL internal information for Linux */
typedef struct
{
    u32 clientType; /*indicate which client use*/
    int fd_mem;              /* /dev/mem */
    int fd_cache;            /* /dev/hantro_cache */

    dwl_l2_regMapping reg[2];
    u32 core_num[2];  /*indicate how many cores in HW*/
    u32 channel_num[2]; /*indicate how many channels supported by HW*/
    u32 valid_ch_num[2];/*indicate how many channels valid set by user*/
    CWLChannelConf_t *cfg[2];
    u32 cache_all; //indiate cache_all feature enable
    u32 exception_list_amount;//indicate how many exception addrs have been added
    u32 exception_addr_max;//indicate the max num of exception addrs supported by HW
    u32 reference_count;//indicate is any instance using CWL

} dwl_l2_cache_t;

 /*------------------------------------------------------------------------------
      Function defination
  ------------------------------------------------------------------------------*/
void *dwl_l2_init(const void *instance, u32 core_id, client_type client);
i32 dwl_l2_release(const void *instance, u32 core_id, const void *inst);
int dwl_l2_write_reg(const void *instance, u32 core_id, const void *inst, u32 offset, u32 val);
void dwl_l2_enable_cache(const void *instance, u32 core_id, const void *inst,cache_dir dir);
void dwl_l2_disable_cache(const void *instance, u32 core_id, const void *inst,cache_dir dir);
u32 dwl_l2_read_reg(const void *instance, u32 core_id, const void *inst, u32 offset);
i32 dwl_l2_reserve_hw(const void *instance, u32 core_id, const void *inst,client_type client,cache_dir dir);
void dwl_l2_release_hw(const void *instance, u32 core_id, const void *inst,cache_dir dir);
i32 dwl_l2_wait_channel_aborted(const void *instance, u32 core_id, const void *inst,u32* status_register,cache_dir dir);
void dwl_l2_set_register_value(const void *instance, u32 core_id, void *reg,u32 *regMirror, regName name, u32 value,u32 write_asic);
u32 dwl_l2_get_register_value(const void *instance, u32 core_id, const void *reg, u32 *regMirror, regName name,u32 read_asic);
void dwl_l2_register_dump_after(const void *instance, u32 core_id, dwl_l2_cache_t *l2_cache,cache_dir dir);
void dwl_l2_print_info(const void *instance, u32 core_id, dwl_l2_cache_t *l2_cache,cache_dir dir);


/*
 * Macros to help debugging
 */

#undef PDEBUG   /* undef it, just in case */
#ifdef CACHE_DEBUG
#  ifdef __KERNEL__
    /* This one if debugging is on, and kernel space */
    #define PDEBUG printk
#  else
    /* This one for user space */
#    define PDEBUG(fmt, args...) printf(__FILE__ ":%d: " fmt, __LINE__ , ## args)
#  endif
#else
#  define PDEBUG(fmt, args...)  /* not debugging: nothing */
#endif

#define PCI_BUS

/*Define Cache&Shaper Offset from common base*/
#define SHAPER_OFFSET                    (0x8<<2)
#define CACHE_ONLY_OFFSET                (0x8<<2)
#define CACHE_WITH_SHAPER_OFFSET         (0x80<<2)

/*IOCTL define*/

/* Use 'k' as magic number */
#define CACHE_IOC_MAGIC  'c'
/*
 * S means "Set" through a ptr,
 * T means "Tell" directly with the argument value
 * G means "Get": reply by setting through a pointer
 * Q means "Query": response is on the return value
 * X means "eXchange": G and S atomically
 * H means "sHift": T and Q atomically
 */
 /*
  * #define CACHE_IOCGBUFBUSADDRESS _IOR(CACHE_IOC_MAGIC,  1, unsigned long *)
  * #define CACHE_IOCGBUFSIZE       _IOR(CACHE_IOC_MAGIC,  2, unsigned int *)
  */
#define CACHE_IOCGHWOFFSET      _IOR(CACHE_IOC_MAGIC,  3, unsigned long *)
#define CACHE_IOCGHWIOSIZE      _IOR(CACHE_IOC_MAGIC,  4, unsigned int *)

#define CACHE_IOCHARDRESET      _IO(CACHE_IOC_MAGIC, 8)   /* debugging tool */

#define CACHE_IOCH_HW_RESERVE   _IOR(CACHE_IOC_MAGIC, 11,unsigned int *)
#define CACHE_IOCH_HW_RELEASE   _IOR(CACHE_IOC_MAGIC, 12,unsigned int *)
#define CACHE_IOCG_CORE_NUM      _IOR(CACHE_IOC_MAGIC, 13,unsigned int *)

#define CACHE_IOCG_ABORT_WAIT     _IOR(CACHE_IOC_MAGIC, 14, unsigned int *)
#define CACHE_IOC_MAXNR 30

typedef enum
{
 VC8000E,
 VC8000D_0,
 VC8000D_1
}cache_client_type;

typedef enum
{
 DIR_RD,
 DIR_WR,
 DIR_BI
}driver_cache_dir;

typedef struct
{
  cache_client_type client;
  unsigned long base_addr;
  u32 iosize;
  int irq;
  driver_cache_dir dir;
}CORE_CONFIG;



#ifdef __cplusplus
}
#endif
#endif
