/*------------------------------------------------------------------------------
--       Copyright (c) 2015-2017, VeriSilicon Inc. All rights reserved        --
--         Copyright (c) 2011-2014, Google Inc. All rights reserved.          --
--         Copyright (c) 2007-2010, Hantro OY. All rights reserved.           --
--                                                                            --
-- This software is confidential and proprietary and may be used only as      --
--   expressly authorized by VeriSilicon in a written licensing agreement.    --
--                                                                            --
--         This entire notice must be reproduced on all copies                --
--                       and may not be removed.                              --
--                                                                            --
--------------------------------------------------------------------------------
-- Redistribution and use in source and binary forms, with or without         --
-- modification, are permitted provided that the following conditions are met:--
--   * Redistributions of source code must retain the above copyright notice, --
--       this list of conditions and the following disclaimer.                --
--   * Redistributions in binary form must reproduce the above copyright      --
--       notice, this list of conditions and the following disclaimer in the  --
--       documentation and/or other materials provided with the distribution. --
--   * Neither the names of Google nor the names of its contributors may be   --
--       used to endorse or promote products derived from this software       --
--       without specific prior written permission.                           --
--------------------------------------------------------------------------------
-- THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"--
-- AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE  --
-- IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE --
-- ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE  --
-- LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR        --
-- CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF       --
-- SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS   --
-- INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN    --
-- CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)    --
-- ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE --
-- POSSIBILITY OF SUCH DAMAGE.                                                --
--------------------------------------------------------------------------------
------------------------------------------------------------------------------*/

#include "basetype.h"
#include "dwl_defs.h"
#include "dwl.h"
#include "dwl_activity_trace.h"
#ifdef NEW_MEM_ALLOC
#include "transcoder.h"
#endif
#include <assert.h>
#include <semaphore.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/ioctl.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <sys/timeb.h>
#include <sys/types.h>
#include "fb_performance.h"
#include "trans_reg_rw_api.h"

#undef DWL_DEBUG
#ifdef FB_SYSLOG_ENABLE
#include "syslog_sink.h"
#define DWL_DEBUG(fmt, ...) FB_SYSLOG(dec_dwl,SYSLOG_SINK_LEV_DEBUG_SW,"%s(%d): " fmt,\
                                    __FUNCTION__, __LINE__, ## __VA_ARGS__)
#define DWL_ERRPRINT(fmt, ...) FB_SYSLOG(dec_dwl,SYSLOG_SINK_LEV_ERROR,"%s(%d): " fmt,\
                                    __FUNCTION__, __LINE__, ## __VA_ARGS__)
#define DWL_REG_DEBUG(fmt, ...) FB_SYSLOG(dec_dwl,SYSLOG_SINK_LEV_DEBUG_M_IP,"%s(%d): " fmt,\
                                    __FUNCTION__, __LINE__, ## __VA_ARGS__)
#define DWL_S_REG_DEBUG(fmt, ...) FB_SYSLOG(dec_dwl,SYSLOG_SINK_LEV_DEBUG_S_IP,"%s(%d): " fmt,\
                                      __FUNCTION__, __LINE__, ## __VA_ARGS__)

#define DWL_INFO(fmt, ...) FB_SYSLOG(dec_dwl,SYSLOG_SINK_LEV_INFO, fmt, ## __VA_ARGS__)
#else

#ifdef _DWL_DEBUG
#define DWL_DEBUG(fmt, args...) \
  printf(__FILE__ ":%d:%s() " fmt, __LINE__, __func__, ##args)
#else
#define DWL_DEBUG(fmt, args...) \
  do {                          \
  } while (0); /* not debugging: nothing */
#endif

#endif

#if 0
#undef DEC_MODULE_PATH
#ifdef INDEPENDENT_2S
#ifdef USE_S0
#define DEC_MODULE_PATH  "/tmp/dev/transcoder_codec_0"
#else
#define DEC_MODULE_PATH  "/tmp/dev/transcoder_codec_1"
#endif
#else
#define DEC_MODULE_PATH  "/tmp/dev/transcoder_codec"
#endif
#endif


#define HANTRO_VC8000D_REGS             393 /*VC8000D total regs*/
#define HANTRO_VC8000D_FIRST_REG        0
#define HANTRO_VC8000D_LAST_REG         HANTRO_VC8000D_REGS-1

#define HANTRODECPP_REG_START 0x400
#define HANTRODEC_REG_START 0x4

#define HANTRODECPP_FUSE_CFG_G1 99
#define HANTRODECPP_FUSE_CFG_G2 99
#define HANTRODECPP_FUSE_CFG 61
#define HANTRODEC_FUSE_CFG 57

#define DWL_DECODER_INT \
  ((DWLReadReg(dec_dwl, HANTRODEC_REG_START) >> 11) & 0xFFU)
#define DWL_PP_INT      ((DWLReadReg(dec_dwl, HANTRODECPP_REG_START) >> 11) & 0xFFU)

#define DEC_IRQ_ABORT (1 << 11)
#define DEC_IRQ_RDY (1 << 12)
#define DEC_IRQ_BUS (1 << 13)
#define DEC_IRQ_BUFFER (1 << 14)
#define DEC_IRQ_ASO (1 << 15)
#define DEC_IRQ_ERROR (1 << 16)
#define DEC_IRQ_SLICE (1 << 17)
#define DEC_IRQ_TIMEOUT (1 << 18)
#define DEC_IRQ_LAST_SLICE_INT (1 << 19)
#define DEC_IRQ_NO_SLICE_INT (1 << 20)
#define DEC_IRQ_EXT_TIMEOUT (1 << 21)

#define DEC_HW_IRQ_BUFFER 0x08
#define DEC_HW_IRQ_EXT_TIMEOUT 0x400

#define PP_IRQ_RDY             (1 << 12)
#define PP_IRQ_BUS             (1 << 13)

#define DWL_HW_ENABLE_BIT 0x000001 /* 0th bit */
#define gcregAHBDECReadConfig 			0x800
#define gcregAHBDECWriteConfig 			0x880
#define gcregAHBDECReadBufferBase		0x900
#define gcregAHBDECReadCacheBase		0x980
#define gcregAHBDECWriteBufferBase		0xA00
#define gcregAHBDECWriteCacheBase		0xA80
#define gcregAHBDECControl				0xB00
#define gcregAHBDECIntrAcknowledge		0xB04
#define gcregAHBDECIntrEnbl				0xB08
#define gcregAHBDECControlEx			0xB68
#define gcregAHBDECReadExConfig		0xC00
#define gcregAHBDECWriteExConfig		0xD00
#define gcregAHBDECReadBufferEnd		0xE00
#define gcregAHBDECWriteBufferEnd		0xE80
#define gcregAHBDECControlEx2			0x13BC
#define gcregAHBDECStatus 				0x1708
#define DEC_TILE_TABLE		(16*1024)

#define DEC400_MAX_CFG_REGS	256

//other ip id
#define L2CACHE_OFFSET		0
#define DEC400_OFFSET		1
#define TCACHE_0FFSET		2



#ifdef _DWL_HW_PERFORMANCE
/* signal that decoder/pp is enabled */
void DwlDecoderEnable(void);
#endif

typedef struct
{
 i32 core_id; //physical core id
}regMapping;



/* wrapper information */
struct HANTRODWL {
#ifdef FB_SYSLOG_ENABLE
  LOG_INFO_HEADER log_header;
  char module_name[20];
#endif
  u32 client_type;
  int priority;
  int mem_id;
  int fd;          /* decoder device file */
  int fd_memalloc; /* linear memory allocator */
  u32 num_cores;
  u32 b_mc; /* flag to indicate MC mode status */ /*for H264 one slice only*/
  int mc_pending_count;
  u32 reg_size;         /* IO mem size */
  addr_t free_lin_mem;     /* Start address of free linear memory */
  addr_t free_ref_frm_mem; /* Start address of free reference frame memory */
  int semid;
  struct MCListenerThreadParams *sync_params;
  struct ActivityTrace activity;
  u32 b_ppreserved;
  u8 dec400_write_channel_en[MAX_ASIC_CORES][32];
  u8 dec400_read_channel_en[MAX_ASIC_CORES][32];
  REG_DESC_t dec400_cfg_shadow[MAX_ASIC_CORES][DEC400_MAX_CFG_REGS];
  u32 dec400_cfg_shadow_valid_num[MAX_ASIC_CORES];
  pthread_mutex_t shadow_mutex;
  PpUnitIntConfig ppu_cfg[4];
  u32 tile_id;
  u32 num_tiles;
  u32 shaper_enable[MAX_ASIC_CORES];
  u16 *tiles;
  pthread_mutex_t shaper_mutex;
  regMapping *reg_all_cores;
  void *edma_handle;
  void *tcache_handle;
  char *dec_dev_name;

#ifdef ERROR_TEST_DEC_MEM_ALLOC
  int mem_err_test;
  int mem_err_count;
#endif

  DECLARE_PERFORMANCE_STATIC(dechw_c0);
  DECLARE_PERFORMANCE_STATIC(dechw_c1);
  DECLARE_PERFORMANCE_STATIC(dechw_c2);
  DECLARE_PERFORMANCE_STATIC(dechw_c3);
  DECLARE_PERFORMANCE_STATIC(dechw);

};

struct MCListenerThreadParams {
  int fd;
  int b_stopped;
  unsigned int n_dec_cores;
  unsigned int n_ppcores;
  sem_t sc_dec_rdy_sem[MAX_ASIC_CORES];
  sem_t sc_pp_rdy_sem[MAX_ASIC_CORES];
  DWLIRQCallbackFn *callback[MAX_ASIC_CORES];
  void *callback_arg[MAX_ASIC_CORES];
  regMapping *reg_all_cores;
  struct HANTRODWL * dec_dwl;
};

#if 0
u32 *DWLMapRegisters(int mem_dev, unsigned long base, unsigned int reg_size,
                     u32 write);
void DWLUnmapRegisters(const void *io, unsigned int reg_size);
#endif
void DWLPullReg(const void *instance, i32 core_id);
int DwlMapAsicRegisters(void * dev);
int DwlUnMapAsicRegisters(void * dev);

