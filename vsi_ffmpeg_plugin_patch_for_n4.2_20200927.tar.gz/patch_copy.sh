cp vpe_src/libavcodec/* ffmpeg/libavcodec
cp vpe_src/libavfilter/* ffmpeg/libavfilter
cp vpe_src/libavutil/* ffmpeg/libavutil
cp vpe_src/* ffmpeg
cp vpe_src/doc/examples/* ffmpeg/doc/examples
