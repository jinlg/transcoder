git apply patch_for_n4.2 on n4.2
./patch_copy.sh
./configure --enable-hantro ......
make clean
make all examples
